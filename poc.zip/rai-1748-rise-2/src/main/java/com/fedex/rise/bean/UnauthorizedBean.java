package com.fedex.rise.bean;

import com.fedex.rise.annotation.JsfController;

@JsfController(path = "/unauthorized", page = "/pages/jsp/unauthorized.jsp", value = "unauthorizedBean")
public class UnauthorizedBean {

}
