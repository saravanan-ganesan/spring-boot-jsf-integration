package com.fedex.rise.xref;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class SvcLvlDescCodes {
    //  Contains all the service Level Codes and their translation
    public final static HashMap svcLvlCodes = new LinkedHashMap();   
    
    static {
        svcLvlCodes.put("17", "ED");
        svcLvlCodes.put("18", "ID");
        svcLvlCodes.put("84", "DF");
    }
    
    public static String lookupCd(String aCode) {
        return (String)svcLvlCodes.get(aCode);
    }
   
    /**
     * Get all service levels
     * @return HashMap of service levels cd and descriptions
     */
    public static HashMap getAll() {
        return svcLvlCodes;
    }
}
