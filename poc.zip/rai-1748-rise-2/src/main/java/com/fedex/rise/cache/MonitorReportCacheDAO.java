package com.fedex.rise.cache;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Calendar;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.MonitorReportDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.MonitorReportVO;

/**
 * Cache MonitorReportVO data from the Monitor Report table. Also, update the number of hits
 * in the Monitor Report table.
 * 
 * @author be379961
 *
 */
public class MonitorReportCacheDAO {
	private static Logger logger = LogManager.getLogger(MonitorReportCacheDAO.class);
    
    private static HashMap _cache = new HashMap();
    private static TimedCache _timedCache = new TimedCache();
    
    static {
        populateCache();
        updateMonitorReport();
    }

    
    private MonitorReportCacheDAO() {
    }
    
    /**
     *	Read data from the Monitor Report table and store in cache.
     */
	private static void populateCache() {
        logger.info("Loading Monitor Report Cache");
        HashMap hm = new HashMap();
        MonitorReportDAO monitorReport = new MonitorReportDAO();
		try {
			Calendar workDt = Calendar.getInstance();
			List monitorReportList = monitorReport.getMonitorReportList(workDt.getTime());
			if (monitorReportList == null){
				logger.warn("monitorReportList is null ");
			}else{
				Iterator monitorReportIterator = monitorReportList.iterator();
				while (monitorReportIterator.hasNext()) {
					MonitorReportVO monitorReportVO = (MonitorReportVO)monitorReportIterator.next();
					hm.put(monitorReportVO.get_emp_nbr(), monitorReportVO);
				}
			}
            _cache = hm;
		} catch (SQLException sqle){
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
				+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
		} catch (ServiceLocatorException sle) {
		    logger.error("Service Locator Excetion:", sle);
        }
	}
	
	/**
     *	Update the Monitor Report table from the cache.
     */
	private static void updateMonitorReport() {
        logger.info("update Monitor Report Number of Hits");
		try {
			MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
			MonitorReportVO monitorReportVO;

			Iterator iterator = _cache.keySet().iterator();     
			while (iterator.hasNext()) {
				String key = (String) iterator.next();    
				monitorReportVO = (MonitorReportVO)_cache.get(key);  
				monitorReportDAO.setNumberHits(monitorReportVO);
			}
		} catch (SQLException sqle){
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
				+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
		} catch (ServiceLocatorException sle) {
		    logger.error("Service Locator Excetion:", sle);
        }
	}
	
	/**
     * 	Get data from the Monitor Report table from the cache.
     *	@param key which is the employee number
     *  @return MonitorReportVO
     */
	public static MonitorReportVO get(Object key) {
		MonitorReportVO monitorReportVO = (MonitorReportVO)_cache.get(key);
		return monitorReportVO;
	}
	
	/**
     * 	Determine if key (employee number) exists in the cache.
     *	@param key which is the employee number
     *  @return true if data for this employee exists in cache.
     */
	public static boolean containsKey(Object key) {
        if (_cache.size()==0) { populateCache(); };
        return _cache.containsKey(key);
	}
	
	/**
     *	Update the number of hits an employee has made to the cache. Periodically 
     *	update the Report Monitor table for the number of hits. 
     */
	public static boolean updateHits(Object key) {
		boolean success = false;
		// Get the work date, which is today.
        Calendar workDate = Calendar.getInstance();
        // Get the MonitorReportVO for this employee from cache.
		MonitorReportVO monitorReportVO = (MonitorReportVO)_cache.get(key);
		
		if (monitorReportVO == null){
			monitorReportVO = new MonitorReportVO();
			String employeeNbr = (String)(key);
			monitorReportVO.set_emp_nbr(employeeNbr);
			monitorReportVO.set_num_hits(1);
			monitorReportVO.set_work_dt(workDate);
		}else{
			int num_hits = monitorReportVO.get_num_hits() + 1;
			monitorReportVO.set_num_hits(num_hits);
		}
		_cache.put(key, monitorReportVO);
		if (_timedCache.isTimeToLoad()) { updateMonitorReport(); };
        return success;
	}
       
}
