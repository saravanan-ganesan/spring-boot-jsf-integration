package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.vo.AccountGroupVO;
import com.fedex.rise.vo.LaneVO;

import javax.faces.model.SelectItem;

/**
 * Backing Bean class for the Search Pages.
 * @author dr670329
 *
 */
public class SearchBeanCalendar implements Serializable {
	/** serializing version */
    private static final long serialVersionUID = 1L;
    /** logger */
    private static final Log log = LogFactory.getLog(SearchBeanCalendar.class);
    
    /** delegate to get shipper data */
    private ShipperDelegate shipperDelegate = new ShipperDelegate();
	private Date _fromDate = null;
	private Date _toDate = null;
	private String _selectRadio =  "one";
	private Calendar _calendar = Calendar.getInstance();
	private String _thisYear = String.valueOf(_calendar.get(Calendar.YEAR));
	private String _twoYearsAgo = String.valueOf(_calendar.get(Calendar.YEAR)-2);
	private String _lastYear = String.valueOf(_calendar.get(Calendar.YEAR)-1);
	private String _selectYear =  new String(_thisYear);
	private String _selectMonth =  new String("Jan");
	private String _groupNbr = new String();
	private String _groupName = new String();
    private List _allGroupNames = new ArrayList();
    private List _laneList = new ArrayList();
    private String _laneNbrStr = new String();
    private String _origCntryCd = new String();
    private String _destCntryCd = new String();
	
    private static SelectItem[] selectRadioItems = {
    	new SelectItem("one","To and From Calendars"),
    	new SelectItem("two", "Month and Year"),
    	new SelectItem("three", "Year")
    };
    
    private static SelectItem[] selectMonthItems = {
    	new SelectItem("0","January"),
    	new SelectItem("1", "February"),
    	new SelectItem("2","March"),
    	new SelectItem("3", "April"),
    	new SelectItem("4","May"),
    	new SelectItem("5", "June"),
    	new SelectItem("6","July"),
    	new SelectItem("7", "August"),
    	new SelectItem("8","September"),
    	new SelectItem("9", "October"),
    	new SelectItem("10","November"),
    	new SelectItem("11","December")
    };
     
    private SelectItem[] selectYearItems = {
        new SelectItem(_twoYearsAgo, _twoYearsAgo),
    	new SelectItem(_lastYear, _lastYear),
    	new SelectItem(_thisYear, _thisYear)

    };
    // =========================================================================
    // Public Methods
    // =========================================================================
    
    /**
     * @return selectRadioItems
     */
    public SelectItem[] getSelectRadioItems() {
    	return selectRadioItems;
    }
    /**
     * 
     * @return selectMonthItems
     */
    public SelectItem[] getSelectMonthItems() {
    	return selectMonthItems;
    }
    /**
     * 
     * @return selectYearItems
     */
    public SelectItem[] getSelectYearItems() {
    	return selectYearItems;
    }
    
    /**
     * @return the _fromDate
     */
    public Date getFromDate() {
    	// Set the default date.
    	if (_fromDate == null){
    		_fromDate = new Date();
    		Calendar startDate = Calendar.getInstance();
    		int day = 1;
    		int month = startDate.get(Calendar.MONTH);
    		int year = startDate.get(Calendar.YEAR);
    		if (month == Calendar.JANUARY){
    			month = Calendar.DECEMBER;
    			year--;
    		} else {
    			month--;
    		}
    		startDate.set(year, month, day);
    		_fromDate = startDate.getTime();
    	}
        return _fromDate;
    }


    /**
     * @param fromDate the _fromDate to set
     */
    public void setFromDate(Date fromDate) {
    	// Don't let from date to go back more than 2 years.
    	if (fromDate != null){
    		Calendar oldestStartDate = Calendar.getInstance();
    		int day = 1;
    		int month = Calendar.JANUARY;
    		int year = oldestStartDate.get(Calendar.YEAR) - 2;
    		
    		oldestStartDate.set(year, month, day);
    		if (fromDate.before(oldestStartDate.getTime())) {
    			fromDate = oldestStartDate.getTime();
    		}
    	}
        _fromDate = fromDate;
    }
    
    /**
     * @return the _toDate
     */
    public Date getToDate() {
    	if (_toDate == null){
    		_toDate = new Date();
    	}
        return _toDate;
    }

    /**
     * @param toDate the _toDate to set
     */
    public void setToDate(Date toDate) {
        _toDate = toDate;
    }
    
    /**
     * @return the _selectRadio
     */
    public String getSelectRadio() {
    	if (_selectRadio == null){
    		_selectRadio =  "one";
    	}
        return _selectRadio;
    }
    
    /**
     * @param selectRadio the _selectRadio to set
     */
    public void setSelectRadio(String selectRadio) {
    	_selectRadio = selectRadio;
    }
    
    /**
     * @return the _selectRadio
     */
    public boolean getSelectRadioOne() {
    	return _selectRadio.equalsIgnoreCase("one");
    }
    
    /**
     * @return the _selectRadio
     */
    public boolean getSelectRadioTwo() {
    	return _selectRadio.equalsIgnoreCase("two");
    }
    
    /**
     * @return the _selectRadio
     */
    public boolean getSelectRadioThree() {
    	return _selectRadio.equalsIgnoreCase("three");
    }
    
    /**
     * @return the _selectYear
     */
    public String getYear() {
        return _selectYear;
    }
    
    /**
     * @param selectYear the selectYear to set
     */
    public void setYear(String selectYear) {
    	_selectYear = selectYear;
    	
    	// Set the from date.
		int year = Integer.parseInt(selectYear);
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, Calendar.JANUARY, 1);
		setFromDate(fromDate.getTime());
		
		// Set the to date.
		Calendar toDate = Calendar.getInstance();
		if (year == toDate.get(Calendar.YEAR)){
			setToDate(new Date());
		}else{
			toDate.set(year, Calendar.DECEMBER, 31);
			setToDate(toDate.getTime());
		}
    }
    
    /**
     * @return the _selectYear
     */
    public String getSelectYear() {
        return _selectYear;
    }
    
    /**
     * @param selectYear the selectYear to set
     */
    public void setSelectYear(String selectYear) {
    	_selectYear = selectYear;
    	
    	// Set the from date.
    	int month = Integer.parseInt(getSelectMonth());
		int year = Integer.parseInt(selectYear);
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, month, 1);
		setFromDate(fromDate.getTime());
		
		// Set the to date.
		int lastDayMonth = fromDate.getActualMaximum(Calendar.DAY_OF_MONTH); 
		Calendar toDate = Calendar.getInstance();
		toDate.set(year, month, lastDayMonth);
		setToDate(toDate.getTime());
    }
    
    /**
     * @return the selectMonth
     */
    public String getSelectMonth() {
    	if (_selectMonth == null){
    		_selectMonth =  "0";
    	}
        return _selectMonth;
    }
    
    /**
     * @param selectMonth the _selectMonth to set
     */
    public void setSelectMonth(String selectMonth) {
    	_selectMonth = selectMonth;
    	
    	// Set the from date.
    	int month = Integer.parseInt(selectMonth);
		int year = Integer.parseInt(getSelectYear());
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, month, 1);
		setFromDate(fromDate.getTime());
		
		// Set the to date.
		int lastDayMonth = fromDate.getActualMaximum(Calendar.DAY_OF_MONTH); 
		Calendar toDate = Calendar.getInstance();
		toDate.set(year, month, lastDayMonth);
		setToDate(toDate.getTime());
    }
    
    /**
     * 
     * @return the _groupName
     */
    public String getGroupName() {
    	return _groupName;
    }
    
    /**
     * 
     * @param groupName the _groupName to set
     */
    public void setGroupName(String groupName){
    	_groupName = groupName;
    }
    /**
     * @return the groupNbr
     */
    public String getGroupNbr() {
        return _groupNbr;
    }

    /**
     * @param groupNbr the _groupNbr to set
     */
    public void setGroupNbr(String groupNbr) {
        _groupNbr = groupNbr;
        if (groupNbr != null){
    		for (Iterator itr=_allGroupNames.iterator(); itr.hasNext(); ) {
    			AccountGroupVO accountGroupVO = (AccountGroupVO)itr.next();
    			String str = Integer.toString(accountGroupVO.get_group_nbr());
    			if (groupNbr.equalsIgnoreCase(str)){
    				setGroupName(accountGroupVO.get_group_nm());
    			}
    		}
    	}
    }
    
    /**
     * @return a list of all group names.
     */
    public List getAllGroupNames() {
    	_allGroupNames = shipperDelegate.getAccountGroupTable();
        List groupNameSelectItems = new ArrayList(_allGroupNames.size());
        for (Iterator itr=_allGroupNames.iterator(); itr.hasNext(); ) {
        	AccountGroupVO accountGroupVO = (AccountGroupVO)itr.next();
            groupNameSelectItems.add(new SelectItem(
            		Integer.toString(accountGroupVO.get_group_nbr()), 
            		accountGroupVO.get_group_nm()));
            if (getGroupNbr().equalsIgnoreCase("")){
            	setGroupNbr(Integer.toString(accountGroupVO.get_group_nbr()));
            }
        }
        return groupNameSelectItems;
    }
    
    /**
     * @return the _laneNbrStr
     */
    public String getLaneNbrStr() {
        return _laneNbrStr;
    }

    /**
     * @param lane the _laneNbrStr to set
     */
    public void setLaneNbrStr(String laneNbrStr) {
    	_laneNbrStr = laneNbrStr;
    	if (laneNbrStr != null){
    		for (Iterator itr=_laneList.iterator(); itr.hasNext(); ) {
    			LaneVO laneVO = (LaneVO)itr.next();
    			String str = String.valueOf(laneVO.get_lane_nbr());
    			if (laneNbrStr.equalsIgnoreCase(str)){
    				setOrigCntryCd(laneVO.get_orig_cntry_cd());
    				setDestCntryCd(laneVO.get_dest_cntry_cd());
    			}
    		}
    	}
    }
    
    /**
     * @return the _origCntryCd
     */
    public String getOrigCntryCd() {
        return _origCntryCd;
    }

    /**
     * @param lane the _origCntryCd to set
     */
    public void setOrigCntryCd(String origCntryCd) {
    	_origCntryCd = origCntryCd;
    }
    
    /**
     * @return the _destCntryCd
     */
    public String getDestCntryCd() {
        return _destCntryCd;
    }

    /**
     * @param lane the _destCntryCd to set
     */
    public void setDestCntryCd(String destCntryCd) {
    	_destCntryCd = destCntryCd;
    }
    
    /**
     * @return a list of all destination country codes for the company of 
     * interest.
     */
    public List getAllLanes() {
    	List allLanesSelectItems = new ArrayList(1);
    	Integer groupNbr =Integer.valueOf(_groupNbr);
    	_laneList = shipperDelegate.getAllLanes(groupNbr.intValue());
    	List laneList = removeDuplicatesLanes(_laneList);
    	allLanesSelectItems = new ArrayList(laneList.size()+1);
    	for (Iterator itr=laneList.iterator(); itr.hasNext(); ) {
    		LaneVO laneVO = (LaneVO)itr.next();
    		allLanesSelectItems.add(new SelectItem(
    				String.valueOf(laneVO.get_lane_nbr()), 
    				laneVO.get_orig_cntry_cd()+ "-" + 
    				laneVO.get_dest_cntry_cd()));
    	}
    	allLanesSelectItems.add(new SelectItem("All", "All"));
    	
        return allLanesSelectItems;
    }
    
    /**
     * Action method to go to the Performance List screen.
     * @return "performanceList"
     */
    public String viewReportAction(){
    	return "performanceList";
    }
    
    /**
     * Action method to reset the Performance screen.
     *
     */
    public void resetAction(){
    	_fromDate = null;
    	_toDate = null;
    	_selectRadio =  "one";
    	_selectYear =  new String(_thisYear);
    	_selectMonth =  new String("January");
    	_groupNbr = new String();
    	_laneNbrStr = new String();
    	_origCntryCd = new String();
        _destCntryCd = new String();
    }
    
    // =========================================================================
    // Private Methods
    // =========================================================================
    
    /**
     * Remove LaneVOs with duplicate lane numbers from a List.
     * @param hasDuplicates List of LaneVOs with duplicate lane numbers.
     * @return List of unique LaneVOs
     */
    private List removeDuplicatesLanes(List hasDuplicates) {
    	if (hasDuplicates == null){
    		List noDuplicates = new ArrayList(1);
    		return noDuplicates;
    	}
    	List noDuplicates = new ArrayList(hasDuplicates.size());
    	List noDuplicatesStr = new ArrayList(hasDuplicates.size());
		for (Iterator itr=hasDuplicates.iterator(); itr.hasNext(); ) {
			LaneVO dupLaneVO = (LaneVO)itr.next();
			String str = new String(dupLaneVO.get_orig_cntry_cd() + "-" +
					dupLaneVO.get_dest_cntry_cd());
			if (!noDuplicatesStr.contains(str)) {
				LaneVO laneVO = dupLaneVO;
				noDuplicates.add(laneVO);
				noDuplicatesStr.add(str);
			}
		}
    	return noDuplicates;
    }   
}
