package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.IssueVO;

public class IssueDAO extends DatabaseDAO {

    /** Logger */
    private static Logger logger = LogManager.getLogger(IssueDAO.class);
        
    public List getUnresolvedIssues(String aTrkngItemNbr,  String aTrkngItemUniqNbr) throws ServiceLocatorException, SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            IssuesAccessor accessor = new IssuesAccessor(connection);
            return accessor.getUnresolvedIssues(aTrkngItemNbr, aTrkngItemUniqNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    public boolean persistIssue(IssueVO aIssueVO) throws ServiceLocatorException, SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            IssuePersister persister = new IssuePersister(connection);
            return persister.persistIssue(aIssueVO);
        } finally {
            closeConnection(connection);
        }      
    }
    
    public void updateIssue(IssueVO aIssueVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            IssueUpdater updater = new IssueUpdater(connection);
            updater.updateIssue(aIssueVO);
        } finally {
            closeConnection(connection);
        }      
    }

    public void deleteIssue(IssueVO aIssueVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            IssueDeleter deleter = new IssueDeleter(connection);
            deleter.deleteIssue(aIssueVO);
        } finally {
            closeConnection(connection);
        }      
    }
    
}
