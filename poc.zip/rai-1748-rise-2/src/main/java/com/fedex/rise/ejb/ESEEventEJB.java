package com.fedex.rise.ejb;
public class ESEEventEJB {
	
}
//
//import java.rmi.RemoteException;
//import java.sql.SQLException;
//
//import javax.ejb.SessionBean;
//import javax.ejb.SessionContext;
//
//import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;
//
//import weblogic.ejbgen.Constants;
//import weblogic.ejbgen.JndiName;
//import weblogic.ejbgen.RemoteMethod;
//import weblogic.ejbgen.Session;
//
//
//
//import com.fedex.rise.bo.issue.TransactionException;
//import com.fedex.rise.ese.EnhancedEventMessageHandler;
//import com.fedex.rise.util.ServiceLocatorException;
//
///**
// * Test EJB for when we want to test without JMS.  Not used in production.
// * 
// * @ejb:bean name="ESEEventBean" display-name="ESEEventEJB" jndi-name="ESEEventEJB"
// *           local-jndi-name="LocalESEEventEJB" type="Stateless"
// *           view-type="both"
// * 
// * @ejb:home extends="javax.ejb.EJBHome"
// *           local-extends="javax.ejb.EJBLocalHome"
// * 
// * @ejb:interface extends="javax.ejb.EJBObject"
// *                local-extends="javax.ejb.EJBLocalObject"
// * 
// * @weblogic.enable-call-by-reference True
// * 
// * @ejb.transaction type="Supports"
// */
///**
//* ESEEventEJB
//* This class implements the EJB which is accessible via the JSPs. It is a
//* stateless SessionBean. This class implements the facade for the Business
//* Objects and or Data Access Objects. All EJB/J2EE related things should be
//* implemented here leaving the BO's with no knowledge of the EJB/J2EE
//* environment.
//*/
//@JndiName(remote="ejb/ESEEventRemote")
//@Session(ejbName = "ESEEventEJB",
//        maxBeansInFreePool="3",
//        initialBeansInFreePool="1",
//        type = Session.SessionType.STATELESS,
//        defaultTransaction=Constants.TransactionAttribute.SUPPORTS,
//        transactionType=Session.SessionTransactionType.BEAN,
//        enableCallByReference=Constants.Bool.TRUE)
//public class ESEEventEJB implements SessionBean {
//
//    private static final long serialVersionUID = 1L;
//
//    /** Logger */
//    private static Logger logger = LogManager.getLogger(ESEEventEJB.class);
//    
//    private SessionContext mySessionContext = null;
//
//    public SessionContext getSessionContext() {
//        return mySessionContext;
//    }
//
//    public void setSessionContext(SessionContext aSessionContext)
//            throws RemoteException {
//        mySessionContext = aSessionContext;
//    }
//
//    public void ejbActivate() {
//        System.out.println("Activate ESEEventEJB");
//    }
//
//    public void ejbPassivate() {
//        System.out.println("Passivate ESEEventEJB");
//    }
//
//    /**
//     * @ejb:create-method
//     */
//    public void ejbCreate() {
//        System.out.println("EJB Create ESEEventEJB");
//    }
//
//    /**
//     * @ejb:remove-method
//     */
//    public void ejbRemove() { 
//        System.out.println("EJB Remove MonitorEJBBean");
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void doEvent(byte[] anESEEvent) {
//        EnhancedEventMessageHandler eemh = new EnhancedEventMessageHandler();
//        try {
//            eemh.processMessage(anESEEvent);
//        } catch (TransactionException te) {
//            te.printStackTrace();
//        } catch (ServiceLocatorException e) {
//            e.printStackTrace();
//        } catch (SQLException e) {
//    // For testing through this ejb, just log the SQL Exception
//    e.printStackTrace();
//        }
//    }
//
//}
