package com.fedex.rise.util;

public class Utilities {

    /**
     * Log the version info.
     * This info comes from the META-INF/MANIFEST.MF file in the JAR that this 
     * package was loaded from. Note that it doesn't get the version from the WAR
     * or EAR, unless this class isn't bundled in it's own JAR.
     */ 
    public static void logPackageVersion(Package pkg) {
        System.out.println("***********************************************************************");
        if (pkg == null) {
            System.out.println("Version not found!");
        } else {
            System.out.println(pkg.getImplementationTitle()
                    + " - Version " + pkg.getImplementationVersion());
        }
        System.out.println("***********************************************************************");
    } 

}

