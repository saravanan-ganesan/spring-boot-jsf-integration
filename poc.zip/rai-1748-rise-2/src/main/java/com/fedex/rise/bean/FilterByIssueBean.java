package com.fedex.rise.bean;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.service.SelectedItemService;
import com.fedex.rise.service.ShipmentDelegateService;

import lombok.extern.slf4j.Slf4j;

@JsfController(path = "/filterByIssue", page = "/pages/jsp/filterByIssue.jsp", value = "filterByIssueBean")
@Slf4j
public class FilterByIssueBean extends BaseBean {


	@Autowired
	ShipmentDelegateService shipmentDelegateService;
	
	@Autowired 
	SelectedItemService selectedItemService;

	/** delegate to get shipment data */
	private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
	/** The selected filter, shipments can be filtered by issue type */
	private List _filterByIssueStr = null;
	private String issue = null;
	private String _shipDateOffsetStr = null;
	private int shipDateOffsetInt = 0;
	String[] noIssuesFiltering = { "-1" };
	private List filterByIssueStr = Arrays.asList(noIssuesFiltering);

	private int totalCount = 0;
	private boolean checkTotalCount = false;

	public String getIssue() {
		return issue;
	}

	public boolean isCheckTotalCount() {
		return checkTotalCount;
	}

	public void setCheckTotalCount(boolean checkTotalCount) {
		this.checkTotalCount = checkTotalCount;
	}

	public void setIssue(String issue) {
		this.issue = issue.trim();
	}

	/**
	 * @return the _shipDateOffsetStr
	 */
	public String getShipDateOffsetStr() {
		if (_shipDateOffsetStr == null) {
			_shipDateOffsetStr = new String("0");
		}
		log.info("value of _shipDateOffsetStr  " + _shipDateOffsetStr);
		return _shipDateOffsetStr;
	}

	/**
	 * @param lane
	 *            the _shipDateOffsetStr to set
	 */
	public void setShipDateOffsetStr(String shipDateOffsetStr) {
		if ((shipDateOffsetStr == null && _shipDateOffsetStr == null) || (shipDateOffsetStr == null)) {
			_shipDateOffsetStr = new String("0");
			return;
		} else if (shipDateOffsetStr != null && _shipDateOffsetStr == null) {
			_shipDateOffsetStr = new String(shipDateOffsetStr);
		} else if (shipDateOffsetStr != null) {
			_shipDateOffsetStr = shipDateOffsetStr;
		}
	}

	/**
	 * @return a list of all ship date offsets
	 */
	public List<SelectItem> getShipDateOffsets() {
		
		List<SelectItem> shipDateOffSetsSelectItems = new ArrayList<>(5);
		
		List<SelectItem> shipDateOffSetsSelectItems1 = selectedItemService.getAllItems();
		
		shipDateOffSetsSelectItems.add(new SelectItem("0", "Today"));
		shipDateOffSetsSelectItems.add(new SelectItem("1", "1 day"));
		shipDateOffSetsSelectItems.add(new SelectItem("7", "7 days"));
		shipDateOffSetsSelectItems.add(new SelectItem("10", "10 days"));
		shipDateOffSetsSelectItems.add(new SelectItem("30", "30 days"));
		
		return shipDateOffSetsSelectItems1;
	}

	/**
	 * get selected filter
	 */
	public List getFilter() {
		log.info("Fetching _filterByIssueStr " + _filterByIssueStr);
		return _filterByIssueStr;
	}

	/**
	 * set selected filter
	 */
	public void setFilter(List filter) {
		_filterByIssueStr = filter;
		if (log.isDebugEnabled()) {
			log.info("Setting  value of _filterByIssueStr " + _filterByIssueStr);
		}
		Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		setFilterByIssueStr(_filterByIssueStr);
	}

	/**
	 * @return the filterByIssueStr
	 */
	public List getFilterByIssueStr() {
		return filterByIssueStr;
	}

	/**
	 * @param filterByIssueStr
	 *            the filterByIssueStr to set
	 */
	public void setFilterByIssueStr(List filterByIssueStr) {
		this.filterByIssueStr = filterByIssueStr;
	}

	/**
	 * Get a list of all issue types, to be used as a filter (unique list of
	 * issue types)
	 * 
	 * @return
	 */
	public List getFilters() {
		
//		Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//		
//		// get the list of distinct Issues on all the shipments
//		//List issueTypeCds = shipmentDelegate.getFilterByIssues();
//		List<Integer> issueTypeCds = shipmentDelegateService.getFilterByIssues();
//
//		// Get preserved filter string
//		_filterByIssueStr = getFilterByIssueStr();
//
//		// See if all the issues the user picked to filter on are still present
//		// in
//		// database. The user may have resolved the last one.
//		for (Iterator i = _filterByIssueStr.iterator(); i.hasNext();) {
//			String selectedIssueFilterStr = (String) i.next();
//			if (!selectedIssueFilterStr.equals("-1")) {
//				String[] issueCds = selectedIssueFilterStr.split(":");
//				for (int j = 0; j < issueCds.length; j++) {
//					Integer issueInt = new Integer(issueCds[j]);
//					if (!issueTypeCds.contains(issueInt)) {
//						issueTypeCds.add(issueInt);
//					}
//				}
//			}
//		}
//		// iterate through issue codes and get descriptions, merge duplicate
//		// descriptions
//		Map<String, String> issueDescs = new HashMap<>();
//		for (Iterator<Integer> i = issueTypeCds.iterator(); i.hasNext();) {
//			Integer issueTypeCd = (Integer) i.next();
//			IssueDesc desc = RiseIssues.getIssueDesc(issueTypeCd.intValue());
//			if (desc != null) {
//				String shortDesc = desc.getShortTextDesc();
//
//				// see if description is already in the hash map, if so, update
//				// the description
//				// in the hash map and concat the issue type codes (user should
//				// only see one desc)
//				String value = (String) issueDescs.get(shortDesc);
//				if (value == null) {
//					issueDescs.put(desc.getShortTextDesc(), issueTypeCd.toString());
//				} else {
//					issueDescs.put(desc.getShortTextDesc(), value + ":" + issueTypeCd);
//				}
//			} else {
//				log.error("No Desc from IssueTypeCd: " + issueTypeCd);
//			}
//		}
//		// Create the SelectItem list of issues
//		List<SelectItem> filters = new ArrayList<>(issueTypeCds.size());
//		filters.add(new SelectItem("-1", "-")); // add no filtering as default
//												// choice
//
//		// iterate through issue to the the codes and descriptions
//		for (Iterator<Entry<String, String>> i = issueDescs.entrySet().iterator(); i.hasNext();) {
//			
//			Map.Entry<String, String> issue = i.next();
//			
//			// issue.value contains the type cd(s) and issue.key is the
//			// description (shown in drop down)
//			filters.add(new SelectItem((String) issue.getValue(), (String) issue.getKey()));
//		}
		List<SelectItem> filters = new ArrayList<>(3);
		filters.add(new SelectItem("1", "AAAAAAAA"));
		filters.add(new SelectItem("2", "BBBBBB"));
		filters.add(new SelectItem("3", "CCCCCCCCCC"));
		filters.add(new SelectItem("4", "DDDDDDDD"));
		filters.add(new SelectItem("5", "EEEE"));
		filters.add(new SelectItem("6", "FF"));
		filters.add(new SelectItem("7", "GGGGGG"));
		filters.add(new SelectItem("8", "HHHHHHHH"));
		return filters;
	}

	public void exportHtmlTableToExcel() throws Exception {

		setCheckTotalCount(false);
		if (getShipDateOffsetStr() != null) {
			shipDateOffsetInt = Integer.valueOf(getShipDateOffsetStr()).intValue();
		}

		log.info("Value of shipDateOffsetInt selected  :" + shipDateOffsetInt);
		//shipmentDelegate = new ShipmentDelegate();
		// tableDataList = new ArrayList<FilterDataBean>();

		// Because the selectItems used to select the issues to filter on can
		// share the same
		// short text, the value of the selectItem is a concatenated array of
		// issueTypeCds
		// We must split them up and build a list to go to the database with
		ArrayList<String> filterByIssues = new ArrayList<String>();
		
		for (Iterator<String> i = _filterByIssueStr.iterator(); i.hasNext();) {
			
			String issueCdsSplitByColons = (String) i.next();
			String[] issueCdsSplitUp = issueCdsSplitByColons.split(":");
			
			for (int j = 0; j < issueCdsSplitUp.length; j++) {
				filterByIssues.add(issueCdsSplitUp[j]);
			}
		}
		String[] filterByIssuesFinal = (String[]) filterByIssues.toArray(new String[0]);
		if (filterByIssuesFinal != null && filterByIssuesFinal.length > 0 && filterByIssuesFinal[0].endsWith("-1")) {
			filterByIssuesFinal = null;
		}
		List filterByIssuesDetails = null;
		//filterByIssuesDetails = shipmentDelegate.getShipmentFilteredIssues(filterByIssuesFinal, shipDateOffsetInt);

		totalCount = filterByIssuesDetails.size();
		log.info(" Total count is " + totalCount);
		

		if (totalCount == 0) {
			checkTotalCount = true;
			FacesContext facesContext = FacesContext.getCurrentInstance();
			FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"No Data Found for this date duration.", null);
			facesContext.addMessage(null, facesMessage);

		} else {

			if (filterByIssuesDetails != null && !filterByIssuesDetails.isEmpty()) {
				try {
					HSSFWorkbook workBook = new HSSFWorkbook();
					HSSFSheet sheet = workBook.createSheet();
					HSSFRow headingRow = sheet.createRow(0);
					HSSFCellStyle style = workBook.createCellStyle();
					HSSFFont font = workBook.createFont();
					font.setFontName(HSSFFont.FONT_ARIAL);
					font.setFontHeightInPoints((short) 10);
					font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
					font.setColor(HSSFFont.BOLDWEIGHT_NORMAL);
					style.setFont(font);
					style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
					style.setBorderTop(HSSFCellStyle.BORDER_THIN);
					style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					style.setBorderRight(HSSFCellStyle.BORDER_THIN);
					headingRow.createCell((short) 0).setCellValue("Shipper Name");
					headingRow.createCell((short) 1).setCellValue("Account Name");
					headingRow.createCell((short) 2).setCellValue("Account Number");
					headingRow.createCell((short) 3).setCellValue("Lane");
					headingRow.createCell((short) 4).setCellValue("Service");
					headingRow.createCell((short) 5).setCellValue("MAWB");
					headingRow.createCell((short) 6).setCellValue("CRN");
					headingRow.createCell((short) 7).setCellValue("Ship date");
					headingRow.createCell((short) 8).setCellValue("Commit Date");
					headingRow.createCell((short) 9).setCellValue("Last Status");					
					headingRow.createCell((short) 10).setCellValue("Issues");
					headingRow.createCell((short) 11).setCellValue("Dest");
					headingRow.createCell((short) 12).setCellValue("Monitor Emp Nbr");
					headingRow.createCell((short) 13).setCellValue("Monitor First Name");
					headingRow.createCell((short) 14).setCellValue("Monitor Last Name");
		
					sheet.setDefaultColumnWidth((short) 16);
					for (int j = 0; j <= 14; j++)
						headingRow.getCell((short) j).setCellStyle(style);
					short rowNo = 1;

					for (int i = 0; i < filterByIssuesDetails.size(); i++) {
						FilterDataBean filterDatabean = (FilterDataBean) filterByIssuesDetails.get(i);
						HSSFRow row = sheet.createRow(rowNo);
						
						row.createCell((short) 0).setCellValue(filterDatabean.get_group_nm());
						row.createCell((short) 1).setCellValue(filterDatabean.get_acct_nm());
						row.createCell((short) 2).setCellValue(filterDatabean.get_acct_nbr());
						row.createCell((short) 3).setCellValue(filterDatabean.getLane());
						row.createCell((short) 4).setCellValue(filterDatabean.get_SVC_TYPE_CD());
						row.createCell((short) 5).setCellValue(filterDatabean.get_assoc_trkng_item_nbr());						
						row.createCell((short) 6).setCellValue(filterDatabean.getTrkng_item_nbr());

						row.createCell((short) 7).setCellValue(
								new SimpleDateFormat("MM/dd/yyyy").format(filterDatabean.get_ship_dt()));
						if(filterDatabean.getCommitDate()!=null){
						row.createCell((short) 8).setCellValue(
								new SimpleDateFormat("MM/dd/yyyy").format(filterDatabean.getCommitDate()));
						}
						else
						{
							row.createCell((short) 8).setCellValue("");
						}
						row.createCell((short) 9).setCellValue(filterDatabean.getStatus());
						row.createCell((short) 10).setCellValue(filterDatabean.getIssuesStr());
						row.createCell((short) 11).setCellValue(filterDatabean.get_dest_loc_cd());
						row.createCell((short) 12).setCellValue(filterDatabean.get_emp_nbr());
						row.createCell((short) 13).setCellValue(filterDatabean.get_emp_first_nm());
						row.createCell((short) 14).setCellValue(filterDatabean.get_emp_last_nm());				
						rowNo++;
					}

					try {

						FacesContext fc = FacesContext.getCurrentInstance();
						HttpServletResponse response = (HttpServletResponse) fc.getExternalContext().getResponse();
						response.reset();
						response.setContentType("application/vnd.ms-excel");
						response.setHeader("Content-Disposition", "attachment; filename=RiseShipment_Details.xls");
						response.setHeader("Refresh", "10; url = FilterByIssue.jsp");
						workBook.write(response.getOutputStream());

						fc.responseComplete();

						log.info("Downloading done :");

					} catch (FileNotFoundException e) {
						log.error("FileNotFoundException Error while processing", e);
					} catch (IOException e) {
						log.error("IOException Error while processing", e);

					} catch (Exception e) {
						log.error("Error while processing", e);

					}

				} catch (Exception e) {
					log.error("Error while processing", e);

				}
			}
		}

	}

	public int getTotalCount() {
		log.info("value of total shipment count : " + totalCount);
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * Override deserialization to handle the re-creation of our transient data
	 */
	private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		shipmentDelegate = new ShipmentDelegate();
	}



}
