// Added as part of RISE WSSO Integration
//WR#TBD - WSSO Integration changes
package com.fedex.rise.auth;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class RedirectFilter implements Filter {

	private static Log log = LogFactory.getLog(RedirectFilter.class);
	private static String WSSOURLL1, WSSOURLL2, WSSOURLL4, L1NODE1,
			WSSOURLPROD, L1NODE2, L2NODE1, L2NODE2, L4SERVER, L4NODE1, L4NODE2,
			L4NODE3, PRODSERVER, PRODNODE1, PRODNODE2, PRODNODE3, LOG4j;

	static {
		try {
			InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("com/fedex/rise/MessageBundle.properties");
			Properties properties = new Properties();
			properties.load(input);
			WSSOURLL1 = properties.getProperty("WSSO.L1URL");
			WSSOURLL2 = properties.getProperty("WSSO.L2URL");
			WSSOURLL4 = properties.getProperty("WSSO.L4URL");
			WSSOURLPROD = properties.getProperty("WSSO.PRODURL");
			L1NODE1 = properties.getProperty("WSSO.L1Node1");
			L1NODE2 = properties.getProperty("WSSO.L1Node2");
			L2NODE1 = properties.getProperty("WSSO.L2Node1");
			L2NODE2 = properties.getProperty("WSSO.L2Node2");
			L4SERVER = properties.getProperty("WSSO.L4");
			L4NODE1 = properties.getProperty("WSSO.L4Node1");
			L4NODE2 = properties.getProperty("WSSO.L4Node2");
			L4NODE3 = properties.getProperty("WSSO.L4Node3");
			PRODSERVER = properties.getProperty("WSSO.PROD");
			PRODNODE1 = properties.getProperty("WSSO.PRODNODE1");
			PRODNODE2 = properties.getProperty("WSSO.PRODNODE2");
			PRODNODE3 = properties.getProperty("WSSO.PRODNODE3");
			LOG4j = properties.getProperty("LOG4J");
			log.info("Properties Loaded Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private FilterConfig filterConfig = null;

	@Override
	public void destroy() {
		filterConfig = null;
		log.info("Method: destroy()");
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletResponse rsp = (HttpServletResponse) resp;
		HttpServletRequest rq = (HttpServletRequest) req;
		String path = rq.getServletPath();
		if(path.endsWith(".jsf"))
			log.info("User Requested path:"+rq.getRequestURL());
		
		log.debug("User Requested path" + path);
		String serverNm = rq.getServerName();
		try {
			if ((serverNm.contains(L1NODE1) || serverNm.contains(L1NODE2)) && (!path.endsWith(LOG4j))) {
				log.info("Redirecting to WSSO L1 URl");
				rsp.sendRedirect("https://" + WSSOURLL1 + "/rise/");
			} else if ((serverNm.contains(L2NODE1) || serverNm .contains(L2NODE2)) && (!path.endsWith(LOG4j))) {
				log.info("Redirecting to WSSO L2 URl");
				rsp.sendRedirect("https://" + WSSOURLL2 + "/rise/");
			} else if ((serverNm.contains(L4SERVER) || serverNm.contains(L4NODE1) || serverNm.contains(L4NODE2) || serverNm .contains(L4NODE3)) && (!path.endsWith(LOG4j))) {
				log.info("Redirecting to WSSO L4 URl");
				rsp.sendRedirect("https://" + WSSOURLL4 + "/rise/");
			} else if ((serverNm.contains(PRODSERVER) || serverNm.contains(PRODNODE1) || serverNm.contains(PRODNODE2) || serverNm .contains(PRODNODE3)) && (!path.endsWith(LOG4j))) {
				log.info("Redirecting to WSSO PROD URl");
				rsp.sendRedirect("https://" + WSSOURLPROD + "/rise/");
			} else {
				log.debug("Requested SeverName " + serverNm);
				chain.doFilter(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		this.filterConfig = filterConfig;
		log.info("Method: init()");

	}

}

