package com.fedex.rise.bean;

import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.service.UserService;
import com.fedex.rise.vo.EmployeeVO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsfController(path = "/", page = "/pages/jsp/home.jsp", value = "homeBean")
public class HomeBean extends BaseBean {

	@Autowired
	UserService userService;

	UserBean userBean;
	
	@SuppressWarnings("unused")
	private String userInfo;

	private String realUserId = null;
	private String password = null;
	private String role = null;
	private String firstName = null;
	private String lastName = null;
	private TimeZone timeZone = null;
	private String empNbr = null;
	private String userId = null;

	public HomeBean() {}

	/******************************************************************************
	 * This is method to validate whether the user is authenticated and get the
	 * user details based okta authentication
	 * 
	 * @param none
	 * @return String
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
	public String getUserInfo() {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (null != authentication && !(authentication instanceof AnonymousAuthenticationToken)) {

			DefaultOidcUser oktaUser = (DefaultOidcUser) authentication.getPrincipal();
			if (null != oktaUser) {

				// get it from okta
				String oktaId = oktaUser.getUserInfo().getNickName();
				setEmpNbr(oktaId);

				//To check whether user details are already populated and available
				if(validateUserInfo() == false) {

					// internal db call to get user details 
					boolean userInfo = initUserInfo();
					
					if (userInfo && null != role) {
						
						//first time to set active 'Home' tab
						NavigationMenu nMenu = getBean("navigationMenu", NavigationMenu.class);

						if (nMenu != null) {

							String servletPath = getServletPath();
							if (servletPath != null && nMenu.getSelectedItem() != null
									&& getServletPath().endsWith("home.jsf")) {
								nMenu.setActive();
							}
						}
					} else {
						
						//redirect to unauthorized page - ro role mapped
						redirect("/unauthorized");
					}
				}
				
			} else {
				redirect("/unauthorized");
			}			
		} else {
			redirect("/unauthorized");
		}
		return "";
	}
	

	/******************************************************************************
	 * This is method to get a user info from the database
	 * 
	 * @param none
	 * @return boolean whether a user info retrieved return true or false 
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
	public boolean initUserInfo() {

		EmployeeVO userVO = userService.getUser(empNbr);

		if (userVO != null) {

			role = userVO.get_emp_role_cd();
			empNbr = userVO.get_emp_nbr();// getting emp-nbr
			userId = empNbr;
			firstName = userVO.get_emp_first_nm();
			lastName = userVO.get_emp_last_nm();
			
			return true;
			
		} else {
			return false;
		}
	}
	

	/******************************************************************************
	 * This is method to check whether a user info is present in the request
	 * 
	 * @param none
	 * @return boolean user validation is success return true or false
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
	public boolean validateUserInfo() {
		
		if(userId != null && firstName != null && lastName != null && role != null)
			return true;
		else
			return false;
	}
}
