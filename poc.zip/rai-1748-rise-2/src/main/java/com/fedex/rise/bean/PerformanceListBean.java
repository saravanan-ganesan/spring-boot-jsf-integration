package com.fedex.rise.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.vo.PerformanceVO;
import java.text.NumberFormat;

/**
 * Performance Summary List Backing bean
 */
public class PerformanceListBean {
    
	private static final Log log = LogFactory.getLog(PerformanceListBean.class);
	private static final int MAX_ROWS = 36;
	
	/** Delegate to get shipper data in DB */
    private ShipperDelegate _shipperDelegate = null;
    
    private DataModel _data;
    private DataModel _columnHeaders;
    
    /** selected month */
    private PerformanceBean _selectedPerformanceBean =  null;
    
    private List _performanceList = null;
    private String _performanceDesc = null;
    
    /**
     * Constructor
     */
    public PerformanceListBean() {
    	_shipperDelegate = new ShipperDelegate();
    	
        // create header row
        List headerList = new ArrayList();
        headerList.add(new ColumnHeader("Month", "10", false));
        headerList.add(new ColumnHeader("MAWB", "6", false));
        headerList.add(new ColumnHeader("CRN", "10", false));
        headerList.add(new ColumnHeader("On-Time", "10", false));
        headerList.add(new ColumnHeader("Late", "10", false));
        headerList.add(new ColumnHeader("Excused", "10", false));
        headerList.add(new ColumnHeader("No POD", "10", false));
        headerList.add(new ColumnHeader("ODA", "10", false));
        headerList.add(new ColumnHeader("Weight (Kgs)", "10", false));
        headerList.add(new ColumnHeader("Transportation Invoice ($)", "10", false));
        headerList.add(new ColumnHeader("Performance (%)", "11", false));
        
        _columnHeaders = new ListDataModel(headerList);
        
        // Get data from the back end performance data.
        if (getPerformanceBean() != null){
        	_performanceList = getPerformanceSumList(getPerformanceBean());
        }
        
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
        //WR#:179441 Changes
        _performanceDesc = new String(
        		" > From Date: " + outputFormat.format(getPerformanceBean().getFromDate()) +
        		" - To Date: " + outputFormat.format(getPerformanceBean().getToDate()) +
        		" - " + getPerformanceBean().getGroupName() +
        		" - Origin: " + getPerformanceBean().getOrigCntryCd() +
        		" - Dest: " + getPerformanceBean().getDestCntryCd() +
        		" - Monitor: " + getPerformanceBean().getMonitorName());
    }
    
    // ==========================================================================
    // Getters and Setters
    // ==========================================================================
    /**
     * Get the _performanceDesc.
     * @return the _performanceDesc
     */
    public String getPerformanceDesc(){
    	return _performanceDesc;
    }
    /**
     * Get the column value for the table.
     * @return column value
     */
    public Object getColumnValue() {
        Object columnValue = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue = ((List) _data.getRowData()).get(_columnHeaders.getRowIndex());
        }
        return columnValue;
    }
    /**
     * Get the column width for the table.
     * @return column width
     */
    public String getColumnWidth() {
        String columnWidth = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnWidth = ((ColumnHeader) _columnHeaders.getRowData()).getWidth();
        }
        return columnWidth;
    }
    
    /**
     * First column (month) is a link to get to details
     * @return true if it is first column
     */
    public boolean isLink() {
        boolean valueLink = false;

        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable() &&
        	(_data.getRowIndex() != _data.getRowCount()- 1)) {
            valueLink = (_columnHeaders.getRowIndex() == 0);
        }
        return valueLink;
    }
    
    /**
     * Fet the number of rows to show on a page
     * @return number rows per page.
     */
    public int getRowsPerPage() {
        return MAX_ROWS;
    }
    /**
     * Get the row index selected.
     * @return row index number selected.
     */
    public int getRowIndex(){
    	return _data.getRowIndex();
    }
    /**
     * Get the data model.
     * @return the data model.
     */
    public DataModel getColumnHeaders() {
        return _columnHeaders;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getCount() {
        // if no data then no rows 
        if (_data == null) return 0;
       
        return _data.getRowCount();
    }
    
    /**
     * Get the Performance that is selected in the list
     * @return
     */
    public PerformanceBean getSelectedPerformance() {
        return _selectedPerformanceBean;
    }
    
    /**
     * Get the Performance data model list
     * @return DataModel
     */
    public DataModel getData() {
        populatePerformanceList();
            
        return _data;
    }
    
    /**
     * Determines which detail JSP to go to, based on the Group Name.
     * @return "performanceAllCustomersList" or "performanceDetailList"
     */
    public String performanceDetail(){
    	if (getPerformanceBean().getGroupName().equals("All"))
    		return "performanceAllCustomersList";
    	else
    		return "performanceDetailList";
    }
    
    // ==========================================================================
    // Private Methods
    // ==========================================================================
    
    /**
     * Return a list of performance data.
     * @return
     */
    public List getPerformanceSumList(PerformanceBean performanceBean) {
    	log.debug("Entering getPerformanceSumList()");
		//WR#:179441 Changes
        return _shipperDelegate.getPerformanceSumList(performanceBean.getGroupNbr(),
        		performanceBean.getFromDate(), 
        		performanceBean.getToDate(),
        		performanceBean.getLaneOrgDest(),
        		performanceBean.getEmpName()); 
    }
    /**
     * Get the selected tree node (account, lane, service, etc.)
     * @return String
     */
    private PerformanceBean getPerformanceBean() {
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        PerformanceBean performanceBean = (PerformanceBean)params.get("PerformanceBean");
        return performanceBean;
    }
    
    /**
     * Get the list of Performance (data rows) for the month level
     */
    private void populatePerformanceList() {
       
        if (_performanceList == null) {
           // no selection, so no data
           _data = null;
        } else {
           // node selected so get data for this account, lane, service, etc.
           List rowList = new ArrayList();
           
           // Format display of performance % and Inv amt.
           NumberFormat formatPercentage = NumberFormat.getInstance();
           formatPercentage.setMaximumFractionDigits(1);
           NumberFormat formatInvAmt = NumberFormat.getInstance();
           formatInvAmt.setMaximumFractionDigits(2);
               
           // create data rows (list of lists)
           Iterator itr=_performanceList.iterator();
           
           // initialize the roll up totals for this page.
           int totalMawbQty = 0;
           int totalCrnQty = 0;
           int totalOnTimeCrnQty = 0;
           int totalLateCrnQty = 0;
           int totalExcusCrnQty = 0;
           int totalNoPodCrnQty = 0;
           int totalOdaCrnQty = 0;
           int totalWgtAmt = 0;
           float totalInvValueAmt = 0;
           
           while (itr.hasNext()) {
        	   PerformanceVO performanceVO = (PerformanceVO) itr.next();
               List colList = new ArrayList();
               
               // Insert Performance results into a display list.
               colList.add(String.valueOf(performanceVO.get_month()));
               colList.add(String.valueOf(performanceVO.get_total_mawb_qty()));      
               colList.add(String.valueOf(performanceVO.get_total_crn_qty()));  
               colList.add(String.valueOf(performanceVO.get_on_time_crn_qty())); 
               colList.add(String.valueOf(performanceVO.get_late_crn_qty()));       
               colList.add(String.valueOf(performanceVO.get_excus_crn_qty())); 
               colList.add(String.valueOf(performanceVO.get_no_pod_crn_qty()));
               colList.add(String.valueOf(performanceVO.get_oda_crn_qty()));
               colList.add(String.valueOf(performanceVO.get_total_wgt_amt()));
               colList.add(formatInvAmt.format(
            		   (float)performanceVO.get_total_inv_value_amt()/100.0));
               
               // Roll up the totals for this page;
               totalMawbQty += performanceVO.get_total_mawb_qty();
               totalCrnQty += performanceVO.get_total_crn_qty();
               totalOnTimeCrnQty += performanceVO.get_on_time_crn_qty();
               totalLateCrnQty += performanceVO.get_late_crn_qty();
               totalExcusCrnQty += performanceVO.get_excus_crn_qty();
               totalNoPodCrnQty += performanceVO.get_no_pod_crn_qty();
               totalOdaCrnQty += performanceVO.get_oda_crn_qty();
               totalWgtAmt += performanceVO.get_total_wgt_amt();
               totalInvValueAmt += performanceVO.get_total_inv_value_amt();
               
               // Calulate performance
               float perfPercent = 0;
               if (performanceVO.get_total_crn_qty() > 0){
               perfPercent = (float)(performanceVO.get_on_time_crn_qty()
            		   + performanceVO.get_excus_crn_qty() 
            		   + performanceVO.get_oda_crn_qty())/
            		   (float)(performanceVO.get_total_crn_qty()) * 100;
               } 
               
               colList.add(formatPercentage.format(perfPercent));  
               
               rowList.add(colList);
               
           }
           
           // Insert Total Performance results into a display list.
           List totalColList = new ArrayList();
           totalColList.add("Total");
           totalColList.add(String.valueOf(totalMawbQty));      
           totalColList.add(String.valueOf(totalCrnQty));  
           totalColList.add(String.valueOf(totalOnTimeCrnQty)); 
           totalColList.add(String.valueOf(totalLateCrnQty));       
           totalColList.add(String.valueOf(totalExcusCrnQty)); 
           totalColList.add(String.valueOf(totalNoPodCrnQty));
           totalColList.add(String.valueOf(totalOdaCrnQty));
           totalColList.add(String.valueOf(totalWgtAmt));
           totalColList.add(formatInvAmt.format(totalInvValueAmt/100.0));
           // Calulate Total Performance
           float totalPerfPercent = 0;
           if (totalCrnQty > 0){
        	   totalPerfPercent = (float)(totalOnTimeCrnQty
        		   + totalExcusCrnQty 
        		   + totalOdaCrnQty)/
        		   (float)(totalCrnQty) * 100;
           } 
           totalColList.add(formatPercentage.format(totalPerfPercent));
           rowList.add(totalColList);
           
           _data = new ListDataModel(rowList);
        }
    }
}
