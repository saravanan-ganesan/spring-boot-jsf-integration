package com.fedex.rise.service;

import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.fedex.rise.repository.SelectedItemRepository;

@Service
public class SelectedItemServiceImpl implements SelectedItemService {

	@Autowired
	SelectedItemRepository selectedItemRepository;
	
	@Cacheable(cacheNames = "shipBackDaysDropDown", keyGenerator="customKeyGenerator")
	public List<javax.faces.model.SelectItem> getAllItems() {
		
		ModelMapper mapper = new ModelMapper();
		
		return Arrays.asList(mapper.map(selectedItemRepository.findAll(), javax.faces.model.SelectItem[].class));
		
		
	}
}
