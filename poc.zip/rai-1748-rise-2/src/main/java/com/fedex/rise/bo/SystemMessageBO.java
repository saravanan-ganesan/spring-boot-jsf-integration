package com.fedex.rise.bo;

import java.sql.SQLException;
import java.util.List;

import com.fedex.rise.db.SystemMessageDAO;
import com.fedex.rise.vo.SystemMessageVO;

public class SystemMessageBO {

    public void persistSystemMessage(SystemMessageVO aVO) throws SQLException {
        SystemMessageDAO systemMessageDAO = new SystemMessageDAO();
        systemMessageDAO.persistSystemMessage(aVO);
    }
    
    public List getSystemMessages() throws SQLException {
        SystemMessageDAO systemMessageDAO = new SystemMessageDAO();
        return systemMessageDAO.getSystemMessages();
    }
    
    public void updateSystemMessage(SystemMessageVO aVO) throws SQLException {
        SystemMessageDAO systemMessageDAO = new SystemMessageDAO();
        systemMessageDAO.updateSystemMessage(aVO);
    }
    
    public void deleteSystemMessage(int aMsgNbr) throws SQLException {
        SystemMessageDAO systemMessageDAO = new SystemMessageDAO();
        systemMessageDAO.deleteSystemMessage(aMsgNbr);
    }
    
}
