package com.fedex.rise.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.lang.Integer;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

/**
 * Cleanup old rows
 */
public class DBCleanup {
	private static Logger logger = LogManager.getLogger(DBCleanup.class);

    /** connection */
    private Connection conn;
    
    /** delete statement */
    private PreparedStatement deleteStmt = null;

    private final static int DAYS_TO_KEEP = 186; //31*6;  // 6 months
    private final static int DAYS_TO_KEEP_PLUS_1 = 187; //31*6 +1;  // 6 months + 1 day
    
    /** Max number of rownum, set default  */
    private int maxRowNum = 5000;
    
    /** Total Max number of rownums to delete, set default  */
    private int totalMaxNumberOfRows = 3000000;

    /**
     * Connect to databases.
     *
     * @param uRL connect string URL
     * @param user user
     * @param passwd password
     * @throws SQLException
     */
    private void connectToDB(String uRL, String user, String passwd)
            throws SQLException, ClassNotFoundException {
        java.util.Properties props = new java.util.Properties();

        // Connect to DB
        props.put("user", user);
        props.put("password", passwd);
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection(uRL, props);
        
        // auto commit to false
        conn.setAutoCommit(false);

        logger.info("DB connect:" + conn.getMetaData().getDriverVersion());
    }

    /**
     * Close databases, make sure they all get closed.
     *
     * @throws SQLException
     */
    public void closeDB() {
    	try {
    		conn.close();
    	} catch (Exception e) {
            logger.error("ERROR: DB connection close", e);
    	}
    }
    
    /**
     * cleanShipmentTable  
     *
     * Algorithm:
     *     1. Purge the shipment table.
     *        Delete the rows in the Shipment table where the 
     *        input_tmstp is less than sysdate - DAYS_TO_KEEP
     *        at maxRowNum row numbers at a time.
     *        
     * @return boolean true for ok, false for errors
     */
    private boolean cleanShipmentTable() throws SQLException, IOException {	  
        // initialize delete statement
    	deleteStmt = null;
        
        deleteStmt = conn.prepareStatement(
        		"delete from shipment where " 
        		+ "input_tmstp < (sysdate - " + DAYS_TO_KEEP + ") "
                + "and rownum <= " + maxRowNum + " ");
        
        // deletion counts for each table 
        int totalDeleteCount = 0;
    
        // Delete the rows in the table of data_reference.
        int deletedCount = 1;
        do  {
        	// delete the data_reference table. 
        	deletedCount = deleteStmt.executeUpdate();
        	totalDeleteCount += deletedCount; 
        	
        	// don't actually delete them yet
        	//conn.rollback();
        	
        	// commit the delete statement.
            conn.commit();
            logger.info("shipment rows deleted = " + Integer.toString(deletedCount));
        } while (deletedCount > 0 && totalDeleteCount < totalMaxNumberOfRows);
       
        // Make sure to commit the remaining db accesses.
        conn.commit();
        
        logger.info("The Total shipment rows deleted = " + Integer.toString(totalDeleteCount)); 
        //System.out.println("The Total shipment rows deleted = " + Integer.toString(totalDeleteCount));
      
        return true;
    }

    /**
     * cleanAssociatedShipmentTable  
     *
     * Algorithm:
     *     1. Purge the associated_shipment table.
     *        Delete the rows in the associated_shipment table where the 
     *        input_tmstp is less than sysdate - DAYS_TO_KEEP_PLUS_1
     *        at maxRowNum row numbers at a time.
     *        
     * @return boolean true for ok, false for errors
     */
    private boolean cleanAssociatedShipmentTable() throws SQLException, IOException {	  
        // initialize delete statement
    	deleteStmt = null;
        
        deleteStmt = conn.prepareStatement(
        		"delete from associated_shipment where " 
        		+ "input_tmstp < (sysdate - " + DAYS_TO_KEEP_PLUS_1 + ") "
                + "and rownum <= " + maxRowNum + " ");
        
        // deletion counts for each table 
        int totalDeleteCount = 0;
    
        // Delete the rows in the table of data_reference.
        int deletedCount = 1;
        do  {
        	// delete the data_reference table. 
        	deletedCount = deleteStmt.executeUpdate();
        	totalDeleteCount += deletedCount; 
        	
        	// don't actually delete them yet
        	//conn.rollback();
        	
        	// commit the delete statement.
            conn.commit();
            logger.info("associated_shipment rows deleted = " + Integer.toString(deletedCount));
        } while (deletedCount > 0 && totalDeleteCount < totalMaxNumberOfRows);
       
        // Make sure to commit the remaining db accesses.
        conn.commit();
        
        logger.info("The Total associated_shipment rows deleted = " + Integer.toString(totalDeleteCount)); 
        //System.out.println("The Total associated_shipment rows deleted = " + Integer.toString(totalDeleteCount));
      
        return true;
    }
    
    /**
     * cleanEventTable  
     *
     * Algorithm:
     *     1. Purge the event table.
     *        Delete the rows in the event table where the 
     *        input_tmstp is less than sysdate - DAYS_TO_KEEP_PLUS_1
     *        at maxRowNum row numbers at a time.
     *        
     * @return boolean true for ok, false for errors
     */
    private boolean cleanEventTable() throws SQLException, IOException {	  
        // initialize delete statement
    	deleteStmt = null;
        
        deleteStmt = conn.prepareStatement(
        		"delete from event where " 
        		+ "input_tmstp < (sysdate - " + DAYS_TO_KEEP_PLUS_1 + ") "
                + "and rownum <= " + maxRowNum + " ");
        
        // deletion counts for each table 
        int totalDeleteCount = 0;
    
        // Delete the rows in the table of data_reference.
        int deletedCount = 1;
        do  {
        	// delete the data_reference table. 
        	deletedCount = deleteStmt.executeUpdate();
        	totalDeleteCount += deletedCount; 
        	
        	// don't actually delete them yet
        	//conn.rollback();
        	
        	// commit the delete statement.
            conn.commit();
            logger.info("event rows deleted = " + Integer.toString(deletedCount));
        } while (deletedCount > 0 && totalDeleteCount < totalMaxNumberOfRows);
       
        // Make sure to commit the remaining db accesses.
        conn.commit();
        
        logger.info("The Total event rows deleted = " + Integer.toString(totalDeleteCount)); 
        //System.out.println("The Total event rows deleted = " + Integer.toString(totalDeleteCount));
      
        return true;
    }
    
    /**
     * cleanIssueTable  
     *
     * Algorithm:
     *     1. Purge the issue table.
     *        Delete the rows in the issue table where the 
     *        input_tmstp is less than sysdate - DAYS_TO_KEEP_PLUS_1
     *        at maxRowNum row numbers at a time.
     *        
     * @return boolean true for ok, false for errors
     */
    private boolean cleanIssueTable() throws SQLException, IOException {	  
        // initialize delete statement
    	deleteStmt = null;
        
        deleteStmt = conn.prepareStatement(
        		"delete from issue where " 
        		+ "input_tmstp < (sysdate - " + DAYS_TO_KEEP_PLUS_1 + ") "
                + "and rownum <= " + maxRowNum + " ");
        
        // deletion counts for each table 
        int totalDeleteCount = 0;
    
        // Delete the rows in the table of data_reference.
        int deletedCount = 1;
        do  {
        	// delete the data_reference table. 
        	deletedCount = deleteStmt.executeUpdate();
        	totalDeleteCount += deletedCount; 
        	
        	// don't actually delete them yet
        	//conn.rollback();
        	
        	// commit the delete statement.
            conn.commit();
            logger.info("issue rows deleted = " + Integer.toString(deletedCount));
        } while (deletedCount > 0 && totalDeleteCount < totalMaxNumberOfRows);
       
        // Make sure to commit the remaining db accesses.
        conn.commit();
        
        logger.info("The Total issue rows deleted = " + Integer.toString(totalDeleteCount)); 
        //System.out.println("The Total issue rows deleted = " + Integer.toString(totalDeleteCount));
      
        return true;
    }

    /**
     * cleanReferenceNoteTable  
     *
     * Algorithm:
     *     1. Purge the reference_note table.
     *        Delete the rows in the reference_note table where the 
     *        ref_crtn_tmstp is less than sysdate - DAYS_TO_KEEP_PLUS_1
     *        at maxRowNum row numbers at a time.
     *        
     * @return boolean true for ok, false for errors
     */
    private boolean cleanReferenceNoteTable() throws SQLException, IOException {	  
        // initialize delete statement
    	deleteStmt = null;
        
        deleteStmt = conn.prepareStatement(
        		"delete from reference_note where " 
        		+ "ref_crtn_tmstp < (sysdate - " + DAYS_TO_KEEP_PLUS_1 + ") "
                + "and rownum <= " + maxRowNum + " ");
        
        // deletion counts for each table 
        int totalDeleteCount = 0;
    
        // Delete the rows in the table of data_reference.
        int deletedCount = 1;
        do  {
        	// delete the data_reference table. 
        	deletedCount = deleteStmt.executeUpdate();
        	totalDeleteCount += deletedCount; 
        	
        	// don't actually delete them yet
        	//conn.rollback();
        	
        	// commit the delete statement.
            conn.commit();
            logger.info("reference_note rows deleted = " + Integer.toString(deletedCount));
        } while (deletedCount > 0 && totalDeleteCount < totalMaxNumberOfRows);
       
        // Make sure to commit the remaining db accesses.
        conn.commit();
        
        logger.info("The Total reference_note rows deleted = " + Integer.toString(totalDeleteCount)); 
        //System.out.println("The Total reference_note rows deleted = " + Integer.toString(totalDeleteCount));
      
        return true;
    }
    
    /**
     * cleanShipmentCommentTable  
     *
     * Algorithm:
     *     1. Purge the shipment_comment table.
     *        Delete the rows in the shipment_comment table where the 
     *        input_tmstp is less than sysdate - DAYS_TO_KEEP_PLUS_1
     *        at maxRowNum row numbers at a time.
     *        
     * @return boolean true for ok, false for errors
     */
    private boolean cleanShipmentCommentTable() throws SQLException, IOException {	  
        // initialize delete statement
    	deleteStmt = null;
        
        deleteStmt = conn.prepareStatement(
        		"delete from shipment_comment where " 
        		+ "input_tmstp < (sysdate - " + DAYS_TO_KEEP_PLUS_1 + ") "
                + "and rownum <= " + maxRowNum + " ");
        
        // deletion counts for each table 
        int totalDeleteCount = 0;
    
        // Delete the rows in the table of data_reference.
        int deletedCount = 1;
        do  {
        	// delete the data_reference table. 
        	deletedCount = deleteStmt.executeUpdate();
        	totalDeleteCount += deletedCount; 
        	
        	// don't actually delete them yet
        	//conn.rollback();
        	
        	// commit the delete statement.
            conn.commit();
            logger.info("shipment_comment rows deleted = " + Integer.toString(deletedCount));
            //System.out.println("shipment_comment rows deleted = " + Integer.toString(deletedCount));
        } while (deletedCount > 0 && totalDeleteCount < totalMaxNumberOfRows);
       
        // Make sure to commit the remaining db accesses.
        conn.commit();
        
        logger.info("The Total shipment_comment rows deleted = " + Integer.toString(totalDeleteCount)); 
      
        return true;
    }
    
    /**
     * Cleaner - clean 
     *
     * Algorithm:
     *     1. Delete the rows in the shipment table for input_tmstp < (sysdate - DAYS_TO_KEEP)
     *     2. Delete the rows in the associated_shipment for input_tmstp < (sysdate - DAYS_TO_KEEP_PLUS_1)
     *     3. Delete the rows in the event for input_tmstp < (sysdate - DAYS_TO_KEEP_PLUS_1)
     *     4. Delete the rows in the issue for input_tmstp < (sysdate - DAYS_TO_KEEP_PLUS_1)
     *     5. Delete the rows in the reference_note for ref_crtn_tmstp < (sysdate - DAYS_TO_KEEP_PLUS_1)
     *     6. Delete the rows in the shipment_comment for input_tmstp < (sysdate - DAYS_TO_KEEP_PLUS_1)
     *
     * @return boolean true for ok, false for errors
     */
    private boolean clean() throws SQLException, IOException {
               
    	cleanShipmentTable();
    	cleanAssociatedShipmentTable();
    	cleanEventTable();
    	cleanIssueTable();
    	cleanReferenceNoteTable();
    	cleanShipmentCommentTable();
      
        return true;
    }

    /**
     * Start comparison
     * @return true if successfully completed conversion
     */
    public boolean start(Connection connection) throws SQLException {
        try {
        	if (connection != null) conn = connection;
            
            return clean();
        } catch (Exception e) {
            logger.error("ERROR: so abort");
            e.printStackTrace();
            return false;
        } finally {
            // make sure everything gets closed
        	conn.commit();
        }
    }

    /**
     * main to start conversion
     *
     * @param args see usage method above
     * @throws Exception
     */
    /**
     * @param args
     * @throws Exception
     */
//    public static void main(String[] args) throws Exception {
//        String user = "RISE_APP";
//        String passwd = "ri_se4ap"; // I know..
//        String uRL = "jdbc:oracle:thin:@ldap://oid.inf.fedex.com:3060/RISE_MSG_SVC1_L1,cn=OracleContext,dc=ute,dc=fedex,dc=com";
//        boolean ok;
//
//        // must have URLs to do conversion
//        if (uRL == null || uRL.length() == 0 ) {
//        	System.exit(1); // error
//        }
//
//        System.out.println("URL: " + uRL);
//
//        /*--------------------------------------------------------------------
//         * Start compare
//         *--------------------------------------------------------------------*/
//        long startTime = System.currentTimeMillis();
//        System.out.println("Start Time: " + (startTime) + " ms");
//        
//        DBCleanup cleaner = new DBCleanup();
//        
//        try {
//        	cleaner.connectToDB(uRL, user, passwd);
//            ok = cleaner.start(null);
//        }finally{
//        	cleaner.closeDB();
//        }
//        long endTime = System.currentTimeMillis();
//        System.out.println("End Time: " + (endTime) + " ms");
//        System.out.println("Elapse Time: " + (endTime - startTime) + " ms");
//        
//        if (!ok) {
//            System.exit(1); // error
//        }
//    }
}
