package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.ShipmentVO;

public class ShipmentDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(ShipmentDAO.class);
    
    /**
     * This method is used to persist a record into the Shipment table.
     *
     * @param aShipmentVO the event data to persist
     * @return true if succeeds, false if contraint violation
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public boolean doPersist(ShipmentVO aShipmentVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            ShipmentPersister persister = new ShipmentPersister(connection);
            return persister.persist(aShipmentVO);
        } finally {
            closeConnection(connection);
        }
    }    
    
    /**
     * 
     * @param trkng_item_nbr
     * @param trkng_item_uniq_nbr
     * @return
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public ShipmentVO getShipment(String trkng_item_nbr, String trkng_item_uniq_nbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            return accessor.getShipment(trkng_item_nbr, trkng_item_uniq_nbr);
        } finally {
            closeConnection(connection);
        }       
    }

    /**
     * 
     * @param trkng_item_nbr
     * @param trkng_item_uniq_nbr
     * @return
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public ShipmentVO getShipmentForUpdate(String trkng_item_nbr, String trkng_item_uniq_nbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            return accessor.getShipmentForUpdate(trkng_item_nbr, trkng_item_uniq_nbr);
        } finally {
            closeConnection(connection);
        }       
    }
    
    
    /**
     * 
     * @param aShipmentVO
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public void updateShipment(ShipmentVO aShipmentVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            ShipmentUpdater shipmentUpdater = new ShipmentUpdater(connection);
            shipmentUpdater.updateShipment(aShipmentVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * 
     * @param rtrn_trkng_item_nbr
     * @return
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getShipmentViaRtrnOrPaprTrkngNbr(String rtrn_trkng_item_nbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            return accessor.getShipmentViaRtrnOrPaprTrkngNbr(rtrn_trkng_item_nbr);
        } finally {
            closeConnection(connection);
        }       
    }
    
    /**
     * Update the GROUP_NBR in the SHIPMENT table of past shipments, if needed.
     * @param groupNbr group number
     * @param accountNbr account number
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void updateGroupNbrPastShipments(int groupNbr, String accountNbr, 
    		int laneNbr, String svcTypeCd) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
           
            ShipmentUpdater shipmentUpdater = new ShipmentUpdater(connection);
            shipmentUpdater.updateGroupNbrOfShipments(groupNbr, accountNbr, 
            		laneNbr, svcTypeCd);
            
        } finally {
            closeConnection(connection);
        }       
    }
}
