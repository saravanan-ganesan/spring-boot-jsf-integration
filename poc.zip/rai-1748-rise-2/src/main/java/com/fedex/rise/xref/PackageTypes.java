package com.fedex.rise.xref;

import java.util.HashMap;

public class PackageTypes {
  
    private static HashMap packageTypes = new HashMap();
    
    static {
        packageTypes.put(new Integer(1), "CUSTOMER");
        packageTypes.put(new Integer(2), "");
        packageTypes.put(new Integer(3), "BOX");
        packageTypes.put(new Integer(6), "");
    }
    
    public static String lookupPackageType(String aPackageType) {
        Integer i = new Integer(aPackageType);
        return (String)packageTypes.get(i);
    }
}
