package com.fedex.rise.db;

import java.io.Serializable;
import java.sql.SQLException;

public class ResourceBusyException extends SQLException implements Serializable {

    private static final long serialVersionUID = 1L;
        
    public ResourceBusyException(SQLException sqle) {
            super(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode());
    }
}