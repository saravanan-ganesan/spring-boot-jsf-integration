package com.fedex.rise.config;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;

import org.ocpsoft.rewrite.servlet.RewriteFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fedex.rise.constant.AppConstant;


/**
 * This configuration class is used to register the rewrite filter into the servlet
 * 
 * @author saravanan g
 *
 */
@Configuration
public class FilterRegistrationBeanConfig {

	/******************************************************************************
	 * This is method to used to configure rewrite filter bean for navigation
	 * 
	 * @param none
	 * @return FilterRegistrationBean rewrite filter object
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
	@Bean
	public FilterRegistrationBean<Filter> rewriteFilter() {
		
		FilterRegistrationBean<Filter> rwFilter = new FilterRegistrationBean<Filter>(new RewriteFilter());
		EnumSet<DispatcherType> enumSet = EnumSet.of(DispatcherType.FORWARD, 
										DispatcherType.REQUEST,
										DispatcherType.ASYNC, 
										DispatcherType.ERROR);
		rwFilter.setDispatcherTypes(enumSet);
		rwFilter.addUrlPatterns(AppConstant.URL_PATTERN_ALL);
		return rwFilter;
		
	}
}
