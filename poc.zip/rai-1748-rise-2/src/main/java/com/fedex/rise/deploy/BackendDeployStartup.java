package com.fedex.rise.deploy;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

//import com.fedex.rise.MCD.RISEMcd;
import com.fedex.rise.cache.AccountCacheDAO;
import com.fedex.rise.cache.LaneCacheDAO;
import com.fedex.rise.cache.LaneServiceCacheDAO;

public class BackendDeployStartup implements ServletContextListener {
    
    private static Logger logger = LogManager.getLogger(BackendDeployStartup.class);
    
    public void contextDestroyed(ServletContextEvent arg0) {
        //RISEMcd.shutdownMCD();
    }

    public void contextInitialized(ServletContextEvent arg0) {
        //RISEMcd.startMCD();

        // Trigger the Caches to load as soon as possible, need this data before
        // we handle any events.
        try {
            AccountCacheDAO.get("");
            LaneCacheDAO.get("");
            LaneServiceCacheDAO.get("");
        } catch (Exception e) {
            logger.error("Exception:", e);
        }
        logger.info("Backend Deployed.");
    }
}
