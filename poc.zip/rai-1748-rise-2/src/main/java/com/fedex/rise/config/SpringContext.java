package com.fedex.rise.config;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 
 * This configuration class is configure the bean to get the
 * spring bean/JSF managed bean from the application context
 *
 */
@Component
@Order(1)
public class SpringContext implements ApplicationContextAware {

	private static ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	public static ApplicationContext getApplicationContext() {
		return applicationContext;
	}
	
	/******************************************************************************
	 * This is method to configure the application security
	 * 
	 * @param beanName beanName to get
	 * @return Object retrieve the bean from application context
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
	public static Object getBean(String beanName) {
		
		return getApplicationContext().getBean(beanName);
	}
}