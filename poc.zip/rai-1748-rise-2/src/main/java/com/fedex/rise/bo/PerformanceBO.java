package com.fedex.rise.bo;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.config.ConfigurationManager;
import com.fedex.rise.db.AccountLaneDAO;
import com.fedex.rise.db.LaneDAO;
import com.fedex.rise.db.PerformanceDAO;
import com.fedex.rise.db.ConfigurationDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.LaneVO;
import com.fedex.rise.vo.PerformanceVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * Class that calculates customer performance and inserts the results in the
 * performance table.
 * @author be379961
 *
 */
public class PerformanceBO extends PerformanceDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(PerformanceBO.class);
    private static final int MAX_LOOPS = 90;
    private static final double POUNDS_TO_KG = 0.45359237 ;
    private static final String MAX_SHIP_DT = "MAX_SHIP_DT";
	
    /**
     * Constructor.
     */
    public PerformanceBO(){
    }
    
    /**
     * Determines how many days the performance needs to be calculated.
     *
     */
    public void performance(){
    	// Get the ship date which is based on the calculation of todays date
    	// minus 10 days or what ever it is configued.  The set the time part
    	// of shipDate to zero, while maintaining the day, month, and year.
    	PerformanceDAO performanceDAO = new PerformanceDAO();
    	Calendar shipDate = getPerformanceShipDate();
    	shipDate = setTimeZero(shipDate);
    	try {
    		// Get the last successful run of performance by getting the max 
    		// ship date and set the time part of it to zero. while maintaining 
    		// the day, month, and year.
    		Calendar maxShipDate = performanceDAO.getMaxShipDate();
    		if (maxShipDate != null && shipDate != null){
    			maxShipDate = setTimeZero(maxShipDate);
    			int nbrLoops = 0;
    			// Continue looping until the ship date and max ship date are
    			// equal, or the number of loops has exceeded MAX_LOOPS.
    			while (shipDate.after(maxShipDate) && nbrLoops < MAX_LOOPS){
    				// Increment the max ship date by one day, and calculate
    				// performance for the ship date of maxShipDate.
    				maxShipDate.add(Calendar.DAY_OF_YEAR, 1);
    				performanceDay(maxShipDate);
    				// Get the max ship date, and set the time to zero, while 
    				// maintaining the day, month, and year.
    				maxShipDate = performanceDAO.getMaxShipDate();
    				maxShipDate = setTimeZero(maxShipDate);
    				nbrLoops++;
    			}
    			return;
    		}
    		
    	}catch (SQLException e){
    		logger.error("SQLException exception", e);
    	} catch (ServiceLocatorException sle) { 
        	logger.error("Service Locator Exception: ", sle);
        } catch (Exception e) { // SystemException && NotSupportedException
            	logger.error("Exception", e); 
        }
        
        // This part of the code is used when maxShipDate is null and shipDate
        // is not null.  This means that either it is the first time performance
        // has run on this DB or there are issues with the DB.  After it has run
        // successfully, insert data into latest ship date into the 
        // configuration table.
        if (shipDate != null){
        	performanceDay(shipDate);
        }else {
        	logger.error("performance did not run, shipDate = null");
        }
    }
    /**
     * Determine what the perfomance is by getting performance data from the 
     * shipment table, roll it up by customer on a daily basis to the 
     * performance table.
     *
     */
    private void performanceDay(Calendar shipDate){
        
        try {
        	/**
        	 * Begin the daily performance calculation.
        	 */
        	SimpleDateFormat sf = new SimpleDateFormat("MM:dd:yyyy:HH:mm:ss");
        	
        	Calendar cal = Calendar.getInstance();
        	String dateStr = sf.format(cal.getTime());
        	logger.info("Starting calculating performance. Start time: " +
        			dateStr);
        	/**
        	 * Get data from the ACCOUNT LANE table.
        	 */
        	AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
        	try {
        		List accountLaneList = accountLaneDAO.getAccountLaneTable();
        		
    			Iterator laneIterator = accountLaneList.iterator();
    			while (laneIterator.hasNext()){
                	AccountLaneVO accountLaneVO = 
                		(AccountLaneVO)laneIterator.next();
                	processPerformance(accountLaneVO, shipDate);
    			}
    			
    			// After successful calculation of performance for this specific
    			// ship date, set it in the configuration table.
    			SimpleDateFormat sd = new SimpleDateFormat("yyyyMMdd");
    			String shipDateStr = sd.format(shipDate.getTime());
    			ConfigurationDAO configurationDAO = new ConfigurationDAO();
    			configurationDAO.doPersistOrUpdate(MAX_SHIP_DT, shipDateStr);
    			
    			dateStr = sf.format(cal.getTime());
            	logger.info("Completed calculating performance. End time: " 
            			+ dateStr);
        	}catch (SQLException sqle){
        		logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
        			+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
        		return;
        	}
        } catch (ServiceLocatorException sle) { 
        	logger.error("Service Locator Exception: ", sle);
        } catch (Exception e) { // SystemException && NotSupportedException
            	logger.error("Exception", e); 
        }
    }
    
    public void processPerformance(AccountLaneVO anAccountLaneVO, 
    		Calendar shipDate) throws ServiceLocatorException{
    	
    	PerformanceDAO performanceDAO = new PerformanceDAO();
    	LaneDAO laneDAO = new LaneDAO();
    	List shipmentVOList = null;
    	
    	try {
    		
    		LaneVO laneVO = laneDAO.getLane(anAccountLaneVO.get_lane_nbr());
    		shipmentVOList = 
    			performanceDAO.getShipmentViaAcctNbrLaneShipDate(anAccountLaneVO, 
    				shipDate);
    		
    		PerformanceVO performanceVO = 
    			calculatePerformance(shipmentVOList, anAccountLaneVO, laneVO, 
    				shipDate);
    		if (!performanceDAO.shipmentExist(anAccountLaneVO, shipDate)) {
    			performanceDAO.doPersist(performanceVO); 
    		}else{
    			performanceDAO.updatePerformance(performanceVO);
    		}
    	}catch (SQLException e){
    		logger.error("SQLException exception", e);
    	}
    	
    }
    
    private PerformanceVO calculatePerformance(List ashipmentVOList, 
    		AccountLaneVO anAccountLaneVO, LaneVO alaneVO, Calendar shipDate) {
    	
    	PerformanceVO performanceVO = new PerformanceVO();
    	
    	int total_mawb_qty  = 0;
    	int on_time_crn_qty = 0;
    	int pod_crn_qty = 0;
    	int late_crn_qty = 0;
    	int excus_crn_qty = 0;
    	int oda_crn_qty = 0;
    	int total_crn_qty = 0;
    	double total_wgt_amt = 0.0;
    	int total_wgt_amt_kg_int = 0;
    	int total_inv_value_amt = 0;
    	
    	/**
    	 * Set the items that should be set outside the while loop. Such as
    	 * ship date, account number, lane number, group number, origin 
    	 * country code, and destination country code.
    	 */
    	performanceVO.set_ship_dt(shipDate);
    	performanceVO.set_acct_nbr(anAccountLaneVO.get_acct_nbr());
    	performanceVO.set_lane_nbr(anAccountLaneVO.get_lane_nbr());
    	performanceVO.set_group_nbr(anAccountLaneVO.get_group_nbr());
    	performanceVO.set_orig_cntry_cd(alaneVO.get_orig_cntry_cd());
    	performanceVO.set_dest_cntry_cd(alaneVO.get_dest_cntry_cd());
    	
    	if (ashipmentVOList != null){
    		Iterator shipmentIterator = ashipmentVOList.iterator();
    		while (shipmentIterator.hasNext()){
    			ShipmentVO shipmentVO = (ShipmentVO)shipmentIterator.next();
			
    			// For shipments that are MAWBs
    			if (shipmentVO.get_shpmt_type_cd().equalsIgnoreCase("MAWB")){
            	total_mawb_qty++;
            	// Calculate total value. Invoice amount only for MAWB's
				total_inv_value_amt +=shipmentVO.get_inv_amt();
            	
            	// For shipments that are CRNs	
    			}else if (shipmentVO.get_shpmt_type_cd().equalsIgnoreCase("CRN")){
    				total_crn_qty ++;
            	
    				// For shipments that are ontime or late or excused or oda.
    				if (shipmentVO.get_perf_rsult_cd() != null){
    					if (shipmentVO.get_perf_rsult_cd().equalsIgnoreCase(
            				"ONTIME")){
    						on_time_crn_qty++;
    					}else if (shipmentVO.get_perf_rsult_cd().equalsIgnoreCase(
            				"LATE")){
    						late_crn_qty++;
    					}else if (shipmentVO.get_perf_rsult_cd().equalsIgnoreCase(
            				"EXCUSED")){
    						excus_crn_qty++;
    					}else if (shipmentVO.get_perf_rsult_cd().equalsIgnoreCase(
            				"ODA")){
    						oda_crn_qty++;
    					}else if (shipmentVO.get_perf_rsult_cd().equalsIgnoreCase(
            				"POD")){
    						pod_crn_qty++;
    					}
    				}
            		
    				// Calculate total weight in kg.
    				if (shipmentVO.get_shpmt_wgt() > 0){
    					if (Character.toString(shipmentVO.get_shpmt_uom_cd())
            				.equalsIgnoreCase("K")){// Kg
    						total_wgt_amt+= shipmentVO.get_shpmt_wgt();
    					} else if (Character.toString(shipmentVO.get_shpmt_uom_cd())
            				.equalsIgnoreCase("L")){//Lbs convert to Kg
    						total_wgt_amt+= 
    							(double)shipmentVO.get_shpmt_wgt() * POUNDS_TO_KG;
    					}
    				}
    			} // CRN or MAWB
    		} // While loop
    	} // ashipmentVOList not null
		
        /**
         * Set the rollup of performance data to the PerformanceVO.
         */
        performanceVO.set_total_mawb_qty(total_mawb_qty);
        performanceVO.set_total_crn_qty(total_crn_qty);
        performanceVO.set_on_time_crn_qty(on_time_crn_qty);
        performanceVO.set_late_crn_qty(late_crn_qty);
        performanceVO.set_excus_crn_qty(excus_crn_qty);
        performanceVO.set_oda_crn_qty(oda_crn_qty);
        performanceVO.set_no_pod_crn_qty(total_crn_qty - on_time_crn_qty
        		- late_crn_qty - excus_crn_qty - oda_crn_qty - pod_crn_qty);
        total_wgt_amt_kg_int = (int)(total_wgt_amt/100.0 + 0.5);
        performanceVO.set_total_wgt_amt(total_wgt_amt_kg_int);
        performanceVO.set_total_inv_value_amt(total_inv_value_amt);
        
        return performanceVO;
    }
    
    /**
     * Get the shipdate to calculate performance.
     * @return The shipdate to calculate performance.
     */
    private Calendar getPerformanceShipDate() {
    	//   Get the numbers of days to go back from the configuration file.  
    	// If it is not defined use a default of 10 days. 
    	String numberOfShipDaysBackStr = 
			ConfigurationManager.get("PERFORMANCE_NUMBER_DAYS_BACK_SHIPDATE");
		if (numberOfShipDaysBackStr == null){
			numberOfShipDaysBackStr = "10";
			logger.error("PERFORMANCE_NUMBER_DAYS_BACK_SHIPDATE property is null");
		}
		
		int numberOfShipDaysBackInt =  Integer.parseInt(numberOfShipDaysBackStr);
		
		// Set the shipDate based on current date minus the 
		// numberOfShipDaysBackMsec.
    	Calendar shipDate = Calendar.getInstance();
    	shipDate.add(Calendar.DAY_OF_YEAR, -numberOfShipDaysBackInt);
    	
    	return shipDate;
    }
    /**
     * Sets the time portion of ship date to zero while maintaining the day, 
     * month and year.
     * @param shipDate the day, month and year of Calendar.
     * @return
     */
    private Calendar setTimeZero(Calendar shipDate){
    	shipDate.clear(Calendar.HOUR);
    	shipDate.clear(Calendar.HOUR_OF_DAY);
    	shipDate.clear(Calendar.MINUTE);
    	shipDate.clear(Calendar.SECOND);
    	shipDate.clear(Calendar.MILLISECOND);
    	return shipDate;
    }
}
