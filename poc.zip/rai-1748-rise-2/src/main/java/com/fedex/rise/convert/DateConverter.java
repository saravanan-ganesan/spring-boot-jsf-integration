package com.fedex.rise.convert;

import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DateConverter implements Converter {
    /** logger */
    private static final Log log = LogFactory.getLog(DateConverter.class);
    
    private final SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
    
    /**
     * Default constructor
     */
    public DateConverter() {
        super();
        //if (log.isDebugEnabled()) log.debug("Constructed");
    }

    /**
     * Convert the Exception cd to a Exception description
     */
    public Object getAsObject(FacesContext context, UIComponent component, String aDate) {
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + aDate);
        return getAsString(context, component, aDate);
    }   

    /**
     * Convert the Exception cd to a Exception description
     */
    public String getAsString(FacesContext context,  UIComponent component, Object aDate) {
        //if (log.isDebugEnabled()) log.debug("GetAsString(): " + aDate);
        if (aDate == null)
            return null;
        else  {
            StringBuffer sb = new StringBuffer();
            outputFormat.format((Date)aDate, sb, new FieldPosition(0));
            return sb.toString();    
        }
    }

}
