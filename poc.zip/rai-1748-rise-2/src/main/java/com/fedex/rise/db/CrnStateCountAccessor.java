package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.CrnStateCountVO;

/**
 * Returns a count for each of the types of states we are looking for.
 * Its possible that the count for a state be greater than one.  In the
 * context of a shipment tracking number it should be considered a count
 * of one.  One or more returns for example on a shipment does not 
 * constitute a count of > 1.  Still just one shipment was returned.
 *
 */
public class CrnStateCountAccessor extends OracleBase {
   private static Logger logger = LogManager.getLogger(CrnStateCountAccessor.class);
    
    public CrnStateCountAccessor(Connection con) {
        super(con);
    }    
   
    /** Get the total number of CRNs we've seen for this MAWB */
    private static final String crnCountSQL = 
        "select count(*) count from SHIPMENT " + 
        " where (TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) in" +
              "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR " +
                 "from ASSOCIATED_SHIPMENT " +
                "where ASSOC_TRKNG_ITEM_NBR  = ? " +
                  "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null)" +
                  "and ASSOC_TRACK_TYPE_CODE = 'P' )";
   
    /**
     * Get count of all CRNs for this MAWB
     * @param aParntTrkngItemNbr
     * @param aParntTrkngUniqItemNbr
     * @return count of all CRNs for this MAWB
     * @throws SQLException
     */
    public int getCrnCount(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr) 
        throws SQLException {    
        int count = 0;

        try {
            setSqlSignature(crnCountSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aParntTrkngItemNbr);
            pstmt.setString(2, aParntTrkngUniqItemNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();
            
            if ( hasResults ) {
                if (rs.next()) {
                    count = rs.getInt("count");
                }
            }

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return count;
    }
    
    private final String crnCountWithIssuesSQL = 
      "select count(distinct i.TRKNG_ITEM_NBR) count " +
        "from ISSUE i, ASSOCIATED_SHIPMENT s " +
       "where RES_DT is null " + // issue not resolved
         "and ISSUE_TMSTP <= SYSDATE " + // issue is active
         "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
         "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
         "and s.ASSOC_TRKNG_ITEM_NBR = ? " +
         "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null) " +
         "and s.ASSOC_TRACK_TYPE_CODE = 'P'"; // parent 
    
    /**
     * Get count of CRNs with issues for this MAWB
     * @param aParntTrkngItemNbr
     * @param aParntTrkngUniqItemNbr
     * @return count of CRNs with issues for this MAWB
     * @throws SQLException
     */
    public int getCrnCountWithIssues(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr) 
        throws SQLException {    
        int count = 0;

        try {
            setSqlSignature( crnCountWithIssuesSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aParntTrkngItemNbr);
            pstmt.setString( 2, aParntTrkngUniqItemNbr);
 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
    
            execute();

            if (hasResults) {
                if (rs.next()) {        
                   count = rs.getInt("count");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }   
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode());
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    
    
    private final String PREcrnCountByIssuesSQL = 
      "select count(distinct i.TRKNG_ITEM_NBR) count " +
        "from ISSUE i, ASSOCIATED_SHIPMENT s " +
       "where RES_DT is null " + // issue not resolved
         "and ISSUE_TMSTP <= SYSDATE " + // issue is active
         "and ISSUE_TYPE_CD IN ( ? ";
         
    private final String POSTcrnCountByIssuesSQL = 
         " ) " + // issues
         "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
         "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
         "and s.ASSOC_TRKNG_ITEM_NBR = ? " +
         "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null) " +
         "and s.ASSOC_TRACK_TYPE_CODE = 'P'"; // parent 
    
    /**
     * Get count of CRNs with issues for this MAWB
     * @param aParntTrkngItemNbr
     * @param aParntTrkngUniqItemNbr
     * @param filterByIssues the Issue Type Cd(s) to filter on
     * @return count of CRNs with issues for this MAWB
     * @throws SQLException
     */
    public int getCrnCountByIssues(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr, 
            String[] filterByIssues) throws SQLException {    
        int count = 0;

        try {
            StringBuffer sql = new StringBuffer(PREcrnCountByIssuesSQL);
            if (filterByIssues != null && filterByIssues.length > 0) {
               for (int i=1; i<filterByIssues.length; i++) {
                  sql.append(", ?");
               }
            }
            sql.append(POSTcrnCountByIssuesSQL);
            
            setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );

            int i=0;
            if (filterByIssues != null && filterByIssues.length > 0) {
                while(i<filterByIssues.length) 
                    pstmt.setInt( i+1, Integer.parseInt(filterByIssues[i++]));
            }
            pstmt.setString( ++i, aParntTrkngItemNbr);
            pstmt.setString( ++i, aParntTrkngUniqItemNbr);
 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
    
            execute();

            if (hasResults) {
                if (rs.next()) {        
                   count = rs.getInt("count");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }   
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode());
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    
    /** Get status counts for CRNs we've seen for this MAWB */
    private static final String crnStateCountSQL = 
        "select count(distinct trkng_item_nbr) counts, track_type_cd, track_excp_cd from Event" + 
        " where" + 
          " ((track_type_cd = '07' and track_excp_cd = '34')" + // DACR
          " or (track_type_cd = '07' and track_excp_cd = '14')" + // RETURN
          " or (track_type_cd = '71')" + // Canceled
          " or (track_type_cd = '20')" + // POD
          " or (track_type_cd = '31'))" + // DDEX
           " and (trkng_item_nbr, trkng_item_uniq_nbr) in" +
             " (select trkng_item_nbr, trkng_item_uniq_nbr from Associated_Shipment a " +     
             " Where " +
               " a.assoc_trkng_item_nbr = ? and" +
               " (a.assoc_trkng_item_uniq_nbr = ? or a.assoc_trkng_item_uniq_nbr is null) and" +
               " a.ASSOC_TRACK_TYPE_CODE = 'P')" +
        " group by track_type_cd, track_excp_cd";
   
    /**
     * Get the list of CRN status counts for this MAWB
     * @param aTrkngItemNbr
     * @param aTrkngItemUniqNbr
     * @return
     * @throws SQLException
     */
    public List getCrnStateCounts(String aTrkngItemNbr, String aTrkngItemUniqNbr)
        throws SQLException {
        
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(crnStateCountSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aTrkngItemNbr);
            pstmt.setString(2, aTrkngItemUniqNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    CrnStateCountVO vo = new CrnStateCountVO();
                    vo.set_count(rs.getInt("counts"));
                    vo.set_trackTypeCd(rs.getString("track_type_cd"));
                    vo.set_trackExcpCd(rs.getString("track_excp_cd"));
                    al.add(vo);
                }
                return al;
            }

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }
       
}
