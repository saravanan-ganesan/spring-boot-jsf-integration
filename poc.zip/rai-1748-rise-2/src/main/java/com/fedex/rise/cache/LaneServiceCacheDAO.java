package com.fedex.rise.cache;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.LaneServiceDAO;
import com.fedex.rise.vo.LaneServiceVO;

public class LaneServiceCacheDAO {
    private static Logger logger = LogManager.getLogger(LaneServiceDAO.class);
    
    private static HashMap _cache = new HashMap();
    private static TimedCache _timedCache = new TimedCache();
    
    static {
        populateCache();
    }
    
    private LaneServiceCacheDAO() {
    }
    
	private static void populateCache() {
        logger.info("Loading Lane/Service Cache");
		HashMap hm = new HashMap();
		LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
		try {
			List laneServiceList = laneServiceDAO.getLaneServiceTable();
			Iterator laneServiceIterator = laneServiceList.iterator();
			while (laneServiceIterator.hasNext()) {
            	LaneServiceVO laneServiceVO = (LaneServiceVO)laneServiceIterator.next();
            	String key = laneServiceVO.get_svc_type_cd() 
            		+ String.valueOf(laneServiceVO.get_lane_nbr())
            		+ laneServiceVO.get_acct_nbr();
            	hm.put(key, laneServiceVO);
			}
			_cache = hm;
		} catch (SQLException sqle){
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
				+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
		} catch (Exception e) {
            logger.error("Exception: ", e);      
        }
	}
	
	public static LaneServiceVO get(Object key) {
		LaneServiceVO laneServiceVO = (LaneServiceVO)_cache.get(key);
		return laneServiceVO;
	}
	
	public static boolean containsKey(Object key) {
        if (_timedCache.isTimeToLoad()) { populateCache(); };
        return _cache.containsKey(key);
	}

}
