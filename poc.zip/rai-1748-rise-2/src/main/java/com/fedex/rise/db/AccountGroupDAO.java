package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AccountGroupVO;

public class AccountGroupDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AccountGroupDAO.class);
    
    public AccountGroupVO getAccountGroup(String groupName) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        AccountGroupVO accountGroupVO = null;

        try {
            connection = initializeConnection();
            AccountGroupAccessor acctGroupAccessor 
            	= new AccountGroupAccessor(connection);
            accountGroupVO = acctGroupAccessor.getAccountGroup(groupName);
        } finally {
            closeConnection(connection);
        }
        return accountGroupVO;
    }
    
    public AccountGroupVO getAccountGroup(int groupNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        AccountGroupVO accountGroupVO = null;

        try {
            connection = initializeConnection();
            AccountGroupAccessor acctGroupAccessor 
            	= new AccountGroupAccessor(connection);
            accountGroupVO = acctGroupAccessor.getAccountGroup(groupNbr);
        } finally {
            closeConnection(connection);
        }
        return accountGroupVO;
    }
    
    public void addAccountGroup(AccountGroupVO anAccountGroupVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountGroupPersister persister = new AccountGroupPersister(connection);
            persister.addAccountGroup(anAccountGroupVO);
        } finally {
            closeConnection(connection);
        }
    }

    public void updateAccountGroup(AccountGroupVO anAccountGroupVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountGroupUpdater updater = new AccountGroupUpdater(connection);
            updater.updateAccountGroup(anAccountGroupVO);
        } finally {
            closeConnection(connection);
        }
    }    
    
    public void deleteAccountGroup(int aGroupNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountGroupDeleter deleter = new AccountGroupDeleter(connection);
            deleter.deleteAccountGroup(aGroupNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    public List getAccountGroupTable() throws SQLException, ServiceLocatorException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            AccountGroupAccessor acctGroupAccessor 
            	= new AccountGroupAccessor(connection);
            list = acctGroupAccessor.getAccountGroupTable();
        } finally {
            closeConnection(connection);
        }
        return list;
    }
}
