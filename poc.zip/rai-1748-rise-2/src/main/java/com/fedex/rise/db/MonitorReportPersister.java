package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.MonitorReportVO;

public class MonitorReportPersister extends OracleBase {
	private static Logger logger = LogManager.getLogger(MonitorReportPersister.class);
	
	public MonitorReportPersister(Connection con) {
        super(con);
    }
    
	private static final String addMonitorReportRowSQL =
	    "Insert into Monitor_Report (" +
	    "EMP_NBR, " +
	    "WORK_DT, " +
	    "BEGIN_HAND_QTY, " +       
	    "ISSUE_RCVD_QTY, " +
	    "END_HAND_QTY, " +
	    "ISSUE_RSLV_QTY, " +
	    "ACCOUNT_QTY, " +
	    "MAWB_RSLV_QTY, " +
	    "CRN_RSLV_QTY) " +
	    "values(?,?,?,?,?,?,?,?,?)";        
	
	private static final String addDurationTimeSQL =
	    "Insert into Monitor_Report (" +
	    "EMP_NBR, " +
	    "WORK_DT, " +
	    "DURATION_QTY) " +
	    "values(?,?,?)"; 
	
	private static final String addNumberHitsSQL =
	    "Insert into Monitor_Report (" +
	    "EMP_NBR, " +
	    "WORK_DT, " +
	    "HIT_QTY) " +
	    "values(?,?,?)";
	
	public void doPersist(MonitorReportVO aMonitorReportVO) throws SQLException {
	    
	    try {
	        setSqlSignature( addMonitorReportRowSQL, false, logger.isDebugEnabled() );    
	            
	        pstmt.setString( 1, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  2, sqlDate);
	        } else {
	            pstmt.setNull(  2, java.sql.Types.DATE);
	        }
	        pstmt.setInt(3, aMonitorReportVO.get_num_issues_begin_shift());
	        pstmt.setInt(4, aMonitorReportVO.get_num_issues_presented());
	        pstmt.setInt(5, aMonitorReportVO.get_num_issues_end_shift());
	        pstmt.setInt(6, aMonitorReportVO.get_num_issues_resolved());
	        pstmt.setInt(7, aMonitorReportVO.get_total_number_accounts());
	        pstmt.setInt(8, aMonitorReportVO.get_num_mawb_resolved());
	        pstmt.setInt(9, aMonitorReportVO.get_num_crn_resolved());
	        
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        execute();

	    } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	        throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
	
	public void doPersistDurationTime(MonitorReportVO aMonitorReportVO) throws SQLException {
	    
	    try {
	        setSqlSignature( addDurationTimeSQL, false, logger.isDebugEnabled() );    
	            
	        pstmt.setString( 1, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  2, sqlDate);
	        } else {
	            pstmt.setNull(  2, java.sql.Types.DATE);
	        }
	        pstmt.setInt(3, aMonitorReportVO.get_total_duration());
	        
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        execute();

	    } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	        throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
	
	public void doPersistNumberHits(MonitorReportVO aMonitorReportVO) throws SQLException {
	    
	    try {
	        setSqlSignature( addNumberHitsSQL, false, logger.isDebugEnabled() );    
	            
	        pstmt.setString( 1, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  2, sqlDate);
	        } else {
	            pstmt.setNull(  2, java.sql.Types.DATE);
	        }
	        pstmt.setInt(3, aMonitorReportVO.get_num_hits());
	        
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        execute();

	    } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	        throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
}
