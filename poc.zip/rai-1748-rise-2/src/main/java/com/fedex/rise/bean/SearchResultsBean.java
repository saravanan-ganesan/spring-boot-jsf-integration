package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.bo.SearchDelegate;
import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.config.SpringContext;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.ShipmentEmployeeVO;

@JsfController(path = "/searchResults", page = "/pages/jsp/searchResultsFindShipperAccountNumber.jsp", value = "SearchResultsBean")
public class SearchResultsBean  implements Serializable  {
	
	@Autowired
	SearchBean searchBean;
	
    /** serializing version */
    private static final long serialVersionUID = 1L;

    /** logger */
    private static Log log = LogFactory.getLog(SearchResultsBean.class);

    /** Delegate to get search results */
    private transient SearchDelegate searchDelegate = new SearchDelegate();
    
    //WR#:179441 Changes
    /** delegate to get shipment data */
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
    
    private DataModel _data;

    private DataModel _columnHeaders;

    private List results = null;
    
    public int getColumnValue300() {
        int columnValue300 = 0;
        if (_data == null) {
        columnValue300 = 0;	
        }else{
        columnValue300 = _data.getRowCount();
        }
        return columnValue300;
    }     

    public SearchResultsBean() {
    	//Start WR#:179441 Changes
    	//super("ship_date");
    	//End WR#:179441 Changes
        // create header row
        List headerList = new ArrayList();
        headerList.add(new ColumnHeader("Tracking Nbr", "10", false));

        _columnHeaders = new ListDataModel(headerList);

        SearchBean sBean = null;
        if(SpringContext.getApplicationContext() != null) {
        	
        	sBean = (SearchBean) SpringContext.getBean("SearchBean");
        	
        	if(sBean != null) {
        		String acctNbr = sBean.getAcctNbr();
        		
        	}
        }
        
        
//        SearchBean _searchBean = (SearchBean) params.get("SearchBean");
          String searchBeanCheckResult = null;

        if (searchBeanCheckResult != null && searchBeanCheckResult.equals("acctNbr")) {
        	
            //results = searchDelegate.searchByAcctNbr(_searchBean.getAcctNbr());
        }
        
//        if (SearchBean.checkResult == null) {
//            // do nothing, should catch when results displayed and selecting
//            // other menu item
//        } else if (SearchBean.checkResult.equals("shprNm")) {
//            results = searchDelegate.searchByShprNm(_searchBean.getShprNm());
//        } else if (SearchBean.checkResult.equals("acctNbr")) {
//            results = searchDelegate.searchByAcctNbr(_searchBean.getAcctNbr());
//        } else if (SearchBean.checkResult.equals("trackingNbr")) {
//            results = searchDelegate.searchByTrkngNbr(_searchBean.getTrackingNbr());
//        } else if (SearchBean.checkResult.equals("referenceNbr")) {
//            results = searchDelegate.searchByReferenceNbr(_searchBean.getReferenceNbr(),
//                    _searchBean.getReferenceNumberMenu(), _searchBean.getLimitOneWeekFromDate(), _searchBean.getLimitOneWeekToDate());
//        } else if (SearchBean.checkResult.equals("trackingNbrMAWB")) {
//            results = searchDelegate.searchByTrkngNbrMAWB(_searchBean.getTrackingNbrMAWB(),
//                    _searchBean.getLimitOneWeekToDateByMAWBTrackingNumber(), _searchBean.getLimitOneWeekFromDateByMAWBTrackingNumber(),null, true, 0, 0);
//            SearchBean.trackingNbrMAWB = null;
//        } else if (SearchBean.checkResult.equals("acctNmMAWB")) {
//            results = searchDelegate.searchByAcctNmMAWB(_searchBean.getAcctNmMAWB(), _searchBean
//                    .getLimitOneWeekToDateByMAWBShipperName(), _searchBean.getLimitOneWeekFromDateByMAWBShipperName(),null, true, 0, 0);
//        } else if (SearchBean.checkResult.equals("issueCodeCRNacctNbrCRN")) {
//            results = searchDelegate.searchByIssueCodeCRN(_searchBean.getTrackingNbrCRN(),
//                    _searchBean.getIssueCodeCRN(), (_searchBean.getAcctNbrCRN()), _searchBean
//                            .getToDate4(), _searchBean.getFromDate4());
//        } else if (SearchBean.checkResult.equals("returnTrkngNbr")) {
//            results = searchDelegate.searchByReturnTrkngNbr(_searchBean.getReturnTrkngNbr(),null, true, 0, 0);
//        } else if (SearchBean.checkResult.equals("recipientName")) {
//            results = searchDelegate.searchByRecipientName(_searchBean.getRecipientName(),
//                    _searchBean.getLimitOneWeekToDateByCRNRecipientName(), _searchBean.getLimitOneWeekFromDateByCRNRecipientName(),null, true, 0, 0);
//        } else if (SearchBean.checkResult.equals("shipDate")) {
//            results = searchDelegate.searchByShipDate(_searchBean.getShipDate(), _searchBean
//                    .getServiceCode2(), _searchBean.getAcctNbrMAWB2(), _searchBean
//                    .getSelectedLane2());
//        } //Start WR#:179441 Changes
//        /*else if (SearchBean.checkResult.equals("shipDateRange")) {
//            results = searchDelegate.searchByShipDateRange(_searchBean.getLimitOneWeekToDate3(), _searchBean
//                    .getLimitOneWeekFromDate3(), _searchBean.getServiceCode(), _searchBean.getAcctNbrMAWB3(),
//                    _searchBean.getSelectedLane(),getSort(),isAscending());
//        } */ //End WR#:179441 Changes
//        else if (SearchBean.checkResult.equals("postalCode")) {
//            results = searchDelegate.searchByPostalCode(_searchBean.getLimitOneWeekToDate(), _searchBean
//                    .getLimitOneWeekFromDate(), _searchBean.getPostalCode(),null, true, 0, 0);
//        } else if (SearchBean.checkResult.equals("rampHubSearch")) {
//            results = searchDelegate.rampHubSearch(_searchBean.getShipDate(), _searchBean.getSelectMenu(), _searchBean.getClearancePoint(),null, true, 0, 0);            
//        } else if (SearchBean.checkResult.equals("findMonitorAcctNbr")) {
//            results = searchDelegate.searchByFindMonitorAcctNbr(_searchBean.getAcctNbr());
//        } else if (SearchBean.checkResult.equals("findMonitorTrkngNbr")) {
//            results = searchDelegate.searchByFindMonitorTrkngNbr(_searchBean.getTrackingNbr());
//        } else if (SearchBean.checkResult.equals("withODACRN")) {
//            results = searchDelegate.searchByWithODACRN(_searchBean.getAcctNbr(), _searchBean.getLimitOneWeekFromDateByCRNWithODA(), _searchBean.getLimitOneWeekToDateByCRNWithODA(),null, true, 0, 0);
//        } else if (SearchBean.checkResult.equals("withoutPODCRN")) {
//            results = searchDelegate.searchByWithoutPODCRN(_searchBean.getAcctNbr2(), _searchBean
//                    .getTrackingNbrMAWB2());
//        } else if (SearchBean.checkResult.equals("findMissingData")) {
//            results = searchDelegate.searchByFindMissingData(_searchBean.getAcctNbr());
//            SearchBean.acctNbr = null;
//        } else if (SearchBean.checkResult.equals("searchByAddress")) {
//            results = searchDelegate.searchByAddressCRN(_searchBean.getAddressLineOne(), _searchBean
//                    .getAddressCityName(), _searchBean.getAddressStateProvince(), _searchBean
//                    .getAddressPostalCode(), _searchBean.getLimitOneWeekToDateByCRNRecipientAddress(), _searchBean.getLimitOneWeekFromDateByCRNRecipientAddress(),null, true, 0, 0);
//        }
        // reset criteria to default values
        //Start WR#:179441 Changes
       if((SearchBean.checkResult!="trackingNbr") && (SearchBean.checkResult!="shipDateRange"))
       {
        //_searchBean.reset();
        
       }//End WR#:179441 Changes
    }

    // ==========================================================================
    // Getters
    // ==========================================================================

    // Get Column Value For Shipment Table

    public Object getColumnValue() {
        Object columnValue = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue = ((ShipmentEmployeeVO)_data.getRowData()).get_trkng_item_nbr();
        }
        return columnValue;
    }

    public Object getColumnValue2() {
        Object columnValue2 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue2 = ((ShipmentEmployeeVO)_data.getRowData()).get_shpmt_type_cd();
        }
        return columnValue2;
    }

    public Object getColumnValue3() {
        Object columnValue3 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue3 = ((ShipmentEmployeeVO)_data.getRowData()).get_acct_nbr();
        }
        return columnValue3;
    }

    public Object getColumnValue4() {
        Object columnValue4 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue4 = ((ShipmentEmployeeVO)_data.getRowData()).get_ship_dt();
        }
        return columnValue4;
    }

    public Object getColumnValue5() {
        Object columnValue5 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue5 = ((ShipmentEmployeeVO)_data.getRowData()).get_svc_type_cd();
        }
        return columnValue5;
    }

    public Object getColumnValue6() {
        Object columnValue6 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue6 = ((ShipmentEmployeeVO)_data.getRowData()).get_shpr_co_nm();
        }
        return columnValue6;
    }

    public Object getColumnValue7() {
        Object columnValue7 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue7 = ((ShipmentEmployeeVO)_data.getRowData()).get_shpr_cntry_cd();
        }
        return columnValue7;
    }

    public Object getColumnValue8() {
        Object columnValue8 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue8 = ((ShipmentEmployeeVO)_data.getRowData()).get_recp_co_nm();
        }
        return columnValue8;
    }

    public Object getColumnValue9() {
        Object columnValue9 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue9 = ((ShipmentEmployeeVO)_data.getRowData()).get_recp_cntry_cd();
        }
        return columnValue9;
    }

    public Object getColumnValue10() {
        Object columnValue10 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue10 = ((ShipmentEmployeeVO)_data.getRowData()).get_recp_ph_nbr();
        }
        return columnValue10;
    }

    public Object getColumnValue11() {
        Object columnValue11 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue11 = Integer.toString(((ShipmentEmployeeVO) _data.getRowData())
                    .get_lane_nbr());
        }
        return columnValue11;
    }

    public Object getColumnValue12() {
        Object columnValue12 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue12 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_city_nm();
        }
        return columnValue12;
    }

    public Object getColumnValue13() {
        Object columnValue13 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue13 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_pstl_cd();
        }
        return columnValue13;
    }   

    public Object getColumnValue15() {
        Object columnValue15 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue15 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_st_prov_cd();
        }
        return columnValue15;
    }    

    // Get Column Values for Employee Table

    public Object getColumnValue100() {
        Object columnValue100 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue100 = ((ShipmentEmployeeVO) _data.getRowData()).get_emp_first_nm();
        }
        return columnValue100;
    }

    public Object getColumnValue101() {
        Object columnValue101 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue101 = ((ShipmentEmployeeVO) _data.getRowData()).get_emp_last_nm();
        }
        return columnValue101;
    }

    public Object getColumnValue102() {
        Object columnValue102 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue102 = ((ShipmentEmployeeVO) _data.getRowData()).get_emp_nbr();
        }
        return columnValue102;
    }
    
  //Start WR#:179441 Changes
    public Object getColumnValue103() {
        Object columnValue103 = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue103 = ((ShipmentEmployeeVO) _data.getRowData()).get_trkng_item_uniq_nbr();
        }
        return columnValue103;
    }
    
	public String getShipmentDetail() {

		FacesContext context = FacesContext.getCurrentInstance();
		Map requestParams = context.getExternalContext()
				.getRequestParameterMap();

		String trackingNbr = (String) requestParams.get("trkng_item_nbr");
		String trackingUniqNbr = (String) requestParams
				.get("trkng_item_uniq_nbr");

		MawbBean _selectedMawbBean = null;//shipmentDelegate.getMAWB(trackingNbr, trackingUniqNbr);
		CrnBean _selectedCrnBean = null;//shipmentDelegate.getCrn(trackingNbr, trackingUniqNbr);
		String shipmentType = "";//_selectedMawbBean.getShipment()
				//.get_shpmt_type_cd();

		if (trackingNbr != null && trackingUniqNbr != null
				&& shipmentType.equals("CRN")) {
			// tell the controller which bean is selected, because the
			// controller is session scope,
			// but we are only request scope
			Map sessionParams = context.getExternalContext().getSessionMap();
			MonitorTreeBean _monitorTreeBean = (MonitorTreeBean) sessionParams
					.get("monitorTreeBean");

			UserBean user = (UserBean) sessionParams.get("UserBean");
			_monitorTreeBean = new MonitorTreeBean(user);

			_selectedMawbBean.setSelectedCRN(_selectedCrnBean);
			_monitorTreeBean.setSelectedMAWB(_selectedMawbBean);
			_monitorTreeBean
					.setCheckMawbDetailsPage("FindShipmentByTrackingNbr");
			sessionParams.put("monitorTreeBean", _monitorTreeBean);

			log.info("Select CRN Detail: " + trackingNbr);

			// navigate to the detail screen
			return "showCrnDetail";
		} else if (trackingNbr != null && trackingUniqNbr != null) {
			// shouldn't happen
			Map sessionParams = context.getExternalContext().getSessionMap();
			MonitorTreeBean _monitorTreeBean = (MonitorTreeBean) sessionParams
					.get("monitorTreeBean");

			UserBean user = (UserBean) sessionParams.get("UserBean");
			_monitorTreeBean = new MonitorTreeBean(user);

			_monitorTreeBean.setSelectedMAWB(_selectedMawbBean);

			_monitorTreeBean
					.setCheckMawbDetailsPage("FindShipmentByTrackingNbr");
			_monitorTreeBean.setNodePathDesc(null);

			sessionParams.put("monitorTreeBean", _monitorTreeBean);
			// navigate to the detail screen
			log.info("Select MAWB Detail: " + trackingNbr);

			Map params = FacesContext.getCurrentInstance().getExternalContext()
					.getSessionMap();
			SearchBean _searchResetBean = (SearchBean) params.get("SearchBean");
			// _searchResetBean.reset();

			return "showMawbDetail";
		} else {
			return null;
		}
	}// End WR#:179441 Changes

    public DataModel getColumnHeaders() {
        return _columnHeaders;
    }

    public DataModel getData() {
    	//Start WR#:179441 Changes
		Map params = FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap();
		SearchBean _searchBean = (SearchBean) params.get("SearchBean");
//		if (SearchBean.checkResult.equals("shipDateRange")) {
//			results = searchDelegate.searchByShipDateRange(
//					_searchBean.getLimitOneWeekToDate3(),
//					_searchBean.getLimitOneWeekFromDate3(),
//					_searchBean.getServiceCode(),
//					_searchBean.getAcctNbrMAWB3(),
//					_searchBean.getSelectedLane(), getSort(), isAscending());
//		}//End WR#:179441 Changes
		if (results != null) {
			_data = new ListDataModel(results);
		}
		return _data;
	}

  //Start WR#:179441 Changes
	protected void sort(String column, boolean ascending) {
		// TODO Auto-generated method stub

	}

//	@Override
//	protected boolean isDefaultAscending(String sortColumn) {
//		// TODO Auto-generated method stub
//		if (sortColumn.equals("ship_date"))
//			return false; // sort descending by default on ship_dt
//		else
//			return true; // sort ascending by default
//	}//End WR#:179441 Changes
}