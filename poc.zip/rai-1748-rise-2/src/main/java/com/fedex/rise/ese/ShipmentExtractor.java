package com.fedex.rise.ese;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.asn.UTF8String.common.Assoc_tracking_number_grp;
import com.fedex.asn.UTF8String.common.Business_entities_grp;
import com.fedex.asn.UTF8String.common.Business_entity_grp;
import com.fedex.asn.UTF8String.common.Special_handling_cd;
import com.fedex.asn.UTF8String.common.Business_entities_grp.Business_entity_grp_md;
import com.fedex.asn.UTF8String.enhancedevent_.EnhancedEvent;
import com.fedex.asn.UTF8String.shipmentprofile_.ShipmentProfile.Special_handling_code_array;
import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.util.SEPDateConverter;
import com.fedex.rise.vo.AssociatedShipmentVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * This class is used to pull out the data for the Shipment table
 */
public class ShipmentExtractor extends BaseEventExtractor {

    private static Logger logger = LogManager.getLogger(ShipmentExtractor.class);
    
    public ShipmentExtractor(EnhancedEvent anEE) throws ESEParseException {
        super(anEE);
    }
    
    /**
     * This constructor can use a BaseEventExtractor which has already parsed the
     * base events.
     * @param aBaseEventExtractor a base event extractor which has already parsed its data
     * @throws ESEParseException if part of the message is missing, and we desperately need it
     */
    ShipmentExtractor(BaseEventExtractor aBaseEventExtractor)
                   throws ESEParseException {
        super(aBaseEventExtractor);     
    }

    public ShipmentVO extract(AssociatedShipmentsHelper anAssocShipmentHelper)
        throws ESEParseException {
        
        ShipmentVO shipmentVO = new ShipmentVO();
        
        // tracking item number
        shipmentVO.set_trkng_item_nbr(trackItemNumber);
        
        // tracking item unique number
        shipmentVO.set_trkng_item_uniq_nbr(trackItemUniqNumber);
        
        // get account number, Not always present in all scan types
        if (sp.hasShipper_account_number()) {
            shipmentVO.set_acct_nbr(sp.getShipper_account_number().stringValue());
        } else {
            if (ml.hasShipper_account_number()) {
                shipmentVO.set_acct_nbr(ml.getShipper_account_number().stringValue());
            }
        } 
        
        // get service code, always present, well almost always
        shipmentVO.set_svc_type_cd(svcTypCd);
        
        // Classify the shipment type as MAWB, CRN, AWB or UNK
        String type = classifyShipment(shipmentVO, anAssocShipmentHelper);
        if (type != null) {
            shipmentVO.set_shpmt_type_cd(type);
        }
        
        // get form code, all events, most always present, form codes do change but shouldn't
        // safest place to get it is from SP, as SEP does weighting based on event types
        int formCode = 0;
        String formCd = null;
        if (sp.hasTracking_item_form_cd()) {
            formCd = sp.getTracking_item_form_cd().stringValue().trim();
            if (formCd.length() > 0) {
                try {
                    formCode = Integer.parseInt(formCd);
                } catch (NumberFormatException nfe) {
                    logger.info("Found invalid form code: " + sp.getTracking_item_form_cd().stringValue());
                }
            }
        }
        // Doris says don't get form code from master list

        shipmentVO.set_trkng_item_form_cd(formCode);
        
        // get packaging type
        if (sp.hasPackaging_type()) {
            int packType = 0;
            try {
                packType = Integer.parseInt(sp.getPackaging_type().stringValue());
            } catch (NumberFormatException nfe) {
                logger.info("Found invalid package type: " + sp.getPackaging_type().stringValue());
            }
            shipmentVO.set_pack_type_cd(packType);
        }
        
        /**
         * Get the shipper, recipient, origin and destination from the master
         * list first.  Then get the same information from shipment profile and
         * over write it, if it exists. Get the Actual only from the shipment
         * profile.
         */
        extractMasterListInfo(shipmentVO);
        extractBusinessEntityInfo(shipmentVO);
        
        char dimWeightUOM = 'K';
        if (ml.hasDim_weight_uom()) {
            dimWeightUOM = ml.getDim_weight_uom().stringValue().charAt(0);
        } else {
            if ((ce != null) && ce.hasDimension_uom()) {
                dimWeightUOM = ce.getDimension_uom().stringValue().charAt(0);
            }
        }
        // Get dimensional weight
        String dimWeightStr = null;
        if (ml.hasDim_weight()) {
            dimWeightStr = ml.getDim_weight().stringValue();
        } else {
            if ((ce != null) && ce.hasDim_weight()) {
                dimWeightStr = ce.getDim_weight().stringValue();
            }
        }
        if (dimWeightStr != null) {
            logger.debug("***DIM WEIGHT***:" + dimWeightStr + ":");
            try {
                double dimWeightDbl = Double.parseDouble(dimWeightStr);
                if (dimWeightUOM != 'K') {
                    BigDecimal bd = new BigDecimal(dimWeightDbl/2.2);
                    bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
                    dimWeightDbl = bd.doubleValue(); 
                }
                dimWeightStr = Double.toString(dimWeightDbl);
                dimWeightStr = convertTo10ths(dimWeightStr);
                shipmentVO.set_dimnl_wgt(Integer.parseInt(dimWeightStr));
            } catch (NumberFormatException nfe) {
                logger.info("Found invalid dim weight: " + ml.getWeight_qty().stringValue());
            }
        } 
        
        // Get shipment weight and convert to 100ths of lbs or kilos
        if (sp.hasShipment_weight()) {
            String shipmentWeight100ths = convertTo100ths(sp.getShipment_weight().stringValue());
            try {
               shipmentVO.set_shpmt_wgt(Integer.parseInt(shipmentWeight100ths));
            } catch (NumberFormatException nfe) {
                logger.info("Found invalid weight: " + sp.getShipment_weight().stringValue());
            }
        }
        
        // get shipment uom
        if (sp.hasShipment_weight_uom()) {
            shipmentVO.set_shpmt_uom_cd((char)sp.getShipment_weight_uom().getChar(0));
        }
        
        // get Ship date
        if (sp.hasShip_date()) {
        	String shipDate = sp.getShip_date().stringValue();
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        	try {
        		Date date = sdf.parse(shipDate);
        		shipmentVO.set_ship_dt(date);
        	} catch (ParseException e) {
        		logger.error("ParseException " + e.toString());
        	}
        }
               
        // get Delivery date time
        if (sp.hasDelivery_date_time()) {
            Calendar cal = null;            
            try {
                cal = SEPDateConverter.getSepDate(sp.getDelivery_date_time().stringValue());
                shipmentVO.set_del_dt(cal);
            } catch (ParseException e) {
                logger.info("Found invalid delivery date: " + 
                        sp.getAcceptance_date_time().stringValue());
            }
        }

        // Get the special handling codes and append them into a string, should be up to 4 pairs
        if (sp.hasSpecial_handling_code_array()) {
            Special_handling_code_array shca = sp.getSpecial_handling_code_array();
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < shca.getSize(); i++) {
                Special_handling_cd entry = shca.get(i);
                sb.append(entry.stringValue());
            }    
            shipmentVO.set_spcl_hndlg_grp(sb.toString());
        }
        
        // Only present in track type of 31 DDEX, to get more information may need to get an ODA
        // or comment scan or both
        if (ml.hasCartage_agent_company_name()) {
            shipmentVO.set_crtg_agent_co_nm(ml.getCartage_agent_company_name().stringValue());
        }

        // Yes, available two places, not always present
        if (ml.hasPackage_contract_enhancement()) { // CE's, has decimal
            if (ce.hasDeclared_value_currency_code()) {
                shipmentVO.set_cstms_curr_cd(ce.getDeclared_value_currency_code().stringValue());
            }
            if (ce.hasCustoms_value()) {
                String penniesStr = convertTo100ths(ce.getCustoms_value().stringValue());
                try {
                    shipmentVO.set_cstms_value_amt(Integer.parseInt(penniesStr));
                } catch (NumberFormatException nfe) {
                    logger.info("Found invalid CE customs value: " + ce.getCustoms_value().stringValue());
                }
            }
        } else { // No decimal, track types 70 & 72 
            if (ml.hasCustoms_currency_code()) {
                shipmentVO.set_cstms_curr_cd(ml.getCustoms_currency_code().stringValue()); 
            }
            if (ml.hasCustoms_value()) {
                String penniesStr = null;
                if (ml.getCustoms_value().stringValue().indexOf('.') != -1) {
                    penniesStr = convertTo100ths(ml.getCustoms_value().stringValue());
                } else {
                    penniesStr = ml.getCustoms_value().stringValue();
                }
                
                try {
                    shipmentVO.set_cstms_value_amt(Integer.parseInt(penniesStr));
                } catch (NumberFormatException nfe) {
                    logger.info("Found invalid ML customs value: " + ml.getCustoms_value().stringValue());
                }
            }
        }

        // Get package count
        //shipment-pkg-count [ 441]
        if (sp.hasShipment_pkg_count()) {
            try {
                shipmentVO.set_shpmt_pkg_qt(Integer.parseInt(sp.getShipment_pkg_count().stringValue()));
            } catch (NumberFormatException nfe) {
                logger.info("Found invalid shipment package count: "  + sp.getShipment_pkg_count().stringValue());
            }
        }  

        //package-piece-qty  [ 598]
        if (ml.hasPackage_piece_qty()) {  
            try {
                shipmentVO.set_package_piece_qty(Integer.parseInt(ml.getPackage_piece_qty().stringValue()));
            } catch (NumberFormatException nfe) {
                logger.info("Found invalid package piece qty : "  + ml.getPackage_piece_qty().stringValue());
            }
        }

        //delivery-qty [ 976]
        if (ml.hasDelivery_qty()) {
            try {
                shipmentVO.set_delivery_qty(Integer.parseInt(ml.getDelivery_qty().stringValue()));
            } catch (NumberFormatException nfe) {
                logger.info("Found invalid delivery qty : "  + ml.getDelivery_qty().stringValue());
            } 
        }

        //skid-intact-flag [ 977]
        if (ml.hasSkid_intact_flag()) {
            shipmentVO.set_skid_intact_flag((char)ml.getSkid_intact_flag().getChar(0));
        }
        
        //quantity-observed-flag [ 979]
        if (ml.hasQuantity_observed_flag()) {
            shipmentVO.set_quantity_observed_flag((char)ml.getQuantity_observed_flag().getChar(0));
        }
        
        // est-avail-for-delv-dt [ 6]
        if (dpe != null){
        	if (dpe.hasEst_avail_for_delv_dt()){
        		Calendar cal = Calendar.getInstance(); 
        		try {
        			SimpleDateFormat dateFormatter = 
        				new SimpleDateFormat("yyyyMMdd");
        			Date d = dateFormatter.parse(
        					dpe.getEst_avail_for_delv_dt().stringValue());
        			if (d == null) {
        				logger.info("Could not parse Estimated available for delivery date: " + 
                    		dpe.getEst_avail_for_delv_dt().toString());
        			} else {
        				cal.setTime(d);
        				shipmentVO.set_est_avail_for_delv_dt(cal);
        			}
        		} catch (ParseException e) {
        			logger.info("Found invalid Estimated available for delivery date: " + 
                		dpe.getEst_avail_for_delv_dt().toString());
        		}
        	}
        }
        
        // The latest event timestamp, used to help with merging data into shipment table
        shipmentVO.set_last_event_tmstp(eventCreationTmstp);
        shipmentVO.set_last_event_track_type_cd(trackTypeCd);
        
        if (ml.hasTrack_location_code()) {
            shipmentVO.set_last_event_track_loc_cd(ml.getTrack_location_code().stringValue());
        }
        
        if (sp.hasSvc_commit_timestamp()) {        
            Calendar cal = null;
            try {
                cal = SEPDateConverter.getSepDate(sp.getSvc_commit_timestamp().stringValue());
                shipmentVO.set_commit_dt(cal);
            } catch (ParseException e) {
                logger.info("Found invalid commit date: " +
                        sp.getSvc_commit_timestamp().stringValue());
            }
        }
        
        return shipmentVO;
    }
    
    /**
     * This method will pull the shipper, recipient, actual delivery info, 
     * origin location and destination location from the Business Entity group.
     * @param aShipmentVO the shipmentVO, to plug the values into
     */
    private void extractMasterListInfo(ShipmentVO aShipmentVO) {
        if (ml.hasShipper_company_name()) {
            aShipmentVO.set_shpr_co_nm(ml.getShipper_company_name().stringValue());
        }
        if (ml.hasShipper_address_desc()) {
            aShipmentVO.set_shpr_addr_line_one_desc(ml.getShipper_address_desc().stringValue());
        }
        if (ml.hasShipper_addl_address_desc()) {
            aShipmentVO.set_shpr_addr_line_two_desc(ml.getShipper_addl_address_desc().stringValue());
        }
        if (ml.hasShipper_city_name()) {
            aShipmentVO.set_shpr_city_nm(ml.getShipper_city_name().stringValue());
        }
        if (ml.hasShipper_postal_code()) {
            aShipmentVO.set_shpr_pstl_cd(ml.getShipper_postal_code().stringValue());
        }
    	if (ml.hasShipper_country_code()) {
        	aShipmentVO.set_shpr_cntry_cd(ml.getShipper_country_code().stringValue());
        }
        if (ml.hasShipper_state_code()) {
            aShipmentVO.set_shpr_st_prov_cd(ml.getShipper_state_code().stringValue());
        }
        if (ml.hasShipper_phone_number()) {
            aShipmentVO.set_shpr_ph_nbr(ml.getShipper_phone_number().stringValue());
        }
        /**
         * Get Recipient information from master list if it exists.
         */    
        if (ml.hasRecipient_company_name()) {
            aShipmentVO.set_recp_co_nm(ml.getRecipient_company_name().stringValue());
        }
        if (ml.hasRecipient_address_desc()) {
            aShipmentVO.set_recp_addr_line_one_desc(ml.getRecipient_address_desc().stringValue());
        }
        if (ml.hasRecipient_addl_address_desc()) {
            aShipmentVO.set_recp_addr_line_two_desc(ml.getRecipient_addl_address_desc().stringValue());
        } 
        if (ml.hasRecipient_city_name()) {
            aShipmentVO.set_recp_city_nm(ml.getRecipient_city_name().stringValue());
        }
        if (ml.hasRecipient_postal_code()) {
            aShipmentVO.set_recp_pstl_cd(ml.getRecipient_postal_code().stringValue());
        }
    	if (ml.hasRecipient_country_code()) {
        	aShipmentVO.set_recp_cntry_cd(ml.getRecipient_country_code().stringValue());
        	logger.debug("ml.getRecipient_country_code = " + 
        			ml.getRecipient_country_code().stringValue());
        }
        if (ml.hasRecipient_state_code()) {
            aShipmentVO.set_recp_st_prov_cd(ml.getRecipient_state_code().stringValue());
        }
        if (ml.hasRecipient_phone_number()) {
            aShipmentVO.set_recp_ph_nbr(ml.getRecipient_phone_number().stringValue());
        }
        
        /**
         * Get Origin information from master list if it exists.
         */
        if (ml.hasOrigin_location_code()) {
        	aShipmentVO.set_orig_loc_cd(ml.getOrigin_location_code().stringValue());
        }
        /**
         * Get Destination information from master list if it exists.
         */ 
        if (ml.hasDest_location_code()) {
        	aShipmentVO.set_dest_loc_cd(ml.getDest_location_code().stringValue());
        }
    }
    
    /**
     * This method will pull the shipper, recipient, actual delivery info, origin location
     *   and destination location from the Business Entity group.
     * @param aShipmentVO the shipmentVO, to plug the values into
     */
    private void extractBusinessEntityInfo(ShipmentVO aShipmentVO) {       
        if (sp.hasBusiness_entities_grp()) {
            Business_entities_grp beg = sp.getBusiness_entities_grp();
            if (beg.hasBusiness_entity_grp_md()) {
                Business_entity_grp_md begmd = beg.getBusiness_entity_grp_md();
                for (int i = 0; i < begmd.getSize(); i++) {
                    Business_entity_grp entry = begmd.get(i);
                    if (entry.getEntity_type_cd().stringValue().equals("Shipper")) {
                        if (entry.hasCompany_name()) {
                            aShipmentVO.set_shpr_co_nm(entry.getCompany_name().stringValue());
                        }
                        if (entry.hasAddress_desc()) {
                            aShipmentVO.set_shpr_addr_line_one_desc(entry.getAddress_desc().stringValue());
                        }
                        if (entry.hasAddl_address_desc()) {
                            aShipmentVO.set_shpr_addr_line_two_desc(entry.getAddl_address_desc().stringValue());
                        }
                        if (entry.hasCity_name()) {
                            aShipmentVO.set_shpr_city_nm(entry.getCity_name().stringValue());
                        }
                        if (entry.hasPostal_cd()) {
                            aShipmentVO.set_shpr_pstl_cd(entry.getPostal_cd().stringValue());
                        }
                        if (entry.hasCountry_cd()) {
                            aShipmentVO.set_shpr_cntry_cd(entry.getCountry_cd().stringValue());
                        }
                        if (entry.hasState_province_cd()) {
                            aShipmentVO.set_shpr_st_prov_cd(entry.getState_province_cd().stringValue());
                        }
                        if (entry.hasPhone_number()) {
                            aShipmentVO.set_shpr_ph_nbr(entry.getPhone_number().stringValue());
                        }
                    } else {
                        if (entry.getEntity_type_cd().stringValue().equals("Recipient")) {
                            if (entry.hasCompany_name()) {
                                aShipmentVO.set_recp_co_nm(entry.getCompany_name().stringValue());
                            }
                            if (entry.hasAddress_desc()) {
                                aShipmentVO.set_recp_addr_line_one_desc(entry.getAddress_desc().stringValue());
                            }
                            if (entry.hasAddl_address_desc()) {
                                aShipmentVO.set_recp_addr_line_two_desc(entry.getAddl_address_desc().stringValue());
                            } 
                            if (entry.hasCity_name()) {
                                aShipmentVO.set_recp_city_nm(entry.getCity_name().stringValue());
                            }
                            if (entry.hasPostal_cd()) {
                                aShipmentVO.set_recp_pstl_cd(entry.getPostal_cd().stringValue());
                            }
                            if (entry.hasCountry_cd()) {
                                aShipmentVO.set_recp_cntry_cd(entry.getCountry_cd().stringValue());
                                logger.debug("entry.getCountry_cd() = " + 
                                		entry.getCountry_cd().stringValue());
                            }
                            if (entry.hasState_province_cd()) {
                                aShipmentVO.set_recp_st_prov_cd(entry.getState_province_cd().stringValue());
                            }
                            if (entry.hasPhone_number()) {
                                aShipmentVO.set_recp_ph_nbr(entry.getPhone_number().stringValue());
                            }
                        } else {
                            if (entry.getEntity_type_cd().stringValue().equals("Actual Delivery")) {
                                if (entry.hasName()) {
                                    aShipmentVO.set_actl_del_nm(entry.getName().stringValue());                                   
                                }
                                if (entry.hasAddress_desc()) {
                                    aShipmentVO.set_actl_addr_line_one_desc(entry.getAddress_desc().stringValue());
                                }
                            } else {
                                if (entry.getEntity_type_cd().stringValue().equals("Origin")) {
                                    if (entry.hasLocation_cd()) {
                                        aShipmentVO.set_orig_loc_cd(entry.getLocation_cd().stringValue());
                                    }
                                } else {
                                    if (entry.getEntity_type_cd().stringValue().equals("Destination")) {
                                        if (entry.hasLocation_cd()) {
                                            aShipmentVO.set_dest_loc_cd(entry.getLocation_cd().stringValue());
                                        }                                        
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * This method is used to classify a shipment as a MAWB, CRN or AWB.
     * It may not always be possible to tell, especially if there is no
     * association group.  For now, lets not force it to a decision.  If
     * we can't tell, its probably already been set by another event.
     * @param the ShipmentVO, which already contains the parent tracking
     *   number if it is present.
     * @return a string representing the type of shipment
     */
    private String classifyShipment(ShipmentVO aShipmentVO, AssociatedShipmentsHelper anAssocShipmentHelper) {
        // Check for AWB first, most easily detected
        
        // if base service cd is not an IPD service, then it must be an AWB,
        // regardless of what was determined by looking at the relationship code
        String baseServiceCd = null;
        if (sp.hasBase_service_cd()) {
            baseServiceCd = sp.getBase_service_cd().stringValue();
        }
        if (baseServiceCd != null) {
            if (!RiseConstants.ID.equals(baseServiceCd) &&
                !RiseConstants.ED.equals(baseServiceCd) &&
                !RiseConstants.DF.equals(baseServiceCd)) {
                return RiseConstants.AWB;
            }
        }
        
        // If this is a message as a result of a NOI, it is an AWB
        if (ml.hasPackage_noi_enhancement()) {
            return RiseConstants.AWB;
        }
        
        // If parent trkng number is set, and this is not an AWB,
        // it must be a CRN
        AssociatedShipmentVO parentAssocShipmentVO = anAssocShipmentHelper.getParent();
        if (parentAssocShipmentVO != null) {
            return RiseConstants.CRN;                
        }
        
        // Look in SP for an association that says it is a MAWB
        if (sp.hasAssoc_tracking_number_md()) {
            Enumeration enu = sp.getAssoc_tracking_number_md().elements();
            if (isMAWB(enu)) {
                return RiseConstants.MAWB;
            }
        }
        
        
        // we tried
        return RiseConstants.UNK;
    }

    /**
     * Look at the relation ship code in the associated group if present and
     * try to find a relation which defines it as a parent, which is a MAWB
     * @param aEnum the associated group
     * @return a boolean indicating if a MAWB has been found
     */
    private boolean isMAWB(Enumeration aEnum) {
        while(aEnum.hasMoreElements()) {
            Assoc_tracking_number_grp relatedDocumentElement = (Assoc_tracking_number_grp) aEnum.nextElement();
            if (relatedDocumentElement != null) {
                String relationshipCode = null;
                if (relatedDocumentElement.hasRelationship_cd()) {
                    relationshipCode = relatedDocumentElement.getRelationship_cd().stringValue();
                }
                if (relationshipCode != null) {
                    if (relationshipCode.equals("I")) {
                        return true;
                    }
                }
            }
        }
        return false;
    }    
    
    /**
     * Used to convert a string value to a value which will represent the value
     *   in hundreds.  Will add places if necessary.
     * @param aStr a string to convert to 100ths
     * @return a string representing the new value
     */
    private String convertTo100ths(String aStr) {
        StringBuffer sb = new StringBuffer(aStr);
        
        // Remove the '+' symbol from the string.
        int plusSymbolPos = sb.indexOf("+");
        if (plusSymbolPos != -1) {
        	sb.deleteCharAt(plusSymbolPos);
        }
        
        // Append 0's to the string.
        int decimalPos = sb.indexOf(".");
        if (decimalPos != -1) {
            sb.append("00");
        } else {
            sb.append(".00");
            decimalPos = sb.indexOf(".");
        }
        sb.deleteCharAt(decimalPos);
        return sb.substring(0, decimalPos + 2);
    }

    /**
     * Used to convert a string value to a value which will represent the value
     *   in tenths.  Will add places if necessary.
     * @param aStr a string to convert to 100ths
     * @return a string representing the new value
     */
    private String convertTo10ths(String aStr) {
        StringBuffer sb = new StringBuffer(aStr);
        int decimalPos = sb.indexOf(".");
        if (decimalPos != -1) {
            sb.append("0");
        } else {
            sb.append(".0");
            decimalPos = sb.indexOf(".");
        }
        sb.deleteCharAt(decimalPos);
        return sb.substring(0, decimalPos + 1);
    }
    
    
//    public static void main(String [] args) {
//
//    	String numberStr = "+100";
//
//        System.out.println(numberStr);
//        
//        //String results = convertTo100ths(numberStr);
//            
//        //System.out.println(results);
//    }
    
}
