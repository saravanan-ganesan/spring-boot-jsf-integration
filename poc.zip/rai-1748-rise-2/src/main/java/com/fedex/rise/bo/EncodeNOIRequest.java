package com.fedex.rise.bo;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Encodes NOI Request messages in XER, using FedEx ASN classes.
 * 
 * @author be379961
 *
 */
public class EncodeNOIRequest {
//	private static Logger logger = LogManager.getLogger(EncodeNOIRequest.class);
//
//	private Coder mCoder = null;
//    
//	/**
//	 * Constructor that gets XER coder.
//	 *
//	 */
//    public EncodeNOIRequest() {
//        mCoder = com.fedex.asn.UTF8String.Utf8string.getXERCoder();
//        mCoder.disableEncoderConstraints();
//    }
//    
    /**
     * Creates an XER encoded NOI Request messgage into ByteArrayOutputStream.
     * 
     * @param trackNum Track Number of NOI to be published.
     * @param shipDate Ship date of package.
     * @param trackDate Track date of package.
     * @param trackTime Track time of package.
     * @param noiUser NOI User, which identifies as RISE.
     * @param noiSystem NOI System, which identifies as RISE.
     * @return
     */
    public ByteArrayOutputStream encode(String trackNum,
            Date shipDate,
            String trackDate,
            String trackTime,
            String noiUser,
            String noiSystem) {
    	ByteArrayOutputStream byteArrayOutputStream = null;
    	try {
//    		byteArrayOutputStream = encodeMasterlist(
//    			noi(trackNum, shipDate,trackDate, trackTime, noiUser, 
//    					noiSystem));
    	} catch (Exception e ) {
    		//logger.error("Encode Failed Exception", e);
    	}   	
    	return byteArrayOutputStream;
    }
  
    /**
     * Creates the NOI request into a MasterList
     * 
     * @param trackNum Track Number
     * @param shipDate Ship Date
     * @param destPostalCd Destination Postal Code
     * @param destCountryCd Destination Country Code
     * @param originPostalCd Origin Postal Code
     * @param originCountryCd Origin Country Code
     * @param noiUser NOI user
     * @param recvTime Receive Time
     * @return
     */
//    private MasterList noi(String trackNum,
//            Date shipDate,
//            String trackDate,
//            String trackTime,
//            String noiUser,
//            String noiSystem) {
//
//    	MasterList     myMasterList     = new MasterList();
//    	NOIEnhancement myNOIEnhancement = new NOIEnhancement();
//    	Noi_requests   myNOIRequests    = new Noi_requests();
//
//    	myMasterList.setPackage_noi_enhancement(myNOIEnhancement);
//    	myNOIEnhancement.setNoi_requests(myNOIRequests);
//
//    	SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
//    	
//    	// Populate some fields for the NOI request
//    	Noi_request myNOIRequest = new Noi_request();
//    	myNOIRequest.setNoi_system(new IA5String(noiSystem));
//    	myNOIRequest.setNoi_user(new IA5String(noiUser));
//    	myNOIRequests.add(myNOIRequest);
//
//    	// Put the rest of the data in the MasterList
//    	myMasterList.setTrack_item_number(new IA5String(trackNum));
//    	myMasterList.setShip_date(new IA5String(sdfDate.format(shipDate)));
//    	
//    	myMasterList.setTrack_type(new IA5String("NR"));
//
//    	// Time and Date fields
//    	myMasterList.setTrack_scan_time(new IA5String(trackTime));
//    	myMasterList.setTrack_date(new IA5String(trackDate));
//
//    	return myMasterList;
//    }
//
//    /**
//     * Encodes the masterlist into an XER.
//     * 
//     * @param masterlist
//     * @return
//     * @throws EncodeFailedException
//     * @throws EncodeNotSupportedException
//     */
//    private ByteArrayOutputStream encodeMasterlist(MasterList masterlist) 
//    	throws EncodeFailedException, EncodeNotSupportedException {
//    	ByteArrayOutputStream out = new ByteArrayOutputStream();
//    	mCoder.encode(masterlist,out);
//    	return out;
//    }
}
