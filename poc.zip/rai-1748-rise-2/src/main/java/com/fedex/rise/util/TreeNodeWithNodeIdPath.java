package com.fedex.rise.util;

import org.apache.myfaces.custom.tree2.TreeNodeBase;

/**
 * TreeNode that has NodeIdPath, tree node path e.g. "0:0:1:0"
 * 
 * This class is needed because the TreeNodeBase only has an Identifier that 
 * we are using to store the key values of the node item (e.g. the 
 * shipperNbr:groupNbr:LaneNbr:SvcType) and thus we can traverse the tree2
 * object with this id.  
 */
public class TreeNodeWithNodeIdPath extends TreeNodeBase {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
   
    /** path to the node, via ids, 0:0:1:0 */
    private String nodeIdPath;
   
    /** constructor */
    public TreeNodeWithNodeIdPath(String type, String description, String identifier, boolean leaf, String nodeIdPath) {
        super(type, description, identifier, leaf);
        this.nodeIdPath = nodeIdPath; 
    }
   
    /**
     * get node id path (e.g. 0:0:1:0)
     * @return path
     */
    public String getNodeIdPath() {
        return nodeIdPath; 
    }
   
    /**
     * set node id path (e.g. 0:0:1:0)
     * @param nodeIdPath
     */
    public void setNodeIdPath(String nodeIdPath) {
        this.nodeIdPath = nodeIdPath; 
    }
    
    /**
     * get the short node identifier, which is just the node id not the path
     * @return id title
     */
    public String getIdentifierTitle() {
        String nodes[] = getIdentifier().split(":");
        // for now only showing the account id, which is the account number
        if (getType().equals("account") && nodes.length>1) {
            return nodes[1];
        } else {
            return "";
        }
    }
   
}
    
