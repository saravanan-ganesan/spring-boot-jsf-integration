package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;


public class SearchVO implements Serializable {


	
	
	
	
	
	
	

}