package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

//Change for WR #135494 by Wipro Surge Uplift : Java class added 

public class STAT79Resolver extends Resolver{
	
private static ArrayList _scans = new ArrayList();
    
    private static STAT79Resolver _instance = new STAT79Resolver();

    static {
        // Scans of interest
        _scans.add(RiseConstants.STAT);        
    };
  
    private STAT79Resolver() {};


	public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
		// TODO Auto-generated method stub
		if ((_scans.contains(anEventVO.get_track_type_cd())) && 
        		anEventVO.get_track_excp_cd().equalsIgnoreCase("79")||
            DeliveryResolver.getInstance().isResolved(anEventVO, anIssueVO)) {
            return true;
		}
		return false;
	}

	public static Object getInstance() {
		
		  return _instance;
	}

}
