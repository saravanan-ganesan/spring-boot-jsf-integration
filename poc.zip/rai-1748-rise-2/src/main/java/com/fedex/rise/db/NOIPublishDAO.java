package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.NOIPublishVO;

/**
 * NOI Publish DAO to the database.
 * 
 * @author be379961
 *
 */
public class NOIPublishDAO extends DatabaseDAO {
	
    /** Logger */
    private static Logger logger = LogManager.getLogger(NOIPublishDAO.class);

    /**
     * Default constructor for DatabaseDAO.
     */
    public NOIPublishDAO() {
    	super();
    }
    
    /**
     * This method is used to persist a record into the NOI_PUBLISH table for 
     * research.
     *
     * @param aNOIPublishVO  
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void doPersist(NOIPublishVO aNOIPublishVO) throws ServiceLocatorException, SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            NOIPublishPersister persister = new NOIPublishPersister(connection);
            persister.persist(aNOIPublishVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    public void update(NOIPublishVO aNOIPublishVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            NOIPublishUpdater updater = new NOIPublishUpdater(connection);
            updater.update(aNOIPublishVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Get a row from the NOI_PUBLISH table of a tracking number to be 
     * published.
     * 
     * @return NOIPublishVO of the NOI to be published.
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public NOIPublishVO getNOIPublishRow() throws SQLException, ServiceLocatorException {
        Connection connection = null;
        NOIPublishVO result = null;
        try {
            connection = initializeConnection(true);
            NOIPublishAccessor accessor = new NOIPublishAccessor(connection);
            result = accessor.getNOIPublishRow();
        } finally {
            closeConnection(connection);
        }
        return result;
    }
    
    /**
     * Delete the to the return tracking number specified in the VO.
     * 
     * @param aNOIPublishVO VO of the tracking number to be deleted.
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void deleteRow(NOIPublishVO aNOIPublishVO) throws ServiceLocatorException, SQLException {
        Connection connection = null;
        try {
            connection = initializeConnection(true);
            NOIPublishPersister persister = new NOIPublishPersister(connection);
            persister.deleteRow(aNOIPublishVO);
        } finally {
            closeConnection(connection);
        }
    }
    
}
