package com.fedex.rise.ese;

// Not all events have associated groups!
// MAWB's always seem to have shipment profiles
// May have relation ship in masterlist, but not ship profile, gonna have to look at both, SP first

public class AssociatedShipmentExtractor {// extends BaseEventExtractor {
//    
//    private static Logger logger = LogManager.getLogger(AssociatedShipmentExtractor.class);
//    
//
//    
//    // A list of associated airbills, paperwork and returns
//    private List _assocAirbills = new ArrayList();
//    
//    public AssociatedShipmentExtractor(EnhancedEvent anEE) throws ESEParseException {
//        super(anEE);
//    }
//    
//    /**
//     * This constructor can use a BaseEventExtractor which has already parsed the
//     * base events.
//     * @param aBaseEventExtractor a base event extractor which has already parsed its data
//     * @throws ESEParseException if part of the message is missing, and we desparately need it
//     */
//    AssociatedShipmentExtractor(BaseEventExtractor aBaseEventExtractor)
//                   throws ESEParseException {
//        super(aBaseEventExtractor);     
//    }
//    
//    /**
//     * Find related return/paperwork
//     * @param anAssociatedShipmentVO the VO to contain the return tracking info
//     */
//    public List extract() throws ESEParseException {
//        // Look in special place for return trkng item in ML
//        // get return track number, only found in track type 07, exception cd 14
//        if (ml.hasReturn_track_item_number()) {
//            if (logger.isDebugEnabled()) {
//                logger.debug("Found Return Track number in Master List " +
//                        ml.getReturn_track_item_number().stringValue());
//            }
//            AssociatedShipmentVO anAssociatedShipmentVO = 
//                new AssociatedShipmentVO(trackItemNumber,
//                                         trackItemUniqNumber,
//                                         ml.getReturn_track_item_number().stringValue(),
//                                         null,  // NO unique ID in this case
//                                         RiseConstants.RETURN);
//            if (!_assocAirbills.contains(anAssociatedShipmentVO)) {
//                _assocAirbills.add(anAssociatedShipmentVO);
//            }
//            
//        }        
//        
//        // Look in shipment profile
//        if (sp.hasAssoc_tracking_number_md()) {
//            Enumeration enu = sp.getAssoc_tracking_number_md().elements();
//            findInterestedAssociations(enu);
//        }
//        
//        // Look in master list
//        if (ml.hasAssoc_tracking_number_md()) {
//            Enumeration enu = ml.getAssoc_tracking_number_md().elements();
//            findInterestedAssociations(enu);
//        }
//        
//        return _assocAirbills;
//    }
//    
//    
//    private void findInterestedAssociations(Enumeration aEnum) {
//        if (aEnum != null) {
//            while(aEnum.hasMoreElements()) {
//                Assoc_tracking_number_grp relatedDocumentElement = (Assoc_tracking_number_grp) aEnum.nextElement();
//                if (relatedDocumentElement != null) {
//                    String relationshipCode = null;
//                    String associationType = null;
//                    if (relatedDocumentElement.hasRelationship_cd()) {
//                        relationshipCode = relatedDocumentElement.getRelationship_cd().stringValue();
//                    }
//                    if (relatedDocumentElement.hasAssociation_type()) {
//                        associationType = relatedDocumentElement.getAssociation_type().stringValue();
//                    }
//                    if ((relationshipCode != null) && (associationType != null)) {
//                        // Parent
//                        if ((relationshipCode.equals("P")) && (associationType.equals("T"))) {
//                            addAssocTrkngItem(relatedDocumentElement, RiseConstants.PARENT); 
//                        } else {
//                            // Return
//                            if ((relationshipCode.equals("B")) && (associationType.equals("R"))) {
//                                addAssocTrkngItem(relatedDocumentElement, RiseConstants.RETURN);
//                            } else {
//                                // Paperwork
//                                if ((relationshipCode.equals("C")) && (associationType.equals("P"))) {
//                                    addAssocTrkngItem(relatedDocumentElement, RiseConstants.PAPERWORK);
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    
//    /**
//     * Will add the associated trkng info if not already in list
//     * @param aRelatedTrkngItem SEP structure containing related info
//     * @param anAssocTrackTypeCd RISE value indicating type of relationship
//     */
//    private void addAssocTrkngItem(Assoc_tracking_number_grp aRelatedTrkngItem, char anAssocTrackTypeCd) {        
//        String assoc_trkng_item_nbr = null;
//        String assoc_trkng_item_unique_id = null;
//        if (aRelatedTrkngItem.hasTracking_nbr()) {
//            assoc_trkng_item_nbr = aRelatedTrkngItem.getTracking_nbr().stringValue();
//        }
//        if (aRelatedTrkngItem.hasTracking_item_unique_id()) {
//            assoc_trkng_item_unique_id = aRelatedTrkngItem.getTracking_item_unique_id().stringValue();
//        }           
//
//        AssociatedShipmentVO anAssociatedShipmentVO = 
//            new AssociatedShipmentVO(trackItemNumber,
//                                     trackItemUniqNumber,
//                                     assoc_trkng_item_nbr,
//                                     assoc_trkng_item_unique_id,
//                                     anAssocTrackTypeCd); 
//        
//        if (!_assocAirbills.contains(anAssociatedShipmentVO)) {
//            _assocAirbills.add(anAssociatedShipmentVO);
//        }        
//    }
//        
}
