package com.fedex.rise.convert;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class will convert an ExceptionCd to a FedEx Exception description
 */
public class CalendarConverter implements Converter {

    /** logger */
    private static final Log log = LogFactory.getLog(CalendarConverter.class);
    
    private final SimpleDateFormat outputFormatLong = new SimpleDateFormat("MM/dd/yyyy HH:mm");
    private final SimpleDateFormat outputFormatShort = new SimpleDateFormat("MM/dd/yyyy");
    
    /**
     * Default constructor
     */
    public CalendarConverter() {
        super();
        if (log.isDebugEnabled()) log.debug("Constructed");
    }

    /**
     * Convert the Exception cd to a Exception description
     */
    public Object getAsObject(FacesContext context, UIComponent component, String calendar) {
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + calendar);
        return getAsString(context, component, calendar);
    }   

    /**
     * Convert the Exception cd to a Exception description
     */
    public String getAsString(FacesContext context,  UIComponent component, Object calendar) {
        //if (log.isDebugEnabled()) log.debug("GetAsString(): " + calendar);
        String type = (String) component.getAttributes().get("type");
        SimpleDateFormat outputFormat = outputFormatLong;
        if ((type != null) && (type.equals("short"))) {
            outputFormat = outputFormatShort;
        }
        if (calendar == null)
            return null;
        else  {
            outputFormat.setCalendar(((Calendar)calendar));
            return outputFormat.format(((Calendar)calendar).getTime());    
        }
    }
}
