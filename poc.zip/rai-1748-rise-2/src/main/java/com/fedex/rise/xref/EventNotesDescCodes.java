package com.fedex.rise.xref;

import java.util.HashMap;

public class EventNotesDescCodes {
    //  Contains all the codes stored in the EventNotes column, and what they mean
    public final static HashMap eventCodes = new HashMap();
    
    public static final String COMMENTS = "COMM";
    public static final String CONTAINER_NBR = "CONT_NBR";
    public static final String CONS_NBR = "CONS_NBR";
    public static final String CER_CTRL_NBR = "CER_CTRL_NBR";
    public static final String CER_QUEUE_TYPE = "CER_QUEUE_TYPE";
    public static final String DOOR_TAG = "DOORTAG";
    public static final String STATION_ETA_TIME = "STTN_ETA_TM";
    public static final String FUTURE_DATE = "FUTUR_DT";
    public static final String REATTEMPT_DELIVERY_TIME = "RATMP_DEL_TM";
    public static final String DELVRD_ADDR_DESC = "DLVD_ADDR";
    public static final String RECP_ADDR_DESC = "RECP_ADDR";
    
    static {
        eventCodes.put(COMMENTS, "Comments");
        eventCodes.put(CONTAINER_NBR, "Container Number");
        eventCodes.put(CONS_NBR, "CONS Number");
        eventCodes.put(CER_CTRL_NBR, "CER Cntrl Number");
        eventCodes.put(CER_QUEUE_TYPE, "CER Queue");
        eventCodes.put(DOOR_TAG, "Door Tag");
        eventCodes.put(STATION_ETA_TIME, "Station ETA Time");
        eventCodes.put(FUTURE_DATE, "Reattempt");
        eventCodes.put(REATTEMPT_DELIVERY_TIME, "by");
        eventCodes.put(DELVRD_ADDR_DESC, "Address to");
        eventCodes.put(RECP_ADDR_DESC, "Address to");
    }
    
    public static String lookupCd(String aCode) {
        return (String)eventCodes.get(aCode);
    }

}

