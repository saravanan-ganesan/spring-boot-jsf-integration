package com.fedex.rise.util;


/**
 **************************************************************************
 *
 * This class contains constants used to find Services via the ServiceLocator
 *
 **************************************************************************
 */

public class ServiceLocatorConstants 
{
    final static public String eseEventRemoteJNDIName = "ejb/ESEEventRemote";
    final static public String ShipmentRemoteJNDIName = "webejb/ShipmentEJBRemote";
    final static public String UserRemoteJNDIName = "webejb/UserEJBRemote";
    final static public String SearchRemoteJNDIName = "webejb/SearchEJBRemote";
    final static public String ShipperRemoteJNDIName = "webejb/ShipperEJBRemote";
    final static public String SystemMessageRemoteJNDIName = "webejb/SystemMessageEJBRemote";
}
