package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.issue.RiseIssues;
import com.fedex.rise.bo.status.StatusCalculator;
import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.util.SpecialHandlingXlator;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentCommentVO;
import com.fedex.rise.vo.ShipmentVO;
import com.fedex.rise.xref.HandlingCodesDesc;

/**
 * CRN bean
 */
public class CrnBean implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    /** logger */
    private static final Log log = LogFactory.getLog(CrnBean.class);
  
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
   
    private ShipmentVO shipment;
    private List shipmentReferences = new ArrayList();
    private List comments = new ArrayList();
    private List events = new ArrayList();
    private List issues = new ArrayList();
    /** list of AssociatedShipmentVO, for return airbills */
    private List associatedShipments = new ArrayList();
   
    /** flag to indicate whether to resolve the issue or not */
    private boolean _resolveIssue = false;
   
    /** new comment to add */
    private String _comment;
   
    
    /**
     * Construct new CRN.
     * 
     * @param shipment
     * @param shipmentReferences
     * @param associatedShipments
     * @param comments
     * @param events
     * @param issues
     */
    public CrnBean(ShipmentVO shipment, List shipmentReferences, List associatedShipments, List comments, List events, List issues) {
        super();
        this.shipment = shipment;
        this.shipmentReferences = shipmentReferences;
        this.associatedShipments = associatedShipments;
        this.comments = comments;
        this.events = events;
        this.issues = issues;
    }

    /**
     * Used to determine if the Piece Count Verification
     * or Appointment Delivery special fields should be
     * displayed on the GUI
     * @return
     */
    public boolean isPCVorAPD() {
        String handlingCodes = shipment.get_spcl_hndlg_grp();
        StringBuffer sb = new StringBuffer((String)handlingCodes);

        while (sb.length() > 0) {
          String handlingCd = sb.substring(0, 2);
          sb.delete(0, 2);
          if (handlingCd.equals(RiseConstants.PCV) || 
             (handlingCd.equals(RiseConstants.APD))) {
              return true;
          }
        } 
        return false;
    }
    
    public String getSpecialHandlingCdTranslation() {
        return SpecialHandlingXlator.getSpecialHandlingCdTranlation(shipment.get_spcl_hndlg_grp());
    }
    
    /**
     * @return the comments
     */
    public List getComments() {
        return comments;
    }

    /**
     * @return the events
     */
    public List getEvents() {
        return events;
    }

    /**
     * @return the issues
     */
    public List getIssues() {
        return issues;
    }

    /**
     * @return the shipment
     */
    public ShipmentVO getShipment() {
        return shipment;
    }

    /**
     * Return the delivery Date as a String (MM/dd/yyyy)
     * @return delivery Date
     */
    public String getDeliveryDateStr() {
        if (shipment.get_del_dt() == null)
            return "";
        
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        return formatter.format(shipment.get_del_dt().getTime()); 
    }
    
    /**
     * Return the Ship Date as a Month String (MM)
     * @return Ship Date Month
     */
    public String getShipDateMonthStr() {
        if (shipment.get_ship_dt() == null)
            return "";
        Calendar shipdt = Calendar.getInstance();
        shipdt.setTimeInMillis(shipment.get_ship_dt().getTime());
        
        SimpleDateFormat formatter = new SimpleDateFormat("MM");
        return formatter.format(shipdt.getTime()); 
    }
    
    /**
     * Return the Ship Date as a Day String (dd)
     * @return Ship Date Month
     */
    public String getShipDateDayStr() {
        if (shipment.get_ship_dt() == null)
            return "";
        Calendar shipdt = Calendar.getInstance();
        shipdt.setTimeInMillis(shipment.get_ship_dt().getTime());
        
        SimpleDateFormat formatter = new SimpleDateFormat("dd");
        return formatter.format(shipdt.getTime()); 
    }
    
    /**
     * Return the Ship Date as a Year String (yyyy)
     * @return Ship Date Month
     */
    public String getShipDateYearStr() {
        if (shipment.get_ship_dt() == null)
            return "";
        Calendar shipdt = Calendar.getInstance();
        shipdt.setTimeInMillis(shipment.get_ship_dt().getTime());
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
        return formatter.format(shipdt.getTime()); 
    }
    
    /**
     * Return the most recent scan event (track type).
     * @return the shipment status
     */
    public String getStatus() {
        StringBuffer status = new StringBuffer();
        if (shipment.get_last_stat_desc() != null) {
            status.append(StatusCalculator.getStatusDesc(shipment.get_last_stat_desc()));
        }
        if (shipment.get_last_event_track_loc_cd() != null) {
            status.append(" @ ");
            // append last status location, since this field is new, if it is null, use old last event location 
            if (shipment.get_last_stat_track_loc_cd() == null) 
               status.append(shipment.get_last_event_track_loc_cd());
            else
               status.append(shipment.get_last_stat_track_loc_cd());
        }
        
        return status.toString();
    }

    /**
     * @return the shipmentReferences
     */
    public List getShipmentReferences() {
        return shipmentReferences;
    }
    
    /**
     * @return the associatedShipments
     */
    public List getAssociatedShipments() {
        return associatedShipments;
    }

    /**
     * @param associatedShipments the associatedShipments to set
     */
    public void setAssociatedShipments(List associatedShipments) {
        this.associatedShipments = associatedShipments;
    }
    
    /**
     * Get DEXStr
     * @return DEX, concat all DEX comma delimited
     */
    public String getDEXStr() {
       if (events!=null && events.size()>0) {
           // DEX scans, show all DEX scans
           StringBuffer eventStr = new StringBuffer();
           for (Iterator itr2=events.iterator(); itr2.hasNext(); ) {
               EventBean event = (EventBean)itr2.next();
               if (event.get_track_type_cd().contains("DEX")) {
                   if (eventStr.length()>0){
                       eventStr.append(", ");
                   }
                   eventStr.append(event.get_track_type_cd());
               }
           }
           return eventStr.toString();
       } else {
           // NO DEX scans
           return "";                 
       }
    }
    
// Start Change for WR #135494 by Wipro Surge Uplift
    
    /**
     * Get PUX_STAT_Str
     * @return PUX/STAT, concat all PUX/STAT comma delimited
     */
    public String getPUX_STAT_Str() {
       if (events!=null && events.size()>0) {
           StringBuffer eventStr = new StringBuffer();
           String strVal = "";
           List trckTypeList=new ArrayList();
           
           for (Iterator itr2=events.iterator(); itr2.hasNext(); ) {
               EventBean event = (EventBean)itr2.next();
               trckTypeList.add(event.get_track_type_cd());
               
               if ((event.get_track_type_cd().contains("PUX"))||(event.get_track_type_cd().contains("STAT")) && (event.get_track_excp_cd().contains("79")))
            	{
            	   if (eventStr.length()>0){
                       eventStr.append(", ");
                   }
                   eventStr.append(event.get_track_type_cd());
                   eventStr.append(event.get_track_excp_cd());
                   log.info("eventStr"+eventStr);
                   if(trckTypeList.contains("PUX(79)") && trckTypeList.contains("STAT(79)"))
                   {     
                          strVal="STAT79";                      
                       
                   }
                   else if(trckTypeList.contains("PUX(79)") && !(trckTypeList.contains("STAT(79)")))
                   {                          
                          strVal="PUX79";                  
                 
                   }
            	   
               }

             }//end of for loop
           return strVal;
       } else {
           // NO PUX/STAT scans
           return "";                 
       }
    }
 // End Change for WR #135494 by Wipro 
    /**
     * Get IssuesStr
     * @return Issues, concat all issues comma delimited
     */
    public String getIssuesStr() {
       if (issues.size()>0) {
           // Issues, show all OPEN issues, not closed ones
           StringBuffer issueStr = new StringBuffer();
           for (Iterator itr2=issues.iterator(); itr2.hasNext(); ) {
               IssueBean issue = (IssueBean)itr2.next();
               if (issue.getIssue().getRes_dt() == null) {
                   if (issueStr.length()>0)
                       issueStr.append(", ");
                   issueStr.append(issue.getDesc());
               }
           }
           return issueStr.toString();
       } else {
           // NO Issues
           return "";                 
       }
    }
    
    /**
     * @return the isClearedCustomsIssue, true if we have a cleared customs issue
     */
    public boolean isClearedCustomsIssue() {
        boolean isClearedCustomsIssue = false;
        for (Iterator itr=issues.iterator(); itr.hasNext(); ) {
            IssueBean issue = (IssueBean)itr.next();
            // If we have a cleared customs issue then set flag on MAWB so we can show it
            // on UI with some special indicator
            if (RiseIssues.NOT_CLRD_CSTMS_DESC.getShortTextDesc().equals(issue.getDesc())) {
                isClearedCustomsIssue = true;
            }
        }
        return isClearedCustomsIssue;
    }

    /**
     * @return true if has Issues
     */
    public boolean hasIssue() {
       return (issues!=null && issues.size()>0);
    }

    /**
     * @return resolve flag, used to indicate if the issue should be resolved
     */
    public boolean getResolveIssue() {
       return _resolveIssue;
    }
    
    /**
     * set flag to indicate if the issue (filtered) should be resolved
     * @param resolve flag
     */
    public void setResolveIssue(boolean resolve) {
       _resolveIssue = resolve;
    }
    /**
     * Is the monitor allowed to edit.
     * Set boolean to indicate whether the request came from performance or not.
     * @return if came from performance, the flag is false, otherwise true.
     */
    public boolean isEditable(){
    	FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
    
        String fromScreen = (String)requestParams.get("from_screen");
        
        if (fromScreen != null){
        	if (fromScreen.equals("performance")){
        		return false;
        	}
        	if (fromScreen.equals("monitorReportDetailList")){
        		return false;
        	}
        }
        return true;
    }
    
    /**
     * Is the performance allowed to edit.
     * Set boolean to indicate whether the request came from performance or not.
     * @return if came from performance, the flag is true, otherwise false.
     */
    public boolean isPerformance(){
    	FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
    
        String fromScreen = (String)requestParams.get("from_screen");
        
        if (fromScreen != null){
        	if (fromScreen.equals("performance")){
        		return true;
        	}
        }
        return false;
    }
    
    /**
     * Is the monitor allowed to edit.
     * Set boolean to indicate whether the request came from monitor report or not.
     * @return if came from monitor, the flag is true, otherwise false.
     */
    public boolean isMonitor(){
    	FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
    
        String fromScreen = (String)requestParams.get("from_screen");
        
        if (fromScreen != null){
        	if (fromScreen.equals("monitorReportDetailList")){
        		return true;
        	}
        }
        return false;
    }

    /*-----------------------------------------------------------------------
     * Actions 
     *-----------------------------------------------------------------------
     */
   
    /**
     * Add a comment
     * @param comment a comment to add, can have formating (CR/LF, tabs, etc.)
     */
    public String addCommentAction() {
        if (_comment != null && _comment.length() > 0) {
            ShipmentCommentVO commentVO = new ShipmentCommentVO();
            commentVO.set_trkng_item_nbr(shipment.get_trkng_item_nbr());
            commentVO.set_trkng_item_uniq_nbr(shipment.get_trkng_item_uniq_nbr());
            commentVO.set_com_tmstp(new Date());
            commentVO.set_emp_nbr(UserBean.getLoggedInUser().getUserId());
            commentVO.set_com_desc(_comment);
        
            // update UI, so we don't have to go back to DB
            this.comments.add(commentVO);
        
            _comment = null;
            shipmentDelegate.saveComment(commentVO);
        }
        
        // TODO: handle errors
        return null;
    }
    
    /**
     * Resolve the selected Issues Action
     */
    public String markIssuesResolvedAction() {
        for (Iterator itr=issues.iterator(); itr.hasNext(); ) {
            IssueBean issue = (IssueBean)itr.next();
            // if issue is set to be resolved and hasn't already been resolved then mark it resolved
            if (issue.isResolved() && issue.getIssue().getRes_dt() == null) {
                issue.markIssueResolvedAction();
            }
        }
        
        // TODO: handle errors
        return null; 
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return _comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this._comment = comment;
    }
    
    public String createMonitorIssue() {
        log.info("Creating Monitor Issue");
        IssueVO newIssue = new IssueVO();
        newIssue.setTrkng_item_nbr(shipment.get_trkng_item_nbr());
        newIssue.setTrkng_item_uniq_nbr(shipment.get_trkng_item_uniq_nbr());
        newIssue.setIssue_type_cd(RiseIssues.MONITOR_ISSUE);
        newIssue.setIssue_loc_cd("    ");
        newIssue.setEvent_crtn_tmstp(new Date());
        newIssue.setIssue_tmstp(new Date());
        newIssue.setGrp_nbr(shipment.get_grp_nbr());
        newIssue.setAcct_nbr(shipment.get_acct_nbr());
        newIssue.setLane_nbr(shipment.get_lane_nbr());
        newIssue.setSvc_type_cd(shipment.get_svc_type_cd());
        newIssue.set_res_desc(null);
        newIssue.setRes_dt(null);
        newIssue.set_trackTypeCd(null);
        shipmentDelegate.createMonitorIssue(newIssue);
        IssueBean issueBean = new IssueBean(newIssue);
        
        // See if there is already a monitor issue, if so remove
        // and add a new one to the begining of the list
        IssueBean removeIssue = null;
        Iterator iter = issues.listIterator();
        while (iter.hasNext()) {
            IssueBean issue = (IssueBean)iter.next();
            if (issue.getIssue().equals(newIssue)) {
                removeIssue = issue;
            }
        }
        if (removeIssue != null) {
            issues.remove(removeIssue);
        }
        issues.add(0, issueBean);       
        return null;
    }
    
    /*-----------------------------------------------------------------------
     * Utility methods
     *-----------------------------------------------------------------------
     */
   
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      shipmentDelegate = new ShipmentDelegate();
    }
    

}
    