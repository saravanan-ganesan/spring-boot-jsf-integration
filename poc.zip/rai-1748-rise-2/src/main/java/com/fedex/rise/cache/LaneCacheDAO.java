package com.fedex.rise.cache;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.LaneDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.LaneVO;

public class LaneCacheDAO {
	private static Logger logger = LogManager.getLogger(LaneCacheDAO.class);
    
    private static HashMap _cache = new HashMap();
    private static TimedCache _timedCache = new TimedCache();
    
    static {
        populateCache();
    }
    
    private LaneCacheDAO() {
    }
    
	public static void populateCache() {
        logger.info("Loading Lane Cache");
		LaneDAO laneDAO = new LaneDAO();
        HashMap hm = new HashMap();
		try {
			List laneList = laneDAO.getLaneTable();
			Iterator laneIterator = laneList.iterator();
			while (laneIterator.hasNext()){
            	LaneVO laneVO = (LaneVO)laneIterator.next();
            	String key = new String(laneVO.get_orig_cntry_cd()+ "-" +
            			laneVO.get_dest_cntry_cd());
            	logger.debug("key = " + key);
            	hm.put(key, laneVO);
			}
            _cache = hm;
		}catch (SQLException sqle){
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
				+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
		} catch (ServiceLocatorException sle) {
		    logger.error("Service Locator Exception:", sle);
        }
	}
	
	public static LaneVO get(Object key) {
		LaneVO laneVO = (LaneVO)_cache.get(key);
		return laneVO;
	}
	
	public static boolean containsKey(Object key) {
        if (_timedCache.isTimeToLoad()) { populateCache(); };
		return _cache.containsKey(key);
	}
 
}
