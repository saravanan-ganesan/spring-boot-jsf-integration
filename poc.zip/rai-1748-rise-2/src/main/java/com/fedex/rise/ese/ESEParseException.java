package com.fedex.rise.ese;

/**
 * Used to indicate that a given ESE event has a problem
 * and cannot not be used.
 */

public class ESEParseException extends Exception {

    private static final long serialVersionUID = 1L;

    public ESEParseException(String aDesc) {
        super(aDesc);
    }
}
