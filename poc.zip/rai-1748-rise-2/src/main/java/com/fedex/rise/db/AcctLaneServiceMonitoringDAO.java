package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;
import com.fedex.rise.vo.LaneServiceVO;

public class AcctLaneServiceMonitoringDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AcctLaneServiceMonitoringDAO.class);
    
    public void addAccountLaneServiceMonitoring(AcctLaneServiceMonitoringVO anAccountLaneServiceMonitoringVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringPersister persister = new AcctLaneServiceMonitoringPersister(connection);
            persister.addAccountLaneServiceMonitoring(anAccountLaneServiceMonitoringVO);
        } finally {
            closeConnection(connection);
        }
    }
    /**
     * Add multiple monitors to an account, will determine which to add, 
     * delete, based on what is already in the database
     * NOTE: must all be same shipperNbr, accountNbr, laneNbr, empyNbr!
     * @throws SQLException
     * @throws ServiceLocatorException 
     *
   */
    
    public void addAccountLaneServiceMonitorings(List anAccountLaneServiceMonitoringVOs) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            if (anAccountLaneServiceMonitoringVOs == null || anAccountLaneServiceMonitoringVOs.size()<1)
                return;
           
            connection = initializeConnection();
          
            // get groupNbr, laneNbr, accountNbr and serviceType must be same on all in list!
            int groupNbr = ((AcctLaneServiceMonitoringVO)anAccountLaneServiceMonitoringVOs.get(0)).get_group_nbr();
            String accountNbr = ((AcctLaneServiceMonitoringVO)anAccountLaneServiceMonitoringVOs.get(0)).get_acct_nbr();
            int laneNbr = ((AcctLaneServiceMonitoringVO)anAccountLaneServiceMonitoringVOs.get(0)).get_lane_nbr();
            String serviceType = ((AcctLaneServiceMonitoringVO)anAccountLaneServiceMonitoringVOs.get(0)).get_svc_type_cd();
            
            // first get existing monitors for this account
            AcctLaneServiceMonitoringAccessor acctLaneServiceMonitoringAccessor = new AcctLaneServiceMonitoringAccessor(connection);
          List existingMonitors = acctLaneServiceMonitoringAccessor.getAcctLaneServiceMonitoring(groupNbr, accountNbr, laneNbr, serviceType);
           
            AcctLaneServiceMonitoringPersister persister = new AcctLaneServiceMonitoringPersister(connection);
          
            // determine which are adds or updates
            for (Iterator itr=anAccountLaneServiceMonitoringVOs.iterator(); itr.hasNext(); ) 
            {
                AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = (AcctLaneServiceMonitoringVO)itr.next();
               boolean updateIt = false;
                for (Iterator itr2=existingMonitors.iterator(); itr2.hasNext(); ) 
               {
                  AcctLaneServiceMonitoringVO existingAcctLaneServiceMonitoringVO = (AcctLaneServiceMonitoringVO)itr2.next();                  
                   if (acctLaneServiceMonitoringVO.get_emp_nbr().equals(existingAcctLaneServiceMonitoringVO.get_emp_nbr())) 
                   {
                        updateIt = true;
                        //remove from list so we don't iterate over it again and we
                         //can use remainder in list as our delete list
                        itr2.remove();
                       break;
                    }
               }
                
                if (updateIt) 
               {
                   // update lane                	
                   
                } else if (acctLaneServiceMonitoringVO.get_emp_nbr().equals("0"))
                {
                   // empNbr of 0 is a dummy lane, used to designate that there
                   // are no monitors to be assigned and any existing should be deleted
                	
                } else 
                {
                   // new so add it
                	
                    persister.addAccountLaneServiceMonitoring(acctLaneServiceMonitoringVO);
                }
            }//End First FOR Loop
            
            // Delete if removed which is remainder in existing list
            AcctLaneServiceMonitoringDeleter deleter = new AcctLaneServiceMonitoringDeleter(connection);
            
            for (Iterator itr=existingMonitors.iterator(); itr.hasNext(); ) 
            {
            	AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = (AcctLaneServiceMonitoringVO)itr.next();
            	
            	deleter.deleteAcctLaneServiceMonitoring(acctLaneServiceMonitoringVO);
            	
             }
            
        } 
            finally {
            closeConnection(connection);
            }
    }
    
    
    /**
     * Delete a specific monitor from a service
     * @param anAcctLaneServiceMonitoringVO
     * @throws SQLException  
     * @throws ServiceLocatorException 
     */
    public void deleteAccountLaneServiceMonitoring(AcctLaneServiceMonitoringVO anAcctLaneServiceMonitoringVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringDeleter deleter = new AcctLaneServiceMonitoringDeleter(connection);
            deleter.deleteAcctLaneServiceMonitoring(anAcctLaneServiceMonitoringVO);
        } finally {
            closeConnection(connection);
        }
    }
   
    /**
     * Delete monitors for all services for an account
     * @param groupNbr
     * @param accountNbr
     * @throws ServiceLocatorException 
     */
    public void deleteAccountLaneServiceMonitoring(int groupNbr, String accountNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringDeleter deleter = new AcctLaneServiceMonitoringDeleter(connection);
            deleter.deleteAcctLaneServiceMonitoring(groupNbr, accountNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Delete monitors for all services for a lane
     * @param groupNbr
     * @param accountNbr
     * @throws ServiceLocatorException 
     */
    public void deleteAccountLaneServiceMonitoring(int groupNbr, String accountNbr, int laneNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringDeleter deleter = new AcctLaneServiceMonitoringDeleter(connection);
            deleter.deleteAcctLaneServiceMonitoring(groupNbr, accountNbr, laneNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Delete monitors for the specified group, account, lane, and service
     * @param groupNbr
     * @param accountNbr
     * @throws ServiceLocatorException 
     */
    public void deleteAccountLaneServiceMonitoring(int groupNbr, String accountNbr, 
            int laneNbr, String serviceTypeCd) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringDeleter deleter = new AcctLaneServiceMonitoringDeleter(connection);
            deleter.deleteAcctLaneServiceMonitoring(groupNbr, accountNbr, 
                    laneNbr, serviceTypeCd);
        } finally {
            closeConnection(connection);
        }
    }
    /**
     * Delete selected monitors for the specified group, account, lane, and service
     * @param groupNbr
     * @param accountNbr
     * @throws ServiceLocatorException 
     */
    
    public List getMonitors(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd) 
    throws SQLException, ServiceLocatorException {
        List monitors = null;
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringAccessor accessor = new AcctLaneServiceMonitoringAccessor(connection);
            monitors = accessor.getAcctLaneServiceMonitoring(shipperNbr, accountNbr, laneNbr, serviceTypeCd);

        } finally {
            closeConnection(connection);
        }
        
        return monitors;
    }
}
