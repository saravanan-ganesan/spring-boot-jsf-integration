package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AssociatedShipmentVO;

public class AssociatedShipmentPersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(AssociatedShipmentPersister.class);
    
    public AssociatedShipmentPersister(Connection con) {
        super(con);
    }
    
    private static final String insertAssocShipmentSQL =
        "Insert into Associated_Shipment (" +
          "TRKNG_ITEM_NBR," +           // VARCHAR2(12) 
          "TRKNG_ITEM_UNIQ_NBR," +      // VARCHAR2(10)
          "ASSOC_TRKNG_ITEM_NBR," +     // VARCHAR2(12)
          "ASSOC_TRKNG_ITEM_UNIQ_NBR, " + // VARCHAR2(10)
          "ASSOC_TRACK_TYPE_CODE, " +
          "INPUT_TMSTP," +              // TimeStamp
          "LAST_UPDT_TMSTP)" +
        "values(?, ?, ?, ?, ?, SYSDATE, SYSDATE)";  
    
    /**
     * Will return false if duplicate detected.
     * @param anAssociatedShipmentVO
     * @return
     * @throws SQLException
     */
    public boolean persist(AssociatedShipmentVO anAssociatedShipmentVO) throws SQLException {
        try {
            setSqlSignature( insertAssocShipmentSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anAssociatedShipmentVO.get_trkng_item_nbr());
            pstmt.setString( 2, anAssociatedShipmentVO.get_trkng_item_uniq_nbr());
            pstmt.setString( 3, anAssociatedShipmentVO.get_assoc_trkng_item_nbr());
            pstmt.setString( 4, anAssociatedShipmentVO.get_assoc_trkng_item_uniq_nbr());
            pstmt.setString( 5, String.valueOf(anAssociatedShipmentVO.get_assoc_track_type_cd()));
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch (SQLException sqle) {
            if (sqle.getMessage().indexOf("ORA-00001") != -1) {
                logger.info("Associated shipment already exists:" + anAssociatedShipmentVO.get_assoc_trkng_item_nbr());
                return false;
            }
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
        return true;
    }    
}
