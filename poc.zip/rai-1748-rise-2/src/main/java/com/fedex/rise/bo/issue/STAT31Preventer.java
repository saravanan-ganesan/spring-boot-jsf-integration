package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class STAT31Preventer extends Preventer {
	private static Logger logger = LogManager.getLogger(STAT31Preventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static STAT31Preventer _instance = new STAT31Preventer();

    static {
        // The previous scan of a STAT 31.
    	_preventingScans.add(RiseConstants.STAT);
    }
  
    private STAT31Preventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	
        // If a STAT31 event previous to the current event.
    	if (_preventingScans.contains(anPastEventVO.get_track_type_cd()) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("31")){
        	logger.debug("Issue prevented by Stat 31");
        	return true;
        }
        
        return false;
    }

    public static STAT31Preventer getInstance() {
        return _instance;
    }
}
