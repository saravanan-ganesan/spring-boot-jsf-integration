// Added as part of RISE WSSO Integration
//WR#TBD - WSSO Integration changes
package com.fedex.rise.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class ReverseProxyPathAdjustmentFilter implements Filter {

	private static Logger logger = LogManager.getLogger(ReverseProxyPathAdjustmentFilter.class);
	// The LOG4J logger for this class

	// The WSSO server name
	private static String WSSO_SERVER;

	// The WSSO server port
	private static Integer WSSO_PORT;

	// The WSSO server scheme
	private static String WSSO_SCHEME;

	public static class ReverseProxyHttpRequestWrapper extends
			HttpServletRequestWrapper {
		private HttpRequestHelper requestHelper;
		
		public ReverseProxyHttpRequestWrapper(HttpServletRequest req) {
			super(req);
			requestHelper = new HttpRequestHelper(req);
		}

		public String getContextPath() {
			String ctx = requestHelper.getPathAdjustedForPathTrim(requestHelper.getContextPath());
			if (logger.isDebugEnabled()) {
				logger.debug("Context path adjusted, original: " + requestHelper.getContextPath() + ", modified: " + ctx);
			}
			return ctx;
		}
	}

	@Override
	public void destroy() {
		logger.info("Method: destroy()");
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest rq = (HttpServletRequest) req;
		HttpServletResponse rsp = (HttpServletResponse) res;
		String path = rq.getServletPath();
		if(path.endsWith(".jsf"))
			logger.info("User Requested path:   "+rq.getRequestURL()+"port:  "+rq.getServerPort());
		
		logger.debug("WSSO Requested URL path" + path);
		if (path.endsWith("logOutProxy.jsp")) {
			HttpSession session = rq.getSession(false);
			if (session != null)
				session.invalidate();
			rsp.sendRedirect("https://" + rq.getServerName() + "/logout");
			logger.debug("User Requested Logout");
		} else if (!path.startsWith("/a4j")) {
			chain.doFilter(new ReverseProxyHttpRequestWrapper((HttpServletRequest) req), res);
		} else {
			chain.doFilter(req, res);
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		logger.info("Method: init()");
	}
}
