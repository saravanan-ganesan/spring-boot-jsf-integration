package com.fedex.rise.cache;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.AccountDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AccountVO;

public class AccountCacheDAO {
	private static Logger logger = LogManager.getLogger(AccountCacheDAO.class);
    
    private static HashMap _cache = new HashMap();
    private static TimedCache _timedCache = new TimedCache();
    
    static {
        populateCache();
    }
    
    private AccountCacheDAO() {
    }
    
	private static void populateCache() {
        logger.info("Loading Account Cache");
        HashMap hm = new HashMap();
		AccountDAO accountDAO = new AccountDAO();
		try {
			List accountList = accountDAO.getAccountTable();
			Iterator acctIterator = accountList.iterator();
			while (acctIterator.hasNext()) {
            	AccountVO accountVO = (AccountVO)acctIterator.next();
            	hm.put(accountVO.get_acct_nbr(), accountVO);
			}
            _cache = hm;
		} catch (SQLException sqle){
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
				+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
		} catch (ServiceLocatorException sle) {
		    logger.error("Service Locator Excetion:", sle);
        }
	}
	
	public static AccountVO get(Object key) {
		AccountVO accountVO = (AccountVO)_cache.get(key);
		return accountVO;
	}
	
	public static boolean containsKey(Object key) {
        if (_timedCache.isTimeToLoad()) { populateCache(); };
        return _cache.containsKey(key);
	}
       
}
