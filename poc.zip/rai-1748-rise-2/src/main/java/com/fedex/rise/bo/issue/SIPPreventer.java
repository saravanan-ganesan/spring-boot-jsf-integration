package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class SIPPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(SIPPreventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static SIPPreventer _instance = new SIPPreventer();

    static {
        // The previous scans below will prevent a new issue being created.
       	_preventingScans.add(RiseConstants.VAN);
       	_preventingScans.add(RiseConstants.DEX);
       	_preventingScans.add(RiseConstants.ODA);
    }
  
    private SIPPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	// If it has been delivered, do not create any new events.
        if (DeliveryPreventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (_preventingScans.contains(anPastEventVO.get_track_type_cd())) {
            logger.debug("Issue prevented by SIP Preventer.");
            return true;
        }
        
        // If a STAT42 event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("42")){
        	logger.debug("Issue prevented by STAT 42");
        	return true;
        }
        // If a STAT43 event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("43")){
        	logger.debug("Issue prevented by STAT 43");
        	return true;
        }
    	// If a STAT19 (ODA equivalent) event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("19")){
        	logger.debug("Issue prevented by STAT 19");
        	return true;
        }
    	// If a STAT67 (ODA equivalent) event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("67")){
        	logger.debug("Issue prevented by STAT 67");
        	return true;
        }
    	// If a STAT33 (ODA equivalent) event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("33")){
        	logger.debug("Issue prevented by STAT 33");
        	return true;
        }
             
        return false;
    }

    public static SIPPreventer getInstance() {
        return _instance;
    }
}
