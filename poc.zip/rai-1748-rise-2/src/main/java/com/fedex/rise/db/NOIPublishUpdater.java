package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.NOIPublishVO;

public class NOIPublishUpdater extends OracleBase {
	private static Logger logger = LogManager.getLogger(NOIPublishUpdater.class);
	
	public NOIPublishUpdater(Connection con) {
        super(con);
    }
	
	 private static final String updateNOIPublishSQL =
	        "update NOTIFICATION_OF_INTEREST set " +
	        "RTRN_TRKNG_ITEM_NBR = ?, " +
	        "SHIP_DT = ?, " +
	        "NOI_RQST_TMSTP = ?, " +       
	        "PBLSH_DT = SYSDATE, " +
	        "NOI_INPUT_TMSTP = SYSDATE " +
	        "where " +
	           "RTRN_TRKNG_ITEM_NBR = ? and SHIP_DT = ?";
	           
	 public void update(NOIPublishVO aNOIPublishVO) throws SQLException {
		    
	        try {
	            setSqlSignature( updateNOIPublishSQL, false, logger.isDebugEnabled() );

	            pstmt.setString( 1, aNOIPublishVO.get_trk_item_nbr());
	             
	            if (aNOIPublishVO.get_ship_date() != null) {
	                java.sql.Date sqlDate = 
	                	new java.sql.Date(aNOIPublishVO.get_ship_date()
	                			.getTime());
	                pstmt.setDate(2, sqlDate);
	            } else {
	                pstmt.setNull(2, java.sql.Types.DATE);
	            }
	            
	            if (aNOIPublishVO.get_trk_date_time() != null) {
	            	
	            	java.sql.Timestamp sqlTimestamp = 
	            		new java.sql.Timestamp(aNOIPublishVO.get_trk_date_time().getTime());
	            	
	            	pstmt.setTimestamp(3, sqlTimestamp);
	            } else {
	            	pstmt.setNull(  3, java.sql.Types.DATE);
	            }
	            
	            pstmt.setString( 4, aNOIPublishVO.get_trk_item_nbr());
	            
	            if (aNOIPublishVO.get_ship_date() != null) {
	                java.sql.Date sqlDate = 
	                	new java.sql.Date(aNOIPublishVO.get_ship_date()
	                			.getTime());
	                pstmt.setDate(5, sqlDate);
	            } else {
	                pstmt.setNull(5, java.sql.Types.DATE);
	            }
	            
	            if (logger.isDebugEnabled()) {
	                logger.debug(pstmt.toString());
	            }
	        
	            int rowsUpdated = executeUpdate();

	            if ( rowsUpdated == 0) {
	                // NOI not updated
	                logger.error("NOI table not Updated for tracking nbr: " +
	                		aNOIPublishVO.get_trk_item_nbr() + "ship dt:" 
	                		+ aNOIPublishVO.get_ship_date().toString());
	            }

	        } catch (SQLException sqle) {
                logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                        + ": ErrorCode: " + sqle.getErrorCode()); 
	            throw sqle;
	        } finally {
	            try {
	                cleanResultSet();
	            } catch (SQLException sqle2) {
	                sqle2.printStackTrace();
	                throw sqle2;
	            }
	        }
	    }
}
