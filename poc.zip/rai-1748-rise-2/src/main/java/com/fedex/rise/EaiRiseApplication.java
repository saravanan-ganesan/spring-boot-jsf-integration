package com.fedex.rise;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.fedex.rise.constant.AppConstant;

/**
 * This is the main class to start the application
 * 
 * @author saravanan g
 *
 */

@CrossOrigin(origins = "*")
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({ AppConstant.APP_ROOT_PATH })
public class EaiRiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(EaiRiseApplication.class, args);
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

	
}
