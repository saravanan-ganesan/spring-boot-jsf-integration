package com.fedex.rise.config;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.oauth2.client.oidc.web.logout.OidcClientInitiatedLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.client.RestOperations;

/**
 * 
 * This configuration class is used Configures our application with Spring Security 
 * to restrict access to our API end points.
 *
 */
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
    ClientRegistrationRepository clientRegistrationRepository;
	
	/******************************************************************************
	 * This is method to configure the application security
	 * 
	 * @param http
	 * @return SecurityFilterChain filter chain to handle the security
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
    @Bean
    public SecurityFilterChain configure(HttpSecurity http) throws Exception {
    	
    	http.authorizeRequests()
    	.mvcMatchers("/login/**", "/logout.jsp", "/images/**", "/actuator*", "actuator/**", "/cache*", "/session*", "/cache/**", "/session/**").permitAll()
    	.antMatchers("/logout.jsp").permitAll()
    	.anyRequest().authenticated()
    	.and().oauth2Login()  
        .and().oauth2ResourceServer().jwt();
        
    	http.csrf().disable();
    	http.cors().disable();
    	http.headers().frameOptions().sameOrigin();
    	
    	http.logout().logoutSuccessHandler(oidcLogoutSuccessHandler())
    	.logoutSuccessUrl("/logout")
    	.clearAuthentication(true)
        .invalidateHttpSession(true)
        .deleteCookies("JSESSIONID");
    	
    	http.sessionManagement(session -> session.invalidSessionUrl("/logout"));
    	http.sessionManagement(session -> session.maximumSessions(1).sessionRegistry(sessionRegistry()));
    	
    	return http.build();
    	
    }
    
    
    /******************************************************************************
	 * This is method to used to responsible for "decoding" a JSON Web Token (JWT) 
	 * from it's compact claims representation format to a Jwt.
	 * 
	 * @param builder builder object
	 * @return JwtDecoder decoder implementation class
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
    @Bean
    public JwtDecoder jwtDecoder(RestTemplateBuilder builder) {
        RestOperations rest = builder
                .setConnectTimeout(Duration.ofSeconds(60000))
                .setReadTimeout(Duration.ofSeconds(60000))
                .build();

        NimbusJwtDecoder jwtDecoder = NimbusJwtDecoder.withJwkSetUri("https://dev-38289286.okta.com/oauth2/default/v1/keys").restOperations(rest).build();
        return jwtDecoder;
    }
    
    
    /******************************************************************************
	 * This is method to used to configure the logout
	 * 
	 * @param none
	 * @return OidcClientInitiatedLogoutSuccessHandler handler object
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
    private OidcClientInitiatedLogoutSuccessHandler oidcLogoutSuccessHandler() { 
        OidcClientInitiatedLogoutSuccessHandler successHandler = new OidcClientInitiatedLogoutSuccessHandler(clientRegistrationRepository);
        successHandler.setPostLogoutRedirectUri("http://localhost:8080/logout");
        return successHandler;
    }

    
    /******************************************************************************
	 * This is method to configure the session registry
	 * 
	 * @param none
	 * @return SessionRegistry registry object
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    
    /******************************************************************************
	 * This is method to configure the session listener
	 * 
	 * @param none
	 * @return ServletListenerRegistrationBean listener event object
	 * ----------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ----------------------------------------------------------------------------
	 * 1.0		12/25/2022	Saravanan	Initial code
	 ******************************************************************************/
    @Bean
    public ServletListenerRegistrationBean<HttpSessionEventPublisher> httpSessionEventPublisher() {
        return new ServletListenerRegistrationBean<HttpSessionEventPublisher>(new HttpSessionEventPublisher());
    }
}
