package com.fedex.rise.auth;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.config.ConfigurationManager;

/**
 * FedEx LDAP Authentication.  
 * 
 * TODO: get context from properties file or maybe setup in WebLogic
 */
public class LDAPAuth {

    private static Log log = LogFactory.getLog(LDAPAuth.class);
    // Get LDAP_URL from config file, production URL is default
    private static String LDAP_URL = ConfigurationManager.get("LDAP_URL", "ldap://directory.fedex.com:636/o=fedex,c=us");

    /**
     * Authenticate the user with LDAP
     * @param emplyNbr The user's employee number
     * @param password The user's password
     * @return true if valid user and password
     */
    public boolean authenticateUser(String emplyNbr, String password) {
        if (log.isDebugEnabled())
            log.debug("LDAP_URL="+LDAP_URL);
        
        // Set up environment for creating initial context
        Hashtable env = new Hashtable(5);
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, LDAP_URL);
        // Specify SSL
        env.put(Context.SECURITY_PROTOCOL, "ssl");
        // Authenticate as User and password 
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, "uid="+emplyNbr+",ou=People,o=fedex,c=us");
		env.put(Context.SECURITY_CREDENTIALS, password);

        DirContext ctx = null;
        try {
            // Create initial context
            ctx = new InitialDirContext(env);
            return true;  
        } catch (AuthenticationException ae) {
            // exception is thrown for invalid credentials
            log.info("Invalid user, " + ae.getMessage());
            return false;  
        } catch (NamingException ne) {
            log.info("Can't lookup user", ne);
            return false;
        } finally {
            // Close the context when we're done
            try {
                if (ctx != null) ctx.close();
            } catch (NamingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    //To Authenticate User with empNbr only in role_change.jsp
    public boolean changeUser(String emplyNbr) {
        if (log.isDebugEnabled())
            log.debug("LDAP_URL="+LDAP_URL);
        
        // Set up environment for creating initial context
        Hashtable env = new Hashtable(5);
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, LDAP_URL);
        // Specify SSL
        env.put(Context.SECURITY_PROTOCOL, "ssl");
        // Authenticate as User and password 
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, "uid="+emplyNbr+",ou=People,o=fedex,c=us");
		//env.put(Context.SECURITY_CREDENTIALS, password);

        DirContext ctx = null;
        try {
            // Create initial context
            ctx = new InitialDirContext(env);
            return true;  
        } catch (AuthenticationException ae) {
            // exception is thrown for invalid credentials
            log.info("Invalid user, " + ae.getMessage());
            return false;  
        } catch (NamingException ne) {
            log.info("Can't lookup user", ne);
            return false;
        } finally {
            // Close the context when we're done
            try {
                if (ctx != null) ctx.close();
            } catch (NamingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    /**
     * Get user information from LDAP
     * @param emplyNbr user to lookup
     */
    public HashMap getUserInfo(String emplyNbr) {
        if (log.isDebugEnabled())
            log.debug("LDAP_URL="+LDAP_URL);
        
        // return a nice key value pair Hashmap
        HashMap userAttrs = new HashMap();
        
        // Set up environment for creating initial context
        Hashtable env = new Hashtable(3);
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, LDAP_URL);
        // Specify SSL
        env.put(Context.SECURITY_PROTOCOL, "ssl");
        // Use anonymous authentication
        env.put(Context.SECURITY_AUTHENTICATION, "none");

        DirContext ctx = null;
        try {
            // Create initial context
            ctx = new InitialDirContext(env);

            /* For dev debugging, uncomment below */
           /*
            NamingEnumeration attrs = ctx.getAttributes("uid="+emplyNbr.trim()+",ou=People").getAll();
            // cycle through result set
            while (attrs.hasMore()) {
                Object attr = attrs.next();
                System.out.println(attr.toString());
            }
           */
            String[] attrIDs = {"cn", "sn", "givenName",  "fullName", "telephoneNumber", "mail"};
            Attributes attrs = ctx.getAttributes("uid="+emplyNbr.trim()+",ou=People", attrIDs);
            
            // return a nice key value pair Hashmap
            userAttrs.put("cn", (String)attrs.get("cn").get());
            userAttrs.put("sn", (String)attrs.get("sn").get());
            userAttrs.put("givenName", (String)attrs.get("givenName").get());
          // userAttrs.put("telephoneNumber", (String)attrs.get("telephoneNumber").get());
            Attribute attr = attrs.get("mail");
            if (attr != null)
               userAttrs.put("mail", (String)attr.getID());
            
            Attribute attrTele = attrs.get("telephoneNumber");
            if (attrTele != null)
                userAttrs.put("telephoneNumber", (String)attrTele.getID());
            
        } catch (NameNotFoundException nnfe) {
            // if no user name found, then handle error gracefully, not a problem
            log.info("Can't get User info: " + nnfe.getMessage());
        } catch (NamingException ne) {
            log.error("Can't get User info", ne);
        } catch (Exception e) {
            log.info("Exception is", e);
            e.printStackTrace();
        }finally {
            // Close the context when we're done
            try {
                if (ctx != null) ctx.close();
            } catch (NamingException e) {
                log.error("Can't close context", e);
            }
        }
        
        return userAttrs;

    }
       
    /**
     * Tester, prompts for a user and password
     * @param args
     */
//    public static void main(String[] args) {
//        
//        // Prompt for emplyNbr and password  
//        String emplyNbr = "";
//        String password = "";
//        try {
//            InputStreamReader sr = new InputStreamReader(System.in);
//            BufferedReader br    = new BufferedReader(sr);
//            System.out.println("Employee Nbr:");
//            emplyNbr = br.readLine();
//            System.out.println("Password:");
//            password = br.readLine();
//        } catch (IOException ioe) {
//            ioe.printStackTrace(); 
//            System.exit(1);
//        }
//
//        // Validate employee number and password
//        LDAPAuth auth = new LDAPAuth();
//        if (auth.authenticateUser(emplyNbr, password)) {
//           System.out.println("Authentication Successful");
//        } else {
//           System.out.println("Authentication Failed");
//        }
//        
//        //To validate User with empNbr only in role_change.jsp
//        if (auth.changeUser(emplyNbr)) {
//            System.out.println("Authentication Successful");
//         } else {
//            System.out.println("Authentication Failed");
//         }
//        
//        // Get user
//        HashMap attrs = auth.getUserInfo(emplyNbr);
//        try {
//            String givenName = (String) attrs.get("givenName");
//            String surName = (String)attrs.get("sn");
//            String commonName = (String) attrs.get("cn");
//            String email = (String) attrs.get("mail");
//            String telephone = (String) attrs.get("telephoneNumber");
//            System.out.println("CommonName=" + commonName);
//            System.out.println("GivenName=" + givenName);
//            System.out.println("SurName=" + surName);
//            System.out.println("Telephone=" + telephone);
//            System.out.println("Email=" + email);
//        } catch (Exception e2) {
//            e2.printStackTrace();
//        }
//    }
}
