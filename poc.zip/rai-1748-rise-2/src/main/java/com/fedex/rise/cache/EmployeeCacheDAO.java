package com.fedex.rise.cache;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.EmployeeDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EmployeeVO;

public class EmployeeCacheDAO {
	private static Logger logger = LogManager.getLogger(EmployeeCacheDAO.class);
    
    private static HashMap _cache = new HashMap();
    private static TimedCache _timedCache = new TimedCache();
    
    static {
        populateCache();
    }
    
    private EmployeeCacheDAO() {
    }
    
	private static void populateCache() {
        logger.info("Loading Employee Cache");
        HashMap hm = new HashMap();
        EmployeeDAO employeeDAO = new EmployeeDAO();
		try {
			List employeeList = employeeDAO.getAllMonitorEmployees();
			Iterator employeeIterator = employeeList.iterator();
			while (employeeIterator.hasNext()) {
            	EmployeeVO employeeVO = (EmployeeVO)employeeIterator.next();
            	hm.put(employeeVO.get_emp_nbr(), employeeVO);
			}
            _cache = hm;
		} catch (SQLException sqle){
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
				+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
		} catch (ServiceLocatorException sle) {
		    logger.error("Service Locator Excetion:", sle);
        }
	}
	
	public static EmployeeVO get(Object key) {
		EmployeeVO employeeVO = (EmployeeVO)_cache.get(key);
		return employeeVO;
	}
	
	public static boolean containsKey(Object key) {
        if (_timedCache.isTimeToLoad()) { populateCache(); };
        return _cache.containsKey(key);
	}
       
}
