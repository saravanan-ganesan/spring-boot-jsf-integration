package com.fedex.rise.ese;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.asn.UTF8String.common.Shpr_ref_notes_grp;
import com.fedex.asn.UTF8String.enhancedevent_.EnhancedEvent;
import com.fedex.asn.UTF8String.shipmentprofile_.ShipmentProfile.Shpr_ref_notes_group;
import com.fedex.rise.vo.ReferenceNoteVO;

/**
 * This class is used to extract the reference notes for the Reference Note table
 */
public class ReferenceNotesExtractor extends BaseEventExtractor {
    private static Logger logger = LogManager.getLogger(ReferenceNotesExtractor.class);
    
    public ReferenceNotesExtractor(EnhancedEvent anEE) throws ESEParseException {
        super(anEE);
    }
    
    /**
     * This constructor can use a BaseEventExtractor which has already parsed the
     * base events.
     * @param aBaseEventExtractor a base event extractor which has already parsed its data
     * @throws ESEParseExceptionif part of the message is missing, and we desparately need it
     */
    ReferenceNotesExtractor(BaseEventExtractor aBaseEventExtractor)
                           throws ESEParseException {
        super(aBaseEventExtractor);     
    }
    
    public List extract() throws ESEParseException {
        ArrayList set = new ArrayList();
        
        // have seen up to two or three reference notes, not always present
        if (sp.hasShpr_ref_notes_group()) {
            Shpr_ref_notes_group srng = sp.getShpr_ref_notes_group();
            for (int i = 0; i < srng.getSize(); i++) {
                ReferenceNoteVO referenceNoteVO = new ReferenceNoteVO();
                // tracking item number
                referenceNoteVO.set_trkng_item_nbr(trackItemNumber);
                
                // tracking item unique number
                referenceNoteVO.set_trkng_item_uniq_nbr(trackItemUniqNumber);
                
                Shpr_ref_notes_grp sgrp = srng.get(i);
                if (sgrp.hasRef_type_cd()) {
                    referenceNoteVO.set_ref_type_cd(sgrp.getRef_type_cd().stringValue());
                }
                if (sgrp.hasShpr_ref_notes()) {
                    referenceNoteVO.set_ref_note_desc(sgrp.getShpr_ref_notes().stringValue());
                }
                
                // must have something in this column to go in the database, have seen examples of having
                // a shpr_ref_notes, but no ref_type_cd
                if (referenceNoteVO.get_ref_type_cd() == null) {
                    referenceNoteVO.set_ref_type_cd("   ");
                }
                set.add(referenceNoteVO);
            }
        }
        return set;
    }
}
