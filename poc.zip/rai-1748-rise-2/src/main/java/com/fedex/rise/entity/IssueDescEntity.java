package com.fedex.rise.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ISSUE_DESC")
public class IssueDescEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "short_text_desc")
	private String shortTextDesc;
	
	@Column(name = "long_text_desc")
	private String longTextDesc;
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "issue_id")
	private IssueEntity issue;

}
