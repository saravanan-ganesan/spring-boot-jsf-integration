package com.fedex.rise.jms;

/**
 * VO that contains the JMS publish queue connection parameters.
 * 
 * @author be379961
 *
 */
public class JMSPublishConfig {
    private String _connFactoryStr;
	private String _queueStr;
	private String _tibjmsInitalContextFactoryStr;
	private String _providerURLStr;
	private String _noiUser;
	private String _noiSystem;
	
    /**
     * Default Constructor
     */
    public JMSPublishConfig() {
    }
    
    /**
     * @return the _connFactoryStr
     */
    public String get_connFactoryStr() {
        return _connFactoryStr;
    }
    /**
     * @param _connFactoryStr the _connFactoryStr to set
     */
    public void set_connFactoryStr(String _connFactoryStr) {
        this._connFactoryStr = _connFactoryStr;
    }
    /**
     * @return the _queueStr
     */
    public String get_queueStr() {
        return _queueStr;
    }
    /**
     * @param _queueStr the _queueStr to set
     */
    public void set_queueStr(String _queueStr) {
        this._queueStr = _queueStr;
    }
    /**
     * @return the _tibjmsInitalContextFactoryStr
     */
    public String get_tibjmsInitalContextFactoryStr() {
        return _tibjmsInitalContextFactoryStr;
    }
    /**
     * @param _tibjmsInitalContextFactoryStr the _tibjmsInitalContextFactoryStr 
     * to set
     */
    public void set_tibjmsInitalContextFactoryStr(
    		String _tibjmsInitalContextFactoryStr) {
        this._tibjmsInitalContextFactoryStr = _tibjmsInitalContextFactoryStr;
    }
    /**
     * @return the _providerURLStr
     */
    public String get_providerURLStr() {
        return _providerURLStr;
    }
    /**
     * @param _providerURLStr the _providerURLStr to set
     */
    public void set_providerURLStr(String _providerURLStr) {
        this._providerURLStr = _providerURLStr;
    }
    /**
     * @return the _noiUser
     */
    public String get_noiUser() {
        return _noiUser;
    }
    /**
     * @param _noiUser the _noiUser to set
     */
    public void set_noiUser(String _noiUser) {
        this._noiUser = _noiUser;
    }
    /**
     * @return the _noiSystem
     */
    public String get_noiSystem() {
        return _noiSystem;
    }
    /**
     * @param _noiSystem the _noiSystem to set
     */
    public void set__noiSystem(String _noiSystem) {
        this._noiSystem = _noiSystem;
    }
}
