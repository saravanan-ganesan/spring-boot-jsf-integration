package com.fedex.rise.xref;

/**
 * A Class representing FedEx Standard mnemonic and description for a track type
 */
public class TrackDesc {
    String _shortName; // a FedEx mnemonic

    String _longDesc; // a FedEx Description of the mnemonic

    // Constructor
    public TrackDesc(String aShortName, String aLongDesc) {
        _shortName = aShortName;
        _longDesc = aLongDesc;
    }

    public String toString() {
        return _shortName + ":" + _longDesc;
    }

    /**
     * @return the _longDesc
     */
    public String get_longDesc() {
        return _longDesc;
    }

    /**
     * @param desc the _longDesc to set
     */
    public void set_longDesc(String desc) {
        _longDesc = desc;
    }

    /**
     * @return the _shortName
     */
    public String get_shortName() {
        return _shortName;
    }

    /**
     * @param name the _shortName to set
     */
    public void set_shortName(String name) {
        _shortName = name;
    }
}
