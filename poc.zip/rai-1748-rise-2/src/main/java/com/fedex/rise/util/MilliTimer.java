package com.fedex.rise.util;

public class MilliTimer {
    private long _startTime, _endTime;

    public MilliTimer() {
    }
    
    public void startTimer() {
        _startTime = System.currentTimeMillis();
    }
    
    public void endTimer() {
        _endTime = System.currentTimeMillis();
    }

    public void reset()	{
        _startTime = -1;
        _endTime = -1;
    }

    public String getTime() {
        return Long.toString( _endTime - _startTime );
    }
}
