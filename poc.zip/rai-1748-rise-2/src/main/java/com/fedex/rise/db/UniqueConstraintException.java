package com.fedex.rise.db;

import java.sql.SQLException;
import java.io.Serializable;

public class UniqueConstraintException extends SQLException implements Serializable {

    private static final long serialVersionUID = 1L;
    
    public UniqueConstraintException(SQLException sqle) {
        super(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode());
    }
}
