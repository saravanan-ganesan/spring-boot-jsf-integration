package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class STAT85Preventer extends Preventer {
	private static Logger logger = LogManager.getLogger(STAT85Preventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static STAT85Preventer _instance = new STAT85Preventer();

    static {
        // The previous scans below will prevent a new issue being created.
    	_preventingScans.add(RiseConstants.SOP);
    	_preventingScans.add(RiseConstants.ROP);
    	_preventingScans.add(RiseConstants.HIP);
    	_preventingScans.add(RiseConstants.ECCO);
       	_preventingScans.add(RiseConstants.HOP);
       	_preventingScans.add(RiseConstants.RIP);
       	_preventingScans.add(RiseConstants.SIP);
       	_preventingScans.add(RiseConstants.VAN);
    }
  
    private STAT85Preventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	// If it has been delivered, do not create any new events.
        if (DeliveryPreventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (_preventingScans.contains(anPastEventVO.get_track_type_cd())) {
            logger.debug("Issue prevented by STAT 85 Preventer.");
            return true;
        }
             
        return false;
    }

    public static STAT85Preventer getInstance() {
        return _instance;
    }
}
