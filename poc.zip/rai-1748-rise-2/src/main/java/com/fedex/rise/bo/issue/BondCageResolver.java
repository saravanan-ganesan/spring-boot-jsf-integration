package com.fedex.rise.bo.issue;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public class BondCageResolver extends Resolver {
    
    private static BondCageResolver _instance = new BondCageResolver();
    
    private BondCageResolver() {};
    
    /*
     * A Stat 60, "In Bond Cage", is resolved by a Stat 65 and Stat 66 or a delivery event
     * @see com.fedex.rise.bo.issue.Resolver#isResolved(com.fedex.rise.vo.EventVO, com.fedex.rise.vo.IssueVO)
     */
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        SpecificEventResolver stat65eventResolver = SpecificEventResolver.getInstance(RiseConstants.STAT, "65");
        if (stat65eventResolver.isResolved(anEventVO, anIssueVO)) return true;
        SpecificEventResolver stat66eventResolver = SpecificEventResolver.getInstance(RiseConstants.STAT, "66");
        if (stat66eventResolver.isResolved(anEventVO, anIssueVO)) return true;
        DeliveryResolver deliveryResolver = DeliveryResolver.getInstance();
        if (deliveryResolver.isResolved(anEventVO, anIssueVO)) return true;
        return false;
    }

    public static BondCageResolver getInstance() {
        return _instance;
    }
}

