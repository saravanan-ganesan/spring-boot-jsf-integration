package com.fedex.rise.bo.issue;

public class Issue {
	
    String trackTypeCd; // Track type
    String trackExcpCd; // Exception cd
    char shpmtTypeCd;   // Shipment type MAWB, CRN, UNK
    IssueCriteria issueCriteria;
    int issueTypeCd;    // identifies the exception
    int timeCalcMethod; // method of time calculation used
    int timeHourOffset; // offset in hours
    IssueDesc issueDesc; // Text description of issue
    
    
    public Issue (String aTrackTypeCd, String aTrackExcpCd, 
                  char aShpmtTypeCd, IssueCriteria aCriterium,
                  int anIssueTypeCd, int aTimeCalcMethod,
                  int aTimeHourOffset, IssueDesc aIssueDesc) {
        this.trackTypeCd = aTrackTypeCd;
        this.trackExcpCd = aTrackExcpCd;
        this.shpmtTypeCd = aShpmtTypeCd;
        this.issueCriteria = aCriterium;
        this.issueTypeCd = anIssueTypeCd;
        this.timeCalcMethod = aTimeCalcMethod;
        this.timeHourOffset = aTimeHourOffset;  
        this.issueDesc = aIssueDesc;
    }
}   