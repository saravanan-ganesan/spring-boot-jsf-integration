package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.tree2.HtmlTree;
import org.apache.myfaces.custom.tree2.TreeModel;
import org.apache.myfaces.custom.tree2.TreeModelBase;
import org.apache.myfaces.custom.tree2.TreeNode;
import org.apache.myfaces.custom.tree2.TreeNodeBase;
import org.apache.myfaces.custom.tree2.TreeState;
import org.apache.myfaces.custom.tree2.TreeStateBase;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.util.TreeNodeWithNodeIdPath;

/**
 * Backer bean for Shipper Tree. Basically makes a TreeNode available.
 * 
 */
public class ShipperTreeBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(ShipperTreeBean.class);

    /** Delegate to get shipper data */
    private ShipperDelegate shipperDelegate = new ShipperDelegate();

    /** tree model that contains all the data  */
    private TreeModelBase _treeModel;
    /** tree html that displays the tree model */
    private transient HtmlTree _tree;
    
    /** tree node selected */
    private TreeNodeWithNodeIdPath _selectedNode = null;
   
    /** path to the selected child node (shipper, account, lane, etc.) */
    private String _nodePathDesc = "";
    
    /** designates which node type we are on (shipper, account, lane, or svc) */
    private int nodeType = 0;
    private boolean _forceNodeZero = false; // Selecting a node, do not force node to zero.
   
    private TreeState _treeState;
    private String[] _expandedNodes; 
    
    /** new node data, for selecting the node */
    private String _newShipperName =  null;
    private String _newAccountNbr =  null;
    
    /**
     * need isNew attrs so the correct node in tree is selected when adding
     * new nodes dynamically
     */
    private boolean _isNewShipper = false;
    private boolean _isNewAccount = false;
   
    /** 
     * this is to set and get the DIV tag scroller positions, so after browser
     * submits, the scroll position can be restored
     */
    private String divScrollerPosition = null;
    
    /** 
     * Default Constructor
     */
    public ShipperTreeBean() {
        // We'll keep the state of the tree (selected Node, expanded Nodes)
        _treeState = new TreeStateBase();
        _treeState.setTransient(true);
    }
   
    
    /*--------------------------------------------------------------------- 
     * Getter/Setter methods
     *---------------------------------------------------------------------
     */
    
    /**
     * @return TreeModel
     */
    public TreeModel getTreeModel() {
       
        // Only retrieve model once from DB for this HTTP request.
        // For some reason this method is called multiple times, but since
        // this bean is request scoped the caching of the model should work.
// TODO: cache or not?
//        if (_treeModel != null) {
//            return _treeModel;
//        }
                
        // create the model
        TreeNode treeData = getTreeData(); 
        _treeModel = new TreeModelBase(treeData);
       
        if (_selectedNode != null) {
           // set the tree to select the node
           String nodeIdPath = _selectedNode.getNodeIdPath();
           _treeState.setSelected(nodeIdPath);
           
           // set the nodepath so the right pane details get populated for the selected node
           _nodePathDesc = getNodePathByIdentifier(nodeIdPath, treeData);
           // Expand the first level, so shippers are always visible
           //String pathToExpand[] = {"0", nodeIdPath};
           //_treeState.expandPath(pathToExpand);
        } else {
           // Expand the first level, so shippers are always visible
           //String pathToExpand[] = {"0"};
           //_treeState.expandPath(pathToExpand);
        }
        
       
        _treeModel.setTreeState(_treeState);
        
        return _treeModel;
    }

    public void setTree(HtmlTree tree) {
        _tree = tree;
    }

    public HtmlTree getTree() {
        return _tree;
    }

    /**
     * Get the selected tree nodes full path description
     * @return
     */
    public String getNodePathDesc() {
        return _nodePathDesc;
    }
    
    /**
     * set force go to node zero
     * @return
     */
    public void setForceNodeZero(boolean forceNodeZero) {
    	_forceNodeZero = forceNodeZero;
    }
    
    /**
     * get force go to node zero 
     * @return
     */
    public boolean getForceNodeZero() {
    	return _forceNodeZero;
    }
    
    /**
     * Determine what node, so we can display correct info in the right pane
     * @return
     */
    public int getNodeType() {
        if (log.isDebugEnabled()) log.debug("Node Type = " + nodeType);
        return nodeType;
    }
    
    /**
     * @return the selectedNode
     */
    public TreeNode getSelectedNode() {
        return _selectedNode;
    }
    
    /**
     * Return the selected node keys
     * @return the selectedKeys
     */
    public String[] getSelectedKeys() {
        // string is shipperNbr:accountNbr:laneNbr:svcTypCd
        String selectedNodeStr = _selectedNode.getIdentifier();
        String[] selectedKeys = selectedNodeStr.split(":");
        return selectedKeys;
    }
   
    /** 
     * Get the DIV tag scroller position, so we can restore the position
     * @return divScrollerPosition
     */
    public String getDivScrollerPosition() {
        return divScrollerPosition;
    }
    
    /**
     * Set the DIV tag scroller position, so we can save the position
     * @param divScrollerPosition
     */
    public void setDivScrollerPosition(String divScrollerPosition) {
        this.divScrollerPosition = divScrollerPosition;
    }

    
    /*--------------------------------------------------------------------- 
     * Action methods
     *---------------------------------------------------------------------
     */
   
    public String expandAll() {
        _tree.expandAll();
        return null;
    }

    public String collapseAll() {
        _tree.collapseAll();
        return null;
    }

    /**
     * Process tree node selection events to capture what node is selected
     * 
     * @param event
     * @throws AbortProcessingException
     */
    public void selectNodeAction(ActionEvent event) throws AbortProcessingException {
        log.debug("Entering processAction()");
        
        // TODO: clear previous selects ??
        this.clearSelection();
        this._forceNodeZero = false;
       
        // find the html tree
        UIComponent component = (UIComponent) event.getSource();
        while (!(component != null && component instanceof HtmlTree)) {
           component = component.getParent();
        }
        if (component != null) {
           HtmlTree tree = (HtmlTree) component;
           // call tree to select node and show it correctly
           //if (this._selectedNode == null)
              tree.setNodeSelected(event);
          
           // find selected tree node path
           TreeNodeBase node = (TreeNodeBase) tree.getNode();
          
           // get id path of selected node
           FacesContext facesCxt = FacesContext.getCurrentInstance();
           ExternalContext context= facesCxt.getExternalContext();
           Map reqMap = context.getRequestParameterMap();
           String nodeId =(String) reqMap.get("nodeId");
           
           // save selected Node
           _selectedNode = new TreeNodeWithNodeIdPath(node.getType(), node.getDescription(), 
                   node.getIdentifier(), node.isLeaf(), nodeId);
           
           _nodePathDesc = getNodePathByIdentifier(tree.getNodeId(), tree.getDataModel().getNodeById("0")); //.get_treeData);
           if (log.isDebugEnabled()) {
               log.debug("Tree Node:" + tree.getNodeId() + ":" + node.getDescription());
               log.debug("Tree Path:" + _nodePathDesc);
           }
        }
    }

    /**
     * Notification of a new account being added
     * so we can select this node when we redisplay the tree
     * @param accountNbr
     */
    public void notifyAccountAdded(String accountNbr) {
        clearSelection();
        
        _newAccountNbr = accountNbr;
        _isNewAccount = true;
    }
    
    /**
     * Notification of a new shipper being added
     * so we can select this node when we redisplay the tree
     * @param accountNbr
     */
    public void notifyShipperAdded(String shipperName) {
        clearSelection();
        
        _newShipperName = shipperName;
        _isNewShipper = true;
    }
    
    /**
     * Notification of deletion
     */
    public void notifyDelete() {
        clearSelection();
    }
    
    /*--------------------------------------------------------------------- 
     * Private utility methods
     *---------------------------------------------------------------------
     */
    
    private TreeNode getTreeData() {
        // TODO: clear Selection ??
        //_selectedNode = null;
        
        // create base tree node
        String nodeId = "0";
        TreeNodeWithNodeIdPath treeData = new TreeNodeWithNodeIdPath("shippers", 
                "Shippers", nodeId, false, nodeId);

        // add shipper, account, lane, and svc nodes
        addShipperNodes(treeData);

        return treeData;
    }

    /**
     * Add all Shippers, accounts, lanes, services nodes to the tree
     * @param treeData
     */
    private void addShipperNodes(TreeNode treeData) {
        
        // Get shippers, accounts, lanes, services, etc. 
        List accounts = shipperDelegate.getAllShippers();
        
        TreeNodeWithNodeIdPath shipperNode = null; 
        TreeNodeWithNodeIdPath accountNode = null; 
        TreeNodeWithNodeIdPath laneNode = null; 
        TreeNodeWithNodeIdPath svcNode = null; 
        
        String currentShipperNbr = null;
        String currentAccountNbr = null;
        String currentLaneNbr = null;
        String currentSvcTypeCd = null;
        
        if (accounts!=null) {
           Iterator iter = accounts.listIterator();
           int shipperCnt = 0;
           int accountCnt = 0;
           int laneCnt = 0;
           int svcCnt = 0;
//           while (iter.hasNext()) {
//               // TODO: rename to just AccountsVO
//               MonitoredAccountsVO account = (MonitoredAccountsVO)iter.next();
//               String shipperNbr = String.valueOf(account.get_groupNbr());
//               String acctNbr = account.get_acctNbr();                
//               String laneNbr = null;
//               if (account.get_laneNbr() != 0)
//                   laneNbr = String.valueOf(account.get_laneNbr());
//               String svcTypeCd = account.get_svcTypeCd();
//              
//               String svcTypeStr = ServiceTypeFormatter.format(svcTypeCd, SvcLvlDescCodes.lookupCd(svcTypeCd));
//               
//               if (currentShipperNbr == null || !shipperNbr.equals(currentShipperNbr)) {
//                   // shipper/group changed, or first shipper
//                  
//                   // increment count if this isn't the first shipper
//                   if (currentShipperNbr != null)
//                      shipperCnt++;
//                   
//                   // reset because shipper changed
//                   accountCnt = 0;
//                   laneCnt = 0;
//                   svcCnt = 0;
//                   currentShipperNbr = shipperNbr;
//                   currentAccountNbr = acctNbr;
//                   currentLaneNbr = laneNbr;                    
//                   currentSvcTypeCd = svcTypeCd;
//                   
//                   // create shipper node
//                   shipperNode = new TreeNodeWithNodeIdPath("shipper",  account.get_groupNm(), 
//                           shipperNbr,
//                           false,
//                           "0:" + shipperCnt);
//                   treeData.getChildren().add(shipperNode);
//                   
//                   // re-select shipper node if new or it was previously selected but its name was changed
//                   if ( (_isNewShipper && account.get_groupNm().equals(_newShipperName)) ||
//                        ((_selectedNode != null) && shipperNode.getIdentifier().equals(_selectedNode.getIdentifier())) ) { 
//                       _selectedNode = shipperNode;
//                       _isNewShipper = false;
//                   }
//                   
//                   // create account node
//                   if (currentAccountNbr != null) {
//                      accountNode = new TreeNodeWithNodeIdPath("account",  account.get_acctName(), 
//                              shipperNbr + ":" + acctNbr,
//                              false,
//                              "0:" + shipperCnt + ":" + accountCnt);
//                      shipperNode.getChildren().add(accountNode);
//                      
//                      // re-select account node if new or it was previously selected but its name was changed
//                      if ( (_isNewAccount && account.get_acctNbr().equals(_newAccountNbr)) ||
//                           ((_selectedNode != null) && accountNode.getIdentifier().equals(_selectedNode.getIdentifier())) ) { 
//                           _selectedNode = accountNode;
//                           _isNewAccount = false;
//                           _newAccountNbr = null;
//                      }
//                      
//                      // create lane node
//                      if (currentLaneNbr != null) {
//                         String lane = account.get_origCntryCd() + "-" + account.get_destCntryCd();
//                         laneNode = new TreeNodeWithNodeIdPath("lane", lane, 
//                                 shipperNbr + ":" + acctNbr + ":" + laneNbr,
//                                 false,
//                                 "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt);
//                         accountNode.getChildren().add(laneNode);
//                            
//                         // create service node
//                         if (currentSvcTypeCd != null) {
//                            svcNode = new TreeNodeWithNodeIdPath("service", svcTypeStr, 
//                                    shipperNbr + ":" + acctNbr + ":" + laneNbr + ":" + svcTypeCd,
//                                    false,
//                                    "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt + ":" + svcCnt);
//                            laneNode.getChildren().add(svcNode);
//                         }
//                      }
//                   }
//                   
//               } else if (!currentAccountNbr.equals(acctNbr)) { 
//                   // account changed
//                   
//                   // reset cause account changed
//                   laneCnt = 0;
//                   svcCnt = 0;
//                   currentAccountNbr = acctNbr;
//                   currentLaneNbr = laneNbr;
//                   currentSvcTypeCd = svcTypeCd;
//                       
//                   // create account node
//                   if (currentAccountNbr != null) {
//                      accountCnt++;
//                      accountNode = new TreeNodeWithNodeIdPath("account",  account.get_acctName(), 
//                              shipperNbr + ":" + acctNbr,
//                              false,
//                              "0:" + shipperCnt + ":" + accountCnt);
//                      shipperNode.getChildren().add(accountNode);
// 
//                      // re-select account node if new or it was previously selected but its name was changed
//                      if ( (_isNewAccount && account.get_acctNbr().equals(_newAccountNbr)) ||
//                           ((_selectedNode != null) && accountNode.getIdentifier().equals(_selectedNode.getIdentifier())) ) { 
//                           _selectedNode = accountNode;
//                           _isNewAccount = false;
//                           _newAccountNbr = null;
//                      }
//                      
//                      // create lane node
//                      if (currentLaneNbr != null) {
//                         String lane = account.get_origCntryCd() + "-" + account.get_destCntryCd();
//                         laneNode = new TreeNodeWithNodeIdPath("lane", lane, 
//                                 shipperNbr + ":" + acctNbr + ":" + laneNbr,
//                                 false,
//                                 "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt);
//                         accountNode.getChildren().add(laneNode);
//                         
//                         // create service node
//                         if (currentSvcTypeCd != null) {
//                            svcNode = new TreeNodeWithNodeIdPath("service", svcTypeStr, 
//                                    shipperNbr + ":" + acctNbr + ":" + laneNbr + ":" + svcTypeCd,
//                                    false,
//                                    "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt + ":" + svcCnt);
//                            laneNode.getChildren().add(svcNode);
//                         }
//                      }
//                  }
//                      
//               } else if (!currentLaneNbr.equals(laneNbr)) {
//                   // lane changed
//                   
//                   // reset cause lane changed
//                   svcCnt = 0;
//                   currentLaneNbr = laneNbr;
//                   currentSvcTypeCd = svcTypeCd;
//                        
//                   // create lane node
//                   if (currentLaneNbr != null) {
//                      laneCnt++;
//                      String lane = account.get_origCntryCd() + "-" + account.get_destCntryCd();
//                      laneNode = new TreeNodeWithNodeIdPath("lane", lane, 
//                              shipperNbr + ":" + acctNbr + ":" + laneNbr,
//                              false,
//                              "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt);
//                      accountNode.getChildren().add(laneNode);
//                      
//                      // create service node
//                      if (currentSvcTypeCd != null) {
//                         svcNode = new TreeNodeWithNodeIdPath("service", svcTypeStr, 
//                                 shipperNbr + ":" + acctNbr + ":" + laneNbr + ":" + svcTypeCd,
//                                 false,
//                                 "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt + ":" + svcCnt);
//                         laneNode.getChildren().add(svcNode);
//                      }
//                   }
//                      
//               } else if (!currentSvcTypeCd.equals(svcTypeCd)) {
//                   // service changed
//                   
//                   currentSvcTypeCd = svcTypeCd;
//                   
//                   // create service node
//                   if (currentSvcTypeCd != null) {
//                      svcCnt++;
//                      svcNode = new TreeNodeWithNodeIdPath("service", svcTypeStr, 
//                              shipperNbr + ":" + acctNbr + ":" + laneNbr + ":" + svcTypeCd,
//                              false,
//                              "0:" + shipperCnt + ":" + accountCnt + ":" + laneCnt + ":" + svcCnt);
//                      laneNode.getChildren().add(svcNode);
//                  }            
//               }            
//           }            
           
        }        
        
    }
   
    /**
     * Return the full path of node descriptions 
     * @param argID
     * @param rootNode
     * @return
     */ 
    private String getNodePathByIdentifier(String id, TreeNode rootNode) {
        StringBuffer nodePath = new StringBuffer();
        TreeNode node = rootNode;
    
        String[] nodeIDs = id.split(":");
        nodePath.append(node.getDescription()); // starts at ROOT node
        for (int i=1; i<nodeIDs.length; i++) {  
           nodePath.append(" > ");
           node = (TreeNode)node.getChildren().get(Integer.parseInt(nodeIDs[i]));
           nodePath.append(node.getDescription());
        }
        
        //this.setNodePath(node.getDescription());
        
        // Save so we can determine which node type we are on (shipper, account, lane, or svc)
        nodeType = nodeIDs.length;
        
        return nodePath.toString();
    }
    
    /** clear the selected node in the tree */
    private void clearSelection() {
        // clear selection
        _nodePathDesc = null;
        _selectedNode = null;
        nodeType = 0;
    }

}

