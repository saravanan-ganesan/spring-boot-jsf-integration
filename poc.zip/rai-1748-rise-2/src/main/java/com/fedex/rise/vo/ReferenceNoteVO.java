package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * Refrence Note Value Object (or Transfer Object) used to encapsulate 
 * reference note date for transport.
 */
public class ReferenceNoteVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;
    private String _trkng_item_uniq_nbr;
    private String _ref_type_cd;
    private String _ref_note_desc;
    private Date   _last_updt_tmstp;
    
    /**
     * Default Constructor
     */
    public ReferenceNoteVO() {
    }
    
    /**
     * Construct a Reference Note
     * @param _trkng_item_nbr
     * @param _trkng_item_uniq_nbr
     * @param _ref_type_cd
     * @param _ref_note_desc
     */
    public ReferenceNoteVO(String _trkng_item_nbr, String _trkng_item_uniq_nbr, String _ref_type_cd, String _ref_note_desc) {
        super();
        this._trkng_item_nbr = _trkng_item_nbr;
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
        this._ref_type_cd = _ref_type_cd;
        this._ref_note_desc = _ref_note_desc;
    }
    
    /**
     * @return the _ref_note_desc
     */
    public String get_ref_note_desc() {
        return _ref_note_desc;
    }
    /**
     * @param _ref_note_desc the _ref_note_desc to set
     */
    public void set_ref_note_desc(String _ref_note_desc) {
        this._ref_note_desc = _ref_note_desc;
    }
    /**
     * @return the _ref_type_cd
     */
    public String get_ref_type_cd() {
        return _ref_type_cd;
    }
    /**
     * @param _ref_type_cd the _ref_type_cd to set
     */
    public void set_ref_type_cd(String _ref_type_cd) {
        this._ref_type_cd = _ref_type_cd;
    }
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((_ref_note_desc == null) ? 0 : _ref_note_desc.hashCode());
        result = PRIME * result + ((_ref_type_cd == null) ? 0 : _ref_type_cd.hashCode());
        result = PRIME * result + ((_trkng_item_nbr == null) ? 0 : _trkng_item_nbr.hashCode());
        result = PRIME * result + ((_trkng_item_uniq_nbr == null) ? 0 : _trkng_item_uniq_nbr.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final ReferenceNoteVO other = (ReferenceNoteVO) obj;
        if (_ref_note_desc == null) {
            if (other._ref_note_desc != null)
                return false;
        } else if (!_ref_note_desc.equals(other._ref_note_desc))
            return false;
        if (_ref_type_cd == null) {
            if (other._ref_type_cd != null)
                return false;
        } else if (!_ref_type_cd.equals(other._ref_type_cd))
            return false;
        if (_trkng_item_nbr == null) {
            if (other._trkng_item_nbr != null)
                return false;
        } else if (!_trkng_item_nbr.equals(other._trkng_item_nbr))
            return false;
        if (_trkng_item_uniq_nbr == null) {
            if (other._trkng_item_uniq_nbr != null)
                return false;
        } else if (!_trkng_item_uniq_nbr.equals(other._trkng_item_uniq_nbr))
            return false;
        return true;
    }

    /**
     * @return the _last_updt_tmstp
     */
    public Date get_last_updt_tmstp() {
        return _last_updt_tmstp;
    }

    /**
     * @param _last_updt_tmstp the _last_updt_tmstp to set
     */
    public void set_last_updt_tmstp(Date _last_updt_tmstp) {
        this._last_updt_tmstp = _last_updt_tmstp;
    }
}
