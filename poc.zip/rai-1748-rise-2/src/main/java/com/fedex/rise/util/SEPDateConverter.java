package com.fedex.rise.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.EventPersister;

/**
 * Calcuate the date based on the four variations of date strings that SEP will give us
 * 
 * GMT with offset to local time    YYYYMMDDHHMMSSZ[+-]HHMM
 * GMT without offset               YYYYMMDDHHMMSSZ
 * Local time                       YYYYMMDDHHMMSS
 * Local time with offset to GMT    YYYYMMDDHHMMSS[+-]HHMM
 *
 */
public class SEPDateConverter {
    private static Logger logger = LogManager.getLogger(SEPDateConverter.class);
    
    public static Calendar getSepDate(String aDateStr) throws ParseException {
        //logger.debug("Into SEP Date Converter:" + aDateStr);
        boolean isGMT = false;   // flag to determine if local or GMT
        TimeZone tz = TimeZone.getTimeZone("GMT+0000");
        
        // edits
        if ((aDateStr == null) || (aDateStr.length() < 14)) {
            return null; 
        }
        
        // Make a string buffer so we can delete things out of the string as we interpret it
        StringBuffer sb = new StringBuffer(aDateStr);
        
        SimpleDateFormat dateAndTimeFormatter = new SimpleDateFormat("yyyyMMddHHmmss");
        dateAndTimeFormatter.setTimeZone(tz);
        Date d = dateAndTimeFormatter.parse(aDateStr);
        if (d == null) {
            return null;  // can't parse it, so forget it and return null
        }
        
        sb.delete(0, 14);  // we are through with the date/time portion of the string
                  
        if (sb.length() > 0 && sb.charAt(0) == 'Z') { // Is this a GMT time?
            isGMT = true;
            sb.deleteCharAt(0);
        }
        
        if (sb.length() >= 5) {
            // make the time zone, if offset is present
            tz = TimeZone.getTimeZone("GMT" + sb.substring(0, 5));
            if (!isGMT) {
                // if not GMT, then offset is from local to GMT, flip it to GMT to local
                // also, adjust time by offset to zulu from local
                if (sb.charAt(0) == '+') {
                    sb.setCharAt(0, '-');
                    d.setTime(d.getTime() + tz.getRawOffset());
                } else {
                    sb.setCharAt(0, '+');
                    d.setTime(d.getTime() - tz.getRawOffset());
                }
            }
        }
        
        // might as well use the calendar that is already in existence
        dateAndTimeFormatter.setTimeZone(tz);
        Calendar calendar = dateAndTimeFormatter.getCalendar();
        calendar.setTime(d);
        //logger.debug("SEPDateConverter output: " + calendar.getTimeInMillis());
        //logger.debug("SEPDateConverter output: " + calendar.getTime().toGMTString());
        return calendar;
    }
    
    
    /**
     * @param args
     */
//    public static void main(String[] args) {
//        TimeZone tz = TimeZone.getTimeZone("GMT+0000");
//        Calendar c = Calendar.getInstance(tz);
//
//        System.out.println(c.getTimeInMillis());
//        //System.out.println(c.getTime().toGMTString());
//        SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
//        sf.setTimeZone(tz);
//        
//        SimpleDateFormat xf = new SimpleDateFormat("d MMM yyyy HH:mm:ss Z");
//        String dateStr = sf.format(c.getTime());
//
//        String testDate1 = dateStr + "Z-0700";  // Zulu, offset to local
//        String testDate2 = dateStr + "Z";       // Zulu
//        //String testDate3 = "20070404000000";      // local time
//        String testDate4 = dateStr + "-0700"; // local time, offset to zulu
//        
//        try {
//            Calendar d = SEPDateConverter.getSepDate(testDate1);
//            System.out.println(d);
//            //System.out.println(d.getTime().toGMTString());
//            xf.setTimeZone(d.getTimeZone());
//            System.out.println(xf.format(d.getTime()));
//            
//            d = SEPDateConverter.getSepDate(testDate2);
//            System.out.println(d);
//            //System.out.println(d.getTime().toGMTString());
//            xf.setTimeZone(d.getTimeZone());
//            System.out.println(xf.format(d.getTime()));
//            
//            //d = GRSDateConverter.getSepDate(testDate3);
//            //System.out.println(d);
//            //System.out.println(d.getTime());
//            //System.out.println(sf.format(d.getTime()));
//            
//            d = SEPDateConverter.getSepDate(testDate4);
//            System.out.println(d);
//            //System.out.println(d.getTime().toGMTString());
//            xf.setTimeZone(d.getTimeZone());
//            System.out.println(xf.format(d.getTime()));
//            
//            d = SEPDateConverter.getSepDate(null);
//            System.out.println(d);
//            
//            d = SEPDateConverter.getSepDate("xxxxx");
//            System.out.println(d);
//            
//            // Will throw parseException
//            //d = SEPDateConverter.getSepDate("yyyyMMddHHmmss");
//            //System.out.println(d);
//            
//            d = SEPDateConverter.getSepDate("20070613122600Z+0200");
//            System.out.println(d);
//            
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//
//    }

}
