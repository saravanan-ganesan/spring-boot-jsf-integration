package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountVO;
/**
 * Account table accessor class.
 * 
 * @author be379961
 *
 */
public class AccountAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(AccountAccessor.class);
    /**
     * Constructor
     * @param con
     */
    public AccountAccessor(Connection con) {
        super(con);
    }
            
    private final String selectAccountSQL = "select " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "ACCT_NM, " +
        "COMPANY_NM, " +
        "DTYTAX_ACCT_NBR, " +
        "CMDTY_DESC, " +
        "SPCL_INSTR_DESC, " +
        "COMMENT_DESC, " +
        "RERTE_FLG, " +
        "HOLD_AT_LOC_FLG, " +
        "INPUT_TMSTP, " +
        "LAST_UPDT_TMSTP " +      
         "from Account where GROUP_NBR = ? and ACCT_NBR = ?";  
    
    private final String selectAccountsSQL = "select " +
    	"GROUP_NBR, " +
    	"ACCT_NBR, " +
        "ACCT_NM, " +
    	"COMPANY_NM, " +
    	"DTYTAX_ACCT_NBR, " +
    	"CMDTY_DESC, " +
    	"SPCL_INSTR_DESC, " +
    	"COMMENT_DESC, " +
    	"RERTE_FLG, " +
    	"HOLD_AT_LOC_FLG, " +
    	"INPUT_TMSTP, " +
    	"LAST_UPDT_TMSTP " +      
    	"from Account where GROUP_NBR = ?";    
    
    /**
     * Return the list of AccountVO for a GROUP_NBR and ACCT_NBR.
     * @param aGroupNbr
     * @param anAccountNbr
     * @return AccountVO for a GROUP_NBR and ACCT_NBR.
     * @throws Exception 
     */        
    public AccountVO getAccount(int aGroupNbr, String anAccountNbr) throws SQLException {
        AccountVO accountVO = new AccountVO();
                
        try {
            setSqlSignature( selectAccountSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, aGroupNbr);
            pstmt.setString( 2, anAccountNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                if (rs.next()) {
                    accountVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    accountVO.set_acct_nm(rs.getString("ACCT_NM"));
                    accountVO.set_company_nm(rs.getString("COMPANY_NM"));
                    accountVO.set_dtytax_acct_nbr(rs.getString("DTYTAX_ACCT_NBR"));
                    accountVO.set_cmdty_desc(rs.getString("CMDTY_DESC"));
                    accountVO.set_spcl_instr_desc(rs.getString("SPCL_INSTR_DESC"));
                    accountVO.set_comment_desc(rs.getString("COMMENT_DESC"));
                    String tmp = rs.getString("RERTE_FLG");
                    if (tmp == null || tmp.length()==0)
                        accountVO.set_rerte_flg(' ');
                    else
                        accountVO.set_rerte_flg(tmp.charAt(0));
                    tmp = rs.getString("HOLD_AT_LOC_FLG");
                    if (tmp == null || tmp.length()==0)
                        accountVO.set_hold_at_loc_flg(' ');
                    else
                        accountVO.set_hold_at_loc_flg(tmp.charAt(0));
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return accountVO;
    }    
    /**
     * Return the list of AccountVO for a GROUP_NBR.
     * @param anAccountLaneVO AccountVO with GROUP_NBR interest.
     * @return list of AccountVO for a GROUP_NBR.
     * @throws SQLException 
     */
    public List getAccounts(AccountVO anAccountVO) throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectAccountsSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, anAccountVO.get_group_nbr());
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    AccountVO accountVO = new AccountVO();
                        
                    accountVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    accountVO.set_acct_nm(rs.getString("ACCT_NM"));
                    accountVO.set_company_nm(rs.getString("COMPANY_NM"));
                    accountVO.set_dtytax_acct_nbr(rs.getString("DTYTAX_ACCT_NBR"));
                    accountVO.set_cmdty_desc(rs.getString("CMDTY_DESC"));
                    accountVO.set_spcl_instr_desc(rs.getString("SPCL_INSTR_DESC"));
                    accountVO.set_comment_desc(rs.getString("COMMENT_DESC"));
                    String tmp = rs.getString("RERTE_FLG");
                    if (tmp == null || tmp.length()==0)
                        accountVO.set_rerte_flg(' ');
                    else
                        accountVO.set_rerte_flg(tmp.charAt(0));
                    tmp = rs.getString("HOLD_AT_LOC_FLG");
                    if (tmp == null || tmp.length()==0)
                        accountVO.set_hold_at_loc_flg(' ');
                    else
                        accountVO.set_hold_at_loc_flg(tmp.charAt(0));
                    
                    al.add(accountVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }

}
