package com.fedex.rise.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "Employee")
@Data
public class UserEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "emp_nbr")
	private String empNbr;
	
	@Column(name = "emp_first_nm")
	private String empFirstNm;
	
	@Column(name = "emp_last_nm")
	private String empLastNm;
	
	@Column(name = "emp_role_cd")
	private String empRoleCd;
}
