package com.fedex.rise.bo;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.bo.issue.ClearedCustomsResolver;
import com.fedex.rise.bo.issue.IssueProcessor;
import com.fedex.rise.bo.issue.TransactionException;
import com.fedex.rise.bo.status.StatusCalculator;
import com.fedex.rise.cache.AccountCacheDAO;
import com.fedex.rise.cache.LaneCacheDAO;
import com.fedex.rise.db.AssociatedShipmentDAO;
import com.fedex.rise.db.EventDAO;
import com.fedex.rise.db.ReferenceNoteDAO;
import com.fedex.rise.db.ResourceBusyException;
import com.fedex.rise.db.ShipmentDAO;
import com.fedex.rise.db.UniqueConstraintException;
import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.util.ServiceLocator;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AssociatedShipmentVO;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IPDShipmentVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * This class will do the business logic for an Enhanced Event
 * From this point we will not have any access to the original
 * EnhancedEvent object.
 */

public class EnhancedEventBO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(EnhancedEventBO.class);
        
    /**
     * 
     * @param aVO The ValueObject that contains the data extracted from the
     * SEP Enhanced Event.
     * @throws Exception 
     * @throws SystemException 
     * @throws NotSupportedException 
     */
    public void processEvent(IPDShipmentVO anIpdShipmentVO) throws Exception {
        ShipmentVO shipmentVO = anIpdShipmentVO.get_shipment();
        EventVO eventVO = anIpdShipmentVO.get_event();
        
        // Edits
        // edit ship date, reject if 60 days old
        Date shipDate = shipmentVO.get_ship_dt();       
            
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.add(Calendar.DATE, -60);
        Date cutoffDate = c.getTime();
        if (shipDate != null && shipDate.before(cutoffDate)) {
            logger.info("Ship date is more than 60(" + cutoffDate + ") days in the past:" + shipDate);
            return;
        }
    
        // Determine if shipment has customs cleared event has occurred and save the
        // date/time of shipment cleared customs, kind of an odd place to put this code
        // because it could be considered an extraction of data from the event.
        // The extraction comes from the event data, however the current code that determines
        // if it has customs cleared is in a single place and it needs an EventVO parameter
        // So this seems to be the first place, in the code that the EventVO is available
        // and I like to minimize the places where the Cleared Customs status is calculated
        boolean clrdCustomsFlag = ClearedCustomsResolver.getInstance().isResolved(eventVO, null);
        if (clrdCustomsFlag) {
            // save off the event time stamp of when the shipment clears customs
            shipmentVO.set_cleared_cstms_tmstp(eventVO.get_event_crtn_tmstp());
        }
        
        // TODO Change the order of how this is done, if the event is a duplicate, don't need
        // to do any of these items
    	
    	/**
    	 * Set the group number based on the account number using the cached 
    	 * data.
    	 */
    	String acctNbr = shipmentVO.get_acct_nbr();
    	if (acctNbr != null){
    		if (AccountCacheDAO.containsKey(acctNbr)){
    			int grp_nbr = 
    				AccountCacheDAO.get(acctNbr).get_group_nbr();
    			if (grp_nbr > 0){
    			    shipmentVO.set_grp_nbr(grp_nbr);
    			}
    		}
    	}
    	
    	/**
    	 * Set the lane number based on the origin and destination using the
    	 * cached data.
    	 */
        if ((shipmentVO.get_shpr_cntry_cd() == null) ||
            (shipmentVO.get_recp_cntry_cd() == null)) {
            logger.debug("Missing shpr or recp cntry code");
        } else {
            String key = shipmentVO.get_shpr_cntry_cd()
    		    + "-" + shipmentVO.get_recp_cntry_cd();
    		if (LaneCacheDAO.containsKey(key)){
    			int lane_nbr = 
    				LaneCacheDAO.get(key).get_lane_nbr();
    			if (lane_nbr > 0){
    			    shipmentVO.set_lane_nbr(lane_nbr);
    				logger.debug("lane number = " + lane_nbr + " key = "
    						+ key);
    			}
            } else {
                logger.debug("Non monitored lane: " + key);
            }
    	}
    	
        // Persist/Update, this retry logic was added to handle errors generated by parallel events
        // and subsequent use of the "select for update" SQL.  Rather than throw the error out
        // and let JMS handle it, lets give it another attempt.  The transaction must be rolled
        // back and typically the insert will occur again which should be enough time to do
        // another attempt, no need to make the thread wait.
        int attempt = 0;
        final int MAX_ATTEMPTS = 2;
        while (++attempt <= MAX_ATTEMPTS) {
            try {
                persist(anIpdShipmentVO);
                break;
            } catch (UniqueConstraintException uce) { // Happens when trying to insert
                // a new shipment with two parallel events
                logger.info("Caught Unique Constraint Exception on attempt:" + attempt);
                if (attempt >= MAX_ATTEMPTS) {
                    throw (SQLException)uce;
                }
            } catch (ResourceBusyException rbe) { // this seems to be a side effect of
                // the "select for update" SQL
                logger.info("Caught Resource Busy Exception on attempt:" + attempt);
                if (attempt >= MAX_ATTEMPTS) {
                    throw (SQLException)rbe;
                }
            }
        }
    }
    
    /**
     * This method is used to persist the new Enhanced Event into the appropriate
     * tables.  It will merge a shipment and update it if the shipment already
     * is in the db.
     * 
     * Attempt to insert event
     * if !successful
     *     event already exists, duplicate or in replay scenario      
     * else     
     *     Attempt to get shipment
     *     if shipment does not exist
     *       insert shipment
     *       insert associations
     *       insert reference notes
     *       do issues
     *       do NOI
     *     else
     *       merge shipment
     *       update shipment
     *       insert/update associations
     *       merge reference notes
     *       insert new reference notes
     *       do issues
     *       do NOI
     * 
     * @param anIpdShipmentVO
     * @throws Exception 
     * @throws Exception 
     * @throws SystemException 
     * @throws NotSupportedException 
     */
    private void persist(IPDShipmentVO anIpdShipmentVO) throws Exception  {
        EventDAO eventDAO = new EventDAO();
        ShipmentDAO shipDAO = new ShipmentDAO();
        ReferenceNoteDAO referenceNoteDAO  = new ReferenceNoteDAO();
        AssociatedShipmentDAO associatedShipmentDAO = new AssociatedShipmentDAO();
        IssueProcessor issueProcessor = new IssueProcessor();
        boolean shipmentExists = true;
        List newAssociations = null;
        
        // transaction part of event processing
        UserTransaction userTransaction = null;
       
        try {
            userTransaction = ServiceLocator.getInstance().getUserTransaction();
            userTransaction.begin();
       
            logger.info("Inserting Event");
            boolean result = eventDAO.doPersist(anIpdShipmentVO.get_event());            
            if (!result) {
                logger.info("Duplicate event");
                userTransaction.commit();
                return;
            } else {
                // event persisted successfully, see if shipment exists
                ShipmentVO existingShipmentVO = shipDAO.getShipmentForUpdate(
                        anIpdShipmentVO.get_shipment().get_trkng_item_nbr(),
                        anIpdShipmentVO.get_shipment().get_trkng_item_uniq_nbr());
                
                // Determine the adjusted commit date.
                AdjustedCommitDt adjustedCommitDt = new AdjustedCommitDt();
                Calendar adjCommitDt = adjustedCommitDt.processAdjustedCommitDate(
                		anIpdShipmentVO, existingShipmentVO);
                anIpdShipmentVO.get_shipment().set_adj_commit_dt(adjCommitDt);
                
                /**
            	 * Determine if the Performance Result Code can be set. Need to
            	 * pull the existing COMMIT_DATE_TMZN_OFFST_NBR out of the 
            	 * SHIPMENT table to calculate whether a package is late or not.
            	 */
            	PerformanceEvents performanceEvents = new PerformanceEvents();
            	String performanceResult = null;
            	performanceResult = performanceEvents.processEvent(
            			anIpdShipmentVO, existingShipmentVO);
            	if (performanceResult != null){
            		anIpdShipmentVO.get_shipment().set_perf_rsult_cd(performanceResult);
            	}
            	
                if (existingShipmentVO == null) {
                    logger.info("Shipment Does NOT Exist, persisting");
                    shipmentExists = false;

                    // Calculate status
                    String newStatus = StatusCalculator.calcStatus(anIpdShipmentVO.get_event(), null);                    
                    if (newStatus != null) {
                        anIpdShipmentVO.get_shipment().set_last_stat_desc(newStatus);
                        anIpdShipmentVO.get_shipment().set_last_stat_track_loc_cd(
                            anIpdShipmentVO.get_event().get_track_loc_cd());
                        anIpdShipmentVO.get_shipment().set_last_stat_tmstp(
                            anIpdShipmentVO.get_event().get_event_crtn_tmstp().getTime());
                    }                    
                    
                    // shipment does not exist, persist it
                    shipDAO.doPersist(anIpdShipmentVO.get_shipment());
                    
                    logger.info("Persisting associations");
                    associatedShipmentDAO.doPersist(anIpdShipmentVO.get_associatedShipments());

                    issueProcessor.doIssues(anIpdShipmentVO, true, null);
                    
                } else {
                    // Shipment does exist, merge, and update
                    logger.info("Shipment DOES Exist, merging");
                    
                    // make a deep copy of the existing shipment, use the merged copy to merge, and
                    // the other to save for the NOI publish, so that he can determine what to do
                    // based on what is in the database before the merge
                    ShipmentVO mergedShipmentVO = new ShipmentVO(existingShipmentVO);

                    // Calculate status
                    String newStatus = StatusCalculator.calcStatus(anIpdShipmentVO.get_event(), existingShipmentVO.get_last_stat_desc());                    
                    if (newStatus != null) {
                        anIpdShipmentVO.get_shipment().set_last_stat_desc(newStatus);
                        anIpdShipmentVO.get_shipment().set_last_stat_track_loc_cd(
                            anIpdShipmentVO.get_event().get_track_loc_cd());
                        anIpdShipmentVO.get_shipment().set_last_stat_tmstp(
                            anIpdShipmentVO.get_event().get_event_crtn_tmstp().getTime());
                    }
                    
                    MergeShipment shipmentMerger = new MergeShipment();
                    boolean changed = shipmentMerger.merge(anIpdShipmentVO.get_shipment(), 
                            mergedShipmentVO, anIpdShipmentVO.get_event().get_event_crtn_tmstp(),
                            anIpdShipmentVO.get_event().get_track_type_cd());                      
                    if (changed) {
                        logger.info("Updating with merged changes.");
                        shipDAO.updateShipment(mergedShipmentVO);
                    } else {
                        logger.info("NOT Updating, no changes.");
                    }

                    logger.info("Updating/Persisting associations");
                    List assocShipments = associatedShipmentDAO.getAssociatedShipments(
                            anIpdShipmentVO.get_shipment().get_trkng_item_nbr(),
                            anIpdShipmentVO.get_shipment().get_trkng_item_uniq_nbr());
                    MergeAssociatedShipments assocShipmentMerger = new MergeAssociatedShipments();
                    List mergedAssocShipments = assocShipmentMerger.merge(anIpdShipmentVO.get_associatedShipments(),
                                                                          assocShipments);
                    associatedShipmentDAO.updateAssociatedShipments(mergedAssocShipments);
                    newAssociations = assocShipmentMerger.findNewAssociations(anIpdShipmentVO.get_associatedShipments(),
                                                                          assocShipments);
                    logger.info("Found " + newAssociations.size() + " associations to add, " +
                                         + mergedAssocShipments.size() + " to update");
                    associatedShipmentDAO.doPersist(newAssociations);
                    
                    issueProcessor.doIssues(anIpdShipmentVO, false, mergedShipmentVO);
                }
            }        
            userTransaction.commit();
                               
            logger.debug(anIpdShipmentVO.get_shipment().get_recp_city_nm() + "," +
                    anIpdShipmentVO.get_shipment().get_recp_st_prov_cd() + " " +
                    anIpdShipmentVO.get_shipment().get_recp_cntry_cd());
            
        // These exceptions really have to do with starting a transaction
        } catch (NotSupportedException e) {     // begin
            throw new TransactionException(e);
        } catch (SystemException e) {           // begin
            throw new TransactionException(e);
        // These exception have to do with commit exceptions
        } catch (RollbackException e) {         // commit
            // Thrown to indicate that the transaction has been rolled back rather than committed
            throw new TransactionException(e);
        } catch (HeuristicMixedException e) {   // commit
            // Thrown to indicate that a heuristic decision was made and that some relevant updates have been committed
            // while others have been rolled back. 
            throw new TransactionException(e);
        } catch (HeuristicRollbackException e) { // commit
            // Thrown to indicate that a heuristic decision was made and that all relevant updates have been rolled back.
            throw new TransactionException(e);
        } catch (SQLException sqle) {
            try {
                logger.info("Rolling back.");
                userTransaction.rollback();
            } catch (IllegalStateException e1) {
                logger.error(e1);
            } catch (SecurityException e1) {
                logger.error(e1);
            } catch (SystemException e1) {
                logger.error(e1);
            }
            // ORA-12899: value too large for column 
        	if (sqle.getMessage().indexOf("ORA-12899") != -1) {
                logger.error(sqle);
                return;
            }
            throw sqle; 
        } catch (Exception e) {
            logger.info("Catching unexpected exception in transaction.");
            try {
                logger.info("Rolling back.");
                userTransaction.rollback();
            } catch (IllegalStateException e1) {
                logger.error(e1);
            } catch (SecurityException e1) {
                logger.error(e1);
            } catch (SystemException e1) {
                logger.error(e1);
            }
            throw e;
        } finally {
            int status = Status.STATUS_UNKNOWN;
            try {
                status = userTransaction.getStatus();
            } catch (SystemException e) {
                logger.debug("Exception getting transaction status.", e);
            }
            logger.debug("Transaction Status: " + logUserTransStatus(status));
        }
               
        // non transaction part of event processing
        if (!shipmentExists) {
            // persist reference notes
            logger.info("Persisting reference notes.");
            List referenceNotes = anIpdShipmentVO.get_referenceNotes();
            referenceNoteDAO.doPersist(referenceNotes);
            
            publishNOI(anIpdShipmentVO, anIpdShipmentVO.get_associatedShipments());
        } else {
            List list = referenceNoteDAO.getReferenceNotes(
                    anIpdShipmentVO.get_shipment().get_trkng_item_nbr(),
                    anIpdShipmentVO.get_shipment().get_trkng_item_uniq_nbr());
            if (list == null) {
                // No reference notes yet, so persist
                logger.info("Reference Notes do NOT Exist, persisting");
                List referenceNotes = anIpdShipmentVO.get_referenceNotes();
                referenceNoteDAO.doPersist(referenceNotes);
            } else {
                // Merge reference notes with existing, and persist only the new ones
                logger.info("Reference Notes DO Exist, merging");
                MergeReferenceNotes refNoteMerger = new MergeReferenceNotes();
                List newRefNotes = refNoteMerger.merge(anIpdShipmentVO.get_referenceNotes(), list);
                if (newRefNotes.size() > 0) {
                    logger.info("Adding " + newRefNotes.size() + " new reference notes");
                    referenceNoteDAO.doPersist(newRefNotes);
                } else {
                    logger.info("No new reference notes.");
                }
            }
                 
            publishNOI(anIpdShipmentVO, newAssociations);            
        }
    }
    
    private String logUserTransStatus(int aStatus) {
        switch (aStatus) {
            // A transaction is associated with the target object and it is in the active state.
            case Status.STATUS_ACTIVE:
                return "Status Active";
            // A transaction is associated with the target object and it has been committed.  
            case Status.STATUS_COMMITTED: 
                return "Status Committed";
            // A transaction is associated with the target object and it is in the process of committing.  
            case Status.STATUS_COMMITTING: 
                return "Status Committing";
            // A transaction is associated with the target object and it has been marked for rollback, perhaps as a result of a setRollbackOnly operation. 
            case Status.STATUS_MARKED_ROLLBACK:
                return "Status Marked Rollback";
            // No transaction is currently associated with the target object.  
            case Status.STATUS_NO_TRANSACTION:
                return "Status No Transaction";
            // A transaction is associated with the target object and it has been prepared.  
            case Status.STATUS_PREPARED:
                return "Status Prepared";
            // A transaction is associated with the target object and it is in the process of preparing.  
            case Status.STATUS_PREPARING: 
                return "Status Preparing";
            // A transaction is associated with the target object and the outcome has been determined to be rollback.  
            case Status.STATUS_ROLLEDBACK: 
                return "Status Rolledback";
            // A transaction is associated with the target object and it is in the process of rolling back.  
            case Status.STATUS_ROLLING_BACK: 
                return "Status Rolling Back";
            //case Status.STATUS_UNKNOWN  
        }
        return "Status Unknown";

    }

    // AWB's do not always have associated groups to their parent CRN, so we must
    // find the parent CRN, get its trkngNbr and trkUniqueNbr and set the AWB
    // with that information so that it can point to its parent.
    // We then update the CRN with the rtrnTrkngUniqeNbr, or pwrkTrkngUniqueNbr,
    // which we did not have when we learned about the return/paperwork shipment.
                      
    // For paperwork, we only learn about them in the assoication group, where
    // hopefully, most of the time, they will have a unique id, and it seems like they do
    
    // For Returns, sometimes we learn about them in the master list, without
    // a unique id, and sometimes we learn about them in the association group
    // where they may have a unique id
     
    
    /**
     * Persist the NOI's so that they can be sent using the timer.
     * Since NOI's are not a life or death event, catch the exceptions
     */
    private void publishNOI(IPDShipmentVO anIPDShipmentVO, List assocShipments) {
        NOIPublishBO noiPublish = new NOIPublishBO();
        Iterator iter = assocShipments.iterator();
        while(iter.hasNext()) {
            try {
                AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                String trkngItemNbr = assocShipmentVO.get_assoc_trkng_item_nbr();
                if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.PAPERWORK) {
                    logger.info("Recording NOI for Paper Work:" + trkngItemNbr);
                    noiPublish.doPersist(trkngItemNbr, anIPDShipmentVO.get_event().get_event_crtn_tmstp().getTime());
                }
                  
                if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.RETURN) {
                    logger.info("Recording NOI for Return Trkng:" + trkngItemNbr);
                    noiPublish.doPersist(trkngItemNbr, anIPDShipmentVO.get_event().get_event_crtn_tmstp().getTime());
                }
            } catch (SQLException sqle) {
                logger.error("SQL Exception persisting NOI", sqle);
            } catch (ServiceLocatorException sle) {
                logger.error("Service Locator Exception:", sle);
            } catch (Exception e) {
                logger.error("Exception durin NOI process:", e);
            }
        }
    }
}
