package com.fedex.rise.bo.issue;

import java.util.ArrayList;

public class IssueDesc {
    String shortTextDesc;
    String longTextDesc;
 
    private static ArrayList _instances = new ArrayList(); 
    
    public IssueDesc(String aShortTextDesc, String aLongTextDesc) {
        shortTextDesc = aShortTextDesc;
        longTextDesc = aLongTextDesc;
    }
    
    public static IssueDesc getInstance(String aShortTextDesc, String aLongTextDesc) {
        IssueDesc issueDesc = new IssueDesc(aShortTextDesc, aLongTextDesc);
        if (_instances.contains(issueDesc)) {
            int index = _instances.indexOf(issueDesc);
            return (IssueDesc)_instances.get(index);
        } else {
            _instances.add(issueDesc);
            return issueDesc;
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((longTextDesc == null) ? 0 : longTextDesc.hashCode());
        result = PRIME * result + ((shortTextDesc == null) ? 0 : shortTextDesc.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final IssueDesc other = (IssueDesc) obj;
        if (longTextDesc == null) {
            if (other.longTextDesc != null)
                return false;
        } else if (!longTextDesc.equals(other.longTextDesc))
            return false;
        if (shortTextDesc == null) {
            if (other.shortTextDesc != null)
                return false;
        } else if (!shortTextDesc.equals(other.shortTextDesc))
            return false;
        return true;
    }

    /**
     * @return the longTextDesc
     */
    public String getLongTextDesc() {
        return longTextDesc;
    }
    
    /**
     * @return the shortTextDesc
     */
    public String getShortTextDesc() {
        return shortTextDesc;
    }
    
    public String toString() {
        return shortTextDesc + "," + longTextDesc;
    }

}
