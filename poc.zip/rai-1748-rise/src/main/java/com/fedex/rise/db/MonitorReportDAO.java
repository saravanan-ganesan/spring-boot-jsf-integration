package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.MonitorReportVO;



/**
 * DAO class to access data for the Monitor Report.
 * @author be379961
 *
 */
public class MonitorReportDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(MonitorReportDAO.class);
    
    /**
     * Persist the duration time to the Monitor Report table.  
     * @param duration time
     * @param employee number
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void setDuration(long durationTime, String employeeNbr) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {  
        	connection = initializeConnection();
        	
            // Get the work date, which is today.
            Calendar workDate = Calendar.getInstance();
			
			// Determine if row already exists, if it doesn't persist the duration time.  
			// Otherwise, do an update to the duration time.
			EmployeeVO aEmployeeVO = new EmployeeVO();
			aEmployeeVO.set_emp_nbr(employeeNbr);
			MonitorReportVO aMonitorReportVO = new MonitorReportVO();
			aMonitorReportVO.set_work_dt(workDate);
    		aMonitorReportVO.set_emp_nbr(aEmployeeVO.get_emp_nbr());
    		int dt = (int)(durationTime/1000); // Set time to seconds.
    		aMonitorReportVO.set_total_duration(dt);
    		
    		if (!rowExist(aEmployeeVO, workDate.getTime())) {
    			MonitorReportPersister persister = 
                	new MonitorReportPersister(connection);
                persister.doPersistDurationTime(aMonitorReportVO);
    		}else{
    			MonitorReportUpdater updater =
    				new MonitorReportUpdater(connection);
    			int durTime = updater.getDurationTimeForUpdate(aMonitorReportVO);
    			aMonitorReportVO.set_total_duration(durTime + dt);
    			updater.updateDurationTime(aMonitorReportVO);
    		}
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Persist the duration time to the Monitor Report table.  
     * @param duration time
     * @param employee number
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void setNumberHits(MonitorReportVO aMonitorReportVO) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {  
        	connection = initializeConnection();
            
            // Determine if row already exists, if it doesn't persist the number of hits.  
			// Otherwise, do an update to the number of hits.
			EmployeeVO aEmployeeVO = new EmployeeVO();
			aEmployeeVO.set_emp_nbr(aMonitorReportVO.get_emp_nbr());
    		
    		if (!rowExist(aEmployeeVO, aMonitorReportVO.get_work_dt().getTime())) {
    			MonitorReportPersister persister = 
                	new MonitorReportPersister(connection);
                persister.doPersistNumberHits(aMonitorReportVO);
    		}else{
    			MonitorReportUpdater updater =
    				new MonitorReportUpdater(connection);
    			updater.updateNumberHits(aMonitorReportVO);
    		}
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Persist a MonitorReportVO to the Monitor Report table.  
     * @param aMonitorReportVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void doPersist(MonitorReportVO aMonitorReportVO) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection();
            MonitorReportPersister persister = 
            	new MonitorReportPersister(connection);
            persister.doPersist(aMonitorReportVO);
        } finally {
            closeConnection(connection);
        }
    }

    /**
     * Update a MonitorReportVO to the Monitor Report table.  
     * @param aMonitorReportVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void updateMonitorReport(MonitorReportVO aMonitorReportVO) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection(true);
            MonitorReportUpdater monitorReportUpdater 
            	= new MonitorReportUpdater(connection);
            monitorReportUpdater.updateMonitorReport(aMonitorReportVO);
        } finally {
            closeConnection(connection);
        }
    }
    /**
     * Get a list of MonitorReportVOs from the Monitor_Report and Employee tables, based on the 
     * work dates.  
     * @param date
     * @return List
     * @throws SQLException
     * @throws ServiceLocatorException
     */
     public List getMonitorReportList(Date fromDate, Date toDate) throws SQLException, 
     		ServiceLocatorException {
    	        	
     	        Connection connection = null;
     	        ArrayList al = new ArrayList();
     	        try {
     	            connection = initializeConnection();   
     	            
     	           // Get employee information. 
     	           EmployeeAccessor employeeAccessor = 
     	        	   new EmployeeAccessor(connection);
     	           List employees = employeeAccessor.getAllMonitorEmployees();
     	           
     	            MonitorReportAccessor accessor = 
     	            	new MonitorReportAccessor(connection);
     	            
     	           // Get monitor report data for each employee.
     	           Iterator itr = employees.iterator();    	           
     	           while (itr.hasNext()) {
     	        	   EmployeeVO employeeVO = (EmployeeVO) itr.next();
     	        	   MonitorReportVO monitorReportVO = accessor.getMonitorReportSum(employeeVO, fromDate, toDate);
     	        	   
     	        	   // Set the employee name and number of accounts.
     	        	   monitorReportVO.set_total_number_accounts(accessor.getNumberMonitorAccounts(employeeVO, toDate));
     	        	   monitorReportVO.set_emp_first_nm(employeeVO.get_emp_first_nm());
     	        	   monitorReportVO.set_emp_last_nm(employeeVO.get_emp_last_nm());
     	        	  
     	        	   al.add(monitorReportVO);
     	           }
     	            
    	            return al;
     	        } finally {
     	            closeConnection(connection);
     	        }        
     }
     
     /**
      * Get a list of MonitorReportVOs from the Monitor_Report table for a single work date. 
      * @param workDate
      * @return List of MonitorReportVO
      * @throws SQLException
      * @throws ServiceLocatorException
      */
      public List getMonitorReportList(Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();   
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
      	            
     	            return accessor.getMonitorReport(workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get a list of MonitorReportVOs from the Monitor_Report and Employee tables, based on the 
      * work dates.  
      * @param monitorName
      * @param monitorType
      * @param fromDate
      * @param toDate
      * @param startIndex
      * @param endIndex
      * @param isSortAscending
      * @return List
      * @throws SQLException
      * @throws ServiceLocatorException
      */
      public List getMonitorReportList(String monitorName, String monitorType, Date fromDate, Date toDate,
    		int startIndex, int endIndex, String sortColumn, 
    		boolean isSortAscending) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        ArrayList al = new ArrayList();
      	        try {
      	            connection = initializeConnection();   
      	            
      	           //Get the monitor first and last name.
      	           String [] firstLastName = monitorName.split(" ");
      	           String firstName =  firstLastName[0];
      	           String lastName = firstLastName[1];
      	           
      	           // Get employee information. 
      	           EmployeeAccessor employeeAccessor = 
      	        	   new EmployeeAccessor(connection);
      	           EmployeeVO employeeVO = employeeAccessor.getEmployee(firstName, lastName);
      	           
      	           MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
      	            
      	           // Get monitor report data for a specific employee.
      	           return accessor.getMonitorReport(monitorType, employeeVO, fromDate, toDate, startIndex, 
      	        		   endIndex,sortColumn, isSortAscending);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
      
     /**
      * Get a list of MonitorReportVOs from the Monitor_Report and Employee tables, based on the 
      * work dates.  
      * @param monitorName
      * @param monitorType
      * @param fromDate
      * @param toDate
      * @return List
      * @throws SQLException
      * @throws ServiceLocatorException
      */
      public List getMonitorReportList(String monitorName, String monitorType, Date fromDate, Date toDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        ArrayList al = new ArrayList();
      	        try {
      	            connection = initializeConnection();   
      	            
      	           //Get the monitor first and last name.
      	           String [] firstLastName = monitorName.split(" ");
      	           String firstName =  firstLastName[0];
      	           String lastName = firstLastName[1];
      	           
      	           // Get employee information. 
      	           EmployeeAccessor employeeAccessor = 
      	        	   new EmployeeAccessor(connection);
      	           EmployeeVO employeeVO = employeeAccessor.getEmployee(firstName, lastName);
      	           
      	           MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
      	            
      	           // Get monitor report data for a specific employee.
      	           return accessor.getMonitorReport(monitorType, employeeVO, fromDate, toDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
      
      /**
       * Get a list of MonitorReportVOs from the Monitor_Report and Employee tables, based on the 
       * work dates.  
       * @param monitorName
       * @param monitorType
       * @param fromDate
       * @param toDate
       * @return int
       * @throws SQLException
       * @throws ServiceLocatorException
       */
       public int getMonitorReportCount(String monitorName, String monitorType, Date fromDate, Date toDate) throws SQLException, 
       		ServiceLocatorException {
      	        	
       	        Connection connection = null;
       	        ArrayList al = new ArrayList();
       	        try {
       	            connection = initializeConnection();   
       	            
       	           //Get the monitor first and last name.
       	           String [] firstLastName = monitorName.split(" ");
       	           String firstName =  firstLastName[0];
       	           String lastName = firstLastName[1];
       	           
       	           // Get employee information. 
       	           EmployeeAccessor employeeAccessor = 
       	        	   new EmployeeAccessor(connection);
       	           EmployeeVO employeeVO = employeeAccessor.getEmployee(firstName, lastName);
       	           
       	           MonitorReportAccessor accessor = 
       	            	new MonitorReportAccessor(connection);
       	            
       	           // Get monitor report data for a specific employee.
       	           return accessor.getMonitorCount(monitorType, employeeVO, fromDate, toDate);
       	        } finally {
       	            closeConnection(connection);
       	        }        
       }
     
     /**
      * Get the number of accounts this employee monitors.  
      * 
      * @param employeeVO
      * @return count of the number of accounts this employee monitors.
      * @throws SQLException 
      * @throws ServiceLocatorException
      */
     public int getEmployeeAccountsCount(EmployeeVO employeeVO) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getEmployeeAccountsCount(employeeVO);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get the count of issues resolved for the employee.  
      * 
      * @param employeeVO
      * @param workDate
      * @return count of issues resolved for the employee
      * @throws SQLException 
      */
     public int getIssuesResolvedCount(EmployeeVO employeeVO, Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getIssuesResolvedCount(employeeVO, workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get the count of MAWB issues resolved for the employee.  
      * 
      * @param employeeVO
      * @param workDate
      * @return count of MAWB issues resolved for the employee
      * @throws SQLException 
      */
     public int getMAWBResolvedCount(EmployeeVO employeeVO, Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getMAWBResolvedCount(employeeVO, workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get the count of CRN issues resolved for the employee.  
      * 
      * @param employeeVO
      * @param workDate
      * @return count of CRN issues resolved for the employee
      * @throws SQLException 
      */
     public int getCRNResolvedCount(EmployeeVO employeeVO, Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getCRNResolvedCount(employeeVO, workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get the count of issues received for the employee.  
      * 
      * @param employeeVO
      * @param workDate
      * @return count of all issues received for the employee
      * @throws SQLException 
      */
     public int getIssuesReceivedCount(EmployeeVO employeeVO, Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getIssuesReceivedCount(employeeVO, workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get the count of issues presented to the monitor at the beginning of the work day.  
      * 
      * @param employeeVO
      * @param workDate
      * @return count of issues presented to the monitor at the begining of the work day
      * @throws SQLException
      */
     public int getIssuesBeginingShiftCount(EmployeeVO employeeVO, Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getIssuesBeginingShiftCount(employeeVO, workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Get the count of issues presented to the monitor at the end of the work day.  
      * 
      * @param employeeVO
      * @param workDate
      * @return count of issues presented to the monitor at the end of the work day
      * @throws SQLException
      */
     public int getIssuesEndShiftCount(EmployeeVO employeeVO, Date workDate) throws SQLException, 
      		ServiceLocatorException {
     	        	
      	        Connection connection = null;
      	        try {
      	            connection = initializeConnection();
      	           
      	            MonitorReportAccessor accessor = 
      	            	new MonitorReportAccessor(connection);
     	            
     	            return accessor.getIssuesEndShiftCount(employeeVO, workDate);
      	        } finally {
      	            closeConnection(connection);
      	        }        
      }
     
     /**
      * Determine if a row already exists in the Monitor Report table.  
      * @param employeeVO
      * @param workDate
      * @return
      * @throws SQLException
      * @throws ServiceLocatorException
      */
     public boolean rowExist(EmployeeVO employeeVO, Date workDate) 
     	throws SQLException, ServiceLocatorException {
         	
         Connection connection = null;
         try {
             connection = initializeConnection();
             MonitorReportAccessor accessor = new MonitorReportAccessor(connection);
             if (accessor.getMonitorReport(employeeVO, workDate, workDate) != null){
                 return true;
             }
         } finally {
             closeConnection(connection);
         }
         return false;        
     }

     /**
      * Get the MAX work date from the configuration table.  
      * @return MAX work date
      * @throws SQLException
      * @throws ServiceLocatorException
      */
     public Calendar getMaxWorkDate() throws SQLException, 
     	ServiceLocatorException {
     	        	
         Connection connection = null;
     	Calendar workDate = null;
         try {
         	connection = initializeConnection();
         	ConfigurationAccessor accessor = 
         		new ConfigurationAccessor(connection);  
     	       	String maxWorkDateStr = accessor.getValue("MAX_WORK_DT");
     	        if (maxWorkDateStr == null){
     	        	return null;
     	        }else{
     	        	SimpleDateFormat inputFormat = 
     	        		new SimpleDateFormat("yyyyMMdd");
     	            Date d = null;
     	            try {
     	            	d = inputFormat.parse(maxWorkDateStr);
     	            	if (d == null){
     	            		return null;
     	            	}
     	            } catch (ParseException e) {
     	            	logger.error("ParseException: ", e);
     	            }
     	            workDate = Calendar.getInstance();
     	            workDate.setTime(d);
     	        }
     	        return workDate;
         	} finally {
         		closeConnection(connection);
         }        
     }
}
