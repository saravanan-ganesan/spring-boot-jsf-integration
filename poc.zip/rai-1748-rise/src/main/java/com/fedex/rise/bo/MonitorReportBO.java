package com.fedex.rise.bo;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.MonitorReportDAO;
import com.fedex.rise.db.ConfigurationDAO;
import com.fedex.rise.db.EmployeeDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.MonitorReportVO;

/**
 * Class that calculates Monitor Reports and inserts the results in the
 * Monitor Report table.
 * @author be379961
 *
 */
public class MonitorReportBO extends MonitorReportDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(MonitorReportBO.class);
    private static final int MAX_LOOPS = 187; // The max number of days event data is retained.
    private static final String MAX_WORK_DT = "MAX_WORK_DT";
	
    /**
     * Constructor.
     */
    public MonitorReportBO(){
    }
    
    /**
     * Determines how many days the monitor report needs to be calculated.
     *
     */
    public void monitorReport(){
    	// Get the work date which is based on the calculation of todays 
    	// or what it is configued.  The set the time part
    	// of workDate time to zero, while maintaining the day, month, and year.
    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
    	Calendar workDate = getWorkDate();
    	workDate = setTimeZero(workDate);
    	try {
    		// Get the last successful run of monitor report by getting the max 
    		// work date and set the time part of it to zero. while maintaining 
    		// the day, month, and year.
    		Calendar maxWorkDate = monitorReportDAO.getMaxWorkDate();
    		if (maxWorkDate != null && workDate != null){
    			maxWorkDate = setTimeZero(maxWorkDate);
    			int nbrLoops = 0;
    			// Continue looping until the work date and max work date are
    			// equal, or the number of loops has exceeded MAX_LOOPS.
    			while (workDate.after(maxWorkDate) && nbrLoops < MAX_LOOPS){
    				// Increment the max work date by one day, and calculate
    				// monitor for the work date of maxWorkDate.
    				maxWorkDate.add(Calendar.DAY_OF_YEAR, 1);
    				monitorReportWorkDay(maxWorkDate);
    				// Get the max work date, and set the time to zero, while 
    				// maintaining the day, month, and year.
    				maxWorkDate = monitorReportDAO.getMaxWorkDate();
    				maxWorkDate = setTimeZero(maxWorkDate);
    				nbrLoops++;
    			}
    			return;
    		}
    		
    	}catch (SQLException e){
    		logger.error("SQLException exception", e);
    	} catch (ServiceLocatorException sle) { 
        	logger.error("Service Locator Exception: ", sle);
        } catch (Exception e) { // SystemException && NotSupportedException
            	logger.error("Exception", e); 
        }
        
        // This part of the code is used when maxWorkDate is null and workDate
        // is not null.  This means that either it is the first time monitor report
        // has run on this DB or there are issues with the DB.  After it has run
        // successfully, insert data into latest work date into the 
        // configuration table.
        if (workDate != null){
        	monitorReportWorkDay(workDate);
        }else {
        	logger.error("monitor report did not run, workDate = null");
        }
    }
    /**
     * Determine what the monitor report is by getting monitor data from various 
     * tables, roll it up by each monitor on a daily basis to the 
     * monitor report table.
     *
     */
    private void monitorReportWorkDay(Calendar workDate){
        
        try {
        	/**
        	 * Begin the daily monitor report calculation.
        	 */
        	SimpleDateFormat sf = new SimpleDateFormat("MM:dd:yyyy:HH:mm:ss");
        	
        	Calendar cal = Calendar.getInstance();
        	String dateStr = sf.format(cal.getTime());
        	logger.info("Start generating Monitor Report data. Start time: " +
        			dateStr);
        	/**
        	 * Get a list of all of the monitors from the EMPLOYEE table.
        	 */
        	EmployeeDAO employeeDAO = new EmployeeDAO();
        	try {
        		List employeesList = employeeDAO.getAllMonitorEmployees();
        		
    			Iterator employeeIterator = employeesList.iterator();
    			while (employeeIterator.hasNext()){
    				EmployeeVO employeeVO = 
                		(EmployeeVO)employeeIterator.next();
                	employeeMonitorReport(employeeVO, workDate);
    			}
    			
    			// After successful calculation of monitor reports for this specific
    			// work date, set it in the configuration table.
    			SimpleDateFormat sd = new SimpleDateFormat("yyyyMMdd");
    			String workDateStr = sd.format(workDate.getTime());
    			ConfigurationDAO configurationDAO = new ConfigurationDAO();
    			configurationDAO.doPersistOrUpdate(MAX_WORK_DT, workDateStr);
    			
    			dateStr = sf.format(cal.getTime());
            	logger.info("Completed calculating Monitor Report data. End time: " 
            			+ dateStr);
        	}catch (SQLException sqle){
        		logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
        			+ sqle.getSQLState()+ ": ErrorCode: " + sqle.getErrorCode());
        		return;
        	}
        } catch (ServiceLocatorException sle) { 
        	logger.error("Service Locator Exception: ", sle);
        } catch (Exception e) { // SystemException && NotSupportedException
            	logger.error("Exception", e); 
        }
    }
    
    
    /**
     * Determine what the monitor report is by getting monitor data from various 
     * tables, roll it up by each monitor on a daily basis to the 
     * monitor report table.
     *
     */
    public void employeeMonitorReport(EmployeeVO employeeVO, 
    		Calendar workDate) throws ServiceLocatorException{
    	
    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
    	MonitorReportVO monitorReportVO = new MonitorReportVO();
    	
    	try {
    		// Get the data for the MonitorReportVO and build it for a specific employee.
    		monitorReportVO.set_work_dt(workDate);
    		monitorReportVO.set_emp_nbr(employeeVO.get_emp_nbr());
    		monitorReportVO.set_total_number_accounts(monitorReportDAO.getEmployeeAccountsCount(employeeVO));
    		monitorReportVO.set_num_issues_resolved(monitorReportDAO.getIssuesResolvedCount(employeeVO, workDate.getTime()));
    		monitorReportVO.set_num_mawb_resolved(monitorReportDAO.getMAWBResolvedCount(employeeVO, workDate.getTime()));
    		monitorReportVO.set_num_crn_resolved(monitorReportDAO.getCRNResolvedCount(employeeVO, workDate.getTime()));
    		monitorReportVO.set_num_issues_presented(monitorReportDAO.getIssuesReceivedCount(employeeVO, workDate.getTime()));
    		monitorReportVO.set_num_issues_begin_shift(monitorReportDAO.getIssuesBeginingShiftCount(employeeVO, workDate.getTime()));
    		monitorReportVO.set_num_issues_end_shift(monitorReportDAO.getIssuesEndShiftCount(employeeVO, workDate.getTime()));
    		
    		// Determine if row already exists, if it doesn't persist it.  Otherwise, do an update.
    		if (!monitorReportDAO.rowExist(employeeVO, workDate.getTime())) {
    			monitorReportDAO.doPersist(monitorReportVO); 
    		}else{
    			monitorReportDAO.updateMonitorReport(monitorReportVO);
    		}
    	}catch (SQLException e){
    		logger.error("SQLException exception", e);
    	}
    	
    }
     
    /**
     * Get the work date to calculate monitor report.
     * @return The work date to calculate the monitor report.
     */
    private Calendar getWorkDate() {
		// Set the work date based on current date 
    	Calendar workDate = Calendar.getInstance();
    	
    	return workDate;
    }
    /**
     * Sets the time portion of work date to zero while maintaining the day, 
     * month and year.
     * @param workDate the day, month and year of Calendar.
     * @return
     */
    private Calendar setTimeZero(Calendar workDate){
    	workDate.set(Calendar.HOUR, 0);
    	workDate.set(Calendar.HOUR_OF_DAY, 0);
    	workDate.set(Calendar.MINUTE, 0);
    	workDate.set(Calendar.SECOND, 0);
    	workDate.set(Calendar.MILLISECOND, 0);
    	return workDate;
    }
}
