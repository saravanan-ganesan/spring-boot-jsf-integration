package com.fedex.rise.cache;

import java.util.Date;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.config.ConfigurationManager;

public class TimedCache {
    private static Logger logger = LogManager.getLogger(TimedCache.class);
    
    private Date _timeToReadCache;
    
    public TimedCache() {
        resetTimer();
    }

    private void resetTimer() {
        Date d = new Date();
        String minutesStr = ConfigurationManager.get("CACHE_LOAD_INTERVAL_IN_MINUTES");
        logger.info("Caches are set to load every " + minutesStr + " minutes");
        int minutes = 10;
        try {
            minutes = Integer.parseInt(minutesStr);
        } catch (NumberFormatException nfe) {
        }
        d.setTime(d.getTime() + (minutes * 60 * 1000));
        _timeToReadCache = d;
    }
    
    public boolean isTimeToLoad() {
        Date d = new Date();
        if (d.after(_timeToReadCache)) {
            resetTimer();
            return true;
        }
        return false;
    }

}
