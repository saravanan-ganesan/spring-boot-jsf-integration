package com.fedex.rise.config;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;

import org.ocpsoft.rewrite.servlet.RewriteFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fedex.rise.constant.AppConstant;


/**
 * This configuration class is used to register the rewrite filter into the servlet
 * 
 * @author saravanan g
 *
 */
@Configuration
public class FilterRegistrationBeanConfig {

	@Bean
	public FilterRegistrationBean<Filter> rewriteFilter() {
		
		FilterRegistrationBean<Filter> rwFilter = new FilterRegistrationBean<Filter>(new RewriteFilter());
		EnumSet<DispatcherType> enumSet = EnumSet.of(DispatcherType.FORWARD, 
										DispatcherType.REQUEST,
										DispatcherType.ASYNC, 
										DispatcherType.ERROR);
		rwFilter.setDispatcherTypes(enumSet);
		rwFilter.addUrlPatterns(AppConstant.URL_PATTERN_ALL);
		return rwFilter;
		
	}
}
