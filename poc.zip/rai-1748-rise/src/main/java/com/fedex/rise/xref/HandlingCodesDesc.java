package com.fedex.rise.xref;

import java.util.HashMap;

public class HandlingCodesDesc {
    
    private static HashMap handlingCodeTypes = new HashMap();
    
    static {
        handlingCodeTypes.put(new Integer(1), "Hold at FedEx Location");
        handlingCodeTypes.put(new Integer(2), "Delivery Weekday");
        handlingCodeTypes.put(new Integer(3), "For Saturday delivery");
        handlingCodeTypes.put(new Integer(4), "Inaccessible Dangerous Goods");
        handlingCodeTypes.put(new Integer(5), "Electronic Signature Service");
        handlingCodeTypes.put(new Integer(6), "Dry Ice");
        handlingCodeTypes.put(new Integer(7), "Other Special Service");
        handlingCodeTypes.put(new Integer(8), "Unassigned");
        handlingCodeTypes.put(new Integer(9), "Weekend Pick-up");
        handlingCodeTypes.put(new Integer(10), "Direct Signature Required");
        handlingCodeTypes.put(new Integer(11), "Chargeable Code");
        handlingCodeTypes.put(new Integer(12), "Emerge");
        handlingCodeTypes.put(new Integer(13), "COD");
        handlingCodeTypes.put(new Integer(14), "Accessible Dangerous Goods");
        handlingCodeTypes.put(new Integer(15), "Priority Alert");
        handlingCodeTypes.put(new Integer(16), "Additonal Handling Charge");
        handlingCodeTypes.put(new Integer(17), "Appointment Delivery");
        handlingCodeTypes.put(new Integer(18), "Piece Count Verification");
        handlingCodeTypes.put(new Integer(19), "Third Party Consignee");
        handlingCodeTypes.put(new Integer(21), "Intl Mail Service");
        handlingCodeTypes.put(new Integer(28), "Resi Del");
        handlingCodeTypes.put(new Integer(29), "Unassigned");
        handlingCodeTypes.put(new Integer(31), "Saturday Hold at FedEx Location");
        handlingCodeTypes.put(new Integer(33), "Sunday Delivery");
        handlingCodeTypes.put(new Integer(34), "Indirect Signature Required");
        handlingCodeTypes.put(new Integer(35), "Adult Signature Required");
        handlingCodeTypes.put(new Integer(39), "Cut Flowers");
        handlingCodeTypes.put(new Integer(40), "Broker Selection Option");
        handlingCodeTypes.put(new Integer(61), "Lift Gate");
        handlingCodeTypes.put(new Integer(69), "Unused");
        handlingCodeTypes.put(new Integer(91), "Intl Controlled Export Svc");
    }
    
    public static String lookupHandlinCdDesc(String aHanldingCd) {
        Integer i = new Integer(aHanldingCd);
        return (String)handlingCodeTypes.get(i);
    }
}
