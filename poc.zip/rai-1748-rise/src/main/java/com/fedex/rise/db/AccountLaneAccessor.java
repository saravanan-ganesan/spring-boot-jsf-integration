package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountLaneVO;
/**
 * Account Lane table accessor class.
 * 
 * @author be379961
 *
 */
public class AccountLaneAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(AccountLaneAccessor.class);
    /**
     * Constructor.
     * 
     * @param con
     */        
    public AccountLaneAccessor(Connection con) {
        super(con);
    }
            
    private final String selectAccountLaneSQL = "select " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "LANE_NBR, " +
        "RTRN_ACCT_NBR, " +
        "RTRN_ADDR_LINE_ONE_DESC, " +
        "RTRN_ADDR_LINE_TWO_DESC, " +
        "RTRN_ADDR_LINE_THREE_DESC, " +
        "RTRN_CITY_NM, " +
        "RTRN_ST_PROV_CD, " +
        "RTRN_CONT_NM, " +
        "RTRN_CONT_PH_NBR, " +
        "IM_OF_REC_NM, " +
        "IM_OF_REC_ADDR_LINE_ONE_DESC, " +
        "IM_OF_REC_ADDR_LINE_TWO_DESC, " +
        "IM_OF_REC_CITY_NM, " +
        "IM_OF_REC_ST_PROV_CD, " +
        "IM_OF_REC_PSTL_CD, " +
        "IM_OF_REC_CONT_NM, " +
        "IM_OF_REC_PH_NBR, " +
        "IM_OF_REC_FAX_NBR, " +
        "IM_OF_REC_EMAIL_DESC, " +
        "ORIG_ACCT_EXEC_NM, " +
        "ORIG_ACCT_EXEC_PH_NBR, " +
        "ORIG_ACCT_EXEC_FAX_NBR, " +
        "ORIG_ACCT_EXEC_EMAIL_DESC, " +
        "DEST_ACCT_EXEC_NM, " +
        "DEST_ACCT_EXEC_PH_NBR, " +
        "DEST_ACCT_EXEC_FAX_NBR, " +
        "DEST_ACCT_EXEC_EMAIL_DESC, " +
        "BRKR_NM, " +
        "BRKR_PH_NBR, " +
        "BRKR_FAX_NBR, " +
        "PRIM_ENGNR_NM, " +
        "PRIM_ENGNR_PH_NBR, " +
        "PRIM_ENGNR_FAX_NBR, " +
        "PRIM_ENGNR_EMAIL_DESC, " +
        "SCNDY_ENGNR_NM, " +
        "SCNDY_ENGNR_PH_NBR, " +
        "SCNDY_ENGNR_FAX_NBR, " +
        "SCNDY_ENGNR_EMAIL_DESC " +
        " from Account_Lane where GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ?";            
            
    
    private final String selectAccountLanesSQL = "select " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "LANE_NBR, " +
        "RTRN_ACCT_NBR, " +
        "RTRN_ADDR_LINE_ONE_DESC, " +
        "RTRN_ADDR_LINE_TWO_DESC, " +
        "RTRN_ADDR_LINE_THREE_DESC, " +
        "RTRN_CITY_NM, " +
        "RTRN_ST_PROV_CD, " +
        "RTRN_CONT_NM, " +
        "RTRN_CONT_PH_NBR, " +
        "IM_OF_REC_NM, " +
        "IM_OF_REC_ADDR_LINE_ONE_DESC, " +
        "IM_OF_REC_ADDR_LINE_TWO_DESC, " +
        "IM_OF_REC_CITY_NM, " +
        "IM_OF_REC_ST_PROV_CD, " +
        "IM_OF_REC_PSTL_CD, " +
        "IM_OF_REC_CONT_NM, " +
        "IM_OF_REC_PH_NBR, " +
        "IM_OF_REC_FAX_NBR, " +
        "IM_OF_REC_EMAIL_DESC, " +
        "ORIG_ACCT_EXEC_NM, " +
        "ORIG_ACCT_EXEC_PH_NBR, " +
        "ORIG_ACCT_EXEC_FAX_NBR, " +
        "ORIG_ACCT_EXEC_EMAIL_DESC, " +
        "DEST_ACCT_EXEC_NM, " +
        "DEST_ACCT_EXEC_PH_NBR, " +
        "DEST_ACCT_EXEC_FAX_NBR, " +
        "DEST_ACCT_EXEC_EMAIL_DESC, " +
        "BRKR_NM, " +
        "BRKR_PH_NBR, " +
        "BRKR_FAX_NBR, " +
        "PRIM_ENGNR_NM, " +
        "PRIM_ENGNR_PH_NBR, " +
        "PRIM_ENGNR_FAX_NBR, " +
        "PRIM_ENGNR_EMAIL_DESC, " +
        "SCNDY_ENGNR_NM, " +
        "SCNDY_ENGNR_PH_NBR, " +
        "SCNDY_ENGNR_FAX_NBR, " +
        "SCNDY_ENGNR_EMAIL_DESC " +
        " from Account_Lane where GROUP_NBR = ? and ACCT_NBR = ?";  
    
    private final String selectAccountLaneTableSQL = "select " +
    "GROUP_NBR, " +
    "ACCT_NBR, " +
    "LANE_NBR " +
    " from Account_Lane";
    
    private final String selectAccountLaneListSQL = "select " +
    "GROUP_NBR, " +
    "ACCT_NBR, " +
    "LANE_NBR " +
    " from Account_Lane where GROUP_NBR = ?";

    /**
     * Return the list of AccountLaneVO for a GROUP_NBR, ACCT_NBR, and LANE_NBR.
     * @param groupNbr
     * @param accountNbr
     * @param laneNbr
     * @return AccountLaneVO for a GROUP_NBR, ACCT_NBR, and LANE_NBR.
     * @throws Exception 
     */
    public AccountLaneVO getAccountLane(int groupNbr, String accountNbr, int laneNbr) throws SQLException {
        AccountLaneVO accountLaneVO = null;
                
        try {
            setSqlSignature( selectAccountLaneSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, groupNbr);
            pstmt.setString( 2, accountNbr);
            pstmt.setInt   ( 3, laneNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                if (rs.next()) {
                    accountLaneVO = new AccountLaneVO();
                        
                    accountLaneVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountLaneVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    accountLaneVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                    accountLaneVO.set_rtrn_acct_nbr(rs.getString("RTRN_ACCT_NBR"));
                    accountLaneVO.set_rtrn_addr_line_one_desc(rs.getString("RTRN_ADDR_LINE_ONE_DESC"));
                    accountLaneVO.set_rtrn_addr_line_two_desc(rs.getString("RTRN_ADDR_LINE_TWO_DESC"));
                    accountLaneVO.set_rtrn_addr_line_three_desc(rs.getString("RTRN_ADDR_LINE_THREE_DESC"));
                    accountLaneVO.set_rtrn_city_nm(rs.getString("RTRN_CITY_NM"));
                    accountLaneVO.set_rtrn_st_prov_cd(rs.getString("RTRN_ST_PROV_CD"));
                    accountLaneVO.set_rtrn_cont_nm(rs.getString("RTRN_CONT_NM"));
                    accountLaneVO.set_rtrn_cont_ph_nbr(rs.getString("RTRN_CONT_PH_NBR"));
                    accountLaneVO.set_im_of_rec_nm(rs.getString("IM_OF_REC_NM"));
                    accountLaneVO.set_im_of_rec_addr_line_one_desc(rs.getString("IM_OF_REC_ADDR_LINE_ONE_DESC"));
                    accountLaneVO.set_im_of_rec_addr_line_two_desc(rs.getString("IM_OF_REC_ADDR_LINE_TWO_DESC"));
                    accountLaneVO.set_im_of_rec_city_nm(rs.getString("IM_OF_REC_CITY_NM"));
                    accountLaneVO.set_im_of_rec_st_prov_cd(rs.getString("IM_OF_REC_ST_PROV_CD"));
                    accountLaneVO.set_im_of_rec_pstl_cd(rs.getString("IM_OF_REC_PSTL_CD"));
                    accountLaneVO.set_im_of_rec_cont_nm(rs.getString("IM_OF_REC_CONT_NM"));
                    accountLaneVO.set_im_of_rec_ph_nbr(rs.getString("IM_OF_REC_PH_NBR"));
                    accountLaneVO.set_im_of_rec_fax_nbr(rs.getString("IM_OF_REC_FAX_NBR"));
                    accountLaneVO.set_im_of_rec_email_desc(rs.getString("IM_OF_REC_EMAIL_DESC"));
                    accountLaneVO.set_orig_acct_exec_nm(rs.getString("ORIG_ACCT_EXEC_NM"));
                    accountLaneVO.set_orig_acct_exec_ph_nbr(rs.getString("ORIG_ACCT_EXEC_PH_NBR"));
                    accountLaneVO.set_orig_acct_exec_fax_nbr(rs.getString("ORIG_ACCT_EXEC_FAX_NBR"));
                    accountLaneVO.set_orig_acct_exec_email_desc(rs.getString("ORIG_ACCT_EXEC_EMAIL_DESC"));
                    accountLaneVO.set_dest_acct_exec_nm(rs.getString("DEST_ACCT_EXEC_NM"));
                    accountLaneVO.set_dest_acct_exec_ph_nbr(rs.getString("DEST_ACCT_EXEC_PH_NBR"));
                    accountLaneVO.set_dest_acct_exec_fax_nbr(rs.getString("DEST_ACCT_EXEC_FAX_NBR"));
                    accountLaneVO.set_dest_acct_exec_email_desc(rs.getString("DEST_ACCT_EXEC_EMAIL_DESC"));
                    accountLaneVO.set_brkr_nm(rs.getString("BRKR_NM"));
                    accountLaneVO.set_brkr_ph_nbr(rs.getString("BRKR_PH_NBR"));
                    accountLaneVO.set_brkr_fax_nbr(rs.getString("BRKR_FAX_NBR"));
                    accountLaneVO.set_prim_engnr_nm(rs.getString("PRIM_ENGNR_NM"));
                    accountLaneVO.set_prim_engnr_ph_nbr(rs.getString("PRIM_ENGNR_PH_NBR"));
                    accountLaneVO.set_prim_engnr_fax_nbr(rs.getString("PRIM_ENGNR_FAX_NBR"));
                    accountLaneVO.set_prim_engnr_email_desc(rs.getString("PRIM_ENGNR_EMAIL_DESC"));
                    accountLaneVO.set_scndy_engnr_nm(rs.getString("SCNDY_ENGNR_NM"));
                    accountLaneVO.set_scndy_engnr_ph_nbr(rs.getString("SCNDY_ENGNR_PH_NBR"));
                    accountLaneVO.set_scndy_engnr_fax_nbr(rs.getString("SCNDY_ENGNR_FAX_NBR"));
                    accountLaneVO.set_scndy_engnr_email_desc(rs.getString("SCNDY_ENGNR_EMAIL_DESC"));
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode());
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return accountLaneVO;
    } 
    
    /**
     * Return the list of AccountLaneVO for a GROUP_NBR, and ACCT_NBR.
     * @param aGroupNbr
     * @param anAccountNbr
     * @return list of AccountLaneVO for a GROUP_NBR, and ACCT_NBR.
     * @throws SQLException 
     */
    public List getAccountLanes(int aGroupNbr, String anAccountNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectAccountLanesSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, aGroupNbr);
            pstmt.setString( 2, anAccountNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    AccountLaneVO accountLaneVO = new AccountLaneVO();
                        
                    accountLaneVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountLaneVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    accountLaneVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                    accountLaneVO.set_rtrn_acct_nbr(rs.getString("RTRN_ACCT_NBR"));
                    accountLaneVO.set_rtrn_addr_line_one_desc(rs.getString("RTRN_ADDR_LINE_ONE_DESC"));
                    accountLaneVO.set_rtrn_addr_line_two_desc(rs.getString("RTRN_ADDR_LINE_TWO_DESC"));
                    accountLaneVO.set_rtrn_addr_line_three_desc(rs.getString("RTRN_ADDR_LINE_THREE_DESC"));
                    accountLaneVO.set_rtrn_city_nm(rs.getString("RTRN_CITY_NM"));
                    accountLaneVO.set_rtrn_st_prov_cd(rs.getString("RTRN_ST_PROV_CD"));
                    accountLaneVO.set_rtrn_cont_nm(rs.getString("RTRN_CONT_NM"));
                    accountLaneVO.set_rtrn_cont_ph_nbr(rs.getString("RTRN_CONT_PH_NBR"));
                    accountLaneVO.set_im_of_rec_nm(rs.getString("IM_OF_REC_NM"));
                    accountLaneVO.set_im_of_rec_addr_line_one_desc(rs.getString("IM_OF_REC_ADDR_LINE_ONE_DESC"));
                    accountLaneVO.set_im_of_rec_addr_line_two_desc(rs.getString("IM_OF_REC_ADDR_LINE_TWO_DESC"));
                    accountLaneVO.set_im_of_rec_city_nm(rs.getString("IM_OF_REC_CITY_NM"));
                    accountLaneVO.set_im_of_rec_st_prov_cd(rs.getString("IM_OF_REC_ST_PROV_CD"));
                    accountLaneVO.set_im_of_rec_pstl_cd(rs.getString("IM_OF_REC_PSTL_CD"));
                    accountLaneVO.set_im_of_rec_cont_nm(rs.getString("IM_OF_REC_CONT_NM"));
                    accountLaneVO.set_im_of_rec_ph_nbr(rs.getString("IM_OF_REC_PH_NBR"));
                    accountLaneVO.set_im_of_rec_fax_nbr(rs.getString("IM_OF_REC_FAX_NBR"));
                    accountLaneVO.set_im_of_rec_email_desc(rs.getString("IM_OF_REC_EMAIL_DESC"));
                    accountLaneVO.set_orig_acct_exec_nm(rs.getString("ORIG_ACCT_EXEC_NM"));
                    accountLaneVO.set_orig_acct_exec_ph_nbr(rs.getString("ORIG_ACCT_EXEC_PH_NBR"));
                    accountLaneVO.set_orig_acct_exec_fax_nbr(rs.getString("ORIG_ACCT_EXEC_FAX_NBR"));
                    accountLaneVO.set_orig_acct_exec_email_desc(rs.getString("ORIG_ACCT_EXEC_EMAIL_DESC"));
                    accountLaneVO.set_dest_acct_exec_nm(rs.getString("DEST_ACCT_EXEC_NM"));
                    accountLaneVO.set_dest_acct_exec_ph_nbr(rs.getString("DEST_ACCT_EXEC_PH_NBR"));
                    accountLaneVO.set_dest_acct_exec_fax_nbr(rs.getString("DEST_ACCT_EXEC_FAX_NBR"));
                    accountLaneVO.set_dest_acct_exec_email_desc(rs.getString("DEST_ACCT_EXEC_EMAIL_DESC"));
                    accountLaneVO.set_brkr_nm(rs.getString("BRKR_NM"));
                    accountLaneVO.set_brkr_ph_nbr(rs.getString("BRKR_PH_NBR"));
                    accountLaneVO.set_brkr_fax_nbr(rs.getString("BRKR_FAX_NBR"));
                    accountLaneVO.set_prim_engnr_nm(rs.getString("PRIM_ENGNR_NM"));
                    accountLaneVO.set_prim_engnr_ph_nbr(rs.getString("PRIM_ENGNR_PH_NBR"));
                    accountLaneVO.set_prim_engnr_fax_nbr(rs.getString("PRIM_ENGNR_FAX_NBR"));
                    accountLaneVO.set_prim_engnr_email_desc(rs.getString("PRIM_ENGNR_EMAIL_DESC"));
                    accountLaneVO.set_scndy_engnr_nm(rs.getString("SCNDY_ENGNR_NM"));
                    accountLaneVO.set_scndy_engnr_ph_nbr(rs.getString("SCNDY_ENGNR_PH_NBR"));
                    accountLaneVO.set_scndy_engnr_fax_nbr(rs.getString("SCNDY_ENGNR_FAX_NBR"));
                    accountLaneVO.set_scndy_engnr_email_desc(rs.getString("SCNDY_ENGNR_EMAIL_DESC"));
                        
                    al.add(accountLaneVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    /**
     * Return the list of AccountLaneVO for a GROUP_NBR.
     * @param aGroupNbr
     * @return list of AccountLaneVO for a GROUP_NBR.
     * @throws SQLException 
     */
    public List getAccountLanes(int aGroupNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectAccountLaneListSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, aGroupNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    AccountLaneVO accountLaneVO = new AccountLaneVO();
                        
                    accountLaneVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountLaneVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    accountLaneVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                        
                    al.add(accountLaneVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    /**
     * Return only part of the AccountLaneVO data. Specifically the GROUP_NBR,
     * ACCT_NBR, and LANE_NBR.
     * 
     * @return List of  AccountLaneVO
     */
    public List getAccountLaneTable() throws SQLException {
        ArrayList al = new ArrayList(); 
        
        try {
            setSqlSignature( selectAccountLaneTableSQL, false, logger.isDebugEnabled() );
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    AccountLaneVO accountLaneVO = new AccountLaneVO();
                        
                    accountLaneVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountLaneVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    accountLaneVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                        
                    al.add(accountLaneVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    } 
}

