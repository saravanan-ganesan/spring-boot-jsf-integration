package com.fedex.rise.webejb;

import javax.ejb.SessionBean;

/**
 * 
 * @ejb:bean name="SearchBean" display-name="SearchEJB" jndi-name="SearchEJB"
 *           local-jndi-name="LocalSearchEJB" type="Stateless"
 *           view-type="both"
 * 
 * @ejb:home extends="javax.ejb.EJBHome"
 *           local-extends="javax.ejb.EJBLocalHome"
 * 
 * @ejb:interface extends="javax.ejb.EJBObject"
 *                local-extends="javax.ejb.EJBLocalObject"
 * 
 * @weblogic.enable-call-by-reference True
 * 
 * @weblogic.pool max-beans-in-free-pool="10" 
 * initial-beans-in-free-pool="3"
 * 
 * @ejb.transaction type="Supports"
 */
/**
* SearchEJB
* This class implements the EJB which is accessible via the JSPs. It is a
* stateless SessionBean. This class implements the facade for the Business
* Objects and or Data Access Objects. All EJB/J2EE related things should be
* implemented here leaving the BO's with no knowledge of the EJB/J2EE
* environment.
*/
//@JndiName(remote="webejb/SearchEJBRemote")
//@Session(ejbName = "SearchEJB",
//        maxBeansInFreePool="3",
//        initialBeansInFreePool="1",
//        type = Session.SessionType.STATELESS,
//        defaultTransaction=Constants.TransactionAttribute.SUPPORTS,
//        transactionType=Session.SessionTransactionType.BEAN,
//        enableCallByReference=Constants.Bool.TRUE)
public class SearchEJB { //implements SessionBean {
//
//    private static final long serialVersionUID = 1L;
//
//    /** Logger */
//    private static Logger logger = LogManager.getLogger(SearchEJB.class);
//    
//    private SessionContext mySessionContext = null;
//
//    public SessionContext getSessionContext() {
//        return mySessionContext;
//    }
//
//    public void setSessionContext(SessionContext aSessionContext)
//            throws RemoteException {
//        mySessionContext = aSessionContext;
//    }
//
//    public void ejbActivate() {
//        System.out.println("Activate SearchEJB");
//    }
//
//    public void ejbPassivate() {
//        System.out.println("Passivate SearchEJB");
//    }
//
//    /**
//     * @ejb:create-method
//     */
//    public void ejbCreate() {
//        System.out.println("EJB Create SearchEJB");
//    }
//
//    /**
//     * @ejb:remove-method
//     */
//    public void ejbRemove() { 
//        System.out.println("EJB Remove SearchEJB");
//    }
//
//// Search By Shipper Name or Account Number ---------------------------------------    
//    
//    /**
//     * Get monitored accounts via shipper name
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByShprNm(String aShprNm) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByShprNm(aShprNm);
//    }    
//
//    /**
//     * Get monitored accounts via account number
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByAcctNbr(String aAcctNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByAcctNbr(aAcctNbr);
//    }        
//    
//    /**
//     * Get monitored accounts via tracking number
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByTrkngNbr(String aTrkngNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByTrkngNbr(aTrkngNbr);
//    }
//    //Start WR#:179441 Changes
//     /**
//     * Get monitored accounts via groupName
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByAll() throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByAll();
//    } 
//    
//    /**
//     * Get monitored accounts via groupName,laneNbr
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByGroupLaneNbr(int groupName,int laneNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByGroupLaneNbr(groupName,laneNbr);
//    } 
//    //End WR#:179441 Changes
//    /**
//     * Get monitored accounts via reference number
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu, Date _limitOneWeekFromDate, Date _limitOneWeekToDate) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByReferenceNbr(aReferenceNbr, aReferenceNumberMenu, _limitOneWeekFromDate, _limitOneWeekToDate);
//    } 
//
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountTrackingNumber(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountTrackingNumber(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber);
//    }      
//    
//    /**
//     * Get monitored accounts via tracking number MAWB
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByTrkngNbrMAWB(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }      
//
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountShipperName(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountShipperName(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName);
//    }      
//    
//    /**
//     * Get monitored accounts via account name MAWB
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByAcctNmMAWB(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName,_limitOneWeekFromDateByMAWBShipperName, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }     
//  
//    /**
//     * Get monitored accounts via issue code CRN and acctNbrCRN
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN, String aAcctNbrCRN, Date _toDate4, Date _fromDate4) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByIssueCodeCRN(aTrackingNbrCRN, aIssueCodeCRN, aAcctNbrCRN, _toDate4, _fromDate4);
//    }     
//
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountReturnTrackingNumber(String aReturnTrkngNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountReturnTrackingNumber(aReturnTrkngNbr);
//    }       
//    
//    /**
//     * Get monitored accounts via account return tracking number
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByReturnTrkngNbr(String aReturnTrkngNbr, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByReturnTrkngNbr(aReturnTrkngNbr, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }    
//
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, _limitOneWeekFromDateByCRNRecipientName);
//    }     
//    
//    /**
//     * Get monitored accounts via account recipient Name
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, _limitOneWeekFromDateByCRNRecipientName, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }      
//    
//    /**
//     * Get monitored accounts via ship date
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2, String aSelectedLane2) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByShipDate(_shipDate, aServiceCode2, aAcctNbrMAWB2, aSelectedLane2);
//    }     
//    
//    //WR#:179441 Changes
//    /**
//     * Get monitored accounts via ship date range
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByShipDateRange(Date _limitOneWeekToDate3, Date _limitOneWeekFromDate3, String aServiceCode, String aAcctNbrMAWB3, String aSelectedLane, String sortColumn,boolean ascending) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByShipDateRange(_limitOneWeekToDate3, _limitOneWeekFromDate3, aServiceCode, aAcctNbrMAWB3, aSelectedLane,sortColumn,ascending);
//    }     
//
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountRecipientPostalCode(String aPostalCode, Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountRecipientPostalCode(aPostalCode, _limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode);
//    }    
//    
//    /**
//     * Get monitored accounts via postal code
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByPostalCode(_limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode, aPostalCode, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }      
//    
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getMAWBShipmentsCount(Date _shipDate, String _selectMenu, 
//    		String aClearancePoint) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getMAWBShipmentsCount(_shipDate, _selectMenu, aClearancePoint);
//    }   
//    
//    /**
//     * Get monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List rampHubSearch(Date _shipDate, String _selectMenu, 
//    		String aClearancePoint, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.rampHubSearch(_shipDate, _selectMenu, aClearancePoint, 
//        		sortColumn, isSortAscending, startIndex, endIndex);
//    }
//    
//    /**
//     * Get monitored accounts via Find Monitor Acct Nbr
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByFindMonitorAcctNbr(String aAcctNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByFindMonitorAcctNbr(aAcctNbr);
//    }   
//    
//    /**
//     * Get monitored accounts via Find Monitor Trkng Nbr
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByFindMonitorTrkngNbr(String aTrackingNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByFindMonitorTrkngNbr(aTrackingNbr);
//    }
//    
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountWithODA(String aPostalCode, Date _limitOneWeekToDateByCRNWithODA, Date _limitOneWeekFromDateByCRNWithODA) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountWithODA(aPostalCode, _limitOneWeekToDateByCRNWithODA, _limitOneWeekFromDateByCRNWithODA);
//    }    
//    
//    /**
//     * Get monitored accounts via With ODA
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByWithODACRN(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA, Date _limitOneWeekToDateByCRNWithODA, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByWithODACRN(aAcctNbr, _limitOneWeekFromDateByCRNWithODA, _limitOneWeekToDateByCRNWithODA, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }     
//    
//    /**
//     * Get monitored accounts via Without POD
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByWithoutPODCRN(aAcctNbr2, aTrackingNbrMAWB2);
//    }  
//    
//    /**
//     * Get monitored accounts via Find Missing Data
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByFindMissingData(String aAcctNbr) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByFindMissingData(aAcctNbr);
//    }  
//
//    /**
//     * Get count of monitored accounts via RampHub
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCountRecipientAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.getCRNShipmentsCountRecipientAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress);
//    }      
//    
//    /**
//     * Get monitored accounts via Find By Address
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List searchByAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) throws SQLException {
//        SearchBO searchBO = new SearchBO();
//        return searchBO.searchByAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress, sortColumn, isSortAscending, 
//        		startIndex, endIndex);
//    }     
//    
}
