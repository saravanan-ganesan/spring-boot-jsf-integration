package com.fedex.rise.bo;

/**
 * User Business Delegate which is resposible for getting data from or 
 * setting data in the persistent storage, e.g. the backend database. 
 * 
 */
public class UserDelegate {
//    private static final Log log = LogFactory.getLog(UserDelegate.class);
//
//    public UserRemote getUserBean() {
//        ServiceLocator sl = null;
//        UserHome ubh = null;
//        UserRemote ub = null;
//
//        try {
//            sl = ServiceLocator.getInstance();
//            ubh = (UserHome)sl.getRemoteHome(ServiceLocatorConstants.UserRemoteJNDIName, UserHome.class);
//            ub = ubh.create();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        
//        return ub;
//    }
//
//    public SystemMessageRemote getSystemMessageBean() {
//        ServiceLocator sl = null;
//        SystemMessageHome smbh = null;
//        SystemMessageRemote smb = null;
//
//        try {
//            sl = ServiceLocator.getInstance();
//            smbh = (SystemMessageHome)sl.getRemoteHome(ServiceLocatorConstants.SystemMessageRemoteJNDIName, SystemMessageHome.class);
//            smb = smbh.create();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        
//        return smb;
//    }
//    
//    /**
//     * Get the shippers, accounts, lanes, services that this employee monitors
//     * @param emplyNbr employee number
//     * @return HashMap of HashMaps containing shippers, accounts, lanes, services
//     */
//    //public HashMap getMonitoredAccounts(String emplyNbr) {
//    public List getMonitoredAccounts(String emplyNbr) {
//       
//        UserRemote ub = getUserBean();
//
//        List monitoredAccounts = null;
//        try {
//            monitoredAccounts = ub.getMonitoredAccounts(emplyNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return monitoredAccounts;
//    }
// 
//    /**
//     * @return the users
//     */
//    public List getUsers() {
//        UserRemote ub = getUserBean();
//
//        List users = null;
//        try {
//            users = ub.getUsers();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//  
//        return users;
//    }
//    
//    /**
//     * @return the user
//     */
//    public EmployeeVO getUser(String userId) {
//        UserRemote ub = getUserBean();
//
//        EmployeeVO user = null;
//        try {
//            user = ub.getUser(userId);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//  
//        return user;
//    }
//    
//    /**
//     * Save an edited user
//     * Note: also inserts new users
//     */
//    public void save(EmployeeVO emply) {
//        UserRemote ub = getUserBean();
//
//        try {
//            ub.saveUser(emply);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//    }
//    
//    /**
//     * Delete a user
//     * @param anEmployeeNbr employee number
//     */
//    public void delete(String anEmployeeNbr) {
//        UserRemote ub = getUserBean();
//
//        try {
//            ub.deleteUser(anEmployeeNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//    }
//
//    public List getSystemMessages() {
//        SystemMessageRemote smb = getSystemMessageBean();
//
//        try {
//            return smb.getSystemMessages();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return null;
//    }
//    
}    
