package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EventVO;


public class EventsAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(EventsAccessor.class);
    
    public EventsAccessor(Connection con) {
        super(con);
    }
   
    // Used by monitors to get events/scans, don't show 'RE' scan
    private final String selectEventSQL = "select " +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "TRACK_TYPE_CD, " +
        "EVENT_CRTN_TMSTP, " +
        "EVENT_CRTN_TMZN_OFFST_NBR, " +
        "TRKNG_ITEM_ENTRY_TYPE_CD, " +
        "ECCO_TYPE_CD, " +
        "ECCO_COMM_CD, " +
        "TRACK_EXCP_CD, " +
        "TRACK_LOC_CD, " +
        "ADMIN_LOC_CD, " +
        "SCAN_EMP_NBR, " +
        "TRACK_SRC_CD, " +
        "EVENT_SQNC_NBR, " +
        "EVENT_NOTE_DESC, " +
        "INPUT_TMSTP, " +
        "LAST_UPDT_TMSTP " +
        "from Event where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND " +
            "TRACK_TYPE_CD != 'RE' AND " +
            "TRACK_TYPE_CD != 'DC' " +
        "order by EVENT_CRTN_TMSTP DESC"; // order with newest first

    
    public List getEvents(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
        
        try {
            setSqlSignature( selectEventSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
         
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if ( hasResults ) {
               
                while(rs.next()) {
                // event(s) found
                    EventVO eventVO = new EventVO();
                    eventVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    eventVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    eventVO.set_track_type_cd(rs.getString("TRACK_TYPE_CD"));
                 
                    Date eventCrtnTmstp = rs.getTimestamp("EVENT_CRTN_TMSTP");
                    //logger.debug("GetEvents:" + eventCrtnTmstp.getTime());
                    String eventCrtnTmstpOffset = rs.getString("EVENT_CRTN_TMZN_OFFST_NBR");
                    
                    TimeZone gmtTz= TimeZone.getTimeZone("GMT+0000");
                    Calendar eventCrtnCalendar = Calendar.getInstance(gmtTz);
                    eventCrtnCalendar.setTime(eventCrtnTmstp);    
                    TimeZone eventCrtnTz= TimeZone.getTimeZone("GMT" + eventCrtnTmstpOffset);

                    //logger.debug("GetEvents:" + eventCrtnCalendar);

                    eventCrtnCalendar.setTimeZone(eventCrtnTz);
                    eventVO.set_event_crtn_tmstp(eventCrtnCalendar);
                    
                    eventVO.set_trkng_item_entry_type_cd(rs.getString("TRKNG_ITEM_ENTRY_TYPE_CD"));
                    String eccoTypeCd = rs.getString("ECCO_TYPE_CD");
                    if (eccoTypeCd != null) {
                        eventVO.set_ecco_type_cd(eccoTypeCd.charAt(0));
                    }
                    String eccoCommCd = rs.getString("ECCO_COMM_CD");
                    if (eccoCommCd != null) {
                        eventVO.set_ecco_comm_cd(eccoCommCd.charAt(0));
                    }
                    eventVO.set_track_excp_cd(rs.getString("TRACK_EXCP_CD"));
                    eventVO.set_track_loc_cd(rs.getString("TRACK_LOC_CD"));
                    eventVO.set_admin_loc_cd(rs.getString("ADMIN_LOC_CD"));
                    eventVO.set_scan_emp_nbr(rs.getString("SCAN_EMP_NBR"));
                    eventVO.set_track_src_cd(rs.getString("TRACK_SRC_CD"));
                    eventVO.set_event_sqnc_nbr(rs.getString("EVENT_SQNC_NBR"));
                    eventVO.set_event_note_desc(rs.getString("EVENT_NOTE_DESC"));
                    eventVO.set_input_tmstp((java.util.Date)rs.getTimestamp("INPUT_TMSTP"));
                    eventVO.set_last_updt_tmstp((java.util.Date)rs.getTimestamp("LAST_UPDT_TMSTP"));
                    al.add(eventVO);
                }
            } else {
                // Event not found
                logger.error("Event not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    
    private final String selectEventForIssuesSQL = "select " +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "TRACK_TYPE_CD, " +
        "EVENT_CRTN_TMSTP, " +
        "EVENT_CRTN_TMZN_OFFST_NBR, " +
        "ECCO_TYPE_CD, " +
        "ECCO_COMM_CD, " +
        "TRACK_EXCP_CD " +
        "from Event where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND " +
            "EVENT_CRTN_TMSTP > ? AND " +
            "TRACK_TYPE_CD not in('12','32','DC','90','92','72','73','74','75','76') " + // CONS(12), REX(32), DC, COMM(90), CER(92), MDE2(72,73)
                                                                                         // MDE3(74), AG67(75), CR66(76)
            "order by EVENT_CRTN_TMSTP";

    public List getEventsForIssues(String aTrkngItemNbr, String aTrkngItemUniqNbr, 
            Date aDate) throws SQLException {
        ArrayList al = new ArrayList(); 
        
        try {
            setSqlSignature( selectEventForIssuesSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
            java.sql.Timestamp timeStamp = new java.sql.Timestamp(aDate.getTime());
            pstmt.setTimestamp( 3, timeStamp);
         
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if ( hasResults ) {
               
                while(rs.next()) {
                // event(s) found
                    EventVO eventVO = new EventVO();
                    eventVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    eventVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    eventVO.set_track_type_cd(rs.getString("TRACK_TYPE_CD"));
                 
                    Date eventCrtnTmstp = rs.getTimestamp("EVENT_CRTN_TMSTP");
                    String eventCrtnTmstpOffset = rs.getString("EVENT_CRTN_TMZN_OFFST_NBR");
                    
                    TimeZone gmtTz= TimeZone.getTimeZone("GMT+0000");
                    Calendar eventCrtnCalendar = Calendar.getInstance(gmtTz);
                    eventCrtnCalendar.setTime(eventCrtnTmstp);    
                    TimeZone eventCrtnTz= TimeZone.getTimeZone("GMT" + eventCrtnTmstpOffset);

                    eventCrtnCalendar.setTimeZone(eventCrtnTz);
                    eventVO.set_event_crtn_tmstp(eventCrtnCalendar);
                    
                    eventVO.set_ecco_type_cd(rs.getString("ECCO_TYPE_CD").charAt(0));
                    eventVO.set_ecco_comm_cd(rs.getString("ECCO_COMM_CD").charAt(0));
                    eventVO.set_track_excp_cd(rs.getString("TRACK_EXCP_CD"));

                    al.add(eventVO);
                }
            } else {
                // Event not found
                logger.error("Event not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    
    private final String selectCountPODonMawbSQL = "select count(*)" +
        "from Event where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND TRACK_TYPE_CD = '20'";
    
    public int getCountPodsOnMawb(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        
        try {
            setSqlSignature( selectCountPODonMawbSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if ( hasResults ) {
               
                while(rs.next()) {
                    int count = rs.getInt(1);
                    return count;
                }
            } else {
                // Event not found
                logger.error("Event not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return -1;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return -1;
    }
    
    
    private final String selectSingleEventSQL = "select " +
    "TRKNG_ITEM_NBR, " +
    "TRKNG_ITEM_UNIQ_NBR, " +
    "TRACK_TYPE_CD, " +
    "EVENT_CRTN_TMSTP, " +
    "EVENT_CRTN_TMZN_OFFST_NBR, " +
    "TRKNG_ITEM_ENTRY_TYPE_CD, " +
    "ECCO_TYPE_CD, " +
    "ECCO_COMM_CD, " +
    "TRACK_EXCP_CD, " +
    "TRACK_LOC_CD, " +
    "ADMIN_LOC_CD, " +
    "SCAN_EMP_NBR, " +
    "TRACK_SRC_CD, " +
    "EVENT_SQNC_NBR, " +
    "EVENT_NOTE_DESC, " +
    "INPUT_TMSTP, " +
    "LAST_UPDT_TMSTP " +
    "from Event where " +
        "TRKNG_ITEM_NBR = ? AND " +
        "TRKNG_ITEM_UNIQ_NBR = ? AND " +
        "TRACK_TYPE_CD = ? AND " +
        "EVENT_SQNC_NBR = ?";

    public EventVO getEvent(String aTrkngItemNbr, String aTrkngItemUniqNbr, String aTrackTypeCd,
            String aSeqNbr) throws SQLException {
        EventVO eventVO = new EventVO();
        
        try {

            setSqlSignature( selectSingleEventSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
            pstmt.setString( 3, aTrackTypeCd);
            pstmt.setString( 4, aSeqNbr);
         
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if (hasResults && rs.next()) {
              
                // event found
                eventVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                
                eventVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                eventVO.set_track_type_cd(rs.getString("TRACK_TYPE_CD"));
                
                Date eventCrtnTmstp = rs.getTimestamp("EVENT_CRTN_TMSTP");
                logger.debug("GetEvent:" + eventCrtnTmstp.getTime());
                String eventCrtnTmstpOffset = rs.getString("EVENT_CRTN_TMZN_OFFST_NBR");
                TimeZone eventCrtnTz= TimeZone.getTimeZone("GMT" + eventCrtnTmstpOffset);
                
                TimeZone gmtTz= TimeZone.getTimeZone("GMT+0000");
                Calendar eventCrtnCalendar = Calendar.getInstance(gmtTz);
                eventCrtnCalendar.setTime(eventCrtnTmstp); 
                
                //Calendar eventCrtnCalendar = Calendar.getInstance(eventCrtnTz);
                eventCrtnCalendar.setTimeZone(eventCrtnTz);
                logger.debug("GetEvent:" + eventCrtnCalendar);
                   
                eventVO.set_event_crtn_tmstp(eventCrtnCalendar);
                
                eventVO.set_trkng_item_entry_type_cd(rs.getString("TRKNG_ITEM_ENTRY_TYPE_CD"));
                eventVO.set_ecco_type_cd(rs.getString("ECCO_TYPE_CD").charAt(0));
                eventVO.set_ecco_comm_cd(rs.getString("ECCO_COMM_CD").charAt(0));
                eventVO.set_track_excp_cd(rs.getString("TRACK_EXCP_CD"));
                eventVO.set_track_loc_cd(rs.getString("TRACK_LOC_CD"));
                eventVO.set_admin_loc_cd(rs.getString("ADMIN_LOC_CD"));
                eventVO.set_scan_emp_nbr(rs.getString("SCAN_EMP_NBR"));
                eventVO.set_track_src_cd(rs.getString("TRACK_SRC_CD"));
                eventVO.set_event_sqnc_nbr(rs.getString("EVENT_SQNC_NBR"));
                eventVO.set_event_note_desc(rs.getString("EVENT_NOTE_DESC"));
                eventVO.set_input_tmstp((java.util.Date)rs.getTimestamp("INPUT_TMSTP"));
                eventVO.set_last_updt_tmstp((java.util.Date)rs.getTimestamp("LAST_UPDT_TMSTP"));
            } else {
                // Event not found
                logger.error("Event not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode());
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return eventVO;
    }    
}
