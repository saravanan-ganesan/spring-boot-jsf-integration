package com.fedex.rise.constant;

public interface AppConstant {

	String APP_ROOT_PATH = "com.fedex.rise";
	
	String URL_PATTERN_ALL = "/*";
	String SERVLET_MAPPING_JSF = "*.jsf";
	
	String BEAN_PACKAGE = "com.fedex.rise.bean";
	
	String JSF_CONTROLLER_ANNOTATION_FULL_NAME = "com.fedex.rise.annotation.JsfController";
	
	String WEB_INF_FOLDER = "WEB-INF";
	String FOLDER_SEPARATOR = "/";
	
	String FILE_EXTN_JSP = ".jsp";
	String FILE_EXTN_JSF = ".jsf";
	String FILE_EXTN_XHTML = ".xhtml";
	
	String STRING_BEAN_PATH = "path";
	String STRING_BEAN_PAGE = "page";
}
