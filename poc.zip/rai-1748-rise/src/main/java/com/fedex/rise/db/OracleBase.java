package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import com.javaunderground.jdbc.DebugableStatement;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

/**
 * This class provides support method for the data access objects to execute a
 * callable or prepared statement. In addition, it provides clean up of the
 * result set and callable/prepared statement objects. Finally, it provides a
 * method to dump sql warnings from the connection, statement, or resultset.
 */
public class OracleBase {
    /** Logger */
    private static Logger logger = LogManager.getLogger(OracleBase.class);

    /** The SQL statement to be prepared */
    protected PreparedStatement pstmt;

    /** The signature of the SQL statement. Set before every database query. */
    protected String sqlSignature;

    /**
     * This will contain the first ResultSet for a SQL execution ( if the SQL
     * has any ResultSets). Subsequent result sets, (multiple resultsets) will
     * have to be obtained manually in the EJB by calling
     * "pstmt.getMoreResults().
     */
    protected ResultSet rs;

    /** Variable to indicate if the SQL query returned any Result Sets. */
    protected boolean hasResults;

    /**
     * The Connection to the database. This is NOT a single connection since it
     * is being obtained from the Pool. This will be passed to the constructor
     * and set for subsequent db access
     */
    protected Connection con;

    /**
     * Default constructor
     */
    public OracleBase(Connection con) {
        this.con = con;
    }

    /**
     * This method will create the SQL Statement mentioned in the sqlSignature.
     * This calls the setSqlSignature(sqlSignature, isProcCall) with the
     * isProcCall set to false (no stored procedure call).
     *
     * @param sqlSignature Pass in the string representing the SQL query.
     * @throws SQLException
     *             If connection was not available (null or closed) or the
     *             Statement could not be prepared.
     */
    public void setSqlSignature(String sqlSignature) throws SQLException {
        setSqlSignature(sqlSignature, false, false);
    }    

    
    /**
     * This method will create the SQL Statement mentioned in the sqlSignature.
     *
     * @param sqlSignature Pass in the string representing the SQL query.
     * @param isProcCall Pass in the flag to identify this as a stored
     *            procedure call or not so the correct prepare method will be
     *            called.
     * @param isDebugable uses a debugable statement
     * @throws SQLException If connection was not available (null or closed) or
     *            the Statement could not be prepared.
     */
    public void setSqlSignature(String sqlSignature, boolean isProcCall, boolean isDebugable) throws SQLException {
        this.sqlSignature = sqlSignature;

//       if (logger.isDebugEnabled()) {
//            logger.debug("DB Statement Create:" + sqlSignature);
//        }

        if ((con == null) || (con.isClosed())) {
            throw new SQLException("Connection not available. "
                    + "Connection must be obtained before this method is called.");
        }
        try {
            if (isProcCall) {
                pstmt = con.prepareCall(sqlSignature );
            } else {
                if (isDebugable) {
                    pstmt = new DebugableStatement(con, sqlSignature);
                } else {
                    pstmt = con.prepareStatement(sqlSignature);
                }
            }

            if (pstmt == null) {
                throw new SQLException("Statement was null. "
                        + "The Signature used was:" + sqlSignature);
            }

        } catch (SQLException e) {
            logger.error("DB Statement Create Exception", e);

            // After logging the execution, throw it to the calling method
            throw e;
        }
    } // end of method setSqlSignature

    /**
     * This method will have to be called after one of the "setSqlSignature()"
     * methods. This is where the actual execution of the SQL statement takes
     * place. If the SQL Statement returns any ResultSets, the first ResultSet
     * will be fetched and stored in the variable "rs".
     *
     * @throws SQLException A SQLException occurred during execution of the SQL.
     */
    public void execute() throws SQLException {
//        if (logger.isDebugEnabled()) {
//            logger.debug("DB Execute:" + sqlSignature);
//        }

        try {
            hasResults = pstmt.execute();

            if (logger.isDebugEnabled()) {
                loggerSQLWarnings(con.getWarnings());
                loggerSQLWarnings(pstmt.getWarnings());
            }

            if (hasResults) {
                //if (logger.isDebugEnabled()) {
                //    logger.debug("DB Result Set Available");
                //}
                rs = pstmt.getResultSet();

                if (logger.isDebugEnabled()) {
                    loggerSQLWarnings(rs.getWarnings());
                }
            } else {
                //if (logger.isDebugEnabled()) {
                //    logger.debug("DB Result Set Not Available");
                //}
            }

            //if (logger.isDebugEnabled()) {
            //    logger.debug("DB Execute Done");
            //}
        } catch (SQLException e) {
            //logger.error("DB Execute Exception", e);

            // After logging the execution, throw it to the calling method
            throw e;
        }
    } // end of method execute()

    /**
     * This method will have to be called after one of the "setSqlSignature()"
     * methods. This is where the actual execution of the SQL takes place.
     * This uses PreparedStatement.executeUpdate so the SQL statement must be an
     * SQL INSERT, UPDATE or DELETE statement; or an SQL statement that returns
     * nothing, such as a DDL statement.
     *
     * @returns The number of rows affected (inserted, updated, or deleted)
     * @throws SQLException An exception occurred during the execution of statement.
     */
    public int executeUpdate() throws SQLException {
        //if (logger.isDebugEnabled()) {
        //    logger.debug("DB Execute Update: " + sqlSignature);
        //}

        int rowsUpdated = 0;

        try {
            rowsUpdated = pstmt.executeUpdate();

            if (logger.isDebugEnabled()) {
                loggerSQLWarnings(con.getWarnings());
                loggerSQLWarnings(pstmt.getWarnings());
            }

            //if (logger.isDebugEnabled()) {
            //    logger.debug("DB Execute Update Done");
            //}
        } catch (SQLException e) {
            logger.error("DB Execute Update Exception", e);

            // After logging the execution, throw it to the calling method
            throw e;
        }

        return rowsUpdated;
    }

    /**
     * This method will be called after one of the "setSqlSignature()"
     * methods. This is where the actual execution of the batching of SQL
     * statements takes place. This uses PreparedStatement.executeBatch() so the
     * SQL statement must be an SQL INSERT, UPDATE or DELETE statement; or an
     * SQL statement that returns nothing, such as a DDL statement.
     *
     * @param numberOfBatchStatements Pass in the number of statements that were
     * batched.
     * @returns The number of rows affected (inserted, updated, or deleted) for
     * each element in the array.  Each element represents the corresponding
     * batch statement added sequentially.
     * @throws SQLException An exception occurred during the execution of statement.
     */
    public int[] executeBatch(int numberOfBatchStatements) throws SQLException {
        if (logger.isDebugEnabled()) {
            logger.debug("DB Exceute Batch" + sqlSignature);
        }

        int [] rowsUpdated = null;

        try {
           rowsUpdated = pstmt.executeBatch();

           if (logger.isDebugEnabled()) {
               loggerSQLWarnings(con.getWarnings());
               loggerSQLWarnings(pstmt.getWarnings());
           }

           if (logger.isDebugEnabled()) {
               logger.debug("DB Execute Batch Done");

               StringBuffer rowIndexBuffer = new StringBuffer(120);
               StringBuffer rowValueBuffer = new StringBuffer(120);

               formatRowsUpdated(rowIndexBuffer, rowValueBuffer, rowsUpdated);

               logger.debug("Batch successful: " + rowIndexBuffer.toString() +
                            rowValueBuffer.toString());
           }
        } catch (SQLException e) {

           logger.error("DB Execute Batch Exception", e);

           if (java.sql.BatchUpdateException.class.isInstance(e)) {
               java.sql.BatchUpdateException bue = (java.sql.BatchUpdateException) e;
               rowsUpdated = bue.getUpdateCounts();

               StringBuffer rowIndexBuffer = new StringBuffer(120);
               StringBuffer rowValueBuffer = new StringBuffer(120);

               formatRowsUpdated(rowIndexBuffer, rowValueBuffer, rowsUpdated);

               logger.info("Batch statements that succeeded: " +
                        rowIndexBuffer.toString() + rowValueBuffer.toString());
               logger.error("Batch sequential statement index that failed: " +
                            (rowsUpdated.length+1));
               logger.info("Number of batch statements: " + numberOfBatchStatements);
           }

           // After logging the execution, throw it to the calling method
           throw e;
        }

        return rowsUpdated;
    }

    /**
     * This method assists in formatting the "rows updated array" by passing the
     * row index buffer and row value buffer.
     *
     * @param rowIndexBuffer Pass in the row index buffer.
     * @param rowValueBuffer Pass in the row value buffer.
     * @param rowsUpdated Pass in the rows updated.
     */
     private void formatRowsUpdated(StringBuffer rowIndexBuffer,
                                  StringBuffer rowValueBuffer,
                                  int [] rowsUpdated) {
       rowIndexBuffer.append("rowsUpdated indexes[");
       rowValueBuffer.append("rowsUpdated values[");

       for (int i = 0; i < rowsUpdated.length; i++) {
          if (i + 1 != rowsUpdated.length) {
              rowIndexBuffer.append(i + ",");
              rowValueBuffer.append(rowsUpdated[i] + ",");
          } else {
              rowIndexBuffer.append(i + "] ");
              rowValueBuffer.append(rowsUpdated[i] + "] ");
          }
      }
   }
    /**
     * This method closes the result set via the ResultSet.close method. The
     * ResultSet should not be close via CallableStatment.close method due to
     * bug WebLogic Oracle Driver in WebLogic 8.1 SP3 (CR194051 resolved in
     * SP4). In the future version, the PreparedStatement.close method may be
     * used instead.
     *
     * @throws SQLException A SQLException occurred when closing of the result set.
     */
    public void cleanResultSet() throws SQLException {
        try {
            if (rs != null) {
                rs.close();
                rs = null;
                //if (logger.isDebugEnabled())
                //    logger.debug("DB Result Set Closed");
            } else {
                //if (logger.isDebugEnabled())
                //    logger.debug("DB ResultSet is NULL");
            }
            // From the API Note: A ResultSet object is automatically closed
            // by the Statement object that generated it when that Statement
            // object is closed, re-executed, or is used to retrieve the next
            // result from a sequence of multiple results. A ResultSet object
            // is also automatically closed when it is garbage collected.
            if (pstmt != null) {
                pstmt.close();
                pstmt = null;
                //if (logger.isDebugEnabled()) {
                //    logger.debug("DB Statement Closed");
                //}
            } else {
                //if (logger.isDebugEnabled()) {
                //    logger.debug("DB Statement is NULL");
                //}
            }
        } catch (SQLException e) {
            logger.warn("Exception", e);

            // After logging the exection, throw it to the calling method
            throw e;
        }
    }

    /**
     * This method logs SQLWarnings.
     *
     * @param sqw The SQLWarnings from the connection, statement, or resultset.
     */
    public void loggerSQLWarnings(SQLWarning sqw) {
        while (sqw != null) {
            logger.debug("SQLWarning - Msg: " + sqw.getMessage()
                         + ", SQLState: " + sqw.getSQLState() + ", ErrCode: "
                         + sqw.getErrorCode());
            sqw = sqw.getNextWarning();
        }
    }

    // GMT-05:00
    public String formatTZ(String aTzId) {
        if (aTzId.equals("GMT")) { return "+0000"; } // Why?
        StringBuffer sb = new StringBuffer();
        sb.append(aTzId.substring(3, 6));
        sb.append(aTzId.substring(7, 9));
        return sb.toString();
    }
} // end of class
