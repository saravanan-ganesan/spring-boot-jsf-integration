package com.fedex.rise.bean;

import com.fedex.rise.annotation.JsfController;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsfController(path = "/", page = "/pages/jsp/home.jsp", value = "homeBean")
public class HomeBean extends BaseBean {

	UserBean userBean = new UserBean();
	
	public HomeBean() {

		userBean.setFirstName("First");
		userBean.setLastName("Last");
		userBean.setRole("RM");
		userBean.setUserId("12345");
	}

	

}
