package com.fedex.rise.bo.issue;

import com.fedex.rise.vo.EventVO;

public class ClearedCustomsCriteria extends IssueCriteria {

    private static ClearedCustomsCriteria _instance = new ClearedCustomsCriteria();
    
    private ClearedCustomsCriteria() {};
    
    public boolean meetsCriteria(EventVO anEventVO) {
        return ClearedCustomsResolver.getInstance().isResolved(anEventVO, null);
    }

    public static ClearedCustomsCriteria getInstance() {
        return _instance;
    }
}
