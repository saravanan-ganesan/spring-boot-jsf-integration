package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.issue.IssueDesc;
import com.fedex.rise.bo.issue.RiseIssues;
import com.fedex.rise.vo.IssueVO;

/**
 * Backer bean for Issues.
 * Encapsulates the IssueVO so that we can add:
 *  - resolved boolean flag for the UI
 *  - description
 *  - and the actions
 */
public class IssueBean implements Serializable {
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(IssueBean.class);

    /** delegate to get shipment data */
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
   
    private IssueVO issue = null;
    private boolean resolved = false;
    private String desc = null;
    private String longDesc = null;
   
    /**
     * @param issue
     */
    public IssueBean(IssueVO issue) {
        super();
        this.issue = issue;
        // if the issue has a resolved date then set the resolved flag to true
        resolved = (issue.getRes_dt() == null) ? false : true;
        
        int issueTypeCd = issue.getIssue_type_cd();
        IssueDesc issueDesc = RiseIssues.getIssueDesc(issueTypeCd);
        if (issueDesc != null) {
            desc = issueDesc.getShortTextDesc();
            longDesc = issueDesc.getLongTextDesc();
        } else {
            log.error("No Desc from IssueTypeCd: " + issueTypeCd);
        }
    }

    
    /*---------------------------------------------------------------------
     * Getter / Setters
     *--------------------------------------------------------------------- 
     */
    
    /**
     * @return the issue
     */
    public IssueVO getIssue() {
        return issue;
    }

    /**
     * @param issue the issue to set
     */
    public void setIssue(IssueVO issue) {
        this.issue = issue;
    }
 
    /**
     * @return the _resolved
     */
    public boolean isResolved() {
        return resolved;
    }

    /**
     * @param _resolved the _resolved to set
     */
    public void setResolved(boolean resolved) {
        this.resolved = resolved;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @return the longDesc
     */
    public String getLongDesc() {
        return longDesc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    
    /*---------------------------------------------------------------------
     * Actions
     *--------------------------------------------------------------------- 
     */
    
   
    /**
     * Resolve the Issue Action
     */
    public String markIssueResolvedAction() {
        log.info("Resolved Issue: " + issue.getTrkng_item_nbr() + ", " + issue.getIssue_type_cd());
       
        issue.setRes_dt(new Date());
        issue.set_res_emp_nbr(UserBean.getLoggedInUser().getUserId());
        //issue.set_res_desc();  // only populated automatically by SEP events resolving issue
      
        // TODO: add comment with loggedInUser that issue was resolved??
        UserBean user = UserBean.getLoggedInUser();
        
        shipmentDelegate.saveChanges(issue);
        
        // TODO: handle errors
        
        return "success"; 
    }
       
    
    /*-----------------------------------------------------------------------
     * Utility methods
     *-----------------------------------------------------------------------
     */
   
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      shipmentDelegate = new ShipmentDelegate();
    }
}
