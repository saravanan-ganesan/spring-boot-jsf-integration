package com.fedex.rise.xref;

import java.util.HashMap;

public class ExceptionTypes {
  
    private static HashMap exceptionTypes = new HashMap();

    // TODO: read in from properties file ?
    static {
        exceptionTypes.put( "01", "Package not delivered/not attempted");
        exceptionTypes.put( "02", "Pkg delvd to rcpt addr-rel auth");
        exceptionTypes.put( "03", "Incorrect Recipient Address");
        exceptionTypes.put( "04", "Delv'd to addr other than rcpt");
        exceptionTypes.put( "05", "Customer security delay");
        exceptionTypes.put( "07", "Shipment refused by recipient");
        exceptionTypes.put( "08", "Not in-business closed");
        exceptionTypes.put( "09", "Damaged--delivery completed");
        exceptionTypes.put( "10", "Damaged - delivery not completed");
        exceptionTypes.put( "11", "COD delivery");
        exceptionTypes.put( "12", "Package sorted to wrong route");
        exceptionTypes.put( "13", "Received from fxk counter");
        exceptionTypes.put( "14", "Undeliverable package");
        exceptionTypes.put( "15", "Business closed due to strike");
        exceptionTypes.put( "16", "Payment received");
        exceptionTypes.put( "17", "Customer requested future delivery");
        exceptionTypes.put( "17", "Future delivery requested");
        exceptionTypes.put( "18", "Missort");
        exceptionTypes.put( "19", "Transfer of custodial control");
        exceptionTypes.put( "20", "DGS commodity unacceptable/incompatible");
        exceptionTypes.put( "21", "Bulk aircraft/truck");
        exceptionTypes.put( "22", "Pkg msd a-c/trk at sta/hub/ramp");
        exceptionTypes.put( "23", "Pkg received after a/c / shuttle departure");
        exceptionTypes.put( "24", "Customer delay (DEX = package delivery)");
        exceptionTypes.put( "25", "Package received without pkg tracking #");
        exceptionTypes.put( "26", "Tendered by cartage agent/consolidator");
        exceptionTypes.put( "27", "Re-expedite");
        exceptionTypes.put( "29", "Reroute requested");
        exceptionTypes.put( "30", "Attempted after close time");
        exceptionTypes.put( "31", "Arrived after couriers dispatched");
        exceptionTypes.put( "32", "Plane arrived late at hub or ramp");
        exceptionTypes.put( "33", "Vendor transportation delay");
        exceptionTypes.put( "34", "Destroyed at customer request");
        exceptionTypes.put( "35", "Third party call in - no package");
        exceptionTypes.put( "36", "Holding in overgoods");
        exceptionTypes.put( "37", "Observed package damage");
        exceptionTypes.put( "38", "Pkg trak# rec'd without pkg.");
        exceptionTypes.put( "39", "Customer did not wait");
        exceptionTypes.put( "40", "Multiple pickups scheduled");
        exceptionTypes.put( "41", "Commitment not due / not attempted");
        exceptionTypes.put( "42", "Holiday - business closed");
        exceptionTypes.put( "43", "No package");
        exceptionTypes.put( "44", "PMX");
        exceptionTypes.put( "45", "Positive pull / early pull");
        exceptionTypes.put( "46", "Mass pickup scan");
        exceptionTypes.put( "47", "Mass routing scan");
        exceptionTypes.put( "48", "Package arrival past cutoff time");
        exceptionTypes.put( "49", "Out of fedex primary delv area");
        exceptionTypes.put( "50", "Improper/missing regulatory paperwork");
        exceptionTypes.put( "51", "Package sent to expedite department");
        exceptionTypes.put( "52", "Held, pkg cleared after sort down");
        exceptionTypes.put( "53", "Part of incomplete shipment");
        exceptionTypes.put( "54", "Psbl-delay-nxt day in 2/3 day ln.");
        exceptionTypes.put( "55", "Regulatory agency clearance delay");
        exceptionTypes.put( "56", "Removed from cage");
        exceptionTypes.put( "57", "Pkg manifested but not received");
        exceptionTypes.put( "58", "Unable to contact rcpt for brk info");
        exceptionTypes.put( "59", "Shipment held for rcpt pickup");
        exceptionTypes.put( "60", "Still in bond cage");
        exceptionTypes.put( "61", "Broker notification");
        exceptionTypes.put( "62", "Customs paperwork transit");
        exceptionTypes.put( "63", "Pkg held for taxes");
        exceptionTypes.put( "64", "Non-Fedex clearance");
        exceptionTypes.put( "65", "Commercial customs release");
        exceptionTypes.put( "66", "Customs release, int'l SIPS");
        exceptionTypes.put( "67", "Recv'd from/rlsd to an ODA agent");
        exceptionTypes.put( "68", "In country transit");
        exceptionTypes.put( "69", "Batch received at imaging loc");
        exceptionTypes.put( "70", "Transit in");
        exceptionTypes.put( "71", "Comm/dutbl rcd at port of entry");
        exceptionTypes.put( "72", "Ncomm/nondutbl, recd at port of entry");
        exceptionTypes.put( "72", "Doc/ncomm/nondutbl/pkg recd at dest");
        exceptionTypes.put( "73", "Req's add'l reglatry procs'ng");
        exceptionTypes.put( "74", "Overage");
        exceptionTypes.put( "74", "International delay");
        exceptionTypes.put( "75", "FEC brokerage");
        exceptionTypes.put( "76", "FEC brokers customs entry");
        exceptionTypes.put( "77", "Transit out");
        exceptionTypes.put( "78", "City/country not in service area");
        // Start Change for WR #135494 by Wipro as suggested by Brad
        exceptionTypes.put( "79", "Customer requests future delivery"); 
        // End Change for WR #135494 by Wipro Surge Uplift
        exceptionTypes.put( "80", "Paperwork available");
        exceptionTypes.put( "81", "COMAT stop");
        exceptionTypes.put( "82", "Dimensional weight");
        exceptionTypes.put( "83", "Billing exception");
        exceptionTypes.put( "84", "Delay caused beyond our control");
        exceptionTypes.put( "85", "Mechanical delay");
        exceptionTypes.put( "86", "Prerouted meter package");
        exceptionTypes.put( "88", "Missing ci fax (ci=commercial invoice)");
        exceptionTypes.put( "89", "Transport accident/psbl delay");
        exceptionTypes.put( "90", "Customs paperwork outbound");
        exceptionTypes.put( "91", "Pickup exception - exceeds service limit");
        exceptionTypes.put( "92", "Pickup exception - pickup not ready");
        exceptionTypes.put( "93", "Unable to collect paymt or bill charges");
        exceptionTypes.put( "94", "P/U excp-no credit approval-bulk ship");
        exceptionTypes.put( "95", "Package retrieval");
        exceptionTypes.put( "96", "P/U excp, incorrect P/U info");
        exceptionTypes.put( "97", "P/U excp, no pickup attempt made");
        exceptionTypes.put( "98", "P/U excp-courier attempt, pkg left");
        exceptionTypes.put( "99", "Sys outage-no disp");

    }
    
    public static String lookupExceptionType(String aExceptionType) {
        return (String)exceptionTypes.get(aExceptionType);
    }
}
