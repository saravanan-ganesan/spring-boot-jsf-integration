package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIData;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.tree2.HtmlTree;
import org.apache.myfaces.custom.tree2.TreeModel;
import org.apache.myfaces.custom.tree2.TreeModelBase;
import org.apache.myfaces.custom.tree2.TreeNode;
import org.apache.myfaces.custom.tree2.TreeNodeBase;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.bo.UserDelegate;

/**
 * Backer bean for Monitor Tree. Basically makes a TreeNode available.
 * 
 */
@JsfController(path = "/monitor", page = "/pages/jsp/monitor.jsp", value = "monitorTreeBean")
public class MonitorTreeBean extends BaseBean implements Serializable {
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(MonitorTreeBean.class);

    // TODO: user model ?
    //private TreeModelBase _treeModel;
    private transient HtmlTree _treeHtml;
    private TreeNodeBase _treeData;
    private TreeNode _selectedNode;
  
    /* user who's monitor tree we will get */
    private UserBean _user = null;

    /** path to the selected child node (account, lane, etc.) */
    private String _nodePathDesc = "";
    private String _nodePath;

    // save the selected mawb
    private MawbBean _selectedMawbBean = null;
    
    // save the ship date offset
    private String _shipDateOffsetStr = null;
    
    // We'll keep the state of the tree (selected Node, expanded Nodes), but only works with 
    // serversidetoggle, and we'll leave as client side for now (faster for user)
//    private TreeState _treeState;

    /** UIData component binding to MAWB List table.  Here so we can reset to page 1 after tree node selection */
    private transient UIData _mawbListUIData;

  //Start WR#:179441 Changes	
    public static String checkMawbDetailsPage = null;
    
    public static String getCheckMawbDetailsPage() {
		return checkMawbDetailsPage;
	}

	public static void setCheckMawbDetailsPage(String checkMawbDetailsPage) {
		MonitorTreeBean.checkMawbDetailsPage = checkMawbDetailsPage;
	}
	//End WR#:179441 Changes 

	/**
     * Construct a MonitorTree the logged in user
     * @param user logged in user
     */
    public MonitorTreeBean() {
        //this(UserBean.getLoggedInUser());
    }
    
    /**
     * Construct a MonitorTree for this user
     * @param user 
     */
    public MonitorTreeBean(UserBean user) {
        this._user = user;
        
        // We'll keep the state of the tree (selected Node, expanded Nodes), but only works with 
        // serversidetoggle, and we'll leave as client side for now (faster for user)
//        _treeState = new TreeStateBase();
//        _treeState.setTransient(true);
        _treeHtml = new HtmlTree(); // create new instance for binding
    }
    
    
    /*-----------------------------
     * Getter methods
     *-----------------------------
     */
    
    /** set MAWBList UI data */
    public void setUIData(UIData uiData) {
        _mawbListUIData = uiData;
    }

    /** get MAWBList UI data */
    public UIData getUIData() {
        return _mawbListUIData;
    }
    
    /**
     * Get the Tree data for the user
     * @return
     */
    public TreeModel getTreeData() {
        // create base tree node
        _treeData = new TreeNodeBase("accounts", "My Accounts", false);

        addAccounts(_treeData);
        
        TreeModelBase treeModel = new TreeModelBase(_treeData);
//        treeModel.setTreeState(_treeState);
        return treeModel;
    }

    public void setTreeHtml(HtmlTree tree) {
        _treeHtml = tree;
    }

    public HtmlTree getTreeHtml() {
        return _treeHtml;
    }

    public void setNodePath(String nodePath) {
        log.info("NodePath="+ nodePath);
        _nodePath = nodePath;
    }

    public String getNodePath() {
        return _nodePath;
    }

    /**
     * Get the selected tree nodes full path description
     * @return
     */
    public String getNodePathDesc() {
        return _nodePathDesc;
    }
    
    /**
     * Determine if we are on the Issues node, so we can display issues on right pane
     * @return
     */
    public boolean isIssuesSelected() {
        if (_nodePathDesc != null && _nodePathDesc.indexOf("Issues") != -1) {
           return true;
        } else {
           return false;
        }
    }
    
    /**
     * Determine if we are on the All node, so we can display all shipments on right pane
     * @return
     */
    public boolean isAllSelected() {
    	log.debug("ALL button is clicked"+ _nodePathDesc);
    	
        if (_nodePathDesc != null && _nodePathDesc.indexOf("All") != -1) {
           return true;
        } else {
           return false;
        }
    }

    /**
     * Determine if we are on the CRN's node, so we can display all CRN"s on right pane
     * @return
     */
    //WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
    public boolean isCrnAllSelected() {
    	log.debug("CRN's button is clicked"+ _nodePathDesc);
    	
        if (_nodePathDesc != null && _nodePathDesc.indexOf("CRN all") != -1) {
           return true;
        } else {
           return false;
        }
    }
    /**
     * @return the selectedNode
     */
    public TreeNode getSelectedNode() {
        return _selectedNode;
    }

    /**
     * Get the selected MAWB, for showing MAWB details, etc.
     * @return mawb the selected MAWB
     */
    public MawbBean getSelectedMAWB() {
        return _selectedMawbBean;
    }
 
    /**
     * Set the selected MAWB, for showing MAWB details, etc.
     * @param selectedMawbBean selected MAWB
     */
    public void setSelectedMAWB(MawbBean selectedMawbBean) {
        this._selectedMawbBean = selectedMawbBean;
    }
    
    /**
     * Get the selected CRN, for showing CRN details, etc.
     * @return crn the selected CRN
     */
    public CrnBean getSelectedCRN() {
        CrnBean crn = _selectedMawbBean.getSelectedCRN();
       
        return crn;
    }
    
    /**
     * Set the selected CRN, for showing CRN details, etc.
     * @param selectedCrnBean selected CRN
     */
    //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
    public void setSelectedCRN(CrnBean selectedCrnBean) {
    	if(_selectedMawbBean!=null)
        _selectedMawbBean.setSelectedCRN(selectedCrnBean);
    	else
    	{
    		setSelectedMAWB(new MawbBean(selectedCrnBean));
    	}
        
    }
    
    public boolean  isNodedesc()
    {
    	if(_nodePathDesc.indexOf("CRN all")!=-1)
    		return true;
    	return false;
    }
    
    //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
    /**
     * @return the _shipDateOffsetStr
     */
    public String getShipDateOffsetStr() {
    	if (_shipDateOffsetStr == null){
    		_shipDateOffsetStr = new String("10");
    	}
        return _shipDateOffsetStr;
    }

    /**
     * @param lane the _shipDateOffsetStr to set
     */
    public void setShipDateOffsetStr(String shipDateOffsetStr) {
    	if (shipDateOffsetStr == null && _shipDateOffsetStr == null){
    		_shipDateOffsetStr = new String("10");
			return;
    	}else if (shipDateOffsetStr != null && _shipDateOffsetStr == null){
    		_shipDateOffsetStr = new String(shipDateOffsetStr);
    	}else if (shipDateOffsetStr != null){
    		_shipDateOffsetStr = shipDateOffsetStr;
    	}
    }
    
    /**
     * @return a list of all ship date offsets
     */
    public List getShipDateOffsets() {
    	List shipDateOffSetsSelectItems = new ArrayList(5);
    	
    	shipDateOffSetsSelectItems.add(new SelectItem("7", "7 days"));
    	shipDateOffSetsSelectItems.add(new SelectItem("10", "10 days"));
    	shipDateOffSetsSelectItems.add(new SelectItem("30", "30 days"));
    	shipDateOffSetsSelectItems.add(new SelectItem("60", "60 days"));
    	shipDateOffSetsSelectItems.add(new SelectItem("183", "6 months"));
    	
        return shipDateOffSetsSelectItems;
    }
    
    
    /*-----------------------------
     * Action methods
     *-----------------------------
     */

    /**
     * Expand the tree path 
     * @param event
     */
    public void expandPath(ActionEvent event) {
        _treeHtml.expandPath(_treeHtml.getPathInformation(_nodePath));
    }

    public String expandAll() {
        _treeHtml.expandAll();
        return null;
    }

    public String collapseAll() {
        _treeHtml.collapseAll();
        return null;
    }

    /**
     * Process tree node selection events to capture what node is selected
     * 
     * @param event
     * @throws AbortProcessingException
     */
    //WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
    public String selectMonitorTreeNodeAction(ActionEvent event) throws AbortProcessingException {
        log.info("selectMonitorTreeNodeAction(): Entered");

        if (_mawbListUIData != null) {
            _mawbListUIData.setFirst(0);  // set MAWB List to page 1 
            // clear list so it is refreshed, even after validation error
            _mawbListUIData.getChildren().clear(); 
        } 
        
        UIComponent component = (UIComponent) event.getSource();
        while (!(component != null && component instanceof HtmlTree)) {
           component = component.getParent();
        }
        if (component != null) {
           HtmlTree tree = (HtmlTree) component;
           // call tree to select node and show it correctly
           tree.setNodeSelected(event);
           
           // find selected tree node path
           _selectedNode = tree.getNode();
           
           
			FacesContext fctx = FacesContext.getCurrentInstance();
			Application application = fctx.getApplication();
			/*
			 * ExpressionFactory expressionFactory =
			 * fctx.getCurrentInstance().getExternalContext().
			 */
			/*
			 * CrnsListBean crns= (CrnsListBean)
			 * fctx.getExternalContext().getApplicationMap
			 * ().get("crnsListBean");
			 */
			try {
				CrnsListBean crns = (CrnsListBean) fctx.getExternalContext()
						.getRequestMap().get("crnsListBean");
				// CrnsListBean crns = (CrnsListBean)
				// FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("crnsListBean");
				
				if(crns!= null)
				{
				UIData _crnListUIData = crns.getUIData();
				if (_crnListUIData != null) {
					_crnListUIData.setFirst(0); // set MAWB List to page 1
					// clear list so it is refreshed, even after validation
					// error
					log.info("Resetting crn");
					_crnListUIData.getChildren().clear();
				}
				}
			} catch (Exception e) {
				log.error("Exception while getting the object from FacesContext _crnListUIData1 ",e);
			}
			try{
				CrnListBean crns = (CrnListBean) fctx.getExternalContext()
						.getRequestMap().get("crnListBean");
				if(crns!=null)
				{
				UIData _crnListUIData = crns.getUIData();
				if (_crnListUIData != null) {
					_crnListUIData.setFirst(0); // set MAWB List to page 1
					// clear list so it is refreshed, even after validation
					// error
					log.info("Resetting crns");
					_crnListUIData.getChildren().clear();
				}
				}
			} catch (Exception e) {
				log.error("Exception while getting the object from FacesContext _crnListUIData1  ",e);
			}
           
			
			
			
			
           // if leaf node then show data
           if (_selectedNode.getChildren().size() == 0) {
              _nodePathDesc = getNodePathByIdentifier(tree.getNodeId(), _treeData);
              log.info("Tree Node:" + _selectedNode.getIdentifier() + ":" + _selectedNode.getDescription());
              log.info("Tree Path:" + _nodePathDesc);
           }
        }
        
        return "showMawbs";
    }
   
    /**
     * pagingActionListener
     * 
     * @param event
     * @throws AbortProcessingException
     */
    public void pagingAction(ActionEvent event) throws AbortProcessingException {
        if (_mawbListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _mawbListUIData.getChildren().clear(); 
        } 
    }
    
    /** 
     * Navigation to get MAWBs (list of MAWBs for this account,lane,etc)
     * @return
     */
    public String refreshAction() {
        if (_mawbListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _mawbListUIData.getChildren().clear(); 
        }
        return "showMawbs";
    }
    
    /*-----------------------------
     * Navigation methods
     *-----------------------------
     */
    
    /** 
     * Navigation to get MAWBs (list of MAWBs for this account,lane,etc)
     * @return
     */
    public String getMAWBs() {
    	//Start WR#:179441 Changes
    	if(checkMawbDetailsPage!=null)
    	{
    		if(checkMawbDetailsPage.equals("FindShipmentByTrackingNbr")){
    			return "showMawbDetails";
    		}
    		else if(checkMawbDetailsPage.equals("FindShipmentMawbsByTrackingNumber")){
        		return "showMawbsByTrackingNumber";
        	}
    		return null;
    	}//End WR#:179441 Changes
    		else
    		{
    			return "showMawbs";
    		}
    }

    /*-----------------------------
     * Utility methods
     *-----------------------------
     */
    
    /**
     * Make sure path is valid (leaves cannot be expanded or renderer will
     * complain)
     * 
     * @param context
     * @param component
     * @param value
     */
    public void checkPath(FacesContext context, UIComponent component, java.lang.Object value) {
        FacesMessage message = null;

        String[] path = _treeHtml.getPathInformation(value.toString());

        for (int i = 0; i < path.length; i++) {
            String nodeId = path[i];
            try {
                _treeHtml.setNodeId(nodeId);
            } catch (Exception e) {
                throw new ValidatorException(message, e);
            }

            if (_treeHtml.getNode().isLeaf()) {
                message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                        "Invalid node path (cannot expand a leaf): " + nodeId,
                        "Invalid node path (cannot expand a leaf): " + nodeId);
                throw new ValidatorException(message);
            }
        }
    }
   
    /**
     * Add Accounts to user's Monitor tree
     * @param treeData
     */
    private void addAccounts(TreeNode treeData) {

        // Get shippers, accounts, lanes, services, etc. for this user
    	String emplyNbr = null;
    	if(!ObjectUtils.isEmpty(_user)) {
    		emplyNbr = _user.getUserId();
    	}
         
        UserDelegate userDelegate = new UserDelegate(); // delegate to get user data 
        List monitoredAccounts = null;
        //List monitoredAccounts = userDelegate.getMonitoredAccounts(emplyNbr);
        
        TreeNodeBase alphabetNode = null;
        TreeNodeBase shipperNode = null; 
        TreeNodeBase accountNode = null; 
        TreeNodeBase laneNode = null; 
        TreeNodeBase svcNode = null; 
        
        String currentAlphabet = null;
        String currentShipperNbr = null;
        String currentAccountNbr = null;
        String currentLaneNbr = null;
        String currentSvcTypeCd = null;
          
        if (monitoredAccounts!=null) {
           Iterator iter = monitoredAccounts.listIterator();
//           while (iter.hasNext()) {
//               MonitoredAccountsVO monitoredAccount = (MonitoredAccountsVO)iter.next();
//               String alphabetString = monitoredAccount.get_groupNm().substring(0,1).toUpperCase();
//               String shipperNbr = String.valueOf(monitoredAccount.get_groupNbr());
//               String acctNbr = monitoredAccount.get_acctNbr();                
//               String laneNbr = String.valueOf(monitoredAccount.get_laneNbr());
//               String svcTypeCd = monitoredAccount.get_svcTypeCd();
//              
//               // Convert service to displayable value
//               String svcType;
//               if (svcTypeCd.equals("17"))
//                   svcType = "ED";
//               else if (svcTypeCd.equals("18"))
//                   svcType = "ID";
//               else if (svcTypeCd.equals("84"))
//                   svcType = "DF";
//               else 
//                   svcType = svcTypeCd;
//               
//               if (currentAlphabet == null || !alphabetString.equals(currentAlphabet)) {
//            	   currentAlphabet = alphabetString;
//            	   
//            	   // create alphabet node
//            	   alphabetNode = new TreeNodeBase("alphabet",  alphabetString, 
//            			   alphabetString, 
//                           false);
//                   _treeData.getChildren().add(alphabetNode);
//                   
//                   // shipper/group changes
//                   
//                   currentShipperNbr = shipperNbr;
//                   currentAccountNbr = acctNbr;
//                   currentLaneNbr = laneNbr;                    
//                   currentSvcTypeCd = svcTypeCd;
//                   
//                   // create shipper node
//                   shipperNode = new TreeNodeBase("shipper",  monitoredAccount.get_groupNm(), 
//                           String.valueOf(monitoredAccount.get_groupNbr()), 
//                           false);
//                   alphabetNode.getChildren().add(shipperNode);
//                   
//                   // create account node
//                   accountNode = new TreeNodeBase("account",  monitoredAccount.get_acctName(), 
//                           // Commented out groupNbr for account node id, so mouse over works
//                           //String.valueOf(monitoredAccount.get_groupNbr())+":"+
//                           String.valueOf(monitoredAccount.get_acctNbr()), 
//                           false);
//                   shipperNode.getChildren().add(accountNode);
//                   
//                   // create lane node
//                   String lane = monitoredAccount.get_origCntryCd() + "-" + monitoredAccount.get_destCntryCd();
//                   laneNode = new TreeNodeBase("lane", lane, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr()),
//                           false);
//                   accountNode.getChildren().add(laneNode);
//                   
//                   // create service node
//                   svcNode = new TreeNodeBase("service", svcType, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd,
//                           false);
//                   laneNode.getChildren().add(svcNode);
//                   
//                   // add Issue and All leaf nodes
//                   svcNode.getChildren().add(new TreeNodeBase("issues", "Issues", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":Issues",
//                           true));
//                   svcNode.getChildren().add(new TreeNodeBase("all", "All", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":All",
//                           true));
//                   //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   svcNode.getChildren().add(new TreeNodeBase("crn all", "CRN all", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":CRN all",
//                           true));
//                   //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//               }else if (currentShipperNbr == null || !shipperNbr.equals(currentShipperNbr)) {
//            	   
//                   // shipper/group changes
//                   
//                   currentShipperNbr = shipperNbr;
//                   currentAccountNbr = acctNbr;
//                   currentLaneNbr = laneNbr;                    
//                   currentSvcTypeCd = svcTypeCd;
//                   
//                   // create shipper node
//                   shipperNode = new TreeNodeBase("shipper",  monitoredAccount.get_groupNm(), 
//                           String.valueOf(monitoredAccount.get_groupNbr()), 
//                           false);
//                   alphabetNode.getChildren().add(shipperNode);
//                   
//                   // create account node
//                   accountNode = new TreeNodeBase("account",  monitoredAccount.get_acctName(), 
//                           // Commented out groupNbr for account node id, so mouse over works
//                           //String.valueOf(monitoredAccount.get_groupNbr())+":"+
//                           String.valueOf(monitoredAccount.get_acctNbr()), 
//                           false);
//                   shipperNode.getChildren().add(accountNode);
//                   
//                   // create lane node
//                   String lane = monitoredAccount.get_origCntryCd() + "-" + monitoredAccount.get_destCntryCd();
//                   laneNode = new TreeNodeBase("lane", lane, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr()),
//                           false);
//                   accountNode.getChildren().add(laneNode);
//                   
//                   // create service node
//                   svcNode = new TreeNodeBase("service", svcType, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd,
//                           false);
//                   laneNode.getChildren().add(svcNode);
//                   
//                   // add Issue and All leaf nodes
//                   svcNode.getChildren().add(new TreeNodeBase("issues", "Issues", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":Issues",
//                           true));
//                   svcNode.getChildren().add(new TreeNodeBase("all", "All", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":All",
//                           true));
//                   //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   svcNode.getChildren().add(new TreeNodeBase("crn all", "CRN all", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":CRN all",
//                           true));
//                   //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//               } else if (!currentAccountNbr.equals(acctNbr)) { 
//                   // account changes
//                   
//                   currentAccountNbr = acctNbr;
//                   currentLaneNbr = laneNbr;
//                   currentSvcTypeCd = svcTypeCd;
//                       
//                   // create account node
//                   accountNode = new TreeNodeBase("account",  monitoredAccount.get_acctName(), 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr()), 
//                           false);
//                   shipperNode.getChildren().add(accountNode);
//                   
//                   // create lane node
//                   String lane = monitoredAccount.get_origCntryCd() + "-" + monitoredAccount.get_destCntryCd();
//                   laneNode = new TreeNodeBase("lane", lane, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr()),
//                           false);
//                   accountNode.getChildren().add(laneNode);
//                   
//                   // create service node
//                   svcNode = new TreeNodeBase("service", svcType, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd,
//                           false);
//                   laneNode.getChildren().add(svcNode);
//                   
//                   // add Issue and All leaf nodes
//                   svcNode.getChildren().add(new TreeNodeBase("issues", "Issues", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":Issues",
//                           true));
//                   svcNode.getChildren().add(new TreeNodeBase("all", "All", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":All",
//                           true));
//                   //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   svcNode.getChildren().add(new TreeNodeBase("crn all", "CRN all", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":CRN all",
//                           true));
//                   //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//               } else if (!currentLaneNbr.equals(laneNbr)) {
//                   // lane changes
//                   
//                   currentLaneNbr = laneNbr;
//                   currentSvcTypeCd = svcTypeCd;
//                        
//                   // create lane node
//                   String lane = monitoredAccount.get_origCntryCd() + "-" + monitoredAccount.get_destCntryCd();
//                   laneNode = new TreeNodeBase("lane", lane, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr()),
//                           false);
//                   accountNode.getChildren().add(laneNode);
//                   
//                   // create service node
//                   svcNode = new TreeNodeBase("service", svcType, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd,
//                           false);
//                   laneNode.getChildren().add(svcNode);
//                   
//                   // add Issue and All leaf nodes
//                   svcNode.getChildren().add(new TreeNodeBase("issues", "Issues", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":Issues",
//                           true));
//                   svcNode.getChildren().add(new TreeNodeBase("all", "All", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":All",
//                           true));
//                   //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   svcNode.getChildren().add(new TreeNodeBase("crn all", "CRN all", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":CRN all",
//                           true));
//                   //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   
//               } else if (!currentSvcTypeCd.equals(svcTypeCd)) {
//                   // service changes
//                   
//                   currentSvcTypeCd = svcTypeCd;
//                   
//                   // create service node
//                   svcNode = new TreeNodeBase("service", svcType, 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd,
//                           false);
//                   laneNode.getChildren().add(svcNode);
//                   
//                   // add Issue and All leaf nodes
//                   svcNode.getChildren().add(new TreeNodeBase("issues", "Issues", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":Issues",
//                           true));
//                   svcNode.getChildren().add(new TreeNodeBase("all", "All", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":All",
//                           true));
//                   //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   svcNode.getChildren().add(new TreeNodeBase("crn all", "CRN all", 
//                           String.valueOf(monitoredAccount.get_groupNbr())+":"
//                           +String.valueOf(monitoredAccount.get_acctNbr())+":" 
//                           +String.valueOf(monitoredAccount.get_laneNbr())+":"
//                           +currentSvcTypeCd+":CRN all",
//                           true));
//                   //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes 
//                   
//               }            
//           }            
           
        }        
        
    }

    /**
     * Return the full path of node descriptions 
     * @param argID
     * @param rootNode
     * @return
     */ 
    private String getNodePathByIdentifier(String id, TreeNode rootNode) {
        StringBuffer nodePath = new StringBuffer();
        TreeNode node = rootNode;

        String[] nodeIDs = id.split(":");
        for (int i=1; i<nodeIDs.length; i++) {
           node = (TreeNode)node.getChildren().get(Integer.parseInt(nodeIDs[i]));
           nodePath.append(node.getDescription());
           //nodePath.append(node.getIdentifier());
           nodePath.append(" > ");
        }
        return nodePath.toString();
    }
    
  //Start WR#:179441 Changes
    /**
     * Get the selected tree nodes full path description
     * @return
     */
    public String setNodePathDesc(String _nodePathDesc) {
        return _nodePathDesc;
    }
    
  //End WR#:179441 Changes
}
