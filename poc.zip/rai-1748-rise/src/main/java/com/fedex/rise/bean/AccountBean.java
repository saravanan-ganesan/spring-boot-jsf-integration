package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.format.LaneFormatter;
import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.AccountVO;
import com.fedex.rise.vo.LaneVO;

/**
 * Backer bean for an Account. 
 */
public class AccountBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(AccountBean.class);

    /** Delegate to get shipper data in DB */
    private ShipperDelegate shipperDelegate = null;
  
    /** Shipper Tree */
    private ShipperTreeBean _shipperTreeBean = null;
    
    /** other key values, to identify an Account */
    private String _shipperNbr = null;
    
    /** editable attributes */
    private String _accountName =  null;
    private String _accountNbr =  null;
    private String[] _chosenLaneNbrs = new String[0];

    /** determine whether to show add account dialog or not */
    private boolean _addDialogCollapsed = true;
    
    
    /** 
     * Default Constructor
     */
    public AccountBean() {
        shipperDelegate = new ShipperDelegate();
        
        // get the ShipperTreeBean from the session, so we can get access to 
        // (1) the selected shipper node (we'll need the shipperNbr) or 
        // (2) the selected account node (we'll need the shipperNbr & accountNbr)
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        _shipperTreeBean = (ShipperTreeBean)params.get("shipperTreeBean");
        init();
    }
    
    private void init() {
        // Get the selected node key values (shipperNbr, accountNbr)
        String[] keys = _shipperTreeBean.getSelectedKeys();
        _shipperNbr = keys[0];
 
        // determine if we are adding a new account to a shipper (only 1 node, shipper node)
        // or if we are showing the account info (should be 2 nodes, shipper and account);
        if (keys.length > 1) {
            _accountNbr = keys[1];
      
            // Get the selected account info
            AccountVO accountVO = shipperDelegate.getAccount(_shipperNbr, _accountNbr);
            _accountName = accountVO.get_acct_nm();
         
        }
    }
    
    /*--------------------------------------------------------------------- 
     * Getter/Setter methods
     *---------------------------------------------------------------------
     */
    
    /**
     * @return the account name
     */
    public String getAccountName() {
        return _accountName;
    }

    /**
     * @param accountName new accountName to set
     */
    public void setAccountName(String accountName) {
        _accountName = accountName.trim();
    }

    /**
     * @return the accountNbr
     */
    public String getAccountNbr() {
        return _accountNbr;
    }

    /**
     * @param accountNbr the new accountNbr to set
     */
    public void setAccountNbr(String accountNbr) {
        _accountNbr = accountNbr.trim();
    }
    
    /**
     * Get the lanesNbrs that are on the account
     * @return
     */
    public String[] getChosenLaneNbrs() {
        List lanes = shipperDelegate.getAccountLanes(_shipperNbr, _accountNbr);
        _chosenLaneNbrs = new String[lanes==null?0:lanes.size()];
        int i=0;
        for (Iterator itr=lanes.iterator(); itr.hasNext(); i++) {
            AccountLaneVO lane = (AccountLaneVO)itr.next();
            _chosenLaneNbrs[i] = String.valueOf(lane.get_lane_nbr());
        }
       
        return _chosenLaneNbrs;
    }
    
    /**
     * Set the lanesNbrs that should be on the account
     * @param list array of laneNbrs
     */
    public void setChosenLaneNbrs( String[] list ) {
        _chosenLaneNbrs = list;
    }
 
    /**
     * Get if the add account dialog collapsed or not
     * @return true if collapsed
     */
    public boolean isAddDialogCollapsed()
    {
        return _addDialogCollapsed;
    }

    /**
     * Set the add account dialog collapsed or not
     * @param collapsed true for collapsed
     */
    public void setAddDialogCollapsed(boolean collapsed)
    {
        _addDialogCollapsed = collapsed;
    }

    /*--------------------------------------------------------------------- 
     * Action methods
     *---------------------------------------------------------------------
     */
   
    
    /**
     * Add Account to a Shipper
     */
    public String addAccountAction() {
        log.debug("Entering addAccountAction()");

        if (_accountNbr != null && _accountNbr.length()>0) {
           shipperDelegate.addAccountToShipper(_shipperNbr, _accountNbr, _accountName);
           
           // tell shipper so this new node will be selected in the tree
           _shipperTreeBean.notifyAccountAdded(_accountNbr);
           
           _addDialogCollapsed = true;  // hide add account dialog after add
        } 
        // TODO: handle errors, also check for dups?
        return "success";
    }
    
    /**
     * Delete Account from a Shipper
     */
    public String deleteAccountAction() {
        log.debug("Entering deleteAccountAction()");

        shipperDelegate.deleteAccountFromShipper(_shipperNbr, _accountNbr);
        
        // tell shipper of deletion
        _shipperTreeBean.notifyDelete();
       
        // TODO: handle errors
        return "success";
    }
    
    /**
     * Save Account 
     */
    public String saveAccountAction() {
        log.debug("Entering saveAccountAction()");

        // accountName and lanes, accountNbr can't change!
        shipperDelegate.updateAccount(_shipperNbr, _accountNbr, _accountName);
       
        // add these lanes to the shippers account (causes adds, deletes, updates)
        shipperDelegate.addLanesToShipper(_shipperNbr, _accountNbr, _chosenLaneNbrs);
        
        // TODO: handle errors
        return "success";
    }
    
}

