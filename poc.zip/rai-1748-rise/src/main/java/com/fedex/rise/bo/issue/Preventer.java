package com.fedex.rise.bo.issue;

import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public abstract class Preventer {
	
	public abstract boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, IssueVO anIssueVO, ShipmentVO anShipmentVO);
    
}
