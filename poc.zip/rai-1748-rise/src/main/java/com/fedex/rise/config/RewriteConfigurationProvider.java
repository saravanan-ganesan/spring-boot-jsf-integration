package com.fedex.rise.config;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.ocpsoft.rewrite.annotation.RewriteConfiguration;
import org.ocpsoft.rewrite.config.Configuration;
import org.ocpsoft.rewrite.config.ConfigurationBuilder;
import org.ocpsoft.rewrite.config.ConfigurationRuleBuilder;
import org.ocpsoft.rewrite.servlet.config.HttpConfigurationProvider;
import org.ocpsoft.rewrite.servlet.config.rule.Join;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.constant.AppConstant;
import com.google.common.reflect.ClassPath;

import lombok.extern.slf4j.Slf4j;


/**
 * This class is used to configure a bi-directional rewrite rule into existing
 * rewrite framework It automatically scan all classes of controller package and
 * configure the path/navigation.
 * 
 * @author saravanan g
 *
 */
@RewriteConfiguration
@Slf4j
public class RewriteConfigurationProvider extends HttpConfigurationProvider {

	@Override
	public Configuration getConfiguration(ServletContext context) {

		ConfigurationBuilder builder = null;
		List<Join> joinList = new ArrayList<>();

		try {

			final ClassLoader loader = Thread.currentThread().getContextClassLoader();

			if (null != loader) {

				for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {

					if (info.getName().startsWith(AppConstant.BEAN_PACKAGE)) {

						final Class<?> clazz = info.load();

						if (null != clazz) {

							Map<String, String> annotationValueMap = getAnnotationValue(clazz);

							if (!ObjectUtils.isEmpty(annotationValueMap)) {

								for (Map.Entry<String, String> entry : annotationValueMap.entrySet()) {
									joinList.add(Join.path(entry.getKey()).to(entry.getValue()));
								}

							}
						}
					}
				}
			}

			builder = ConfigurationRuleBuilder.begin();

			if(!ObjectUtils.isEmpty(joinList) && !ObjectUtils.isEmpty(builder)) {
				
				for (Join join : joinList) {
					System.out.println(join);
					builder.addRule(join);
				}
				//builder.addRule(Join.path("/authorization-code/**").to("/WEB-INF/pages/jsp/home.jsf"));
				
			}
			
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return builder;
	}

	@Override
	public int priority() {
		return 10;
	}

	private Map<String, String> getAnnotationValue(Class<?> clazz) {

		Map<String, String> annotationMap = new HashMap<>();

		if (clazz != null) {

			Annotation[] arr = clazz.getAnnotations();

			if (!ObjectUtils.isEmpty(arr)) {

				for (Annotation a : arr) {

					Class<? extends Annotation> type = a.annotationType();

					if (!ObjectUtils.isEmpty(type) && !ObjectUtils.isEmpty(type.getDeclaredMethods())) {

						if (AppConstant.JSF_CONTROLLER_ANNOTATION_FULL_NAME.equals(type.getName())) {

							List<String> valueList = new ArrayList<>();

							for (Method method : type.getDeclaredMethods()) {

								try {

									Object value = method.invoke(a, (Object[]) null);

									String path = StringUtils.EMPTY;
									String page = StringUtils.EMPTY;

									if (AppConstant.STRING_BEAN_PATH.equals(method.getName())) {
										path = value.toString();
									} else if (AppConstant.STRING_BEAN_PAGE.equals(method.getName())) {
										page = value.toString();
									}

									if (!ObjectUtils.isEmpty(path)) {

										if (!path.startsWith(AppConstant.FOLDER_SEPARATOR)) {
											path = AppConstant.FOLDER_SEPARATOR + path;
										}
										valueList.add(path);
									}

									if (!ObjectUtils.isEmpty(page)) {

										if (page.endsWith(AppConstant.FILE_EXTN_JSP)
												|| page.endsWith(AppConstant.FILE_EXTN_XHTML)) {
											page = page.replace(AppConstant.FILE_EXTN_JSP, AppConstant.FILE_EXTN_JSF);
										}

										if (!page.startsWith(AppConstant.FOLDER_SEPARATOR)) {
											page = AppConstant.FOLDER_SEPARATOR + AppConstant.WEB_INF_FOLDER
													+ AppConstant.FOLDER_SEPARATOR + page;
										} else {
											page = AppConstant.FOLDER_SEPARATOR + AppConstant.WEB_INF_FOLDER + page;
											//page =  AppConstant.WEB_INF_FOLDER + page;
										}
										valueList.add(page);

									}

								} catch (IllegalAccessException | IllegalArgumentException
										| InvocationTargetException e) {
									log.error(ExceptionUtils.getStackTrace(e));
								}
							}

							if (!ObjectUtils.isEmpty(valueList) && valueList.size() == 2) {

								annotationMap.put(valueList.get(0), valueList.get(1));
							}
						}
					}
				}
			}
		}

		return annotationMap;
	}
}
