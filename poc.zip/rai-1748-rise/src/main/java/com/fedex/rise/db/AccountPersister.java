package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountVO;

public class AccountPersister extends OracleBase {

    private static Logger logger = LogManager.getLogger(AccountPersister.class);
    
    public AccountPersister(Connection con) {
        super(con);
    }
    
    private static final String addAccountSQL =
            "Insert into Account(" +
            "GROUP_NBR, " +
            "ACCT_NBR, " +
            "ACCT_NM, " +
            "COMPANY_NM, " +
            "DTYTAX_ACCT_NBR, " +
            "CMDTY_DESC, " +
            "SPCL_INSTR_DESC, " +
            "COMMENT_DESC, " +
            "RERTE_FLG, " +
            "HOLD_AT_LOC_FLG, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP) " +
             "values(?,?,?,?,?,?,?,?," +
                     "?,?,SYSDATE,SYSDATE)";        
    
    public void addAccount(AccountVO anAccountVO) throws SQLException {
        
        try {
            setSqlSignature( addAccountSQL, false, logger.isDebugEnabled() );

            pstmt.setInt( 1, anAccountVO.get_group_nbr());
            pstmt.setString( 2, anAccountVO.get_acct_nbr());
            pstmt.setString( 3, anAccountVO.get_acct_nm());
            pstmt.setString( 4, anAccountVO.get_company_nm());
            pstmt.setString( 5, anAccountVO.get_dtytax_acct_nbr());
            pstmt.setString( 6, anAccountVO.get_cmdty_desc());
            pstmt.setString( 7, anAccountVO.get_spcl_instr_desc());
            pstmt.setString( 8, anAccountVO.get_comment_desc());
            pstmt.setString( 9, String.valueOf(anAccountVO.get_rerte_flg()));
            pstmt.setString(10, String.valueOf(anAccountVO.get_hold_at_loc_flg()));
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }       
}
