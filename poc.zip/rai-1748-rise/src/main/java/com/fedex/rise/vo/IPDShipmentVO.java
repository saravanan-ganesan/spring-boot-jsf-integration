package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.List;

public class IPDShipmentVO implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private EventVO _event;
    private ShipmentVO _shipment;
    private List _associatedShipment;
    private List _referenceNotes;
    
    public IPDShipmentVO() {   
    }
    
    public IPDShipmentVO(EventVO aEventVO, ShipmentVO aShipmentVO, 
            List anAssociatedShipmentVO, List aReferenceNotes) {
        _event = aEventVO;
        _shipment = aShipmentVO;
        _associatedShipment = anAssociatedShipmentVO;
        _referenceNotes = aReferenceNotes;
    }

    /**
     * @return the _event
     */
    public EventVO get_event() {
        return _event;
    }

    /**
     * @param _event the _event to set
     */
    public void set_event(EventVO _event) {
        this._event = _event;
    }

    /**
     * @return the _referenceNotes
     */
    public List get_referenceNotes() {
        return _referenceNotes;
    }

    /**
     * @param notes the _referenceNotes to set
     */
    public void set_referenceNotes(List notes) {
        _referenceNotes = notes;
    }

    /**
     * @return the _shipment
     */
    public ShipmentVO get_shipment() {
        return _shipment;
    }

    /**
     * @param _shipment the _shipment to set
     */
    public void set_shipment(ShipmentVO _shipment) {
        this._shipment = _shipment;
    }
    
    public String toString() {
        return this._event.toString();
    }

    /**
     * @return the _associatedShipment
     */
    public List get_associatedShipments() {
        return _associatedShipment;
    }

    /**
     * @param associatedShipments
     */
    public void set_associatedShipments(List associatedShipments) {
        _associatedShipment = associatedShipments;
    }
}
