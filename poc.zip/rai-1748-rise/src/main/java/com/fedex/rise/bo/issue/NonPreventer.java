package com.fedex.rise.bo.issue;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class NonPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(NonPreventer.class);
    private static NonPreventer _instance = new NonPreventer();

  
    private NonPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {       
        return false;
    }

    public static NonPreventer getInstance() {
        return _instance;
    }
}
