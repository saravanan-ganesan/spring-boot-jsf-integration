/**
 * 
 */
package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.auth.LDAPAuth;
import com.fedex.rise.bo.UserDelegate;
import com.fedex.rise.vo.EmployeeVO;

public class UsersBean implements Serializable {
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    private static Log log = LogFactory.getLog(UsersBean.class);
   
    private List users = new ArrayList();
    
    /** List of users for showing them in UI. */
    private DataModel userModel = new ListDataModel();

    /** Cached list of roles */
    private ArrayList rolesList = null;
    
    /** temp holding for new user or edited user */ 
    private EmployeeVO user = new EmployeeVO();
   
    /** sorting */
    private String sortColumn = null;
    private boolean sortAscending = true;

    /** max number of rows of users to show on a page */
    private int maxRows = 15;
    
    /** Delegate to get user info */
    private transient UserDelegate userDelegate = new UserDelegate();
    
    /**
     * Default Constructor
     */
    public UsersBean() {
    }

    /** 
     * @return max number of rows of users to show on a page 
     */
    public int getMaxRowsInt() {
        return maxRows;
    }
    public String getMaxRows() {
        return String.valueOf(maxRows);
    }
    
    /** 
     * set the max number of rows of users to show on a page 
     * @param maxRows the max number of rows of users to show on a page 
     */
    public void setMaxRows(String maxRows ) {
        this.maxRows = Integer.parseInt(maxRows);
    }
    
    /**
     * Get all possible roles
     * @return List of SelectItem roles
     */
    public List getRoles() {
        if (rolesList == null) {
           // if roles haven't been cached yet then get them
           rolesList = new ArrayList();
      
           // For Security reasons, remove FedEx Administrator role if this is just an Administrator
           Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
           UserBean userBean = (UserBean)params.get("UserBean");
               
           // get all roles
           HashMap roles = UserRole.getUserRoles();
           for (Iterator iter = roles.entrySet().iterator(); iter.hasNext();) { 
               Map.Entry entry = (Map.Entry)iter.next();
               String key = (String)entry.getKey();
               String value = (String)entry.getValue();
               if (userBean != null && userBean.getRole().equals("A") && key.equals("FA")) 
                   ; // don't add FedEx Admin role for Admins
               else 
                   rolesList.add(new SelectItem(key, value));
           }
        }
        
        return rolesList;
    }
    

    /**
     * @return the users data model for listing users in UI
     */
    public DataModel getUsers() {
       
        if (userDelegate == null)
            userDelegate = new UserDelegate();
        
        //users = userDelegate.getUsers();
       
        // For Security reasons, remove FedEx Administrators if this is just an Administrator
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        UserBean userBean = (UserBean)params.get("UserBean");
        if (userBean != null && userBean.getRole().equals("A")) {
            for (Iterator i=users.iterator(); i.hasNext(); ) {
                EmployeeVO emply = (EmployeeVO)i.next();
                if (emply.get_emp_role_cd().equals("FA")) {
                    i.remove();
                }
            }
        }
        
        userModel.setWrappedData(users);
        return userModel;
    }
    
    /**
     * @param users the users to set
     */
    public void setUsers(List users) {
        this.users = users;
    }
   
    /**
     * @return a user (new or existing)
     */
    public EmployeeVO getUser() {
        //user = new EmployeeVO();
        return user;
    }
   
    /**
     * Set a user
     */
    public void setUser(EmployeeVO user) {
    	this.user = user;
    }
    
    public String getSortColumn() {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }
    
    public boolean isSortAscending() {
        return sortAscending;
    }

    public void setSortAscending(boolean sortAscending) {
        this.sortAscending = sortAscending;
    }

    /**
     * Get LDAP Info action
     * @param 
     * @return
     */
    public String getLDAPInfoAction() {
        log.debug("Get LDAP Info selected");
        
        // get attrs from LDAP
        LDAPAuth ldap = new LDAPAuth();
        HashMap attrs = ldap.getUserInfo(user.get_emp_nbr());
        if (attrs.size() == 0) {
            // user not found, so error
            FacesContext facesContext = FacesContext.getCurrentInstance(); 
            FacesMessage facesMessage = new FacesMessage("Employee Number not found!"); 
            facesContext.addMessage("userAdminForm:empNbr", facesMessage);
        } else {
            String givenName = (String)attrs.get("givenName");
            String surName = (String)attrs.get("sn");
         
            user.set_emp_first_nm(givenName);
            user.set_emp_last_nm(surName);
            log.info("LDAP: user name=" + givenName + " " + surName);
        }
        
        return null; // just redisplay same page
    }   

    /**
     * Edit User action
     * @param 
     * @return
     */
    public String editUserAction() {
        log.debug("Edit User selected");
        user = (EmployeeVO)userModel.getRowData();
      
        return null; // just redisplay same page
    }
    
    // To Change the User role
    public String editChangeUserAction() {
        log.debug("Edit User selected");
        user = (EmployeeVO)userModel.getRowData();
        
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        UserBean userBean = (UserBean)params.get("UserBean");
        userBean.setUserId(user.get_emp_nbr()); // set userId to empNbr after login
        
        return null; 
    }
    
    /**
     * Delete User action
     * @return
     */
    public String deleteUserAction() {
        log.debug("Delete User selected");
        
        if (userDelegate == null)
            userDelegate = new UserDelegate();
        
        EmployeeVO user = (EmployeeVO)userModel.getRowData();
        //userDelegate.delete(user.get_emp_nbr());
       
        users.remove(user);
        return "success"; 
    }
   
    /**
     * Save User action
     * @return
     */
    public String saveUserAction() {
        log.debug("Save User selected");
        //To get right user details of the given emp no
        getLDAPInfoAction();
        // TODO: validate user in LDAP and name, lastname (warn if diff)
        
        if (userDelegate == null)
            userDelegate = new UserDelegate();
        
        //userDelegate.save(user);
        
        return null; // just redisplay same page
    }
   
}