package com.fedex.rise.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


// 20070410200000Z+0000
// 20070410200000Z
// 20070410200000+0000
// 20070410200000

public class GRSDateConverter {

    public static TimeZone extractTimeZone(String aDateStr) {
        StringBuffer outputTzStr = new StringBuffer("GMT");
        if (aDateStr.length() < 20) {
            if ((aDateStr.length() == 15) && (aDateStr.charAt(14) == 'Z')) {
                outputTzStr.append("+0000");
            } else {
                if (aDateStr.length() == 19) {
                    if (aDateStr.charAt(14) == '+') {
                        outputTzStr.append('-');
                    } else {
                        outputTzStr.append('+');
                    }
                    outputTzStr.append(aDateStr.substring(15, 19));
                }
            }
        } else {
            outputTzStr.append(aDateStr.substring(15,20));
        } 
        TimeZone outputTz = TimeZone.getTimeZone(outputTzStr.toString());
        return outputTz;
    }
    
    public static Calendar getSepDate(String aDateStr) throws ParseException {
        System.out.println(aDateStr);
        
        if ((aDateStr == null) || (aDateStr.length() < 14)) {
            return null; 
        }
 
        TimeZone outputTz = extractTimeZone(aDateStr);
        
        SimpleDateFormat dateAndTimeFormatter = new SimpleDateFormat("yyyyMMddHHmmss");
        Date d = dateAndTimeFormatter.parse(aDateStr);
        if (d == null) {
            return null;  // can't parse it, so forget it and return null
        }
        
        Calendar cal = dateAndTimeFormatter.getCalendar();

        cal.setTimeZone(outputTz);
        return cal;
    }
    
//    public static void main(String [] args) {
//
//        
//        
//        TimeZone tz = TimeZone.getTimeZone("GMT+0000");
//        Calendar c = Calendar.getInstance(tz);
//
//        System.out.println(c.getTimeInMillis());
//        //System.out.println(c.getTime().toGMTString());
//        SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
//        SimpleDateFormat xf = new SimpleDateFormat("d MMM yyyy HH:mm:ss Z");
//        String dateStr = sf.format(c.getTime());
//
//        
//        System.out.println("XXXXX");
//        TimeZone gmtTZ = TimeZone.getTimeZone("GMT-0000");
//        Calendar x = Calendar.getInstance(gmtTZ);
//        x.setTimeInMillis(1177467780000L);
//        System.out.println(x);
//        xf.setTimeZone(x.getTimeZone());
//        System.out.println(xf.format(x.getTime()));
//        
//        TimeZone xx = TimeZone.getTimeZone("GMT-0100");
//        x.setTimeZone(xx);
//        System.out.println(x);
//        xf.setTimeZone(x.getTimeZone());
//        System.out.println(xf.format(x.getTime()));
//        System.out.println("XXXXX");
//        
//        
//        
//        String testDate1 = dateStr + "Z-0400";  // Zulu, offset to local
//        String testDate2 = dateStr + "Z";       // Zulu
//        //String testDate3 = "20070404000000";      // local time
//        String testDate4 = dateStr + "-0400"; // local time, offset to zulu
//        
//        try {
//            Calendar d = GRSDateConverter.getSepDate(testDate1);
//            System.out.println(d);
//            //System.out.println(d.getTime().toGMTString());
//            xf.setTimeZone(d.getTimeZone());
//            System.out.println(xf.format(d.getTime()));
//            
//            d = GRSDateConverter.getSepDate(testDate2);
//            System.out.println(d);
//            //System.out.println(d.getTime().toGMTString());
//            xf.setTimeZone(d.getTimeZone());
//            System.out.println(xf.format(d.getTime()));
//            
//            //d = GRSDateConverter.getSepDate(testDate3);
//            //System.out.println(d);
//            //System.out.println(d.getTime());
//            //System.out.println(sf.format(d.getTime()));
//            
//            d = GRSDateConverter.getSepDate(testDate4);
//            System.out.println(d);
//            //System.out.println(d.getTime().toGMTString());
//            xf.setTimeZone(d.getTimeZone());
//            System.out.println(xf.format(d.getTime()));
//            
//            //d = GRSDateConverter.getSepDate(null);
//            //System.out.println(d);
//            
//            //d = GRSDateConverter.getSepDate("xxxxx");
//            //System.out.println(d);
//            
//            // Will throw parseException
//            //d = SEPDateConverter.getSepDate("yyyyMMddHHmmss");
//            //System.out.println(d);
//            
//            //d = SEPDateConverter.getSepDate("20071300000000");
//            //System.out.println(d);
//            
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//    }
}
