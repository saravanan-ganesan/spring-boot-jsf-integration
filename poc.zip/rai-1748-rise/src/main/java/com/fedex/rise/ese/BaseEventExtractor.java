package com.fedex.rise.ese;

import java.text.ParseException;
import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.fedex.asn.UTF8String.enhancedevent_.*;
import com.fedex.rise.util.SEPDateConverter;

/**
 * This class is used to extract data from the ESE Event.  It gets a handle
 * on commonly used parts of the message so that it only has to be done once
 * 
 */
public class BaseEventExtractor {
    private static Logger logger = LogManager.getLogger(BaseEventExtractor.class);
    
    // private copy of the enhanced event we are pulling data out of
    private EnhancedEvent _ee;
    
    // used by extractors to get a quick handle on the Master List section of the ESE Event
    protected MasterList ml = null;
    
    // used by extractors to get a quick handle on the Shipment Profile section of the ESE Event
    protected ShipmentProfile sp = null;
    
    // used by extractors to get a quick handle on the Contract Event section of the ESE EVent
    protected ContractEnhancement ce = null;
    
    // used by extractors to get a quick handle on the Delivery Event section of the ESE EVent
    protected DeliveryPlanEnhancement dpe = null;
    
    // The track type cd of the event
    protected String trackTypeCd = null;
    
    // The event creation timestamp 
    protected Calendar eventCreationTmstp = null;
    
    // The track item number
    protected String trackItemNumber = null;
    
    // The track item unique number
    protected String trackItemUniqNumber = null;
    
    // The service type code
    protected String svcTypCd = null;
    
    /**
     * Constructor, which will parse the base events
     * @param anEE an ESE EVent
     * @throws ESEParseException if part of the message is missing, and we desparately need it
     */
    public BaseEventExtractor(EnhancedEvent anEE) throws ESEParseException {
        _ee = anEE;
    
        if (_ee.hasMaster_list()) {
            ml = _ee.getMaster_list();    
        } else {
            throw new ESEParseException("No Master List");
        }
    
        if (_ee.hasShipment_profile()) {
            sp = _ee.getShipment_profile();    
        } else {
            throw new ESEParseException("No Shipment Profile");
        }
    
        // not always present
        if (_ee.hasPackage_contract_enhancement()) {
            ce = _ee.getPackage_contract_enhancement();
        }
        
        // not always present
        if (_ee.hasDelivery_plan_enhancement()) {
        	dpe = _ee.getDelivery_plan_enhancement();
        } 
        
        trackTypeCd = getTrackTypeCd();
        if (trackTypeCd == null) {
            throw new ESEParseException("No Track Type Code");
        }
        
        eventCreationTmstp = getEvent_creation_tmstp();
        if (eventCreationTmstp == null) {
            throw new ESEParseException("No Event Creation Timestamp");
        }
        
        trackItemNumber = getTrack_item_number();
        if (trackItemNumber == null) {
            throw new ESEParseException("No Track Item Number");
        }
        
        trackItemUniqNumber = getTracking_item_unique_id();
        if (trackItemUniqNumber == null) {
            throw new ESEParseException("No Track Item Unique Number");
        }
        
        // get service code, always present, well almost
        // This is currently required to insert into shipment
        if (sp.hasBase_service_cd()) {
            svcTypCd = sp.getBase_service_cd().stringValue();
        }
        if (svcTypCd == null) {
            throw new ESEParseException("No Service Type Cd");
        }
    }
     
    /**
     * This constructor can be used if a BaseEventExtractor has already
     *  been used and has already parsed the base event fields
     * @param anEE an Enhanced event
     * @param aBaseEventExtractor 
     * @throws ESEParseException
     */
    protected BaseEventExtractor(BaseEventExtractor aBaseEventExtractor) 
                                 throws ESEParseException {
        
        this._ee = aBaseEventExtractor._ee;
        this.ml = aBaseEventExtractor.ml;
        this.sp = aBaseEventExtractor.sp;
        this.ce = aBaseEventExtractor.ce;
        this.dpe = aBaseEventExtractor.dpe;
        this.trackTypeCd = aBaseEventExtractor.trackTypeCd;
        this.eventCreationTmstp = aBaseEventExtractor.eventCreationTmstp;
        this.trackItemNumber = aBaseEventExtractor.trackItemNumber;
        this.trackItemUniqNumber = aBaseEventExtractor.trackItemUniqNumber;
        this.svcTypCd = aBaseEventExtractor.svcTypCd;
    }
    
    public BaseEventExtractor getBaseEventExtractor() {
        return this;    
    }
    
    /**
     * Extract the tracking number from the shipment profile or 
     * master list.
     * @return the tracking item number or null if not found
     */
    private String getTrack_item_number() {
        if (sp.hasTrack_item_number()) {
            return sp.getTrack_item_number().stringValue();
        } else {
            if (ml.hasTrack_item_number()) {
                return ml.getTrack_item_number().stringValue();
            }
        }
        return null;
    }
    
    /**
     * Extract the tracking item unique id from the shipment profile or
     * master list
     * @return the tracking item unique id or null if not found
     */
    private String getTracking_item_unique_id() {
        if (sp.hasTracking_item_unique_id()) {
            return sp.getTracking_item_unique_id().stringValue();
        } else {
            if (ml.hasTracking_item_unique_id()) {
                return ml.getTracking_item_unique_id().stringValue();
            }
        }
        return null;
    }
    
    /**
     * Extract the track type code which represent the type of ESE
     * event such as POD, SIP, SOP etc
     * @return the track type cd or null if not found
     */
    private String getTrackTypeCd() {
        if (ml.hasTrack_type()) {
            return ml.getTrack_type().stringValue();
        }
        return null;
    }
    
    /**
     * For all operational events the even creation time stamp is always made up of a GMT time
     * and offset.  A 'DC' event is a local time but a GMT offset can be gotten from the
     * derived location group of the event.  This can then be concatenated onto the time stamp.
     * 'CE' events may be either a GMT time with no offset or with offset, with no offset
     * we will append "+0000" and when it is displayed on the GUI, it should be displayed in Zulu.
     * @return a Calendar representing the Time and Timzone of the event.
     * @throws ESEParseException if the timestamp cannot be parsed
     */
    private Calendar getEvent_creation_tmstp() throws ESEParseException {
        if (ml.hasEvent_creation_timestamp()) {
            String eventCreationTimestamp = ml.getEvent_creation_timestamp().stringValue();
            
            if (trackTypeCd.equals("DC")) {
                // event creation timestamp is always in local time, get GMT offset
                if ((eventCreationTimestamp.length() == 14) && (ml.hasDerived_track_loc_info_group())) {
                    Derived_track_loc_info_grp derivedInfo = ml.getDerived_track_loc_info_group();
                    if (derivedInfo.hasGmt_offset()) {
                        String gmtOffset = derivedInfo.getGmt_offset().stringValue();
                        // Have to reverse the sign of the offset, as we have the local time and
                        // need to have offset to GMT.
                        if (gmtOffset.charAt(0) == '+') {
                            eventCreationTimestamp = eventCreationTimestamp + "-" + gmtOffset.substring(1);
                        } else {
                            eventCreationTimestamp = eventCreationTimestamp + "+" + gmtOffset.substring(1);
                        }
                    } 
                }
            } else {
                if (trackTypeCd.equals("CE")) {
                    if (eventCreationTimestamp.length() == 15) {
                        eventCreationTimestamp = eventCreationTimestamp + "+0000";
                    }
                }
            }
             
            Calendar cal = null;
            try {
                cal = SEPDateConverter.getSepDate(ml.getEvent_creation_timestamp().stringValue());
            } catch (ParseException pe) {
                logger.info("Event Creation Timestamp failed to parse:", pe);
                return null;
            }
            return cal;
        }
        return null;
    }
    
}
