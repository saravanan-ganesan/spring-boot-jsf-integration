package com.fedex.rise.bo.status;

public class StatusRule {

    StatusMatchRule [] matchRules;
    int weight;
    String dbValue;
    String longDesc;
    
    public StatusRule(StatusMatchRule[] anArrayOfMatchRules, int aWeight, String aDBValue, String aLongDesc) {
        matchRules = anArrayOfMatchRules;
        weight = aWeight;
        dbValue = aDBValue;
        longDesc = aLongDesc;
    }
    
}
