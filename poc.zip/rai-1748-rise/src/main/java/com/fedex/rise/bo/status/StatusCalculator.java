package com.fedex.rise.bo.status;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.xref.TrackDesc;
import com.fedex.rise.xref.TrackTypes;

public class StatusCalculator {
    private static Logger logger = LogManager.getLogger(StatusCalculator.class);
    
    // Rules for matching on events which can set a status
    // If a rule has an exception code, the event must match it
    // If a rule has no exception code, but the event does, then it will match
    //   this prevents us from having to define a rule for every possible 
    //   exception code, for example DDEX's can have many exception codes
    //                                                                   Track Type,                Excptn  Misc
    //                                                                                              Cd      Criteria 
    private static StatusMatchRule [] plcdRule =      { new StatusMatchRule(RiseConstants.CE,        null,   null)  };
    private static StatusMatchRule [] trnstInRule =   { new StatusMatchRule(RiseConstants.STAT,      "70",   null)  };
    private static StatusMatchRule [] tndrRule =      { new StatusMatchRule(RiseConstants.MDD,       null,   null),
                                                        new StatusMatchRule(RiseConstants.MDE1_70,   null,   null),
                                                        new StatusMatchRule(RiseConstants.MDE1_72,   null,   null),
                                                        new StatusMatchRule(RiseConstants.MDE2_73,   null,   null),
                                                        new StatusMatchRule(RiseConstants.MDE3_74,   null,   null)  };
    private static StatusMatchRule [] pckdUpRule =    { new StatusMatchRule(RiseConstants.PUP,       null,   null)  };
    private static StatusMatchRule [] arrvdCustRule = { new StatusMatchRule(RiseConstants.STAT,      "71",   null),
                                                        new StatusMatchRule(RiseConstants.STAT,      "72",   null),
                                                        new StatusMatchRule(RiseConstants.ECCO,      null,   new ArrivedCustomsCriteria()) };
    private static StatusMatchRule [] clrdCustRule =  { new StatusMatchRule(RiseConstants.STAT,      "65",   null),
                                                        new StatusMatchRule(RiseConstants.STAT,      "66",   null),
                                                        new StatusMatchRule(RiseConstants.ECCO,      null,   new ClearedCustomsCriteria()) };
    private static StatusMatchRule [] trnstRule =     { new StatusMatchRule(RiseConstants.SIP,       null,   null),    
                                                        new StatusMatchRule(RiseConstants.SOP,       null,   null),    
                                                        new StatusMatchRule(RiseConstants.HIP,       null,   null),    
                                                        new StatusMatchRule(RiseConstants.HOP,       null,   null),    
                                                        new StatusMatchRule(RiseConstants.RIP,       null,   null),    
                                                        new StatusMatchRule(RiseConstants.ROP,       null,   null)  };
    private static StatusMatchRule [] pndngRule =     { new StatusMatchRule(RiseConstants.DEX,       "03",   null),
                                                        new StatusMatchRule(RiseConstants.DEX,       "08",   null),
                                                        new StatusMatchRule(RiseConstants.DEX,       "17",   null)  };
    private static StatusMatchRule [] halRule =       { new StatusMatchRule(RiseConstants.HAL,       null,   null)  }; 
    private static StatusMatchRule [] heldRule =      { new StatusMatchRule(RiseConstants.HLD,       null,   null)  };
    private static StatusMatchRule [] mssrtRule =     { new StatusMatchRule(RiseConstants.MIS,       null,   null)  };
    private static StatusMatchRule [] cncldRule =     { new StatusMatchRule(RiseConstants.MDE_CANCEL,null,   null)  };
    private static StatusMatchRule [] dlvrdRule =     { new StatusMatchRule(RiseConstants.POD,       null,   null)  };  
    private static StatusMatchRule [] exDlvrdRule =   { new StatusMatchRule(RiseConstants.DDEX,      null,   null)  };
    private static StatusMatchRule [] outForDlvrRule ={ new StatusMatchRule(RiseConstants.VAN,       null,   null)  };
    
    /**
     * Defines the rules, weighting, and text values
     * The weight is to prevent the status from going backwards
     * As long as the weight is >= to the previous value the status can change
     */
    private static StatusRule [] statusRules = {    
      //              Rule        Weight,                DB             English
      //                                                 Value          Translation
      new StatusRule( plcdRule,       0,                 "PLCD",        "Placed"),  
      new StatusRule( trnstInRule,   10,                 "TRNSTIN",     "Transit In"),
      new StatusRule( tndrRule,      10,                 "TNDR",        "Tendered"),
      new StatusRule( pckdUpRule,    20,                 "PCKDUP",      "Picked Up"),
      new StatusRule( arrvdCustRule, 30,                 "AC",          "Arrived Customs"),
      new StatusRule( clrdCustRule,  30,                 "CC",          "Cleared Customs"),
      new StatusRule( trnstRule,     30,                 "TRNST",       "Transit"),
      new StatusRule( halRule,       30,                 "HAL",         "Hold at Location"),
      new StatusRule( heldRule,      30,                 "HLD",         "Held at Location"),
      new StatusRule( mssrtRule,     30,                 "MSSRT",       "Missort"),
      new StatusRule( outForDlvrRule,30,                 "OTFRDLVR",    "Out for Delivery"),
      new StatusRule( cncldRule,     50,                 "CNCLD",       "Canceled"),
      new StatusRule( pndngRule,     50,                 "PNDNG",       "Pending Delivery"),
      new StatusRule( dlvrdRule,     60,   RiseConstants.STATUS_DLVRD,  "Delivered"),
      new StatusRule( exDlvrdRule,   60,   RiseConstants.STATUS_DDLVRD, "Delivered with Exception")
    };
    
    /**
     * Calculate the status for a shipment based on the event
     * 
     * @param anEventVO
     * @param aPreviousStatus
     * @return new string if status changes, null if status does not change
     */
    public static String calcStatus(EventVO anEventVO, String aPreviousStatus) {
        logger.debug("Calculate status, previous status was: " + aPreviousStatus);
        
        String trackTypeCd = anEventVO.get_track_type_cd();
        String exceptionCd = anEventVO.get_track_excp_cd();
        
        String newDBValue = null;
        int newWeight = -1;
        int prevWeight = -1;
        
        for (int i = 0; i < statusRules.length; i++) {
            StatusMatchRule[] matchRules = statusRules[i].matchRules;
            for(int j = 0; j < matchRules.length; j++) {
                // does track type match
                if (matchRules[j].trackTypeCd.equals(trackTypeCd)) {
                    
                    // does exception code match
                    if (exceptionCd != null) {
                        // There is an exception code in the event
                        if (matchRules[j].exceptionCd != null) {
                            // The table has an exception code as well
                            if (!exceptionCd.equals(matchRules[j].exceptionCd)) {
                                // The event exception code and the table do not match
                                continue;
                            }
                        }
                    } else {
                        // The event does not have an exception code
                        if (matchRules[j].exceptionCd != null) {
                            // The event does not have an exception code, the table does, not a match
                            continue;
                        }
                    }
                    
                    // is there additional criteria to check
                    if (matchRules[j].addtlMatchCriteria != null) {
                        StatusCriteria criteria = matchRules[j].addtlMatchCriteria;
                        if (!criteria.meetsCriteria(anEventVO)) {
                            continue;
                        }
                    }
                    newDBValue = statusRules[i].dbValue;
                    newWeight = statusRules[i].weight;

                    // Find the weight of the previous status, if there is one
                    if (aPreviousStatus != null) {
                        for (int k = 0; k < statusRules.length; k++) {
                            if (aPreviousStatus.equals(statusRules[k].dbValue)) {
                                prevWeight = statusRules[k].weight;
                                break;
                            }
                        } 
                    }
                    if (newWeight >= prevWeight) {
                        StringBuffer sb = new StringBuffer();
                        sb.append("Previous status:");
                        sb.append(aPreviousStatus);
                        sb.append('(');
                        sb.append(prevWeight);
                        sb.append(')');
                        sb.append(" New status is: ");
                        sb.append(newDBValue);
                        sb.append('(');
                        sb.append(newWeight);
                        sb.append(')');
                        logger.info(sb.toString());
                        return newDBValue;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * For the GUI, translate the DB value into a string for display
     * on the GUI
     * @param aStatus
     * @return 
     */
    public final static String getStatusDesc(String aStatus) {
        if (aStatus == null) return null;
        for (int i = 0; i < statusRules.length; i++) {
            if (aStatus.equals(statusRules[i].dbValue)) {
               return statusRules[i].longDesc;
            }
        }
        // return status code if desc not found
        return aStatus;
    }
    
    /*
     * Create a CSV file of the tables above.
     */
    public static String listStatus() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < statusRules.length; i++) {
            StatusMatchRule [] matchRules = statusRules[i].matchRules;
            for (int j = 0; j < matchRules.length; j++) {
                TrackDesc trackDesc = TrackTypes.getTrackTypeDesc(matchRules[j].trackTypeCd);
                sb.append(trackDesc.get_shortName());
                sb.append('(');
                sb.append(matchRules[j].trackTypeCd);
                String exceptionCd = matchRules[j].exceptionCd;
                if (exceptionCd != null) {
                    sb.append(':');
                    sb.append(exceptionCd);
                }
                sb.append(')');
                if (j < matchRules.length-1) {
                    sb.append(';');
                }
            }
            sb.append(',');
            sb.append(statusRules[i].weight);
            sb.append(',');
            sb.append(statusRules[i].dbValue);
            sb.append(',');
            sb.append(statusRules[i].longDesc);
            sb.append("\n");
        }
        return sb.toString();
    }
    
//    public static void main(String[] args) {
//        System.out.println(listStatus());
//        System.out.println(getStatusDesc("DDLVRD"));
//        
//        // Test setting status based on event
//        EventVO eventVO = new EventVO();
//        eventVO.set_track_type_cd(RiseConstants.CE);
//        String newStatus = calcStatus(eventVO, null);
//        System.out.println("New Status should be PLCD:" + newStatus);
//        
//        eventVO = new EventVO();
//        eventVO.set_track_type_cd(RiseConstants.STAT);
//        eventVO.set_track_excp_cd("71");
//        newStatus = calcStatus(eventVO, "PLCD");
//        System.out.println("New Status should be AC:" + newStatus);        
//        
//        eventVO = new EventVO();
//        eventVO.set_track_type_cd(RiseConstants.DEX);
//        eventVO.set_track_excp_cd("03");
//        newStatus = calcStatus(eventVO, null);
//        System.out.println("New Status should be PNDNG:" + newStatus);           
//        
//        eventVO = new EventVO();
//        eventVO.set_track_type_cd(RiseConstants.DDEX);
//        eventVO.set_track_excp_cd("02");
//        newStatus = calcStatus(eventVO, "OTFRDLVR");
//        System.out.println("New Status should be DDLVRD:" + newStatus);
//        
//        // Test don't go back
//        eventVO = new EventVO();
//        eventVO.set_track_type_cd(RiseConstants.STAT);
//        eventVO.set_track_excp_cd("71");
//        newStatus = calcStatus(eventVO, RiseConstants.STATUS_DLVRD);
//        System.out.println("New Status should be null:" + newStatus);
//    }
    
    
    
    
}
