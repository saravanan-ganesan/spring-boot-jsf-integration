package com.fedex.rise.bo.status;

import com.fedex.rise.vo.EventVO;

public class ArrivedCustomsCriteria extends StatusCriteria {

    public boolean meetsCriteria(EventVO anEventVO) {
        char eccoTypeCd = anEventVO.get_ecco_type_cd();
        char eccoCommCd = anEventVO.get_ecco_comm_cd();
        
        if ((eccoTypeCd == 'P') && ((eccoCommCd == 'B') || (eccoCommCd == '2'))) {
            return true;
        }
        
        return false;
    }

}
