package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountGroupVO;

public class AccountGroupPersister extends OracleBase {

    private static Logger logger = LogManager.getLogger(AccountGroupPersister.class);
    
    public AccountGroupPersister(Connection con) {
        super(con);
    }
    
    private static final String addAccountGroupSQL =
            "Insert into Account_Group(" +
            "GROUP_NBR, " +
            "GROUP_NM, " +
            "GROUP_DESC, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP) " +
             "values(GROUP_NBR_SQ.NEXTVAL, ?, ? ,SYSDATE, SYSDATE)";        
    
    public void addAccountGroup(AccountGroupVO anAccountGroupVO) throws SQLException {
        
        try {
            setSqlSignature( addAccountGroupSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anAccountGroupVO.get_group_nm());
            pstmt.setString( 2, anAccountGroupVO.get_group_desc());

            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }       
}
