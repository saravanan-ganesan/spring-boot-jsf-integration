package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.db.EventsAccessor;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EventVO;

public class EventDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(EventDAO.class);
    
    public List getEvents(String aTrkngItemNbr, String aTrkngUniqItemNbr)
    	throws SQLException, ServiceLocatorException {
    
    	Connection connection = null;

    	try {
    		connection = initializeConnection(true);
    		EventsAccessor accessor = new EventsAccessor(connection);
    		return accessor.getEvents(aTrkngItemNbr, aTrkngUniqItemNbr);
    	} finally {
    		closeConnection(connection);
    	}    
    }
    
    /**
     * This method is used to persist a record into the Event table.
     *
     * @param anEventVO the event data to persist
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public boolean doPersist(EventVO anEventVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            EventPersister persister = new EventPersister(connection);
            return persister.persist(anEventVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    public List getEventsForIssues(String aTrkngItemNbr, String aTrkngUniqItemNbr, Date aDate)
        throws SQLException, ServiceLocatorException {
        
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            EventsAccessor accessor = new EventsAccessor(connection);
            return accessor.getEventsForIssues(aTrkngItemNbr, aTrkngUniqItemNbr, aDate);
        } finally {
            closeConnection(connection);
        }    
    }
    
    public int getCountPodsOnMawb(String aTrkngItemNbr, String aTrkngUniqItemNbr)
        throws SQLException, ServiceLocatorException {
    
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            EventsAccessor accessor = new EventsAccessor(connection);
            return accessor.getCountPodsOnMawb(aTrkngItemNbr, aTrkngUniqItemNbr);
        } finally {
            closeConnection(connection);
        }    
    }    
    // For testing
    public EventVO getEvent(String aTrkngItemNbr, String aTrkngUniqItemNbr, String aTrackTypeCd, 
            String aSeqNbr) throws SQLException, ServiceLocatorException {
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            EventsAccessor accessor = new EventsAccessor(connection);
            return accessor.getEvent(aTrkngItemNbr, aTrkngUniqItemNbr, aTrackTypeCd, aSeqNbr);
        } finally {
            closeConnection(connection);
        }       
    }
}
