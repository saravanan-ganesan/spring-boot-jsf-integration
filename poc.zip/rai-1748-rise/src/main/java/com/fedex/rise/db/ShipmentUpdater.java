package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ShipmentVO;

public class ShipmentUpdater extends OracleBase {
    private static Logger logger = LogManager.getLogger(ShipmentUpdater.class);
    
    public ShipmentUpdater(Connection con) {
        super(con);
    }
    
    private static final String updateShipmentSQL = 
        "update Shipment set " +
        "GROUP_NBR = ?, " +
        "ACCT_NBR = ?, " +
        "LANE_NBR = ?, " +
        "SVC_TYPE_CD = ?, " +
        "SHPMT_TYPE_CD = ?, " +
        "TRKNG_ITEM_FORM_CD = ?, " +
        "PACK_TYPE_CD = ?, " +
        "ORIG_LOC_CD = ?, " +
        "DEST_LOC_CD = ?, " +
        "SHPMT_WGT = ?, " +
        "SHPMT_UOM_CD = ?, " +
        "SHPR_CO_NM = ?, " +
        "SHPR_PH_NBR = ?, " +
        "SHPR_ADDR_LINE_ONE_DESC = ?, " +
        "SHPR_ADDR_LINE_TWO_DESC = ?, " +
        "SHPR_ADDR_LINE_THREE_DESC = ?, " +
        "SHPR_CITY_NM = ?, " +
        "SHPR_PSTL_CD = ?, " +
        "SHPR_CNTRY_CD = ?, " +
        "SHPR_ST_PROV_CD = ?, " +
        "RECP_CO_NM = ?, " +
        "RECP_PH_NBR = ?, " +
        "RECP_ADDR_LINE_ONE_DESC = ?, " +
        "RECP_ADDR_LINE_TWO_DESC = ?, " +
        "RECP_ADDR_LINE_THREE_DESC = ?, " +
        "RECP_CITY_NM = ?, " +
        "RECP_ST_PROV_CD = ?, " +
        "RECP_CNTRY_CD = ?, " +
        "RECP_PSTL_CD = ?, " +
        "ACTL_DEL_NM = ?, " +
        "ACTL_ADDR_LINE_ONE_DESC = ?, " +
        "DEL_DT = ?, " +
        "DEL_DATE_TMZN_OFFST_NBR = ?, " +
        "SPCL_HNDLG_GRP = ?, " +
        "CRTG_AGENT_CO_NM = ?, " +
        "CSTMS_CURR_CD = ?, " +
        "CSTMS_VALUE_AMT = ?, " +
        "DIMNL_WGT = ?, " +
        "INV_AMT = ?, " +
        "SHPMT_PKG_QTY = ?, " +
        "LAST_EVENT_TMSTP = ?, " +
        "LAST_EVENT_TMZN_OFFST_NBR = ?, " +
        "LAST_EVENT_TRACK_TYPE_CD = ?, " +
        "COMMIT_DT = ?, " +
        "ADJ_COMMIT_DT = ?, " +
        "COMMIT_DATE_TMZN_OFFST_NBR = ?, " +
        "PERF_RSULT_CD = ?, " +
        "SHIP_DT = ?, " +
        "ADJ_COMMIT_DT_OFFST_NBR = ?, " +
        
        "DEL_QTY = ?, " +
        "SKID_INTACT_FLG = ?, " +
        "QTY_OBSER_FLG = ?, " +
        "PKG_PIECE_QTY = ?, " +
        "LAST_STAT_DESC = ?, " +
        "LAST_EVENT_TRACK_LOC_CD = ?, " +
        
        "LAST_STAT_TRACK_LOC_CD = ?, " +
        "LAST_STAT_TMSTP = ?, " +
        "CLEARED_CSTMS_TMSTP = ?, " +
        "CLEARED_CSTMS_TMZN_OFFSET_NBR = ?, " +
        "WRK_STAT_CD = ?, " +
        
        "LAST_UPDT_TMSTP = SYSDATE " +        
        "where " +
           "TRKNG_ITEM_NBR = ? and " + 
           "TRKNG_ITEM_UNIQ_NBR = ?";

    public void updateShipment(ShipmentVO aShipmentVO) throws SQLException {
    
        try {
            setSqlSignature( updateShipmentSQL, false, logger.isDebugEnabled() );

            pstmt.setInt(    1, aShipmentVO.get_grp_nbr());
            pstmt.setString( 2, aShipmentVO.get_acct_nbr());
            pstmt.setInt(    3, aShipmentVO.get_lane_nbr());
            pstmt.setString( 4, aShipmentVO.get_svc_type_cd());
            pstmt.setString( 5, aShipmentVO.get_shpmt_type_cd());
            pstmt.setInt(    6, aShipmentVO.get_trkng_item_form_cd());
            pstmt.setInt(    7, aShipmentVO.get_pack_type_cd());
            pstmt.setString( 8, aShipmentVO.get_orig_loc_cd());
            pstmt.setString( 9, aShipmentVO.get_dest_loc_cd());
            pstmt.setInt(   10, aShipmentVO.get_shpmt_wgt());
            pstmt.setString(11, String.valueOf(aShipmentVO.get_shpmt_uom_cd()));
            pstmt.setString(12, aShipmentVO.get_shpr_co_nm());
            pstmt.setString(13, aShipmentVO.get_shpr_ph_nbr());
            pstmt.setString(14, aShipmentVO.get_shpr_addr_line_one_desc());
            pstmt.setString(15, aShipmentVO.get_shpr_addr_line_two_desc());
            pstmt.setString(16, aShipmentVO.get_shpr_addr_line_three_desc());
            pstmt.setString(17, aShipmentVO.get_shpr_city_nm());
            pstmt.setString(18, aShipmentVO.get_shpr_pstl_cd());
            pstmt.setString(19, aShipmentVO.get_shpr_cntry_cd());
            pstmt.setString(20, aShipmentVO.get_shpr_st_prov_cd());
            pstmt.setString(21, aShipmentVO.get_recp_co_nm());
            pstmt.setString(22, aShipmentVO.get_recp_ph_nbr());
            pstmt.setString(23, aShipmentVO.get_recp_addr_line_one_desc());
            pstmt.setString(24, aShipmentVO.get_recp_addr_line_two_desc());
            pstmt.setString(25, aShipmentVO.get_recp_addr_line_three_desc());
            pstmt.setString(26, aShipmentVO.get_recp_city_nm());
            pstmt.setString(27, aShipmentVO.get_recp_st_prov_cd());
            pstmt.setString(28, aShipmentVO.get_recp_cntry_cd());
            pstmt.setString(29, aShipmentVO.get_recp_pstl_cd());
            pstmt.setString(30, aShipmentVO.get_actl_del_nm());
            pstmt.setString(31, aShipmentVO.get_actl_addr_line_one_desc());
            if (aShipmentVO.get_del_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentVO.get_del_dt().getTimeInMillis());
                pstmt.setTimestamp(  32, sqlDate);
                pstmt.setString(33, formatTZ(aShipmentVO.get_del_dt().getTimeZone().getID()));
            } else {
                pstmt.setNull(32, java.sql.Types.TIMESTAMP);
                pstmt.setNull(33, java.sql.Types.VARCHAR);
            }           

            pstmt.setString(34, aShipmentVO.get_spcl_hndlg_grp());
            pstmt.setString(35, aShipmentVO.get_crtg_agent_co_nm());
            pstmt.setString(36, aShipmentVO.get_cstms_curr_cd());
            pstmt.setInt(   37, aShipmentVO.get_cstms_value_amt());
            pstmt.setInt(   38, aShipmentVO.get_dimnl_wgt());
            pstmt.setInt(   39, aShipmentVO.get_inv_amt());
            pstmt.setInt(   40, aShipmentVO.get_shpmt_pkg_qt());

            if (aShipmentVO.get_last_event_tmstp() != null) {
                java.sql.Timestamp timeStamp = new java.sql.Timestamp(aShipmentVO.get_last_event_tmstp().getTimeInMillis());
                pstmt.setTimestamp(41, timeStamp);
                pstmt.setString(42, formatTZ(aShipmentVO.get_last_event_tmstp().getTimeZone().getID()));
            } else {
                pstmt.setNull(41, java.sql.Types.TIMESTAMP);
                pstmt.setNull(42, java.sql.Types.VARCHAR);
            }

            pstmt.setString(43, aShipmentVO.get_last_event_track_type_cd());
            
            if (aShipmentVO.get_commit_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentVO.get_commit_dt().getTimeInMillis());
              pstmt.setTimestamp(44, sqlDate);
            } else {
                pstmt.setNull(44, java.sql.Types.TIMESTAMP);
            }  

            if (aShipmentVO.get_adj_commit_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentVO.get_adj_commit_dt().getTimeInMillis());
              pstmt.setTimestamp(45, sqlDate);
            } else {
                pstmt.setNull(45 , java.sql.Types.TIMESTAMP);
            }            
            
            if (aShipmentVO.get_commit_dt() != null) {
                pstmt.setString(46, formatTZ(aShipmentVO.get_commit_dt().getTimeZone().getID()));                
            } else {
                pstmt.setNull(46, java.sql.Types.VARCHAR);
            }

            pstmt.setString(47,aShipmentVO.get_perf_rsult_cd());     
            
            if (aShipmentVO.get_ship_dt() != null) {
            	java.sql.Date sqlDate = 
            		new java.sql.Date(aShipmentVO.get_ship_dt().getTime());
            	pstmt.setDate(48, sqlDate);
            } else {
            	pstmt.setNull(48, java.sql.Types.DATE);
            }
            pstmt.setInt(49, aShipmentVO.get_adj_commit_dt_offst_nbr());
            
            pstmt.setInt(50, aShipmentVO.get_delivery_qty());
            pstmt.setString(51, String.valueOf(aShipmentVO.get_skid_intact_flag()));
            pstmt.setString(52, String.valueOf(aShipmentVO.get_quantity_observed_flag()));
            pstmt.setInt(53, aShipmentVO.get_package_piece_qty());
            pstmt.setString(54, aShipmentVO.get_last_stat_desc());
            pstmt.setString(55, aShipmentVO.get_last_event_track_loc_cd());
            
            pstmt.setString(56, aShipmentVO.get_last_stat_track_loc_cd());
            if (aShipmentVO.get_last_stat_tmstp() != null) {
                java.sql.Timestamp sqlDate = 
                    new java.sql.Timestamp(aShipmentVO.get_last_stat_tmstp().getTime());
                pstmt.setTimestamp(57, sqlDate);
            } else {
                pstmt.setNull(57, java.sql.Types.DATE);
            }
            
            if (aShipmentVO.get_cleared_cstms_tmstp() != null) {
                java.sql.Timestamp sqlDate = 
                    new java.sql.Timestamp(aShipmentVO.get_cleared_cstms_tmstp().getTimeInMillis());
                pstmt.setTimestamp(58, sqlDate);
                pstmt.setString(59, formatTZ(aShipmentVO.get_cleared_cstms_tmstp().getTimeZone().getID()));
            } else {
                pstmt.setNull(58, java.sql.Types.DATE);
                pstmt.setNull(59, java.sql.Types.VARCHAR);
            }            
            
            pstmt.setString(60, aShipmentVO.get_wrk_stat_cd());
            
            pstmt.setString(61, aShipmentVO.get_trkng_item_nbr());
            pstmt.setString(62, aShipmentVO.get_trkng_item_uniq_nbr());
 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
         
            int rowsUpdated = executeUpdate();

            if ( rowsUpdated == 0) {
                // Shipment not updated
                logger.error("Shipment not Updated for : " +
                        aShipmentVO.get_trkng_item_nbr() + ":" + aShipmentVO.get_trkng_item_uniq_nbr());
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
    }
    
    private static final String updateShipmentGroupNbrSQL = 
        "update Shipment set " +
        "GROUP_NBR = ?, " +
        "LAST_UPDT_TMSTP = SYSDATE " +        
        "where ACCT_NBR = ? " + 
        "and LANE_NBR = ?  " +
        "and SVC_TYPE_CD = ? " +
         "and GROUP_NBR = 0 ";
    /**
     * Update group numbers that are zero for a specific account number.
     * @param groupNbr 
     * @param accountNbr
     * @throws SQLException
     */
    public void updateGroupNbrOfShipments(int groupNbr, String accountNbr, 
    		int laneNbr, String svcTypeCd) throws SQLException {
        try {
            setSqlSignature( updateShipmentGroupNbrSQL, false, logger.isDebugEnabled() );

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);
            pstmt.setInt(3, laneNbr);
            pstmt.setString(4, svcTypeCd);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
         
            int rowsUpdated = executeUpdate();

            if ( rowsUpdated == 0) {
                // Shipment not updated
                logger.info("Shipment not Updated for account number : " +
                		accountNbr);
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
    }
}
