package com.fedex.rise.vo;

import java.io.Serializable;

/**
 * Employee Value Object (or Transfer Object) used to encapsulate the employee
 * data for transport.
 */
public class EmployeeVO implements Serializable{
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _emp_nbr;
    private String _emp_first_nm;
    private String _emp_last_nm;
    private String _emp_role_cd;
    
    /**
     * Default Constructor
     */
    public EmployeeVO() {
    }

    /**
     * Construct an Employee
     * @param _emp_nbr
     * @param _emp_first_nm
     * @param _emp_last_nm
     * @param _emp_role_cd
     */
    public EmployeeVO(String _emp_nbr, String _emp_first_nm, String _emp_last_nm, String _emp_role_cd) {
        super();
        this._emp_nbr = _emp_nbr;
        this._emp_first_nm = _emp_first_nm;
        this._emp_last_nm = _emp_last_nm;
        this._emp_role_cd = _emp_role_cd;
    }

    /**
     * @return the _emp_first_nm
     */
    public String get_emp_first_nm() {
        return _emp_first_nm;
    }

    /**
     * @param _emp_first_nm the _emp_first_nm to set
     */
    public void set_emp_first_nm(String _emp_first_nm) {
        this._emp_first_nm = _emp_first_nm.trim();
    }

    /**
     * @return the _emp_last_nm
     */
    public String get_emp_last_nm() {
        return _emp_last_nm;
    }

    /**
     * @param _emp_last_nm the _emp_last_nm to set
     */
    public void set_emp_last_nm(String _emp_last_nm) {
        this._emp_last_nm = _emp_last_nm.trim();
    }

    /**
     * @return the _emp_nbr
     */
    public String get_emp_nbr() {
        return _emp_nbr;
    }

    /**
     * @param _emp_nbr the _emp_nbr to set
     */
    public void set_emp_nbr(String _emp_nbr) {
        this._emp_nbr = _emp_nbr.trim();
    }

    /**
     * @return the _emp_role_cd
     */
    public String get_emp_role_cd() {
        return _emp_role_cd;
    }

    /**
     * @param _emp_role_cd the _emp_role_cd to set
     */
    public void set_emp_role_cd(String _emp_role_cd) {
        this._emp_role_cd = _emp_role_cd;
    }
    
}
