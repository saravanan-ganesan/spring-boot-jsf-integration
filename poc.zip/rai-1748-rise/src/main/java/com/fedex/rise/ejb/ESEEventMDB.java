package com.fedex.rise.ejb;
public class ESEEventMDB {
	
}

//
//import java.sql.SQLException;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Properties;
//import java.util.TimeZone;
//import java.util.Enumeration;
//
//import javax.ejb.EJBException;
//import javax.ejb.MessageDrivenBean;
//import javax.ejb.MessageDrivenContext;
//import javax.jms.BytesMessage;
//import javax.jms.JMSException;
//import javax.jms.Message;
//import javax.jms.MessageListener;
//
//import org.apache.logging.log4j.Logger;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.ThreadContext;
//
//
//import weblogic.ejbgen.ForeignJmsProvider;
//import weblogic.ejbgen.MessageDriven;
//
////import com.fedex.rise.MCD.RISEMcd;
//import com.fedex.rise.bo.issue.TransactionException;
//import com.fedex.rise.ese.EnhancedEventMessageHandler;
//import com.fedex.rise.util.RiseConstants;
//import com.fedex.rise.util.ServiceLocatorException;
//import com.fedex.rise.xref.TrackDesc;
//import com.fedex.rise.xref.TrackTypes;
//
///**
// * This is the MDB to process JMS ESE Events.
// *       
// */
//@MessageDriven(destinationType = "javax.jms.Queue",
//        ejbName = "RiseEngineMDB@NBR@",
//        destinationJndiName = "RiseEseJmsQueue@NBR@",
//        jmsPollingIntervalSeconds ="60",
//        maxBeansInFreePool = "1",
//        initialBeansInFreePool = "1",
//        acknowledgeMode = MessageDriven.AcknowledgeMode.AUTO_ACKNOWLEDGE,
//        transactionType = MessageDriven.MessageDrivenTransactionType.BEAN,
//        transTimeoutSeconds = "120")
//@ForeignJmsProvider(
//        connectionFactoryJndiName = "RiseEseJmsConnectionFactory@NBR@")
//public class ESEEventMDB implements MessageDrivenBean, MessageListener {
//
//    /**
//     * Default serialVersionUID
//     */
//    private static final long serialVersionUID = 1L;
//    
//    private static Logger logger = LogManager.getLogger(ESEEventMDB.class);
//    
//    /** The MessageDrivenContext */
//    private MessageDrivenContext context;
//    
//    // To format the MsgCreateTmstp
//    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss'.'SSS");
//    SimpleDateFormat outputFormat = new SimpleDateFormat("'TP2MI Tmstp:'MM-dd-yyyy HH:mm:ss z");
//    TimeZone tz = TimeZone.getTimeZone("GMT+0000");
//    private int maxDeliveryCount = 0; // default to NO maxDeliveryCount
//    private int maxDeliveryAlarmThreshold = 254;
//      
//   // String shortClassName = null;  // used in the MCD event
//    
//    public ESEEventMDB() {
//        // Get the timestamp on the input formattter to GMT
//        inputFormat.setTimeZone(tz);
//        //shortClassName = this.getClass().getName();
//        //shortClassName = shortClassName.substring(shortClassName.lastIndexOf('.')+1); 
//    }
//
//    public void ejbRemove() throws EJBException {
//        System.out.println("ejbRemove called");
//    }
//
//    /**
//     * Set the associated context. The container calls this method 
//     * after the instance creation.  <br>
//     * 
//     * The enterprise bean instance should store the reference to the context 
//     * object in an instance variable. <br>
//     * 
//     * This method is called with no transaction context.
//     * 
//     * @param newContext A MessageDrivenContext interface for the instance. 
//     * 
//     * @throws EJBException Thrown by the method to indicate a failure caused by a system-level error.
//     */
//    public void setMessageDrivenContext(MessageDrivenContext newContext)
//        throws EJBException {
//        context = newContext;
//    }
//
//    /**
//     * The method called by the container to handle the JMS message.  This code
//     * will build the context strings for logging and MCD events and will time
//     * the event.  Some events are not processed as they are unwanted by the
//     * users.  Some exceptions will cause the event to be redelievered.
//     * @param aMsg the ESE Event
//     */
//    public void onMessage(Message aMsg) {      
//        long startTime = System.currentTimeMillis();
//        EnhancedEventMessageHandler eemh = new EnhancedEventMessageHandler();
//        
//        // The text string to put in the logger context
//        StringBuffer contextString = null;
//        // The text string to use in events to MCD
//       // StringBuffer mcdString = null;
//        //Properties mcdProp = new Properties();
//        
//        try {  
//            if (logger.isDebugEnabled()) {
//        	    dumpProperties(aMsg);
//            }
//            
//            // Get the Object Properties to use as a context string for logging
//            String trkngNbr = (String)aMsg.getObjectProperty("TrackItemNbr");
//            String eventCd = (String)aMsg.getObjectProperty("TriggerEventType");
//            String jmsID = (String)aMsg.getJMSMessageID();
//            if (eventCd == null) {
//                eventCd = "UN";
//            }
//            String exceptionCd = (String)aMsg.getObjectProperty("TrackExcpCd");
//            // Lookup the Acronym of the track type
//            TrackDesc trackTypeDesc = TrackTypes.getTrackTypeDesc(eventCd);
//
//            contextString = buildContextString(trkngNbr, exceptionCd, trackTypeDesc);                    
//            ThreadContext.push(contextString.toString());
//
//            int slice = calculateSlice(trkngNbr);
//
//            /*mcdString = buildMCDString(exceptionCd, trackTypeDesc);
//            mcdProp.setProperty("trkngNbr", trkngNbr);
//            mcdProp.setProperty("slice", Integer.toString(slice));
//            RISEMcd.sendMCDEvent(shortClassName, RISEMcd.REQUEST_FROM_CLIENT,  mcdString.toString(), -1, mcdProp);            
//            */
//            String localCreateTmpstp = convertZuluToLocal((String)aMsg.getObjectProperty("MsgCreateTmstp"));
//            StringBuffer sb = new StringBuffer();
//            sb.append(jmsID);
//            sb.append(" : ");
//            sb.append(localCreateTmpstp);
//            sb.append(" : Slice:");
//            sb.append(slice);
//            logger.info(sb.toString());
//
//            // Check for a poison pill, a poison pill is a message that we are stumbling
//            // on over and over.  If the EIT group had implemented a count on 
//            // redeliveries, we wouldn't have to do this.  The list is added to via 
//            // a admin jsp page.  Determine if the auto delete of poison pills is enabled.
//            boolean poisonPill = PoisonPillHandler.checkPoisonPillList(jmsID);
//            boolean autoDelete = PoisonPillHandler.getAutoDelete();
//            
//            if (poisonPill) {
//                logger.info("Poison pill detected, message dropped");
//            }
//            
//            if (autoDelete) {
//                logger.debug("Auto delete of the poison pills is enabled.");
//            }
//                        
//            if ((!isPoisonPill(aMsg, autoDelete)) && (!poisonPill) && (!unwantedEvent(eventCd, exceptionCd)) && (aMsg instanceof BytesMessage)) {
//                BytesMessage bMsg = (BytesMessage)aMsg;
//                long length = bMsg.getBodyLength();
//                byte[] rawBytes = new byte[(int)length];
//                bMsg.readBytes(rawBytes, (int) length);
//                bMsg.reset();
//                 
//                eemh.processMessage(rawBytes);
//            }
//            // Any thrown exceptions will be redelivered, must throw exceptions as a wrapped
//            // EJBException
//        } catch (JMSException jmse) {
//            logger.error("JMS Exception:", jmse);
//            throw new EJBException(jmse);
//        } catch (SQLException sqle) {
//            throw new EJBException(sqle);
//        } catch (TransactionException te) { // transaction related
//            throw new EJBException(te);
//        } catch (ServiceLocatorException svcloce) { // something not set up right
//            throw new EJBException(svcloce);
//        } finally {
//            long elapsedTime = System.currentTimeMillis() - startTime;
//            //RISEMcd.sendMCDEvent(shortClassName, RISEMcd.RESPONSE_TO_CLIENT, mcdString.toString(), elapsedTime, mcdProp); 
//            logger.info("Process time in milli: " + elapsedTime);
//            
//            if ((contextString != null) && (contextString.length() > 0)) {
//            	ThreadContext.pop();
//            }
//        }
//    }
//
//    /**
//     * An ejbCreate method as required by the EJB specification.
//     * 
//     * The container calls the instance's <code>ejbCreate</code> method 
//     * immediately after instantiation.
//     */
//    public void ejbCreate() {
//        System.out.println("ESEEventMDB ejbCreate");
//    }
//
//    /**
//     * This method is used to build a context string for logging.  It will
//     * contain the event acronym, the tracking number and exception code
//     * if present
//     * @param aTrkngNbr
//     * @param anExceptionCd
//     * @param aTrackTypeDesc
//     * @return
//     */
//    private StringBuffer buildContextString(String aTrkngNbr, String anExceptionCd,
//                                            TrackDesc aTrackTypeDesc) {
//        StringBuffer contextString = new StringBuffer();
//        contextString.append(aTrkngNbr);
//        contextString.append(" ");
//        if (aTrackTypeDesc != null) {
//             contextString.append(aTrackTypeDesc.get_shortName());
//        } else {
//            contextString.append("UNKNOWN");
//        }
//        if (anExceptionCd != null) {
//            contextString.append(anExceptionCd);
//        }
//        return contextString;
//    }
//    
//    /**
//     * This method is used to build a string which will be in the MCD event message
//     * @param anExceptionCd the exception code or null
//     * @param aTrackTypeDesc used to get the event acronym
//     * @return
//     */
//    /*private StringBuffer buildMCDString(String anExceptionCd, TrackDesc aTrackTypeDesc) {
//        StringBuffer mcdString = new StringBuffer();
//        mcdString.append("OnMessage.");
//        if (aTrackTypeDesc != null) {
//            mcdString.append(aTrackTypeDesc.get_shortName());
//            if (anExceptionCd != null) {
//                mcdString.append(anExceptionCd);
//            }
//        } else {
//            mcdString.append("Unknown");
//        }
//        return mcdString;
//    }*/
//    
//    /**
//     * Used to format the MsgCreateTmstp into local time, this timestamp
//     * can be used to see what the delay is between TP2MI in transporter
//     * and EIT output.
//     * @param aMsgCreateTmstp
//     * @return
//     */
//    private String convertZuluToLocal(String aMsgCreateTmstp) {
//        if (aMsgCreateTmstp == null) {
//            return null;
//        }
//        //2007-04-10T23:35:34.268Z
//        //20070724T142601.707Z+0000
//
//        try {
//            Date d = inputFormat.parse(aMsgCreateTmstp);
//            if (d != null) {
//                return outputFormat.format(d);    
//            }
//        } catch (ParseException e) {
//        }
//        return null;
//    }
//    
//    /**
//     * Used to calculate the Transporter slice to aid in debugging
//     * @param aTrkngNbr
//     * @return the slice
//     */
//    private int calculateSlice(String aTrkngNbr) {
//        if (aTrkngNbr != null && aTrkngNbr.length() >= 7) {
//            try {
//                String sub = aTrkngNbr.substring(aTrkngNbr.length() - 6, aTrkngNbr.length() - 1);
//                int subInt = Integer.valueOf(sub).intValue();
//                int slice = subInt % 24;
//                return slice;
//            } catch (Exception e) {
//                return -1;
//            }
//        } else {
//            return -1;
//        }
//    }
//    
//    /**
//     * Determine if the message could be a poison pill and handle it
//     * @param aMsg
//     * @return true if it was a poison pill
//     */
//    private boolean isPoisonPill(Message aMsg, boolean autoDelete) throws JMSException {
//        try {
//            // Is the Message is being re-delivered?
//    		if (aMsg.getJMSRedelivered() && autoDelete) {
//    		    int deliveryCount = aMsg.getIntProperty("JMSXDeliveryCount");
//    		    if (deliveryCount >= maxDeliveryAlarmThreshold) {
//    		    	logger.error("JMS Message Redelivery threshold is being exceeded, count is: " + deliveryCount);
//    		    } else {
//    		    	logger.info("JMS Message Redelivery Count: " + deliveryCount);
//    		    }
//        	    
//        	    // If too many deliveries, then this could be a poison pill and we 
//    		    // will dump the message and return true so it gets taken off the JMS queue.
//    		    if (deliveryCount >= maxDeliveryAlarmThreshold) {
//    		        // TODO: save message to disk or to undeliv queue
//             	    dumpProperties(aMsg);
//    		        return true;
//    		    }
//    		}
//     		return false;
//        } catch (Exception e) {
//		    logger.error("Bad JMS Message: " + aMsg, e);
//		    return true;
//		}
//    }
//    
//    /**
//     * This method is used to filter out events that
//     * the monitors do not want.  We have the info needed to determine
//     * if we want the event or not based on properties from the JMS header.
//     * It will be quicker to do it here than to extract the data from the 
//     * event and then determine if we want to keep it.
//     * 
//     * @param anEventCd
//     * @param anExceptionCd
//     * @return
//     */
//    public boolean unwantedEvent(String anEventCd, String anExceptionCd) {
//        int [] unwantedStatExceptionCds = { 1,  2,  5, 11, 15, 16, 20, 27, 35, 43, 
//                                           44, 46, 47, 51, 59, 61, 64, 68, 73, 78,
//                                           81, 86, 92, 93, 94, 97};
//        String [] unwantedEventCds = { "ZY", "2D", "NR", "SD", "CC" };
//        if (anEventCd != null) {
//            for (int i = 0; i < unwantedEventCds.length; i++) {
//                if (anEventCd.equals(unwantedEventCds[i])) {
//                    logger.debug("Dropping event");
//                    return true;
//                }
//            }
//            if (anExceptionCd != null) {
//                if (anEventCd.equals(RiseConstants.STAT)) {
//                    int exceptionCd = -1;
//                    try {
//                        exceptionCd = Integer.parseInt(anExceptionCd);
//                    } catch (NumberFormatException nfe) { return false; }
//                    for (int i = 0; i < unwantedStatExceptionCds.length; i++) {
//                        if (exceptionCd == unwantedStatExceptionCds[i]) {
//                            logger.debug("Dropping event");
//                            return true;
//                        }
//                    }
//                }
//            }
//        }
//        return false;
//    }
//    
//    private void dumpProperties(Message aMsg) {
//    // Use this code to dump off of the properties.
//    	try {
//    		Enumeration enuma = aMsg.getPropertyNames();
//    		StringBuffer sb = new StringBuffer();
//    		sb.append("JMS Properties:");
//    		while(enuma.hasMoreElements()) {
//    			String o = (String)enuma.nextElement();
//    			sb.append( o + "-" + aMsg.getObjectProperty(o) + "|");                       
//    		}
//    		logger.debug(sb);
//    	} catch (JMSException e){
//    		logger.error(e);
//    	}
//    }
//    
//    // Example of properties
//    //Properties:TriggerEventType-11|FormCd-0491|ParentTrkNbr-732782853400|
//    //MsgCharCd-XER|ORIGIN_COUNTRY_CODE-CN|HashId-5|CreateTmstp-20070319074030707Z|
//    //TrackItemNbr-732782862335|MsgUser-SEP|CARRIER_OID-541057295|SpecialHandlingCd-02,34|
//    //MsgVsn-200706|ServiceCd-18|MsgCreateTmstp-2007-03-22T12:38:13.363Z|DEST_COUNTRY_CODE-US|
//    //GeoCode-RAPAC,RUS|DestStProvCd-OH|JMS_TIBCO_COMPRESS-true|
//    //JMS_TIBCO_PRESERVE_UNDELIVERED-true|MoveStatusCd-OD|MsgSource-TP2MI| 
//    
//}
