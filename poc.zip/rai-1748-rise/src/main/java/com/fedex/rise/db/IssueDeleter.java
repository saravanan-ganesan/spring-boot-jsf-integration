package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.IssueVO;

public class IssueDeleter extends OracleBase {
    private static Logger logger = LogManager.getLogger(IssueDeleter.class);

    public IssueDeleter(Connection con) {
        super(con);
    }

    private static final String deleteIssueSQL = "delete from Issue where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND " +
            "ISSUE_TYPE_CD = ?";
    /**
     * Delete an Issue
     * @param anIssueVO
     * @throws SQLException
     */
    public void deleteIssue(IssueVO anIssueVO) throws SQLException {

        try {
            setSqlSignature(deleteIssueSQL, false, logger.isDebugEnabled());            
            
            pstmt.setString( 1, anIssueVO.getTrkng_item_nbr());
            pstmt.setString( 2, anIssueVO.getTrkng_item_uniq_nbr());           
            pstmt.setInt( 3, anIssueVO.getIssue_type_cd());
       
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
}
