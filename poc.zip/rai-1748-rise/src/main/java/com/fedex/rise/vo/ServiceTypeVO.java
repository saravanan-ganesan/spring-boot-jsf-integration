package com.fedex.rise.vo;

import java.io.Serializable;

public class ServiceTypeVO implements Serializable {
    private String _svcTypeCd;
    private String _svcTypeDesc;

    
    public ServiceTypeVO(String typeCd, String typeDesc) {
        super();
        _svcTypeCd = typeCd;
        _svcTypeDesc = typeDesc;
    }

    /**
     * @return the _svcTypeCd
     */
    public String get_svcTypeCd() {
        return _svcTypeCd;
    }
    /**
     * @param typeCd the _svcTypeCd to set
     */
    public void set_svcTypeCd(String typeCd) {
        _svcTypeCd = typeCd;
    }
    /**
     * @return the _svcTypeDesc
     */
    public String get_svcTypeDesc() {
        return _svcTypeDesc;
    }
    /**
     * @param typeDesc the _svcTypeDesc to set
     */
    public void set_svcTypeDesc(String typeDesc) {
        _svcTypeDesc = typeDesc;
    }

    
}
