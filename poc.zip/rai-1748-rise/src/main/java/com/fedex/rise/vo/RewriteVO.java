package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

public class RewriteVO implements Serializable {
    private String _trk_type_cd;
    private String _trk_item_nbr;
    private String _trk_item_unique_id;
    private String _trk_item_form_cd;
    private String _rise_trk_type_cd;  // MAWB, CRN, AWB
    private String _return_trk_item_nbr;
    private String _trk_exception_cd;

    private String _shpr_acct_nbr;

    private Date _ship_date;
    private String _declared_value_currency_cd;
    private String _customs_currency_cd;
    private String _ce_customs_value;
    private String _ml_customs_value;
    private String _shipment_pkg_count;

    private String _packaging_type;
    private String _base_service_cd;
    private String _shipper_company_name;
    private String _shipper_addr_desc;
    private String _shipper_addl_addr_desc;
    private String _shipper_city_name;
    private String _shipper_postal_cd;
    private String _shipper_country_cd;
    private String _shipper_state_province_cd;
    private String _shipper_phone_nbr;
    
    private String _consignee_company_name;
    private String _consignee_addr_desc;
    private String _consignee_addl_addr_desc;
    private String _consignee_city_name;
    private String _consignee_postal_cd;
    private String _consignee_country_cd;
    private String _consignee_state_province_cd;
    private String _consignee_phone_nbr;   
    
    private String _oda_company_name ;

    private String _loc_cd;
    private String _admin_loc_cd;

    private String _ref_type_cd;
    private String _shipper_ref_notes;

    private String _special_handling;
    private String _sp_shpmt_weight;
    private String _sp_shpmt_weight_uom;
     
    private String _sp_pkg_weight;
    private String _sp_pkg_weight_uom;
    
    
    private String _acceptance_dt_tm;
    private String _delivery_dt_tm;
    private String _event_creation_tmstp;
    private String _trk_date;
    private String _trk_scan_time;
    
    private String _ecco_typ_cd;
    private String _ecco_comment_cd;
    private String _ml_relation_ships;
    private String _sp_relation_ships;
    
    private String _actual_delivery_name;
    private String _actual_delivery_addr_desc;
    
    private String _employee_nbr;
    private String _track_source_cd;
    
    private String _event_sequence_nbr;    
    private String _parent_trk_item_nbr;
    private String _parent_trk_item_unique_id;
    
    private String _airbill_entry_type;
    
    private String _orig_loc_cd;
    private String _dest_loc_cd;
    
    /**
     * @return the _dest_loc_cd
     */
    public String get_dest_loc_cd() {
        return _dest_loc_cd;
    }
    /**
     * @param _dest_loc_cd the _dest_loc_cd to set
     */
    public void set_dest_loc_cd(String _dest_loc_cd) {
        this._dest_loc_cd = _dest_loc_cd;
    }
    /**
     * @return the _orig_loc_cd
     */
    public String get_orig_loc_cd() {
        return _orig_loc_cd;
    }
    /**
     * @param _orig_loc_cd the _orig_loc_cd to set
     */
    public void set_orig_loc_cd(String _orig_loc_cd) {
        this._orig_loc_cd = _orig_loc_cd;
    }
    /**
     * @return the _airbill_entry_type
     */
    public String get_airbill_entry_type() {
        return _airbill_entry_type;
    }
    /**
     * @param _airbill_entry_type the _airbill_entry_type to set
     */
    public void set_airbill_entry_type(String _airbill_entry_type) {
        this._airbill_entry_type = _airbill_entry_type;
    }
    /**
     * @return the _employee_nbr
     */
    public String get_employee_nbr() {
        return _employee_nbr;
    }
    /**
     * @param _employee_nbr the _employee_nbr to set
     */
    public void set_employee_nbr(String _employee_nbr) {
        this._employee_nbr = _employee_nbr;
    }
    /**
     * @return the _track_source_cd
     */
    public String get_track_source_cd() {
        return _track_source_cd;
    }
    /**
     * @param _track_source_cd the _track_source_cd to set
     */
    public void set_track_source_cd(String _track_source_cd) {
        this._track_source_cd = _track_source_cd;
    }
    /**
     * @return the _actual_delivery_addr_desc
     */
    public String get_actual_delivery_addr_desc() {
        return _actual_delivery_addr_desc;
    }
    /**
     * @param _actual_delivery_addr_desc the _actual_delivery_addr_desc to set
     */
    public void set_actual_delivery_addr_desc(String _actual_delivery_addr_desc) {
        this._actual_delivery_addr_desc = _actual_delivery_addr_desc;
    }
    /**
     * @return the _actual_delivery_name
     */
    public String get_actual_delivery_name() {
        return _actual_delivery_name;
    }
    /**
     * @param _actual_delivery_name the _actual_delivery_name to set
     */
    public void set_actual_delivery_name(String _actual_delivery_name) {
        this._actual_delivery_name = _actual_delivery_name;
    }
    /**
     * @return the _ecco_typ_cd
     */
    public String get_ecco_typ_cd() {
        return _ecco_typ_cd;
    }
    /**
     * @param _ecco_typ_cd the _ecco_typ_cd to set
     */
    public void set_ecco_typ_cd(String _ecco_typ_cd) {
        this._ecco_typ_cd = _ecco_typ_cd;
    }
    /**
     * @return the _admin_loc_cd
     */
    public String get_admin_loc_cd() {
        return _admin_loc_cd;
    }
    /**
     * @param _admin_loc_cd the _admin_loc_cd to set
     */
    public void set_admin_loc_cd(String _admin_loc_cd) {
        this._admin_loc_cd = _admin_loc_cd;
    }
    /**
     * @return the _base_service_cd
     */
    public String get_base_service_cd() {
        return _base_service_cd;
    }
    /**
     * @param _base_service_cd the _base_service_cd to set
     */
    public void set_base_service_cd(String _base_service_cd) {
        this._base_service_cd = _base_service_cd;
    }

    /**
     * @return the _consignee_addl_addr_desc
     */
    public String get_consignee_addl_addr_desc() {
        return _consignee_addl_addr_desc;
    }
    /**
     * @param _consignee_addl_addr_desc the _consignee_addl_addr_desc to set
     */
    public void set_consignee_addl_addr_desc(String _consignee_addl_addr_desc) {
        this._consignee_addl_addr_desc = _consignee_addl_addr_desc;
    }
    /**
     * @return the _consignee_addr_desc
     */
    public String get_consignee_addr_desc() {
        return _consignee_addr_desc;
    }
    /**
     * @param _consignee_addr_desc the _consignee_addr_desc to set
     */
    public void set_consignee_addr_desc(String _consignee_addr_desc) {
        this._consignee_addr_desc = _consignee_addr_desc;
    }
    /**
     * @return the _consignee_city_name
     */
    public String get_consignee_city_name() {
        return _consignee_city_name;
    }
    /**
     * @param _consignee_city_name the _consignee_city_name to set
     */
    public void set_consignee_city_name(String _consignee_city_name) {
        this._consignee_city_name = _consignee_city_name;
    }
    /**
     * @return the _consignee_company_name
     */
    public String get_consignee_company_name() {
        return _consignee_company_name;
    }
    /**
     * @param _consignee_company_name the _consignee_company_name to set
     */
    public void set_consignee_company_name(String _consignee_company_name) {
        this._consignee_company_name = _consignee_company_name;
    }
    /**
     * @return the _consignee_country_cd
     */
    public String get_consignee_country_cd() {
        return _consignee_country_cd;
    }
    /**
     * @param _consignee_country_cd the _consignee_country_cd to set
     */
    public void set_consignee_country_cd(String _consignee_country_cd) {
        this._consignee_country_cd = _consignee_country_cd;
    }
    /**
     * @return the _consignee_phone_nbr
     */
    public String get_consignee_phone_nbr() {
        return _consignee_phone_nbr;
    }
    /**
     * @param _consignee_phone_nbr the _consignee_phone_nbr to set
     */
    public void set_consignee_phone_nbr(String _consignee_phone_nbr) {
        this._consignee_phone_nbr = _consignee_phone_nbr;
    }
    /**
     * @return the _consignee_postal_cd
     */
    public String get_consignee_postal_cd() {
        return _consignee_postal_cd;
    }
    /**
     * @param _consignee_postal_cd the _consignee_postal_cd to set
     */
    public void set_consignee_postal_cd(String _consignee_postal_cd) {
        this._consignee_postal_cd = _consignee_postal_cd;
    }
    /**
     * @return the _consignee_state_province_cd
     */
    public String get_consignee_state_province_cd() {
        return _consignee_state_province_cd;
    }
    /**
     * @param _consignee_state_province_cd the _consignee_state_province_cd to set
     */
    public void set_consignee_state_province_cd(String _consignee_state_province_cd) {
        this._consignee_state_province_cd = _consignee_state_province_cd;
    }
    /**
     * @return the _customs_currency_cd
     */
    public String get_customs_currency_cd() {
        return _customs_currency_cd;
    }
    /**
     * @param _customs_currency_cd the _customs_currency_cd to set
     */
    public void set_customs_currency_cd(String _customs_currency_cd) {
        this._customs_currency_cd = _customs_currency_cd;
    }
    /**
     * @return the _ce_customs_value
     */
    public String get_ce_customs_value() {
        return _ce_customs_value;
    }
    /**
     * @param _ce_customs_value the _ce_customs_value to set
     */
    public void set_ce_customs_value(String _ce_customs_value) {
        this._ce_customs_value = _ce_customs_value;
    }
    /**
     * @return the _ml_customs_value
     */
    public String get_ml_customs_value() {
        return _ml_customs_value;
    }
    /**
     * @param _ml_customs_value the _ml_customs_value to set
     */
    public void set_ml_customs_value(String _ml_customs_value) {
        this._ml_customs_value = _ml_customs_value;
    }
    /**
     * @return the _declared_value_currency_cd
     */
    public String get_declared_value_currency_cd() {
        return _declared_value_currency_cd;
    }
    /**
     * @param _declared_value_currency_cd the _declared_value_currency_cd to set
     */
    public void set_declared_value_currency_cd(String _declared_value_currency_cd) {
        this._declared_value_currency_cd = _declared_value_currency_cd;
    }
    /**
     * @return the _loc_cd
     */
    public String get_loc_cd() {
        return _loc_cd;
    }
    /**
     * @param _loc_cd the _loc_cd to set
     */
    public void set_loc_cd(String _loc_cd) {
        this._loc_cd = _loc_cd;
    }
    /**
     * @return the _oda_company_name
     */
    public String get_oda_company_name() {
        return _oda_company_name;
    }
    /**
     * @param _oda_company_name the _oda_company_name to set
     */
    public void set_oda_company_name(String _oda_company_name) {
        this._oda_company_name = _oda_company_name;
    }
    /**
     * @return the _packaging_type
     */
    public String get_packaging_type() {
        return _packaging_type;
    }
    /**
     * @param _packaging_type the _packaging_type to set
     */
    public void set_packaging_type(String _packaging_type) {
        this._packaging_type = _packaging_type;
    }
    /**
     * @return the _ref_type_cd
     */
    public String get_ref_type_cd() {
        return _ref_type_cd;
    }
    /**
     * @param _ref_type_cd the _ref_type_cd to set
     */
    public void set_ref_type_cd(String _ref_type_cd) {
        this._ref_type_cd = _ref_type_cd;
    }
    /**
     * @return the _return_trk_item_nbr
     */
    public String get_return_trk_item_nbr() {
        return _return_trk_item_nbr;
    }
    /**
     * @param _return_trk_item_nbr the _return_trk_item_nbr to set
     */
    public void set_return_trk_item_nbr(String _return_trk_item_nbr) {
        this._return_trk_item_nbr = _return_trk_item_nbr;
    }
    /**
     * @return the _rise_trk_type_cd
     */
    public String get_rise_trk_type_cd() {
        return _rise_trk_type_cd;
    }
    /**
     * @param _rise_trk_type_cd the _rise_trk_type_cd to set
     */
    public void set_rise_trk_type_cd(String _rise_trk_type_cd) {
        this._rise_trk_type_cd = _rise_trk_type_cd;
    }
    /**
     * @return the _ship_date
     */
    public Date get_ship_date() {
        return _ship_date;
    }
    /**
     * @param _ship_date the _ship_date to set
     */
    public void set_ship_date(Date _ship_date) {
        this._ship_date = _ship_date;
    }
    /**
     * @return the _shipment_pkg_count
     */
    public String get_shipment_pkg_count() {
        return _shipment_pkg_count;
    }
    /**
     * @param _shipment_pkg_count the _shipment_pkg_count to set
     */
    public void set_shipment_pkg_count(String _shipment_pkg_count) {
        this._shipment_pkg_count = _shipment_pkg_count;
    }
    /**
     * @return the _shipper_addl_addr_desc
     */
    public String get_shipper_addl_addr_desc() {
        return _shipper_addl_addr_desc;
    }
    /**
     * @param _shipper_addl_addr_desc the _shipper_addl_addr_desc to set
     */
    public void set_shipper_addl_addr_desc(String _shipper_addl_addr_desc) {
        this._shipper_addl_addr_desc = _shipper_addl_addr_desc;
    }
    /**
     * @return the _shipper_addr_desc
     */
    public String get_shipper_addr_desc() {
        return _shipper_addr_desc;
    }
    /**
     * @param _shipper_addr_desc the _shipper_addr_desc to set
     */
    public void set_shipper_addr_desc(String _shipper_addr_desc) {
        this._shipper_addr_desc = _shipper_addr_desc;
    }
    /**
     * @return the _shipper_city_name
     */
    public String get_shipper_city_name() {
        return _shipper_city_name;
    }
    /**
     * @param _shipper_city_name the _shipper_city_name to set
     */
    public void set_shipper_city_name(String _shipper_city_name) {
        this._shipper_city_name = _shipper_city_name;
    }
    /**
     * @return the _shipper_company_name
     */
    public String get_shipper_company_name() {
        return _shipper_company_name;
    }
    /**
     * @param _shipper_company_name the _shipper_company_name to set
     */
    public void set_shipper_company_name(String _shipper_company_name) {
        this._shipper_company_name = _shipper_company_name;
    }
    /**
     * @return the _shipper_country_cd
     */
    public String get_shipper_country_cd() {
        return _shipper_country_cd;
    }
    /**
     * @param _shipper_country_cd the _shipper_country_cd to set
     */
    public void set_shipper_country_cd(String _shipper_country_cd) {
        this._shipper_country_cd = _shipper_country_cd;
    }
    /**
     * @return the _shipper_phone_nbr
     */
    public String get_shipper_phone_nbr() {
        return _shipper_phone_nbr;
    }
    /**
     * @param _shipper_phone_nbr the _shipper_phone_nbr to set
     */
    public void set_shipper_phone_nbr(String _shipper_phone_nbr) {
        this._shipper_phone_nbr = _shipper_phone_nbr;
    }
    /**
     * @return the _shipper_postal_cd
     */
    public String get_shipper_postal_cd() {
        return _shipper_postal_cd;
    }
    /**
     * @param _shipper_postal_cd the _shipper_postal_cd to set
     */
    public void set_shipper_postal_cd(String _shipper_postal_cd) {
        this._shipper_postal_cd = _shipper_postal_cd;
    }

    /**
     * @return the _shipper_ref_notes
     */
    public String get_shipper_ref_notes() {
        return _shipper_ref_notes;
    }
    /**
     * @param _shipper_ref_notes the _shipper_ref_notes to set
     */
    public void set_shipper_ref_notes(String _shipper_ref_notes) {
        this._shipper_ref_notes = _shipper_ref_notes;
    }
    /**
     * @return the _shipper_state_province_cd
     */
    public String get_shipper_state_province_cd() {
        return _shipper_state_province_cd;
    }
    /**
     * @param _shipper_state_province_cd the _shipper_state_province_cd to set
     */
    public void set_shipper_state_province_cd(String _shipper_state_province_cd) {
        this._shipper_state_province_cd = _shipper_state_province_cd;
    }

    /**
     * @return the _special_handling
     */
    public String get_special_handling() {
        return _special_handling;
    }
    /**
     * @param _special_handling the _special_handling to set
     */
    public void set_special_handling(String _special_handling) {
        this._special_handling = _special_handling;
    }
    /**
     * @return the _trk_exception_cd
     */
    public String get_trk_exception_cd() {
        return _trk_exception_cd;
    }
    /**
     * @param _trk_exception_cd the _trk_exception_cd to set
     */
    public void set_trk_exception_cd(String _trk_exception_cd) {
        this._trk_exception_cd = _trk_exception_cd;
    }
    /**
     * @return the _trk_item_form_cd
     */
    public String get_trk_item_form_cd() {
        return _trk_item_form_cd;
    }
    /**
     * @param _trk_item_form_cd the _trk_item_form_cd to set
     */
    public void set_trk_item_form_cd(String _trk_item_form_cd) {
        this._trk_item_form_cd = _trk_item_form_cd;
    }
    /**
     * @return the _trk_item_nbr
     */
    public String get_trk_item_nbr() {
        return _trk_item_nbr;
    }
    /**
     * @param _trk_item_nbr the _trk_item_nbr to set
     */
    public void set_trk_item_nbr(String _trk_item_nbr) {
        this._trk_item_nbr = _trk_item_nbr;
    }
    /**
     * @return the _trk_item_unique_id
     */
    public String get_trk_item_unique_id() {
        return _trk_item_unique_id;
    }
    /**
     * @param _trk_item_unique_id the _trk_item_unique_id to set
     */
    public void set_trk_item_unique_id(String _trk_item_unique_id) {
        this._trk_item_unique_id = _trk_item_unique_id;
    }
    /**
     * @return the _trk_type_cd
     */
    public String get_trk_type_cd() {
        return _trk_type_cd;
    }
    /**
     * @param _trk_type_cd the _trk_type_cd to set
     */
    public void set_trk_type_cd(String _trk_type_cd) {
        this._trk_type_cd = _trk_type_cd;
    }
    /**
     * @return the _sp_pkg_weight
     */
    public String get_sp_pkg_weight() {
        return _sp_pkg_weight;
    }
    /**
     * @param _sp_pkg_weight the _sp_pkg_weight to set
     */
    public void set_sp_pkg_weight(String _sp_pkg_weight) {
        this._sp_pkg_weight = _sp_pkg_weight;
    }
    /**
     * @return the _sp_pkg_weight_uom
     */
    public String get_sp_pkg_weight_uom() {
        return _sp_pkg_weight_uom;
    }
    /**
     * @param _sp_pkg_weight_uom the _sp_pkg_weight_uom to set
     */
    public void set_sp_pkg_weight_uom(String _sp_pkg_weight_uom) {
        this._sp_pkg_weight_uom = _sp_pkg_weight_uom;
    }
    /**
     * @return the _sp_shpmt_weight
     */
    public String get_sp_shpmt_weight() {
        return _sp_shpmt_weight;
    }
    /**
     * @param _sp_shpmt_weight the _sp_shpmt_weight to set
     */
    public void set_sp_shpmt_weight(String _sp_shpmt_weight) {
        this._sp_shpmt_weight = _sp_shpmt_weight;
    }
    /**
     * @return the _sp_shpmt_weight_uom
     */
    public String get_sp_shpmt_weight_uom() {
        return _sp_shpmt_weight_uom;
    }
    /**
     * @param _sp_shpmt_weight_uom the _sp_shpmt_weight_uom to set
     */
    public void set_sp_shpmt_weight_uom(String _sp_shpmt_weight_uom) {
        this._sp_shpmt_weight_uom = _sp_shpmt_weight_uom;
    }
    /**
     * @return the _acceptance_dt_tm
     */
    public String get_acceptance_dt_tm() {
        return _acceptance_dt_tm;
    }
    /**
     * @param _acceptance_dt_tm the _acceptance_dt_tm to set
     */
    public void set_acceptance_dt_tm(String _acceptance_dt_tm) {
        this._acceptance_dt_tm = _acceptance_dt_tm;
    }
    /**
     * @return the _delivery_dt_tm
     */
    public String get_delivery_dt_tm() {
        return _delivery_dt_tm;
    }
    /**
     * @param _delivery_dt_tm the _delivery_dt_tm to set
     */
    public void set_delivery_dt_tm(String _delivery_dt_tm) {
        this._delivery_dt_tm = _delivery_dt_tm;
    }
    /**
     * @return the _event_creation_tmstp
     */
    public String get_event_creation_tmstp() {
        return _event_creation_tmstp;
    }
    /**
     * @param _event_creation_tmstp the _event_creation_tmstp to set
     */
    public void set_event_creation_tmstp(String _event_creation_tmstp) {
        this._event_creation_tmstp = _event_creation_tmstp;
    }
    /**
     * @return the _trk_date
     */
    public String get_trk_date() {
        return _trk_date;
    }
    /**
     * @param _trk_date the _trk_date to set
     */
    public void set_trk_date(String _trk_date) {
        this._trk_date = _trk_date;
    }
    /**
     * @return the _trk_scan_time
     */
    public String get_trk_scan_time() {
        return _trk_scan_time;
    }
    /**
     * @param _trk_scan_time the _trk_scan_time to set
     */
    public void set_trk_scan_time(String _trk_scan_time) {
        this._trk_scan_time = _trk_scan_time;
    }
    /**
     * @return the _shpr_acct_nbr
     */
    public String get_shpr_acct_nbr() {
        return _shpr_acct_nbr;
    }
    /**
     * @param _shpr_acct_nbr the _shpr_acct_nbr to set
     */
    public void set_shpr_acct_nbr(String _shpr_acct_nbr) {
        this._shpr_acct_nbr = _shpr_acct_nbr;
    }
    /**
     * @return the _ecco_comment_cd
     */
    public String get_ecco_comment_cd() {
        return _ecco_comment_cd;
    }
    /**
     * @param _ecco_comment_cd the _ecco_comment_cd to set
     */
    public void set_ecco_comment_cd(String _ecco_comment_cd) {
        this._ecco_comment_cd = _ecco_comment_cd;
    }
    /**
     * @return the _ml_relation_ships
     */
    public String get_ml_relation_ships() {
        return _ml_relation_ships;
    }
    /**
     * @param _ml_relation_ships the _ml_relation_ships to set
     */
    public void set_ml_relation_ships(String _ml_relation_ships) {
        this._ml_relation_ships = _ml_relation_ships;
    }
    /**
     * @return the _sp_relation_ships
     */
    public String get_sp_relation_ships() {
        return _sp_relation_ships;
    }
    /**
     * @param _sp_relation_ships the _sp_relation_ships to set
     */
    public void set_sp_relation_ships(String _sp_relation_ships) {
        this._sp_relation_ships = _sp_relation_ships;
    }
    /**
     * @return the _event_sequence_nbr
     */
    public String get_event_sequence_nbr() {
        return _event_sequence_nbr;
    }
    /**
     * @param _event_sequence_nbr the _event_sequence_nbr to set
     */
    public void set_event_sequence_nbr(String _event_sequence_nbr) {
        this._event_sequence_nbr = _event_sequence_nbr;
    }
    /**
     * @return the _parent_trk_item_nbr
     */
    public String get_parent_trk_item_nbr() {
        return _parent_trk_item_nbr;
    }
    /**
     * @param _parent_trk_item_nbr the _parent_trk_item_nbr to set
     */
    public void set_parent_trk_item_nbr(String _parent_trk_item_nbr) {
        this._parent_trk_item_nbr = _parent_trk_item_nbr;
    }
    /**
     * @return the _parent_trk_item_unique_id
     */
    public String get_parent_trk_item_unique_id() {
        return _parent_trk_item_unique_id;
    }
    /**
     * @param _parent_trk_item_unique_id the _parent_trk_item_unique_id to set
     */
    public void set_parent_trk_item_unique_id(String _parent_trk_item_unique_id) {
        this._parent_trk_item_unique_id = _parent_trk_item_unique_id;
    }

}
