package com.fedex.rise.bo.status;

import com.fedex.rise.vo.EventVO;

public abstract class StatusCriteria {
    
    public abstract boolean meetsCriteria(EventVO anEventVO);

}
