package com.fedex.rise.bo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fedex.rise.vo.ReferenceNoteVO;

public class MergeReferenceNotes {

    /**
     * Merges the reference notes into the target and returns the reference
     * notes that were not in the original target.
     * @param aSource reference notes present in event
     * @param aTarget refernce notes in database
     * @return only the new, not in database notes
     */
    public List merge(List aSource, List aTarget) {
        ArrayList hs = new ArrayList();
        Iterator iter = aSource.iterator();
        while (iter.hasNext()) {
            ReferenceNoteVO referenceNoteVO = (ReferenceNoteVO)iter.next();
            if (!aTarget.contains(referenceNoteVO)) {
                aTarget.add(referenceNoteVO);
                hs.add(referenceNoteVO);
            }
        }
        return hs;
    }
}
