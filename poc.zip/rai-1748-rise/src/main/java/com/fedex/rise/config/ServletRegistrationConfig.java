package com.fedex.rise.config;

import javax.faces.webapp.FacesServlet;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fedex.rise.constant.AppConstant;

/**
 * This configuration class is used to create faces SERVLET instance with specified URL mapping
 * 
 * @author saravanan g
 *
 */
@Configuration
public class ServletRegistrationConfig {

	@Bean
	public ServletRegistrationBean<FacesServlet> servletRegistrationBean() {
		
		FacesServlet servlet = new FacesServlet();
		return new ServletRegistrationBean<FacesServlet>(servlet, AppConstant.SERVLET_MAPPING_JSF);
	}
}
