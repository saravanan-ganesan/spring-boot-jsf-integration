package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;

public class AcctLaneServiceMonitoringAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(AcctLaneServiceMonitoringAccessor.class);
    
    public AcctLaneServiceMonitoringAccessor(Connection con) {
        super(con);
    }
    //Start WR#:179441 Changes        
    private final String selectAccountLaneMonitoringSQL = "select " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "LANE_NBR, " +
        "SVC_TYPE_CD, " +
        "EMP_NBR " +
         "from Acct_Lane_Service_Monitoring where GROUP_NBR = ? " +
         "and ACCT_NBR = ? and LANE_NBR = ? and SVC_TYPE_CD = ?";          
    
    
    private final String selectGroupMonitoringSQL = "select " +
             "distinct(EMP_NBR) " +
             "from Acct_Lane_Service_Monitoring";
    
    private final String selectGroupLaneMonitoringSQL = "select " +
            "distinct(EMP_NBR) " +
            "from Acct_Lane_Service_Monitoring where group_nbr= ? and lane_nbr= ?";
    
   //End WR#:179441 Changes            
            
    public List getAcctLaneServiceMonitoring(int groupNbr, String accountNbr, 
            int laneNbr, String serviceTypeCd) throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectAccountLaneMonitoringSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt(    1, groupNbr);
            pstmt.setString( 2, accountNbr);
            pstmt.setInt(    3, laneNbr);
            pstmt.setString( 4, serviceTypeCd);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = new AcctLaneServiceMonitoringVO();
                        
                    acctLaneServiceMonitoringVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
                    acctLaneServiceMonitoringVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    acctLaneServiceMonitoringVO.set_lane_nbr(rs.getInt("LANE_NBR"));             
                    acctLaneServiceMonitoringVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));             
                    acctLaneServiceMonitoringVO.set_emp_nbr(rs.getString("EMP_NBR"));
                                        
                    al.add(acctLaneServiceMonitoringVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
	//Start WR#:179441 Changes
    public List searchByAll() throws SQLException {
    	 ArrayList al = new ArrayList(); 
         
         try {
             setSqlSignature( selectGroupMonitoringSQL, false, logger.isDebugEnabled() );
            
             
             if (logger.isDebugEnabled()) {
                 logger.debug(pstmt.toString());
             }
             execute();
             
             if ( hasResults ) {
            	 while(rs.next()) {
                 AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = new AcctLaneServiceMonitoringVO();
                 acctLaneServiceMonitoringVO.set_emp_nbr(rs.getString("EMP_NBR"));
                 al.add(acctLaneServiceMonitoringVO);
             }
         } else {
             return null;
         }
     } catch (SQLException sqle) {
         logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                 + ": ErrorCode: " + sqle.getErrorCode()); 
         throw sqle;
     } finally {
         try {
             cleanResultSet();
         } catch (SQLException sqle2) {
             logger.warn(sqle2.getMessage(), sqle2);
         }
     }
     return al;
 }
    
    public List searchByGroupLaneNbr(int groupNbr,int laneNbr) throws SQLException {
   	 ArrayList al = new ArrayList(); 
        
        try {
            setSqlSignature( selectGroupLaneMonitoringSQL, false, logger.isDebugEnabled() );
            pstmt.setInt(1, groupNbr);
            pstmt.setInt(2, laneNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            execute();
            
            if ( hasResults ) {
           	 while(rs.next()) {
                AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = new AcctLaneServiceMonitoringVO();
                acctLaneServiceMonitoringVO.set_emp_nbr(rs.getString("EMP_NBR"));
                al.add(acctLaneServiceMonitoringVO);
            }
        } else {
            return null;
        }
    } catch (SQLException sqle) {
        logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                + ": ErrorCode: " + sqle.getErrorCode()); 
        throw sqle;
    } finally {
        try {
            cleanResultSet();
        } catch (SQLException sqle2) {
            logger.warn(sqle2.getMessage(), sqle2);
        }
    }
    return al;
}//End WR#:179441 Changes
}
