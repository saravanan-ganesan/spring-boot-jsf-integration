package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.LaneVO;

public class LaneDAO extends DatabaseDAO {

    /** Logger */
    private static Logger logger = LogManager.getLogger(LaneDAO.class);
        
    public void addLane(LaneVO aLaneVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LanePersister persister = new LanePersister(connection);
            persister.addLane(aLaneVO);
        } finally {
            closeConnection(connection);
        }
    }
        
        
    public void deleteLane(int anLaneNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LaneDeleter deleter = new LaneDeleter(connection);
            deleter.deleteLane(anLaneNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    public LaneVO getLane(int laneNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        LaneVO laneVO = null;

        try {
            connection = initializeConnection();
            LaneAccessor laneAccessor 
            	= new LaneAccessor(connection);
            laneVO = laneAccessor.getLane(laneNbr);
        } finally {
            closeConnection(connection);
        }
        return laneVO;
    }
    
    public List getLaneTable() throws SQLException, ServiceLocatorException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            LaneAccessor laneAccessor 
            	= new LaneAccessor(connection);
            list = laneAccessor.getLaneTable();
        } finally {
            closeConnection(connection);
        }
        return list;
    }
}
