package com.fedex.rise.timer;

/**
 * Application lifecycle listener events provide handles on which developers can 
 * control behavior during deployment, undeployment, and redeployment.  This 
 * class shall be used to intantiate and cleanUp the TimerScheduler which is 
 * used to publish NOIs and Performance calculation.
 * 
 * @author be379961
 *
 */
public class TimerListener { //extends ApplicationLifecycleListener {
//	private static Logger logger = LogManager.getLogger(TimerListener.class);
//	
//	NOITimerScheduler noiTimerScheduler = null;
//	PerformanceTimerScheduler performanceTimerScheduler = null;
//	DBCleanUpScheduler dBCleanUpScheduler = null;
//	MonitorReportTimerScheduler monitorReportTimerScheduler = null;
//	
//	/**
//	 * The preStart event is the beginning of the prepare phase, or the start of 
//	 * the application deployment process.
//	 */
//	public void preStart(ApplicationLifecycleEvent evt) {     
//		   
//	} 
//	
//	/**
//	 * The postStart event is the end of the activate phase, or the end of the 
//	 * application deployment process. The application is deployed. Instantiate
//	 * the TimerScheduler class.
//	 */
//	public void postStart(ApplicationLifecycleEvent evt)
//	  {
//		logger.info("TimerListener:postStart Event");
//
//		/**
//		 * /Start the Scheduler of NOI.
//		 */
//		noiTimerScheduler = new NOITimerScheduler();
//		
//		/**
//		 * Start the Scheduler of the Performance.
//		 */
//		performanceTimerScheduler = new PerformanceTimerScheduler();
//		
//		/**
//		 * Start the Scheduler of DB Clean up.
//		 */
//		dBCleanUpScheduler = new DBCleanUpScheduler();
//		
//		/**
//		 * Start the Scheduler of the Monitor Report.
//		 */
//		monitorReportTimerScheduler = new MonitorReportTimerScheduler();
//	  }
//
//	/**
//	 * The preStop event is the beginning of the deactivate phase, or the start 
//	 * of the application removal or undeployment process. cleanUp the 
//	 * TimerScheduler instance.
//	 */
//	public void preStop(ApplicationLifecycleEvent evt)
//	  {
//		logger.info("TimerListener:preStop Event");
//
//	    /**
//	     * Stop the NOI Scheduler.
//	     */
//	    if (noiTimerScheduler != null) {
//	    	noiTimerScheduler.cleanUp();
//	    }
//	    /**
//	     * Stop the Performance Scheduler.
//	     */
//	    if (performanceTimerScheduler != null) {
//	    	performanceTimerScheduler.cleanUp();
//	    }
//	    /**
//	     * Stop the DB clean up Scheduler.
//	     */
//	    if (dBCleanUpScheduler != null){
//	    	dBCleanUpScheduler.cleanUp();
//	    }
//	    /**
//	     * Stop the Monitor Report Scheduler.
//	     */
//	    if (monitorReportTimerScheduler != null){
//	    	monitorReportTimerScheduler.cleanUp();
//	    }
//	  }
//	
//	/**
//	 * The postStop event is the end of the remove phase, or the end of the 
//	 * application removal or undeployment process. 
//	 */
//	public void postStop(ApplicationLifecycleEvent evt) {     
//		   
//	} 
//
}
