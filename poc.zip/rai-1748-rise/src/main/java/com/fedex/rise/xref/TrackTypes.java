package com.fedex.rise.xref;

import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * This class represents the valid track types that are valid
 * for the RISE application.  Track types are mnemonic strings
 * that can be numeric or alpha.  This class stores numeric
 * track types in one HashMap and alpha's in an other for
 * performance and not having to store something like 02 and 2.
 * Along with the track type is a FedEx mnemonic for the type
 * of scan such as POD for a track type of 20.  A short description
 * is also included for those of us who can't remember what 
 * a track type is or what the string mnemonic means.
 * 
 * HashMap is used for best performance
 *
 */
public class TrackTypes {

    // Contains all valid RISE alpha track types
    public final static HashMap AlphaTrackTypes = new HashMap();

    // Contains all valid RISE numeric track types
    public final static HashMap NumericTrackTypes = new HashMap();

    // Contains the singleton
    private static TrackTypes instance = null;

    static {
        NumericTrackTypes.put(new Integer(1), new TrackDesc("SOP",
                "Station Outbound Package"));
        NumericTrackTypes.put(new Integer(2), new TrackDesc("SIP",
                "Station Inbound Package"));
        NumericTrackTypes.put(new Integer(6), new TrackDesc("PKGC",
                "Package Consolidator"));
        NumericTrackTypes.put(new Integer(7), new TrackDesc("STAT",
                "Status Scan"));
        NumericTrackTypes.put(new Integer(8), new TrackDesc("PU",
                "PickUp Package"));
        NumericTrackTypes.put(new Integer(9), new TrackDesc("HLD",
                "Held Package"));
        NumericTrackTypes.put(new Integer(10), new TrackDesc("HOP",
                "Hub Outbound Package"));
        NumericTrackTypes.put(new Integer(11), new TrackDesc("VAN",
                "Van Scan"));
        NumericTrackTypes.put(new Integer(12), new TrackDesc("CONS",
                "Consolidation Scan"));        
        NumericTrackTypes.put(new Integer(13), new TrackDesc("HIP",
                "Hub Inbound Package"));
        NumericTrackTypes.put(new Integer(17), new TrackDesc("BAT",
                "Batch Header Association"));
        NumericTrackTypes.put(new Integer(18), new TrackDesc("LBL",
                "PUP Astra Label"));
        NumericTrackTypes.put(new Integer(20), new TrackDesc("POD",
                "Proof of Delivery"));
        NumericTrackTypes.put(new Integer(22), new TrackDesc("ROP",
                "Ramp Outbound Package"));
        NumericTrackTypes.put(new Integer(24), new TrackDesc("RIP",
                "Ramp Inbound Package Scan "));
        NumericTrackTypes.put(new Integer(25), new TrackDesc("REV",
                "Revenue Scan"));
        NumericTrackTypes.put(new Integer(29), new TrackDesc("PUX",
                "Pickup Exception"));
        NumericTrackTypes.put(new Integer(30), new TrackDesc("DEX",
                "Delivery Exception")); // or RDLVR
        NumericTrackTypes.put(new Integer(31), new TrackDesc("DDEX",
                "Delivered Delivery Exception"));
        NumericTrackTypes.put(new Integer(32), new TrackDesc("REX",
                "Revenue Exception"));
        NumericTrackTypes.put(new Integer(41), new TrackDesc("HAL",
                "Hold at Location"));
        NumericTrackTypes.put(new Integer(42), new TrackDesc("ODA",
                "Out of Delivery Area"));
        NumericTrackTypes.put(new Integer(43), new TrackDesc("NSLM",
                "Net Service level Missort"));
        NumericTrackTypes.put(new Integer(46), new TrackDesc("HEX",
                "Hub Exception"));
        NumericTrackTypes.put(new Integer(47), new TrackDesc("MIS",
                "Missort Exception(Old)"));
        NumericTrackTypes.put(new Integer(48), new TrackDesc("MIS",
                "Missort Exception(New)"));
        NumericTrackTypes.put(new Integer(49), new TrackDesc("Expedited",
                "Expedited"));
        NumericTrackTypes.put(new Integer(50), new TrackDesc("PEXP",
                "Expedited Pickup"));
        NumericTrackTypes.put(new Integer(53), new TrackDesc("TDE",
                "Transit Destination Exception"));
        NumericTrackTypes.put(new Integer(60), new TrackDesc("MDD",
                "INTL Manifest Data Distribution"));
        NumericTrackTypes.put(new Integer(70), new TrackDesc("MDE1",
                "INTL Manifest Data Entry 1"));
        NumericTrackTypes.put(new Integer(71), new TrackDesc("MDE1",
                "INTL Manifest Data Entry 1(Delete)"));
        NumericTrackTypes.put(new Integer(72), new TrackDesc("MDE2",
                "INTL Manifest Data Entry 2(Original)"));
        NumericTrackTypes.put(new Integer(73), new TrackDesc("MDE2",
                "INTL Manifest Data Entry 2"));
        NumericTrackTypes.put(new Integer(74), new TrackDesc("MDE3",
                "INTL Manifest Data Entry 3(Update)"));
        NumericTrackTypes.put(new Integer(75), new TrackDesc("AG67",
                "INTL SIPS - Released to ODA Agent"));
        NumericTrackTypes.put(new Integer(76), new TrackDesc("CR66",
                "INTL SIPS - Release to Customs"));
        NumericTrackTypes.put(new Integer(79), new TrackDesc("ECCO",
                "ECCO II Upload Information"));
        NumericTrackTypes.put(new Integer(80), new TrackDesc("CDE",
                "Country Data Entry"));
        NumericTrackTypes.put(new Integer(83), new TrackDesc("APS",
                "Associated Package Scan"));
        NumericTrackTypes.put(new Integer(90), new TrackDesc("COMM",
                "Comment")); 
        NumericTrackTypes.put(new Integer(92), new TrackDesc("CER",
                "Customer Exception Request"));        

        AlphaTrackTypes.put("CD", new TrackDesc("CD", "Commit Event"));
        AlphaTrackTypes.put("CE", new TrackDesc("CE", "Contract Event"));
        AlphaTrackTypes.put("DC", new TrackDesc("DC", "Document Event"));
        AlphaTrackTypes.put("RE", new TrackDesc("RE", "Relationship Event"));
        AlphaTrackTypes.put("SD", new TrackDesc("SD", "None Event"));
        AlphaTrackTypes.put("2D", new TrackDesc("2D", "Unknown Event"));
        AlphaTrackTypes.put("NR", new TrackDesc("NR", "NOI Event"));
        AlphaTrackTypes.put("ZY", new TrackDesc("ZY", "NED Event"));
        AlphaTrackTypes.put("AR", new TrackDesc("AR", "AR Event"));
        AlphaTrackTypes.put("DN", new TrackDesc("DN", "DN Event"));
        AlphaTrackTypes.put("IM", new TrackDesc("IM", "IM Event"));
        AlphaTrackTypes.put("CC", new TrackDesc("CC", "CC Event"));
        AlphaTrackTypes.put("RU", new TrackDesc("RU", "RU Event"));
        AlphaTrackTypes.put("RR", new TrackDesc("RR", "RR Event"));
        AlphaTrackTypes.put("AA", new TrackDesc("AA", "POF Point Of Failure"));
        // Created when event arrives without a track type code
        AlphaTrackTypes.put("UN", new TrackDesc("UN", "Unknown Event"));
    }

    /**
     * Private constructor, so this cannot be constructed, its use
     * is in a static context for the most part.
     */
    private TrackTypes() {}

    /**
     * Provides access to a single instance of the class
     * @return a singleton
     */
    public static TrackTypes getInstance() {
        if(instance == null) {
           instance = new TrackTypes();
        }
        return instance;
     }    
    
    /**
     * This method is used to validate a track type as a track
     * type accepted by the RISE application.  Numeric track 
     * types are kept in a different HashMap then alphas.
     * 
     * @param aTrackType a track type
     * @return a TrackDesc or null if not valid
     */
    public static TrackDesc isValidTrackType(String aTrackType) {
        TrackDesc trackDesc = null;
        if (Character.isDigit(aTrackType.charAt(0)) &&
            Character.isDigit(aTrackType.charAt(1))) {
            Integer i = new Integer(aTrackType);
            trackDesc = (TrackDesc) NumericTrackTypes.get(i);
        } else {
            trackDesc = (TrackDesc) AlphaTrackTypes.get(aTrackType);
        }
        return trackDesc;
    }
    
    /**
     * Used to get the TrackDesc of a track type
     * @param aTrackType a track type
     * @return a TrackDesc or null if not valid
     */
    public static TrackDesc getTrackTypeDesc(String aTrackType) {
        return isValidTrackType(aTrackType);
    }

    /**
     * Don't know how much value, but create a string of sorted track types
     * @return a String of track types
     */
    public String toString() {
       StringBuffer sb = new StringBuffer();

       HashMap [] trackTypes = { NumericTrackTypes, AlphaTrackTypes };
       
       for(int i = 0; i < trackTypes.length; i++) {
           TreeMap treeMap = new TreeMap(trackTypes[i]);
           Iterator iterator = treeMap.keySet().iterator();
           
           while (iterator.hasNext()) {
               Object key = iterator.next();
               TrackDesc trackDesc = (TrackDesc)trackTypes[i].get(key);
               sb.append(key);
               sb.append(":");
               sb.append(trackDesc);
               sb.append("\n");
           }
       }
       return sb.toString();
    }
    
    /**
     * Test stub
     */
//    public static void main(String[] args) {
//        System.out.println(TrackTypes.isValidTrackType("02"));
//        System.out.println(TrackTypes.getTrackTypeDesc("02"));
//        System.out.println(TrackTypes.getTrackTypeDesc("xxx"));
//        System.out.println(TrackTypes.isValidTrackType("CE"));
//        System.out.println(TrackTypes.getTrackTypeDesc("CE"));
//        System.out.println(TrackTypes.getInstance());
//    }
}    

