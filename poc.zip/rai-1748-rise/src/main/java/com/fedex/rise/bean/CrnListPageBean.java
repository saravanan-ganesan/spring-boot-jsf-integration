/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormatSymbols;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIData;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.util.Pageable;
import com.fedex.rise.util.PagedList;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.AssociatedShipmentVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * CRN Summary List Backing bean
 */
public class CrnListPageBean extends SortableList implements Serializable, Pageable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(CrnListPageBean.class);
    private static final int PAGE_SIZE = 50;
    
    /** delegate to get shipment data */
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
    
    /** list of shipments (CRNBean) */
    private transient List _shipments = null;
    private transient DataModel _dataModel = null;
    
    private PerformanceBean _performanceBean = null;
    
    private String _performanceDesc = null;
    private String _performanceSelect = null;
    
    /** UIData component binding to MAWB List table.  Here so we can reset to page 1 after tree node selection */
    private transient UIData _crnListUIData;
    
    /**
     * Constructor
     */
    public CrnListPageBean() {
        super("trkng_item_nbr"); // default sort column
        // Get performance bean data.
        _performanceBean = getPerformanceBean();
        
        String selectedMonth = getSelectedMonth();
        int selectedMonthInt = Integer.parseInt(selectedMonth);
        String selectedMonthName = null;
        
        if (selectedMonthInt >= 0 && selectedMonthInt <= 11 ) {
	    	DateFormatSymbols dfs = new DateFormatSymbols();
	    	String[] months = dfs.getMonths();
	    	selectedMonthName = months[selectedMonthInt];
	    }
        _performanceSelect = new String(
        		" > Month Selected: " + selectedMonthName);
         //WR#:179441 Changes			
        _performanceDesc = new String(
        		" > " + getPerformanceBean().getGroupName() +
        		" | Acct # " + getPerformanceBean().getSelectedAcctNbr() +
        		" | " + getPerformanceBean().getSelectedPerformanceType() + 
        		" | Origin: " + getPerformanceBean().getOrigCntryCd() +
        		" | Dest: " + getPerformanceBean().getDestCntryCd() +
        		" | Monitor: " + getPerformanceBean().getMonitorName());
        
        if (_crnListUIData != null) {
            _crnListUIData.setFirst(0);  // set MAWB List to page 1 
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        } 
    }

    
    // ==========================================================================
    // Getters
    // ==========================================================================
    /** set MAWBList UI data */
    public void setUIData(UIData uiData) {
    	_crnListUIData = uiData;
    }

    /** get MAWBList UI data */
    public UIData getUIData() {
        return _crnListUIData;
    }
    
    /**
     * Get the _performanceDesc.
     * @return the _performanceDesc
     */
    public String getPerformanceDesc(){
    	return _performanceDesc;
    }
    /**
     * @param performanceDesc the _performanceDesc to set
     */
    public String getPerformanceSelect(){
    	return _performanceSelect;
    }
    
    /**
     * Get the CRN data model list
     * @return DataModel
     */
    public DataModel getData() {
        if (_shipments == null) {
            // shipments are cached here, and since we are request scope, and since getData() can be 
            // called multiple times, we only get from DB once.  And since we are request scope it is 
            // gotten fresh each request.
            _shipments = new PagedList(this, PAGE_SIZE);
        }      
        sort(getSort(), isAscending());
        
        _dataModel = new com.fedex.rise.util.ListDataModel(_shipments);
        return _dataModel;
    }

    /**
     * setData only called to update data if 'preservedatamodel=true' in dataTable on jsp
     * @param dataModel
     */
    public void setData(DataModel dataModel) {
        System.out.println("preserved datamodel updated");
        _dataModel = dataModel;
        
        // don't recreate shipment, because after saving state we
        // want to re-populate the shipment list.
        //_shipments = (List)_dataModel.getWrappedData();
    }

    /**
     * Get the specified page from the backend/database for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getPage(int, int)
     */
    public List getPage(int page, int pageSize) {
        int startIndex = (page-1) * pageSize;
        int endIndex = (page * pageSize);
          
    	List shipments = null;
        if (_performanceBean != null) {
           // node selected so get data for this account, lane, service, etc.
           
           // list of shipments, items in list are CRNBean
           //WR#:179441 Changes
        	shipments = shipmentDelegate.getCRNShipments(
        		   _performanceBean.getSelectedAcctNbr(), 
        		   _performanceBean.getFromDate(), 
        		   _performanceBean.getToDate(),
        		   _performanceBean.getLaneOrgDest(),
           		   Integer.parseInt(_performanceBean.getSelectedMonth()),
           		   _performanceBean.getSelectedPerformanceType(),
           		   startIndex, endIndex, getSort(), isAscending());
        }
        return shipments;
    }
    
    /**
     * Get the size of the list of tracking numbers for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getSize()
     */
    public int getSize() {
        int size = 0;
        
        if (_performanceBean != null) {
            // node selected so get data for this account, lane, service, etc.
            
            // list of shipments, items in list are CRNBean
            //WR#:179441 Changes
         	size = shipmentDelegate.getShipmentsCount(
         		   _performanceBean.getSelectedAcctNbr(), 
         		   _performanceBean.getFromDate(), 
         		   _performanceBean.getToDate(),
         		   _performanceBean.getLaneOrgDest(),
            		   Integer.parseInt(_performanceBean.getSelectedMonth()),
            		   _performanceBean.getSelectedPerformanceType());
         }
        
        return size;
    }
    
    /**
     * 
     * @return count of CRNs
     */
    public int getCount() {
        return _shipments.size();    
    }
    
    // ==========================================================================
    // Navigation methods
    // ==========================================================================

    /**
     * Navigation to get the CRN details
     * @return
     */
    public String getCRNDetail() {
    	MawbBean selectedMawbBean = null; 
        FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
    
        String trackingNbr = (String)requestParams.get("trkng_item_nbr");
        String trackingUniqNbr = (String)requestParams.get("trkng_item_uniq_nbr");
        CrnBean  _selectedCrnBean =  shipmentDelegate.getCrn(trackingNbr, trackingUniqNbr);
        
        if (trackingNbr != null && trackingUniqNbr != null) {
        	
        	if (_selectedCrnBean.getAssociatedShipments() != null){
        		List associatedShipmentsList = _selectedCrnBean.getAssociatedShipments();
        		Iterator iter = associatedShipmentsList.iterator();
                while(iter.hasNext()) {
                    AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                    if (assocShipmentVO.get_assoc_track_type_cd() == 'P'){
                    	if (assocShipmentVO.get_assoc_trkng_item_nbr() != null
                    			&& assocShipmentVO.get_assoc_trkng_item_uniq_nbr() != null){
                    		selectedMawbBean = shipmentDelegate.getMAWB(
                    				assocShipmentVO.get_assoc_trkng_item_nbr(), 
                    				assocShipmentVO.get_assoc_trkng_item_uniq_nbr());
                    		
                    	}
                    	
                    }
                }
        		
        	}
        	
            // tell the controller which bean is selected, because the controller is session scope,
            // but we are only request scope
            Map sessionParams = context.getExternalContext().getSessionMap();
            MonitorTreeBean _monitorTreeBean = (MonitorTreeBean)sessionParams.get("monitorTreeBean");
            
            UserBean user = (UserBean)sessionParams.get("UserBean");
            _monitorTreeBean = new MonitorTreeBean(user);
            	
            if (selectedMawbBean == null){
            	ShipmentVO shipment = _selectedCrnBean.getShipment();
            	List shipmentReferences = _selectedCrnBean.getShipmentReferences();
            	List associatedShipments = _selectedCrnBean.getAssociatedShipments();
            	List comments = _selectedCrnBean.getComments();
            	List events = _selectedCrnBean.getEvents();
            	List issues = _selectedCrnBean.getIssues();
            	
            	selectedMawbBean = new MawbBean(shipment, 
            			shipmentReferences, associatedShipments, comments, 
            			events, issues);
            }
            	
            _monitorTreeBean.setSelectedMAWB(selectedMawbBean);
            _monitorTreeBean.setSelectedCRN(_selectedCrnBean);
            sessionParams.put("monitorTreeBean", _monitorTreeBean);
            
       
            // navigate to the detail screen
            return "showCrnDetail";
        } else {
            // shouldn't happen
            return null;
        }
    }
    
    /**
     * Navigation to get the Next CRN details
     * @return
     */
    public String getNextCRNDetail() {
        return "nextCrnDetail";
    }
    
    /**
     * Navigation to get the Previous CRN details
     * @return
     */
    public String getPreviousCRNDetail() {
        return "prevCrnDetail";
    }

    /**
     * Navigation back to the CRN List, on MAWB details 
     * @return
     */
    public String getCrnList() {
        return "showCrnList";
    }

    /**
     * pagingActionListener
     * 
     * @param event
     * @throws AbortProcessingException
     */
    public void pagingAction(ActionEvent event) throws AbortProcessingException {
        if (_crnListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        } 
    }
    
    /** 
     * Navigation to get CRNs (list of CRNs for this account,lane,etc)
     * @return
     */
    public String refreshAction() {
        if (_crnListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        }
        return "success";
    }
    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        return true;
    }
    
    protected void sort(final String column, final boolean ascending) {
        // sort handled by SQL in database, but we still need the column and ascending info
    }

    /*-----------------------------------------------------------------------
     * Private Utility Methods
     *-----------------------------------------------------------------------
     */
    
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      shipmentDelegate = new ShipmentDelegate();
    }
    
    /**
     * Get the selected tree node (account, lane, service, etc.)
     * @return String
     */
    private PerformanceBean getPerformanceBean() {
        Map params = FacesContext.getCurrentInstance().getExternalContext().
        	getSessionMap();
        PerformanceBean performanceBean = 
        	(PerformanceBean)params.get("PerformanceBean");
        return performanceBean;
    }
    
    /**
     * Get the selected month from the performance bean, which stores it into 
     * the session.
     */
    private String getSelectedMonth(){
        return getPerformanceBean().getSelectedMonth();
    }

}
