package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.SystemMessageVO;

public class SystemMessagePersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(SystemMessagePersister.class);
    
    public SystemMessagePersister(Connection con) {
        super(con);
    }
    
    private static final String systemMessagePersisterSQL =
        "Insert into System_Message" +
        "(MSG_NBR, START_DT, END_DT, EMP_ROLE_CD, EMP_NBR, MESSAGE_DESC)" +
        "values(MSG_NBR_SQ.NEXTVAL,?,?,?,?,?)";
    
    public void persistSystemMessage(SystemMessageVO aVO) throws SQLException {
        try {
            setSqlSignature( systemMessagePersisterSQL, false, logger.isDebugEnabled() );

            java.sql.Timestamp timeStamp = new java.sql.Timestamp(aVO.get_startDt().getTime());
            pstmt.setTimestamp( 1, timeStamp);
            timeStamp = new java.sql.Timestamp(aVO.get_endDt().getTime());
            pstmt.setTimestamp( 2, timeStamp);
            
            pstmt.setString(3, aVO.get_empRoleCd());
            pstmt.setString(4, aVO.get_empNbr());
            pstmt.setString(5, aVO.get_msgDesc());
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();
            
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }   

}
