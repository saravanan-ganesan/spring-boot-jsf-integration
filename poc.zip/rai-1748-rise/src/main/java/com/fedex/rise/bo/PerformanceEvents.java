package com.fedex.rise.bo;

import java.util.Calendar;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.IPDShipmentVO;
import com.fedex.rise.vo.ShipmentVO;


/**
 * Class to set the PERF_RSULT_CD of the Shipment table in the database to 
 * ONTIME, EXCUSE, ODA or LATE.  These are being set on a package level based 
 * on specific events and conditions.
 * 
 * @author be379961
 *
 */
public class PerformanceEvents {
    /** Logger */
    private static Logger logger = LogManager.getLogger(PerformanceEvents.class);
    private static final String INVALID = "INVALID"; 
    private static final String LATE_DELIVERY = "LATE_DELIVERY";
    private static final String ONTIME_DELIVERY = "ONTIME_DELIVERY";
    
	/**
	 * Constructor
	 */
	public PerformanceEvents(){
	}
	
	/**
	 * Determine for performance calculations whether the package is ONTIME, 
	 * EXCUSED, ODA or LATE.
	 * 
	 * @param anIpdShipmentVO the IPDShipmentVO of the current event.
	 * @param existingShipmentVO the ShipmentVO of what is currently in the 
	 * Shipment table.
	 * @return The IPDShipmentVO with the PERF_RSULT_CD set.
	 */
	public String processEvent(IPDShipmentVO anIpdShipmentVO, 
			ShipmentVO existingShipmentVO) {
		String trackType = anIpdShipmentVO.get_event().get_track_type_cd();
		String trackExceptionCd=anIpdShipmentVO.get_event().get_track_excp_cd();
		
		// Only process this event if it has a track type of interest.
		if (trackTypeOfInterest(trackType)){			
			// Use the SEP commit date. Use the newest or non-null value for commit date.
			Calendar commit_dt = null;
			if (anIpdShipmentVO.get_shipment().get_commit_dt() !=  null){
				commit_dt = anIpdShipmentVO.get_shipment().get_commit_dt();
			}else if (existingShipmentVO.get_commit_dt() != null){
				commit_dt = existingShipmentVO.get_commit_dt();
			}
			// Get the delivery date.
			Calendar delDt = determineDeliveryDate(trackType, 
					anIpdShipmentVO.get_shipment().get_del_dt(), 
					anIpdShipmentVO.get_event().get_event_crtn_tmstp());
			// Determine the delivery status.
			String DeliveryStatus = calculateDeliveryStatus(delDt, commit_dt);
		
			if (isExcused(trackType, trackExceptionCd, DeliveryStatus)){
				logger.debug("EXCUSED");
				return "EXCUSED";
			}else if (isODA(trackType, trackExceptionCd)){
				logger.debug("ODA");
				return "ODA";
			} else if (isOnTime(trackType, DeliveryStatus)){
				logger.debug("ONTIME");
				return "ONTIME";
			} else if (isLate(trackType, trackExceptionCd, DeliveryStatus)){
				logger.debug("LATE");
				return "LATE";
			} else if (isPOD(trackType)){
				logger.debug("POD");
				return "POD";
			}
		}
		return null;
	}
	
	/**
	 * If it is ONTIME the track type  20  POD or track type  31  DDEX, and the
	 * actual delivery date is before the adjusted commit date.
	 * 
	 * @param trackType The track type
	 * @param DeliveryStatus INVALID or LATE_DELIVERY or ONTIME_DELIVERY.
	 * @return true if the package was delivered ONTIME.
	 */
	private boolean isOnTime(String trackType, String DeliveryStatus){
		if (trackType.equals("20") || trackType.equals("31")) {
			if (DeliveryStatus.equals(ONTIME_DELIVERY) ){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * If it is POD the track type  20  POD or track type  31  DDEX, and the
	 * commit date and adjusted commit date is null.
	 * 
	 * @param trackType The track type
	 * @return true if the package was delivered.
	 */
	private boolean isPOD(String trackType){
		if (trackType.equals("20") || trackType.equals("31")) {
			return true;
		}
		return false;
	}
	
	/**
	 * The delivery is EXCUSED if the track type is "30" DEX and the Exception
	 * code is any of the following, 02, 03, 05, 07, 08, 09, 10, 15, 17, 22, 23, 
	 * 24, 25, 29, 38, 41, 84.
	 * 
	 * The delivery is EXCUSED if the track type is "30" DEX and the actual 
	 * delivery date is before the adjusted commit date, and the Exception code
	 * is 01 or 12.
	 * 
	 * The package was canceled which is  a track type "71" MDE1 or a the 
	 * contract delete flag is set to "Y".
	 * 
	 * The package was undeliverable if the track type "07" STAT and the 
	 * exception code is "14"
	 * 
	 * The package was destroyed at customers request if the track type "07" 
	 * STAT and the exception code is "34".
	 * 
	 * The shipment was refused by the recipient if the (track type was "07" 
	 * STAT or track type "30" DEX) AND (the exception code is "07" OR the 
	 * exception code is "08").
	 * 
	 * The package is excused if it is a PUX 17, where the "Customer Requested 
	 * Future Delivery". This has a track type "29" and the exception code is 
	 * "17".
	 * 
	 * @param trackType The track type
	 * @param trackExceptionCd The track Exception Code
	 * @param DeliveryStatus INVALID or LATE_DELIVERY or ONTIME_DELIVERY.
	 * @return true if the package was delivered EXCUSED.
	 */
	private boolean isExcused(String trackType, String trackExceptionCd, 
			String DeliveryStatus){
		/**
		 * DEX and package and the Exception code is the following:
		 * "02" Pkg delvd to rcpt addr-rel auth
		 * "03" Incorrect Recipient Address
		 * "05" Customer security delay
		 * "07" Shipment refused by recipient
		 * "08" Not in-business closed
		 * "09" Damaged--delivery completed 
		 * "10" Damaged - delivery not completed                       
		 * "15" Business closed due to strike.
		 * "17" Customer requested future delivery
		 * "22" Pkg msd a-c/trk at sta/hub/ramp
		 * "23" Pkg received after a/c / shuttle departure
		 * "24" Customer delay (DEX = package delivery)
		 * "25" Package received without pkg tracking # 
		 * "29" Reroute requested
		 * "38" Pkg trak# rec'd without pkg. 
		 * "41" Commitment not due / not attempted  
		 * "84" Delay caused beyond our control 
		 */
		if (trackType.equals("30") && (
		    trackExceptionCd.equals("02") ||
			trackExceptionCd.equals("03") ||
			trackExceptionCd.equals("05") || 
			trackExceptionCd.equals("07") ||
			trackExceptionCd.equals("08") ||
			trackExceptionCd.equals("09") ||
			trackExceptionCd.equals("10") ||
			trackExceptionCd.equals("15") ||
			trackExceptionCd.equals("17") ||
			trackExceptionCd.equals("22") ||
			trackExceptionCd.equals("23") ||
			trackExceptionCd.equals("24") ||
			trackExceptionCd.equals("25") ||
			trackExceptionCd.equals("29") ||
			trackExceptionCd.equals("38") ||
			trackExceptionCd.equals("41") ||
			trackExceptionCd.equals("84"))) {
				return true;
		}
		
		/**
		 * The delivery is EXCUSED if the track type is "30" DEX and the actual 
		 * delivery date is before the adjusted commit date, and the Exception code
		 * is 01 or 12.
		 * "01" Package not delivered/not attempted
		 * "12" Package sorted to wrong route
		 */
		if (trackType.equals("30") && (trackExceptionCd.equals("01") ||
				trackExceptionCd.equals("12"))){
			if (DeliveryStatus.equals(ONTIME_DELIVERY) ){
				return true;
			}else{
				return false;
			}
			
		}
		/**
		 * The package was canceled.
		 */
		if (trackType.equals("71")) {
			return true;
		}
		/**
		 * The package was undeliverable.
		 */
		if (trackType.equals("07") && trackExceptionCd.equals("14")) {
			return true;
		}
		/**
		 * The package was destroyed at customers request.
		 */
		if (trackType.equals("07") && trackExceptionCd.equals("34")) {
			return true;
		}
		/**
		 * The shipment was refused by the recipient, or Recipient Not 
		 * In/Business Closed 
		 */
		if ((trackType.equals("07")) &&
				(trackExceptionCd.equals("07") || trackExceptionCd.equals("08"))) {
			return true;
		}
		/**
		 * PUX 17, Customer Requested Future Delivery.
		 */
		if (trackType.equals("29") && trackExceptionCd.equals("17")) {
			return true;
		}
		return false;
	}
	/**
	 * Is ODA(Out of Delivery Area) if the track type is "42" ODA or a track
	 * type is "75" AG67(INTL SIPS - Released to ODA Agent) or track type "07"
	 * STAT and exception code "67" (RECV'D FROM/RLSD TO AN ODA AGENT).
	 * 
	 * @param trackType The track type
	 * @param trackExceptionCd The track Exception Code
	 * @param anIpdShipmentVO the IPDShipmentVO.
	 * @return true if the package was ODA.
	 */
	private boolean isODA(String trackType, String trackExceptionCd){
		/**
		 * If the track type is ODA or Released to ODA Agent.
		 */
		if(trackType.equals("42") || trackType.equals("75")){
			return true;
		}
		/**
		 * If the package is received from or released to an ODA agent.
		 */
		if (trackType.equals("07") && trackExceptionCd.equals("67")) {
			return true;
		}
		return false;
	}
	/**
	 * If it is LATE the track type  20  POD or track type  31  DDEX, and the
	 * actual delivery date is after the adjusted commit date.
	 * 
	 * The delivery is LATE if the track type is "30" DEX and the actual 
	 * delivery date is after the adjusted commit date, and the Exception code
	 * is 01 or 12.
	 * 
	 * @param trackType The track type
	 * @param trackExceptionCd The track Exception Code
	 * @param DeliveryStatus INVALID or LATE_DELIVERY or ONTIME_DELIVERY.
	 * @return true if the package was delivered LATE.
	 */
	private boolean isLate(String trackType, String trackExceptionCd, 
			String DeliveryStatus){
		/**
		 * If it is LATE the track type  20  POD or track type  31  DDEX, and 
		 * the actual delivery date is after the adjusted commit date.
		 */
		if (trackType.equals("20") || trackType.equals("31")) {
			if (DeliveryStatus.equals(LATE_DELIVERY) ){
				return true;
			}
		/**
		 * The delivery is LATE if the track type is "30" DEX and the actual 
		 * delivery date is after the adjusted commit date, and the Exception code
		 * is 01 or 12.
		 */
		}else if (trackType.equals("30") && (trackExceptionCd.equals("01") ||
				trackExceptionCd.equals("12"))){
			if (DeliveryStatus.equals(LATE_DELIVERY) ){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * For the time when SEP delivers a delivery date from the Profile which is 
	 * null during a POD(20), DDEX(31) or DEX(30) scan. In these cases set the 
	 * delivery date to the event creation timestamp
	 * @param trackType The track type
	 * @param delDt The delivery date
	 * @param eventTimeStamp The event creation timestamp
	 * @return
	 */
	private Calendar determineDeliveryDate(String trackType, Calendar delDt, 
				Calendar eventTimeStamp){
		if (trackType.equals("20") || trackType.equals("31") || 
				trackType.equals("30")) {
			if (delDt == null){
				return eventTimeStamp;
			}
		}
		return delDt;
	}
	/**
	 * Determine if the the package was delivered on time or not base on the 
	 * commit and delivery date.  If the package was delivered on the same day
	 * as the commit day, it is on time.  Since the time granularity is at the 
	 * day level, need to set the time the same for both delDt and commitDt.
	 * The Default is INVALID.
	 * 
	 * @param delDt The delivery date.
	 * @param commitDt The commit date.
	 * @return INVALID or LATE_DELIVERY or ONTIME_DELIVERY.
	 */
	private String calculateDeliveryStatus(Calendar delDt, Calendar commitDt) {
		// If either dates are null, can not calculate delivery status.
		if (delDt != null && commitDt != null) { 
	        // Clone the commit date calendar so as to not corrupt what is going to the db.
	        Calendar cloneCommitDt = (Calendar)commitDt.clone();
	        
	        // Its only late if the delivery is after the commit date for IPD,
	        // so set the time to 23:59:59 in the commit date calendar
	        cloneCommitDt.set(Calendar.HOUR_OF_DAY, 23);
	        cloneCommitDt.set(Calendar.MINUTE, 59);
	        cloneCommitDt.set(Calendar.SECOND, 59);
	           
			// Determine if it is late or not.
			if (delDt.after(cloneCommitDt)) {
				return LATE_DELIVERY;
			} else {
				return ONTIME_DELIVERY;
			}
		}
		return INVALID;
	}
	
	/**
     * This method is used to filter out events with track type codes that
     * performance processing is interested in.  
     * 
     * @param trackType The track type code of interest
     * @return
     */
    public boolean trackTypeOfInterest(String trackType) {
        int [] wantedTrackTypeCds = {7, 20, 30,  31, 42, 71, 75};
        
        if (trackType != null) {
        	int trackTypeCd = -1;
            try {
            	trackTypeCd = Integer.parseInt(trackType);
            } catch (NumberFormatException nfe) { 
            	return false; 
            }
            
            for (int i = 0; i < wantedTrackTypeCds.length; i++) {
            	if (trackTypeCd == wantedTrackTypeCds[i]) {
            		logger.debug("Performance processing this event. trackType = "
            				+ trackType);
            		return true;
            	}
            }
        }
        return false;
    }
}
