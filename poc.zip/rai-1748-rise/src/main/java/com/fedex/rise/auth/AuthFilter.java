package com.fedex.rise.auth;

import java.io.IOException;
import java.util.Enumeration;

import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.logging.log4j.ThreadContext;

import com.fedex.rise.bean.UserBean;
import com.fedex.rise.cache.EmployeeCacheDAO;
import com.fedex.rise.cache.MonitorReportCacheDAO;

/**
 * Filter to determine if we are already logged in or if we need to redirect to
 * the FedEx WSSO (Web Single Sign On) application to login. Uses Oblix header
 * variables.
 * 
 * XDoclet tags to build the correct config in the web.xml file
 * 
 * @web:filter name="AutoFilter" display-name="AuthFilter"
 * @web:filter-mapping url-pattern="*"
 */
public class AuthFilter implements Filter {

	private static Log log = LogFactory.getLog(AuthFilter.class);
	private FilterConfig filterConfig = null;

	// WSSO demo
	// private static final String redirectLogin =
	// "http://keep.wsso.fedex.com/support/presentation/EntryPointPO.jsp";
	// WSSO proxy
	// private static final String redirectLogin =
	// "http://dev-wgproxy.corp.fedex.com/rise";
	private static final String redirectLogin = "/rise/login.jsf";
	private static final String redirectHome = "/rise/home.jsf";

	/**
	 * This method is the init life cycle method.
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
		log.info("Method: init()");
	}

	/**
	 * Get the logged in user from the session (UserBean), if any
	 * 
	 * @return UserBean
	 */
	public UserBean getLoggedInUser(HttpServletRequest req,
			HttpServletResponse res) {
		try {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			if (facesContext == null) {
				FacesContextFactory contextFactory = (FacesContextFactory) FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
				LifecycleFactory lifecycleFactory = (LifecycleFactory) FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
				Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
				// Either set a private member servletContext =
				// filterConfig.getServletContext();
				// in you filter init() method or set it here like this:
				// ServletContext servletContext =
				// ((HttpServletRequest)request).getSession().getServletContext();
				// Note that the above line would fail if you are using any
				// other protocol than http
				// Doesn't set this instance as the current instance of FacesContext.getCurrentInstance
				ServletContext servletContext = filterConfig.getServletContext();
				facesContext = contextFactory.getFacesContext(servletContext,req, res, lifecycle);
				if (facesContext == null) {
					return null;
				}
			}
			// try to get the logged in user from the session
			UserBean user = (UserBean) req.getSession().getAttribute("UserBean");
			log.debug("UserBean Created");
			return user;
		} catch (Exception e) {
			log.info("Unable to get logged in user", e);
			return null;
		}
	}

	/**
	 * Get the user from the WSSO attributes (via proxy), if any
	 * 
	 * @return UserBean
	 */
	public UserBean getWSSOUserInfo(HttpServletRequest req,HttpServletResponse res) 
	throws IOException {
		log.debug("Method: getWSSOUserInfo()");
		// Do not close the output stream - allow the servlet engine to close it
		// to enable better performance.
		// A few LDAP variables specified to be available when authorization
		// success.
		String oblixUID = null; // user Id
		HttpSession session = req.getSession();
		// Get LDAP vars from Oblix header variables.
		Enumeration e1 = req.getHeaderNames();
		while (e1.hasMoreElements()) {
			String name = ((String) e1.nextElement()).toUpperCase();
			Enumeration e2 = req.getHeaders(name);
			while (e2.hasMoreElements()) {
				String value = (String) e2.nextElement();
				if (log.isDebugEnabled())
					log.debug("Header " + name + "=" + value);
				if (name.equalsIgnoreCase("OBLIX_UID")) {
					oblixUID = value;
					log.info("OblixUID: " + oblixUID);
				} else {
					/*
					 * other useful attrs if (name.equalsIgnoreCase("OBLIX_CN"))
					 * { } else if (name.equalsIgnoreCase("OBLIX_MAIL")) { }
					 * else if (name.equalsIgnoreCase("OBLIX_GIVENNAME")) { }
					 * else if (name.equalsIgnoreCase("OBLIX_SN")) { }
					 */
				}
			} // inner while
		} // outer while

		// Redirect to Oblix login page if did not come in via WebGate.
		// OBLIX_UID must be found.
		if (oblixUID == null || oblixUID.trim().length() == 0) {
			return null;
		} else {
			// if found WSSO logged in user Id, then validate authorization to
			// RISE
			UserBean userBean = new UserBean();
			userBean.setUserId(oblixUID);
			log.debug("UserId " + userBean.getUserId());
			// check if valid in RISE
			if (userBean.initUserInfo()) {
				// put user bean in session so we know we are logged in
				//Start WR#TBD - WSSO Integration changes
				log.debug("User Info: UserID " + userBean.getUserId()+ " UserName " + userBean.getFirstName()+ userBean.getLastName() + " UserRole "+ userBean.getRole());
				//End WR#TBD - WSSO Integration changes
				session.setAttribute("UserBean", userBean);
				// FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("UserBean",
				// userBean);
				return userBean;
			} else {
				return null;
			}
		}

	} // service

	/**
	 * This method will filter requests to ensure that a logged in session
	 * exists.
	 * 
	 * @param req
	 *            Pass in the servlet request.
	 * @param resp
	 *            Pass in the servlet response.
	 * @param chain
	 *            Pass in the filter chain.
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	 // WR#TBD - WSSO Integration changes
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		if (log.isDebugEnabled())
			log.debug("Entering doFilter()");
		HttpServletResponse rsp = (HttpServletResponse) resp;
		HttpServletRequest rq = (HttpServletRequest) req;
		String path = rq.getServletPath();
		log.debug("User Request Path: " + path);
		
		if(path.endsWith(".jsf"))
			log.info("User Requested path:"+rq.getRequestURL());
		
		if (path.endsWith(".jsf") || path.endsWith("index.jsp")|| path.endsWith("log4jAdmin.jsp")) {
			// ignore ajax4j, fixes browser back when no session
			if (path.startsWith("/a4j")) {
				// if (log.isDebugEnabled()) log.debug("Ignore: '" + path);
				chain.doFilter(req, resp);
				if (log.isDebugEnabled())
					log.debug("Exiting doFilter()");
				return;
			}
			// Check if user already logged in to RISE
			UserBean user = getLoggedInUser(rq, rsp);
			if (user == null || user.getUserId() == null) {
				// Not already logged in, so check if already logged via WSSO
				user = getWSSOUserInfo(rq, rsp);
				if (user.getUserId() != null) {
					// Already logged in via WSSO, so redir to home, now that
					// session in RISE created
					// rsp.sendRedirect(rsp.encodeRedirectURL(redirectHome));
					chain.doFilter(req, resp);
					if (log.isDebugEnabled())
						log.debug("Exiting doFilter(): WSSO logged in ");
					return;
				}
			}
			

			// If not logged in, then goto login page
			if ((user == null || user.getUserId() == null)) {
				// if already accessing login or error pages, then just go there
				if ((path.indexOf("login.jsf") == -1)&& (path.indexOf("contactus.jsf") == -1)&& (path.indexOf("error.jsf") == -1)) {
					// redirect to login
					if (log.isDebugEnabled())
						log.debug("No session, access='" + path+ "', so redirect to login");
					rsp.sendRedirect(rsp.encodeRedirectURL(redirectLogin));
				} else {
					chain.doFilter(req, resp);
				}

			} else {
				// already logged in, so do nothing except setup Logging user id
				String userId = user.getUserId();
				// if timezone not set then, look for it in the request
				if (user.getTimeZone() == null) {
					String timeZoneOffset = rq.getParameter("getTimezoneOffset");
					user.setVisitorTimeZoneOffset(timeZoneOffset);
				}

				try {
					// add log4j NDC for user logged in
					ThreadContext.push(userId);
					log.info("Access=" + path);

					// Determine if it is a RISE monitor
					if (EmployeeCacheDAO.containsKey(user.getUserId())) {
						// Add a "hit" for this employee to the cache.
						MonitorReportCacheDAO.updateHits(user.getUserId());
					}
					chain.doFilter(req, resp);

					if (log.isDebugEnabled())
						sessionSize(((HttpServletRequest) req).getSession());

				} finally {
					ThreadContext.pop();
					// ThreadContext.remove(); TODO: end of thread???
				}

			}

			if (log.isDebugEnabled())
				log.debug("Exiting doFilter()");
		} else {
			chain.doFilter(req, resp);
		}
	}

	/**
	 * This method is the destroy life cycle method.
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		filterConfig = null;
		log.info("Method: destroy()");
	}

	/**
	 * This method returns the filter config.
	 * 
	 * @return Returns the filterConfig.
	 */
	protected FilterConfig getFilterConfig() {
		return filterConfig;
	}

	/**
	 * Utility method to determine the session size, for debugging
	 */
	public static int sessionSize(HttpSession session) {
		int total = 0;

		try {
			java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
			java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);
			Enumeration enumeration = session.getAttributeNames();

			while (enumeration.hasMoreElements()) {
				String name = (String) enumeration.nextElement();
				Object obj = session.getAttribute(name);
				try {
					oos.writeObject(obj);
				} catch (java.io.NotSerializableException e) {
					log.error(e.toString() + " " + e.getMessage());
				}

				int size = baos.size();
				total += size;
				log.debug("Session Object: " + name + " size: " + size);
			}

			log.debug("TOTAL session size: " + total);
		} catch (Exception e) {
			log.error("Could not get the session size", e);
		}

		return total;
	}

}
