package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class ConfigurationPersister extends OracleBase {
private static Logger logger = LogManager.getLogger(ConfigurationPersister.class);
	
	public ConfigurationPersister(Connection con) {
        super(con);
    }
	private static final String addConfigurationRowSQL =
	    "Insert into Configuration (" +
	    "CONFG_VALUE_NM, " +
	    "CONFG_VALUE_DESC) " +
	    "values(?,?)";        

	public void doPersist(String  confgValueNm, String confgValueDesc) throws SQLException {
	    
	    try {
	        setSqlSignature( addConfigurationRowSQL, false, logger.isDebugEnabled() );    
	            
	        
	        pstmt.setString( 1, confgValueNm);
	        pstmt.setString(2, confgValueDesc);
	        
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        execute();

	    } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	        throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
}
