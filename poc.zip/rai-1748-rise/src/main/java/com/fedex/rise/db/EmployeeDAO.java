package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EmployeeVO;

public class EmployeeDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(EmployeeDAO.class);
    
    /**
     * Get All of the employees
     * @return list of monitor employees
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public List getAllMonitorEmployees() throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EmployeeAccessor userAccessor = new EmployeeAccessor(connection);
            return userAccessor.getAllMonitorEmployees();
        } finally {
            closeConnection(connection);
        }      
    }
    
    /**
     * Get the employees
     * @return list of employees
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public List getEmployees() throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EmployeeAccessor userAccessor = new EmployeeAccessor(connection);
            return userAccessor.getEmployees();
        } finally {
            closeConnection(connection);
        }      
    }

    /**
     * Get the employee
     * @return EmployeeVO
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public EmployeeVO getEmployee(String emplyNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EmployeeAccessor userAccessor = new EmployeeAccessor(connection);
            return userAccessor.getEmployee(emplyNbr);
        } finally {
            closeConnection(connection);
        }      
    }

    public void addEmployee(EmployeeVO anEmployeeVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EmployeePersister persister = new EmployeePersister(connection);
            persister.addEmployee(anEmployeeVO);
        } finally {
            closeConnection(connection);
        }
    }

    public void updateEmployee(EmployeeVO anEmployeeVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EmployeeUpdater updater = new EmployeeUpdater(connection);
            updater.updateEmployee(anEmployeeVO);
        } finally {
            closeConnection(connection);
        }
    }    
    
    
    public void deleteEmployee(String anEmployeeNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EmployeeDeleter deleter = new EmployeeDeleter(connection);
            deleter.deleteEmployee(anEmployeeNbr);
        } finally {
            closeConnection(connection);
        }
    }
}

