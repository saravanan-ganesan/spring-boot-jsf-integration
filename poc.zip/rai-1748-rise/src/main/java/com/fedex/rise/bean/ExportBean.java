package com.fedex.rise.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponse;

/**
 * Backer bean for exporting to data to an Excel spreadsheet. 
 */
public class ExportBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(ExportBean.class);

    private String htmlBuffer;

    /** 
     * Default Constructor
     */
    public ExportBean() {
        
    }
    
    /*--------------------------------------------------------------------- 
     * Getter/Setter methods
     *---------------------------------------------------------------------
     */
    public String getHtmlBuffer() {
        return htmlBuffer;
    }
    
    public void setHtmlBuffer(String htmlBuffer) {
        this.htmlBuffer = htmlBuffer;
    }

    /*--------------------------------------------------------------------- 
     * Action methods
     *---------------------------------------------------------------------
     */
   
    public void exportHtmlTableToExcel() throws IOException{        
        
        //Set the filename
    	TimeZone tz = TimeZone.getTimeZone("GMT+0000");
        Calendar c = Calendar.getInstance(tz);
        SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
        String dateStr = sf.format(c.getTime());
        String filename = dateStr + ".xls";
        
        
        //Setup the output
        String contentType = "application/vnd.ms-excel";
        FacesContext fc = FacesContext.getCurrentInstance();
        filename = UserBean.getLoggedInUser().getUserId() + "-"+ filename;
        HttpServletResponse response = (HttpServletResponse)fc.getExternalContext().getResponse();
        response.setHeader("Content-disposition", "attachment; filename=" + filename);
        response.setContentType(contentType);
        
        //Write the table back out
        PrintWriter out = response.getWriter();
        out.print(htmlBuffer);
        out.close();
        fc.responseComplete();
    }  
}

