package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AssociatedShipmentVO;

public class AssociatedShipmentAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(AssociatedShipmentAccessor.class);
        
    public AssociatedShipmentAccessor(Connection con) {
        super(con);
    }
        
    private final String selectAssocShipmentSQL = "select " +
        "TRKNG_ITEM_NBR, " +           // VARCHAR2(12) 
        "TRKNG_ITEM_UNIQ_NBR, " +      // VARCHAR2(10)
        "ASSOC_TRKNG_ITEM_NBR, " +     // VARCHAR2(12)
        "ASSOC_TRKNG_ITEM_UNIQ_NBR, " + // VARCHAR2(10)
        "ASSOC_TRACK_TYPE_CODE " +
        "From Associated_Shipment where " +
            "TRKNG_ITEM_NBR = ? AND TRKNG_ITEM_UNIQ_NBR = ?";
        
     public List getAssociatedShipments(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
         ArrayList al = new ArrayList(); 
            
         try {
             setSqlSignature( selectAssocShipmentSQL, false, logger.isDebugEnabled() );

             pstmt.setString( 1, aTrkngItemNbr);
             pstmt.setString( 2, aTrkngItemUniqNbr);
             
             if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
             }
                
             execute();

             if ( hasResults ) {
                   
                while(rs.next()) {
                    // Associated Shipment(s) found
                    AssociatedShipmentVO assocShipmentVO = new AssociatedShipmentVO();
                    assocShipmentVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    assocShipmentVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    assocShipmentVO.set_assoc_trkng_item_nbr(rs.getString("ASSOC_TRKNG_ITEM_NBR"));
                    assocShipmentVO.set_assoc_trkng_item_uniq_nbr(rs.getString("ASSOC_TRKNG_ITEM_UNIQ_NBR"));
                    String assocTrackTypeCd = rs.getString("ASSOC_TRACK_TYPE_CODE");
                    if (assocTrackTypeCd != null) {
                        assocShipmentVO.set_assoc_track_type_cd(assocTrackTypeCd.charAt(0));
                    }
                    
                    al.add(assocShipmentVO);
                }
            } else {
                // Associated Shipment not found
                logger.error("Associated Shipment not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }

  
     private final String selectReverseAssocShipmentSQL = "select " +
         "TRKNG_ITEM_NBR, " +           // VARCHAR2(12) 
         "TRKNG_ITEM_UNIQ_NBR, " +      // VARCHAR2(10)
         "ASSOC_TRKNG_ITEM_NBR, " +     // VARCHAR2(12)
         "ASSOC_TRKNG_ITEM_UNIQ_NBR, " + // VARCHAR2(10)
         "ASSOC_TRACK_TYPE_CODE " +
             "From Associated_Shipment where " +
             "ASSOC_TRKNG_ITEM_NBR = ? AND ASSOC_TRACK_TYPE_CD = ?";     
     
     
    public List getReverseAssociatedShipmentsByType(String anAssocTrkngItemNbr, char anAssocTypeCd) throws SQLException {
        ArrayList al = new ArrayList(); 
         
        try {
            setSqlSignature( selectReverseAssocShipmentSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anAssocTrkngItemNbr);
            pstmt.setString( 2, String.valueOf(anAssocTypeCd));
             
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }  
                
            execute();
             
            if ( hasResults ) {
                   
                while(rs.next()) {
                    // Associated Shipment(s) found
                    AssociatedShipmentVO assocShipmentVO = new AssociatedShipmentVO();
                    assocShipmentVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    assocShipmentVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    assocShipmentVO.set_assoc_trkng_item_nbr(rs.getString("ASSOC_TRKNG_ITEM_NBR"));
                    assocShipmentVO.set_assoc_trkng_item_uniq_nbr(rs.getString("ASSOC_TRKNG_ITEM_UNIQ_NBR"));
                    String assocTrackTypeCd = rs.getString("ASSOC_TRACK_TYPE_CODE");
                    if (assocTrackTypeCd != null) {
                        assocShipmentVO.set_assoc_track_type_cd(assocTrackTypeCd.charAt(0));
                    }
                        
                    al.add(assocShipmentVO);
                }
            } else {
                // Associated Shipment not found
                logger.error("Associated Shipment not found for : " + anAssocTrkngItemNbr + ":" + anAssocTypeCd);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                         + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;         
    }
}

