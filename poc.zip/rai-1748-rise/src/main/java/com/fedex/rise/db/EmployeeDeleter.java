package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class EmployeeDeleter extends OracleBase {

    private static Logger logger = LogManager.getLogger(EmployeeDeleter.class);

    public EmployeeDeleter(Connection con) {
        super(con);
    }

    private static final String deleteEmployeeSQL = "Delete Employee where " +
                "EMP_NBR = ?";

    public void deleteEmployee(String anEmployeeNbr) throws SQLException {

        try {
            setSqlSignature(deleteEmployeeSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, anEmployeeNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
    