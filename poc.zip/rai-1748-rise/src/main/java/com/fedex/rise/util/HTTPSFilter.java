package com.fedex.rise.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class HTTPSFilter implements Filter {
    private FilterConfig filterConfig = null;
    //WR#TBD - WSSO Integration changes
    private static Logger logger = LogManager.getLogger(HTTPSFilter.class);
  
    /**
     * This method is the init life cycle method.
     * 
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
        logger.info("Method: init()");
    }

 
    /**
     * This method will filter requests to ensure that a logged in session exists.
     * 
     * @param req Pass in the servlet request.
     * @param resp Pass in the servlet response.
     * @param chain Pass in the filter chain.
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    //WR#TBD - WSSO Integration changes
    public void doFilter(ServletRequest req, ServletResponse res,
            FilterChain chain) throws IOException, ServletException {
            
		String serverName = req.getServerName();
		serverName = serverName.toLowerCase();
		int port = req.getServerPort();

        HttpServletResponse rsp = (HttpServletResponse)res;
        HttpServletRequest rq = (HttpServletRequest)req;
        
		if (rq.getServletPath().endsWith(".jsf"))
			logger.info("User Requested path:" + rq.getRequestURL());

		if (req.isSecure()) {
			// VIPS
			if (serverName.startsWith("rise")) {
				logger.debug("Requested Server starts with rise");
				logger.debug("Request URL: http://" + serverName + rq.getRequestURI());
				rsp.sendRedirect("http://" + serverName + rq.getRequestURI());
			} else { // NON VIPS
				logger.debug("Request URL: http://" + serverName + rq.getRequestURI());
				rsp.sendRedirect("http://" + serverName + ":" + (port-1) + rq.getRequestURI());
			}
		} else {
				logger.debug("Request URL: http://" + serverName + rq.getRequestURI());
			// continue on to requested page
			chain.doFilter(req, rsp);   
		}
    }
    

    /**
     * This method is the destroy life cycle method.
     * 
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy() {
        filterConfig = null;
        logger.info("Method: destroy()");
    }

    /**
     * This method returns the filter config.
     * 
     * @return Returns the filterConfig.
     */
    protected FilterConfig getFilterConfig() {
        return filterConfig;
    }
}
