package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class PerformanceVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
    private Calendar   _ship_dt;                 // DATE(5)
    private String     _acct_nbr;                // VARCHAR2(12);
	private int        _lane_nbr;                // NUMBER(6);
	private int        _group_nbr;               // NUMBER(6); 
    private String     _orig_cntry_cd;           // VARCHAR2(5);
    private String     _dest_cntry_cd;           // VARCHAR2(5);
    private long        _total_mawb_qty;          // NUMBER(10);
    private long        _total_crn_qty;           // NUMBER(10);
    private long        _on_time_crn_qty;         // NUMBER(10);
    private long        _late_crn_qty;            // NUMBER(10);
    private long        _excus_crn_qty;           // NUMBER(10);
    private long        _oda_crn_qty;             // NUMBER(10);
    private long        _no_pod_crn_qty;          // NUMBER(10);
    private long        _total_wgt_amt;           // NUMBER(10);
    private long        _total_inv_value_amt;     // NUMBER(10);
    private Date       _input_tmstp;             // TIMESTAMP(6)
    private String      _month;
    
    public PerformanceVO() {
    }
    
    /**
     * @return the _lane_nbr
     */
    public int get_lane_nbr() {
        return _lane_nbr;
    }
    
    /**
     * @param _lane_nbr the _lane_nbr to set
     */
    public void set_lane_nbr(int _lane_nbr) {
        this._lane_nbr = _lane_nbr;
    }
    /**
     * @return the _group_nbr
     */
    public int get_group_nbr() {
        return _group_nbr;
    }
    
    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_group_nbr(int _group_nbr) {
        this._group_nbr = _group_nbr;
    }
    
    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }
   
    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr;
    }
    
    /**
     * @return the _month
     */
    public String get_month() {
        return _month;
    }
   
    /**
     * @param _month the _month to set
     */
    public void set_month(String _month) {
        this._month = _month;
    }
  
    /**
     * @return the _rprt_dt
     */
    public Calendar get_ship_dt() {
        return _ship_dt;
    }
    
    /**
     * @param _ship_dt the _ship_dt to set
     */
    public void set_ship_dt(Calendar _ship_dt) {
        this._ship_dt = _ship_dt;
    }
    
    /**
     * @return the _orig_loc_cd
     */
    public String get_orig_cntry_cd() {
        return _orig_cntry_cd;
    }
    
    /**
     * @param _orig_cntry_cd the _orig_cntry_cd to set
     */
    public void set_orig_cntry_cd(String _orig_cntry_cd) {
        this._orig_cntry_cd = _orig_cntry_cd;
    }
    
    /**
     * @return the _dest_cntry_cd
     */
    public String get_dest_cntry_cd() {
        return _dest_cntry_cd;
    }
    
    /**
     * @param _dest_cntry_cd the _dest_cntry_cd to set
     */
    public void set_dest_cntry_cd(String _dest_cntry_cd) {
        this._dest_cntry_cd = _dest_cntry_cd;
    }
    
    /**
     * @return the _total_mawb_qty
     */
    public long get_total_mawb_qty() {
        return _total_mawb_qty;
    }
    
    /**
     * @param _total_mawb_qty the _total_mawb_qty to set
     */
    public void set_total_mawb_qty(long _total_mawb_qty) {
        this._total_mawb_qty = _total_mawb_qty;
    }
    
    /**
     * @return the _total_crn_qty
     */
    public long get_total_crn_qty() {
        return _total_crn_qty;
    }
    
    /**
     * @param _total_mawb_qty the _total_mawb_qty to set
     */
    public void set_total_crn_qty(long _total_crn_qty) {
        this._total_crn_qty = _total_crn_qty;
    }
    
    /**
     * @return the _on_time_crn_qty
     */
    public long get_on_time_crn_qty() {
        return _on_time_crn_qty;
    }
    
    /**
     * @param _on_time_crn_qty the _on_time_crn_qty to set
     */
    public void set_on_time_crn_qty(long _on_time_crn_qty) {
        this._on_time_crn_qty = _on_time_crn_qty;
    }
    
    /**
     * @return the _late_crn_qty
     */
    public long get_late_crn_qty() {
        return _late_crn_qty;
    }
    
    /**
     * @param _late_crn_qty the _late_crn_qty to set
     */
    public void set_late_crn_qty(long _late_crn_qty) {
        this._late_crn_qty = _late_crn_qty;
    }
    
    /**
     * @return the _excus_crn_qty
     */
    public long get_excus_crn_qty() {
        return _excus_crn_qty;
    }
    
    /**
     * @param _excus_crn_qty the _excus_crn_qty to set
     */
    public void set_excus_crn_qty(long _excus_crn_qty) {
        this._excus_crn_qty = _excus_crn_qty;
    }
    
    /**
     * @return the _oda_crn_qty
     */
    public long get_oda_crn_qty() {
        return _oda_crn_qty;
    }
    
    /**
     * @param _oda_crn_qty the _oda_crn_qty to set
     */
    public void set_oda_crn_qty(long _oda_crn_qty) {
        this._oda_crn_qty = _oda_crn_qty;
    }
    
    /**
     * @return the _no_pod_crn_qty
     */
    public long get_no_pod_crn_qty() {
        return _no_pod_crn_qty;
    }
    
    /**
     * @param _no_pod_crn_qty the _no_pod_crn_qty to set
     */
    public void set_no_pod_crn_qty(long _no_pod_crn_qty) {
        this._no_pod_crn_qty = _no_pod_crn_qty;
    }
    
    /**
     * @return the _total_wgt_amt
     */
    public long get_total_wgt_amt() {
        return _total_wgt_amt;
    }
    
    /**
     * @param _total_wgt_amt the _total_wgt_amt to set
     */
    public void set_total_wgt_amt(long _total_wgt_amt) {
        this._total_wgt_amt = _total_wgt_amt;
    }
    
    /**
     * @return the _total_inv_value_amt
     */
    public long get_total_inv_value_amt() {
        return _total_inv_value_amt;
    }
    
    /**
     * @param _total_inv_value_amt the _total_inv_value_amt to set
     */
    public void set_total_inv_value_amt(long _total_inv_value_amt) {
        this._total_inv_value_amt = _total_inv_value_amt;
    }
    
    /**
     * @return the _input_tmstp
     */
    public Date get_input_tmstp() {
        return _input_tmstp;
    }
    
    /**
     * @param _input_tmstp the _input_tmstp to set
     */
    public void set_input_tmstp(Date _input_tmstp) {
        this._input_tmstp = _input_tmstp;
    }
}
