package com.fedex.rise.util;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Date;

/**
 * Methods to return month names and increment through months given a date 
 * range.
 * @author be379961
 *
 */
public class DateUtility {
	private Calendar _toDate;
	private Calendar _startDate;
	private Calendar _endDate;
	
	/**
	 * Constructor
	 * @param fromDate The date range from.
	 * @param toDate The date range to.
	 */
    public DateUtility(Date fromDate, Date toDate) {
    	_toDate = Calendar.getInstance();
    	_toDate.setTime(toDate);
    	_startDate = Calendar.getInstance();
        _startDate.setTime(fromDate);
        _endDate = Calendar.getInstance();
        // Determine if the request is greater than a month.
        if (greaterThanAMonth()){
        	incrementEndDate();
        }
    }
    
    /**
     * 
     * @param fromDate The date range from.
     * @param toDate The date range to.
     * @param monthNbr The month number (0-11) within the date range.
     */
    public DateUtility(Date fromDate, Date toDate, int monthNbr) {
    	_toDate = Calendar.getInstance();
    	_toDate.setTime(toDate);
    	_startDate = Calendar.getInstance();
        _startDate.setTime(fromDate);
        _endDate = Calendar.getInstance();
        // Determine if the request is greater than a month
        if (greaterThanAMonth(monthNbr)){
        	resetStartEndDate(monthNbr);
        }
    }
    
    /**
     * 
     * @param fromDate The date range from.
     * @param toDate The date range to.
     * @param monthNbr The month number (0-11) within the date range.
     * @param monthSelectedNumber The month selected, independent of monthNbr.
     */
    public DateUtility(Date fromDate, Date toDate, int monthNbr, 
    		int monthSelectedNumber) {
    	_toDate = Calendar.getInstance();
    	_toDate.setTime(toDate);
    	_startDate = Calendar.getInstance();
        _startDate.setTime(fromDate);
        _endDate = Calendar.getInstance();
        // Determine if the request is greater than a month
        if (monthSelectedNumber < 12){
        	if (greaterThanAMonth(monthNbr)){
        		resetStartEndDate(monthNbr);
        	}
        }else{
        	_endDate.setTime(_toDate.getTime());
            int startMonthInt = _endDate.get(Calendar.MONTH);
            int startYearInt = _endDate.get(Calendar.YEAR);
            _startDate.set(startYearInt, startMonthInt, 1);
        }
    }
     
    // Public Methods.
    

	/**
	 * Get the number of months for a specific date range.
	 * @param fromDate The start date.
	 * @param toDate The end date.
	 * @return Number of months for a specific date range.
	 */
	public int getNumberOfMonths() {
        int startMonthInt = _startDate.get(Calendar.MONTH);
        int startYearInt = _startDate.get(Calendar.YEAR);
        int endMonthInt = _toDate.get(Calendar.MONTH);
        int endYearInt = _toDate.get(Calendar.YEAR);
        
        if (startMonthInt == endMonthInt && startYearInt != endYearInt){
        	return 13;
        }else if (endMonthInt >= startMonthInt){
        	return (endMonthInt - startMonthInt +1);
        }else {
        	return (12 - startMonthInt + endMonthInt +1);
        }    
	}
	
	/**
	 * Increment the date range to the next month.
	 *
	 */
	public void incrementMonth() {
		incrementStartDate();
		incrementEndDate();
	}
	
	/**
	 * Get the startDate for month.
	 * @return Date of startDate.
	 */
	public Date getstartDate(){
		return _startDate.getTime();
	}
	
	/**
	 * Get the endDate for month.
	 * @return Date of endDate
	 */
	public Date getEndDate(){
		return _endDate.getTime();
	}
	
	/**
	 * Get the name of the month for the startDate.
	 * @return String of name of month for startDate.
	 */
	public String getStartMonthName() {
		return getMonthName(_startDate.get(Calendar.MONTH));
	}
	
	// Private Methods.
	
    /**
     * Convert an integer month to a string name for date.
     * @param m interger for month from 0 to 11.
     * @return String name for the month.
     */
	private String getMonthName(int m) {
	    String month = null;
	    if (m >= 0 && m <= 11 ) {
	    	DateFormatSymbols dfs = new DateFormatSymbols();
	    	String[] months = dfs.getMonths();
	        month = months[m];
	    }
	    return month;
	}
	
	/**
	 * Increment the startDate to the next month within the date range.
	 *
	 */
	private void incrementStartDate(){
		_startDate.add(Calendar.MONTH, 1);
		int firstDay = _startDate.getActualMinimum(Calendar.DAY_OF_MONTH);
		_startDate.set(Calendar.DAY_OF_MONTH, firstDay);
		if (_startDate.after(_toDate)){
			_startDate.add(Calendar.MONTH, -1);
		}
	}
	
	/**
	 * Increment the endDate to the next month within the date range.
	 *
	 */
	private void incrementEndDate(){
		int lastDay =_startDate.getActualMaximum(Calendar.DAY_OF_MONTH);
		_endDate.setTime(_startDate.getTime());
		_endDate.set(Calendar.DAY_OF_MONTH, lastDay);
		
		if (_endDate.after(_toDate)){
			_endDate.setTime(_toDate.getTime());
		}
	}
	
	/**
	 * Determine if the start and end date is greater than a month.
	 */
	private boolean greaterThanAMonth(){
		boolean greaterThanMonth = true;
		int startMonthNbr = _startDate.get(Calendar.MONTH);
		int startYearNbr = _startDate.get(Calendar.YEAR);
		int endMonthNbr = _toDate.get(Calendar.MONTH);
		int endYearNbr = _toDate.get(Calendar.YEAR);
		if ((startMonthNbr == endMonthNbr) && (startYearNbr == endYearNbr)){
			_endDate.setTime(_toDate.getTime());
			return false;
		}else if ((startMonthNbr+1 == endMonthNbr) 
				&& (startYearNbr == endYearNbr)){
			incrementEndDate();
			return false;
		}
		return greaterThanMonth;
	}
	
	/**
	 * Determine if the start and end date is greater than a month.
	 * @param monthNbr The month number (0-11) within the date range.
	 */
	private boolean greaterThanAMonth(int monthNbr){
		boolean greaterThanMonth = true;
		int startMonthNbr = _startDate.get(Calendar.MONTH);
		int startYearNbr = _startDate.get(Calendar.YEAR);
		int endMonthNbr = _toDate.get(Calendar.MONTH);
		int endYearNbr = _toDate.get(Calendar.YEAR);
		if ((startMonthNbr == endMonthNbr) && (startYearNbr == endYearNbr)){
			_endDate.setTime(_toDate.getTime());
			return false;
		}
		return greaterThanMonth;
	}
	
	/**
	 * Reset the start and end date based on the monthNbr.
	 * @param monthNbr The month number (0-11) within the date range.
	 */
	private void resetStartEndDate(int monthNbr){
		int numberOfMonths = getNumberOfMonths();
        for (int count=0; count< numberOfMonths; count++ ){  
        	if (monthNbr == _startDate.get(Calendar.MONTH)){
        		if (count == 0){
        			incrementEndDate();
        		}
        		return;
        	}
        	incrementMonth();
        }
	}
}
