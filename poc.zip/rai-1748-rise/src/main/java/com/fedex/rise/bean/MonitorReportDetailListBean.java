package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.text.DateFormat; 

import java.util.Calendar; 
import java.util.Date; 
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIData;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.bo.UserDelegate;
import com.fedex.rise.bo.issue.IssueDesc;
import com.fedex.rise.bo.issue.RiseIssues;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.util.Pageable;
import com.fedex.rise.util.PagedList;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.AssociatedShipmentVO;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.MonitorReportVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * Monitor Report Detail List Backing bean
 */
public class MonitorReportDetailListBean extends SortableList implements Serializable, Pageable {
	/** serializing version */
    private static final long serialVersionUID = 1L;
    
	private static final Log log 
		= LogFactory.getLog(MonitorReportDetailListBean.class);
	private static final int MAX_ROWS = 1000;
	
    private static final int PAGE_SIZE = 100;
    
    /** delegate to get shipment data */
    private transient ShipperDelegate shipperDelegate = new ShipperDelegate();
    
    /** delegate to get shipment data */
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
    
    private DataModel _columnHeaders;
    
    /** selected monitor */
    private MonitorReportBean _selectedMonitorReportBean =  null;
    
    /** list of shipments */
    private transient List _shipments = null;
    private transient DataModel _dataModel = null;
    
    private String _monitorReportDesc = null;
    private String _monitorReportSelect = null;
    private transient List _getMonitorsList = null;
    private int _size = 0;
    
    /** UIData component binding to List table.  Here so we can reset to page 1 after tree node selection */
    private transient UIData _crnListUIData;
    
    
    /**
     * Constructor
     */
    public MonitorReportDetailListBean() {
    	super("Ship Date"); // default sort column
    	String employeeNumber = new String(" ");
    	
        // create header row
        List headerList = new ArrayList();
        headerList.add(new ColumnHeader("Trk #", "14", false));
        headerList.add(new ColumnHeader("Ship Date", "12", false));
        headerList.add(new ColumnHeader("Commit Date", "20", false));
        headerList.add(new ColumnHeader("Acct #", "10", false));
        headerList.add(new ColumnHeader("Shipment Code", "6", false));
        headerList.add(new ColumnHeader("Shipper", "10", false));
        headerList.add(new ColumnHeader("Recipient", "10", false));
        headerList.add(new ColumnHeader("Recipient Ph #", "10", false));
        headerList.add(new ColumnHeader("Issue Type", "10", false));       
        headerList.add(new ColumnHeader("Issue Name", "10", false));  
        _columnHeaders = new ListDataModel(headerList);
        
        employeeNumber = getEmployeeNumber();

        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
        
        _monitorReportSelect = new String(
        		" > From Date: " 
        		+ outputFormat.format(getMonitorReportBean().getFromDate()) +
        		" | To Date: " 
        		+ outputFormat.format(getMonitorReportBean().getToDate()) );
        		
        _monitorReportDesc = new String(
        		" > Monitor Name: " + getMonitorReportBean().getSelectedMonitorName() +
        		" | Employee Number: " + employeeNumber +
        		" | Monitor Category: " + getMonitorReportBean().getSelectedMonitorType() );  
        
        isFromDateBeforeSixMonths();
        
        if (_crnListUIData != null) {
            _crnListUIData.setFirst(0);  // set List to page 1 
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        } 
    }
     
    // ==========================================================================
    // Getters and Setters
    // ==========================================================================
    
    /** set List UI data */
    public void setUIData(UIData uiData) {
    	_crnListUIData = uiData;
    }

    /** get List UI data */
    public UIData getUIData() {
        return _crnListUIData;
    }
    
    /**
     * Get the _monitorReportDesc.
     * @return the _monitorReportDesc
     */
    public String getMonitorReportDesc(){
    	return _monitorReportDesc;
    }
    /**
     * @param monitorReportSelect the _monitorReportSelect to set
     */
    public String getMonitorReportSelect(){
    	return _monitorReportSelect;
    }
    /**
     * Get the column value for the table.
     * @return column value
     */
    public Object getColumnValue() {
        Object columnValue = null;
        
        if (_dataModel.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue = ((List) _dataModel.getRowData()).get(_columnHeaders.getRowIndex());
        }
        return columnValue;
    }
    
    /**
     * Get the column width for the table.
     * @return column width
     */
    public String getColumnWidth() {
        String columnWidth = null;
        if (_dataModel.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnWidth = ((ColumnHeader) _columnHeaders.getRowData()).getWidth();
        }
        return columnWidth;
    }
    
    /**
     * First column (account) is a link to get to details
     * @return true if it is first column
     */
    public boolean isLink() {
        boolean valueLink = false;
        
        if (_dataModel.isRowAvailable() && _columnHeaders.isRowAvailable() &&
        		(_dataModel.getRowIndex() != _dataModel.getRowCount())) {
            valueLink = ((_columnHeaders.getRowIndex() == 0) && 
            !getColumnValue().equals("0") && !isToDateBeforeSixMonths());
        }
        return valueLink;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getRowsPerPage() {
        // if no data then no rows 
        if (_dataModel == null) return 0;
       
        // if less than a page, then return actual number of rows
        int rows = _dataModel.getRowCount();
        if (rows > MAX_ROWS)
            return MAX_ROWS;
        else
            return rows;
    }
    
    public DataModel getColumnHeaders() {
        return _columnHeaders;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getCount() {   
        return _size;
    }
    /**
     * Get the size of the list of tracking numbers for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getSize()
     */
    public int getSize() {
        int size = 0;
        
    	MonitorReportBean monitorReportBean = getMonitorReportBean();
    	
        if (monitorReportBean != null) {
        	size = getMonitorReportCount(monitorReportBean);
        }
        _size = size;
        return size;
    }
    
    /**
     * Get the specified page from the backend/database for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getPage(int, int)
     */
    public List getPage(int page, int pageSize) {
        int startIndex = (page-1) * pageSize;
        int endIndex = (page * pageSize);
          
    	List shipments = null;
    	MonitorReportBean monitorReportBean = getMonitorReportBean();
    	
        if (monitorReportBean != null) {
        	_getMonitorsList = getMonitorReportList(getMonitorReportBean(), 
        			startIndex,  endIndex, getSort(), isAscending());
        	shipments = populateMonitorReportList();
        }
        return shipments;
    }
    
    /**
     * Get the Monitor Report data model list
     * @return DataModel
     */
    public DataModel getData() {
        if (_shipments == null) {
            // shipments are cached here, and since we are request scope, and since getData() can be 
            // called multiple times, we only get from DB once.  And since we are request scope it is 
            // gotten fresh each request.
            _shipments = new PagedList(this, PAGE_SIZE);
        }      
        sort(getSort(), isAscending());
        
        _dataModel = new com.fedex.rise.util.ListDataModel(_shipments);
        return _dataModel;
    }
    
    /**
     * setData only called to update data if 'preservedatamodel=true' in dataTable on jsp
     * @param dataModel
     */
    public void setData(DataModel dataModel) {
        System.out.println("preserved datamodel updated");
        _dataModel = dataModel;
        
        // don't recreate shipment, because after saving state we
        // want to re-populate the shipment list.
       //_getMonitorsList = (List)dataModel.getWrappedData();
    }
    
    
    public String performanceDetail(){
    	return "crnListPage";
    }

    /**
     * Determine if the FromDate is less than 6 months from today.
     * @return true if the FromDate is less than 6 months from today.
     */
    public boolean isFromDateLessThanSixMonths(){
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.MONTH, -6);
    	boolean fromDateLessThanSixMonths 
    		= getMonitorReportBean().getFromDate().before(today.getTime());
    	if (fromDateLessThanSixMonths){
    		log.info("All tracking numbers may not be displayed, because the detail shipment data is purged after six months.");
        	FacesMessage facesMessage = new FacesMessage(
        		FacesMessage.SEVERITY_WARN, 
        		"All tracking numbers may not be displayed, because the detail shipment data is purged after six months.", 
        		null);
        	facesContext.addMessage(null, facesMessage);
    	}
        
    	return fromDateLessThanSixMonths;
    	
    }
    
    /**
     * pagingActionListener
     * 
     * @param event
     * @throws AbortProcessingException
     */
    public void pagingAction(ActionEvent event) throws AbortProcessingException {
        if (_crnListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        } 
    }
    
    /** 
     * Navigation to get CRNs (list of CRNs for this account,lane,etc)
     * @return
     */
    public String refreshAction() {
        if (_crnListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        }
        return "success";
    }
    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        return false;
    }

    protected void sort(final String column, final boolean ascending) {
        // sort handled by SQL in database, but we still need the column and ascending info
    }
    
    // =========================================================================
    // Private Methods
    // =========================================================================
    /**
     * Get the list of all valid monitors
     * @return
     */
    private List getMonitors() {
    	UserDelegate userDelegate = new UserDelegate();
        List users = userDelegate.getUsers();
        List monitors = new ArrayList(users.size());
        for (Iterator itr=users.iterator(); itr.hasNext(); ) {
            EmployeeVO user = (EmployeeVO)itr.next();
            if (user.get_emp_role_cd().equals("M")) {
                monitors.add(user);
            }
        }
        return monitors;
    }
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      shipperDelegate = new ShipperDelegate();
    }
    
    /**
     * Return a list of monitor data.
     * @return
     */
    private List getMonitorReportList(MonitorReportBean monitorReportBean) {
    	log.debug("Entering getMonitorReportList()");
        	
        return shipperDelegate.getMonitorReportList(
        	monitorReportBean.getSelectedMonitorName(),
        	monitorReportBean.getSelectedMonitorType(),
        	monitorReportBean.getFromDate(),
        	monitorReportBean.getToDate());
    }  
   
    /**
     * Return a list of monitor data.
     * @return
     */
    private int getMonitorReportCount(MonitorReportBean monitorReportBean) {
    	log.debug("Entering getMonitorReportCount()");
        	
        return shipperDelegate.getMonitorReportCount(
        	monitorReportBean.getSelectedMonitorName(),
        	monitorReportBean.getSelectedMonitorType(),
        	monitorReportBean.getFromDate(),
        	monitorReportBean.getToDate());
    }
    
    /**
     * Return a list of monitor data.
     * @return
     */
    private List getMonitorReportList(MonitorReportBean monitorReportBean,
    		int startIndex, int endIndex, String sortColumn, 
    		boolean isSortAscending) {
    	log.debug("Entering getMonitorReportList()");
        	
        return shipperDelegate.getMonitorReportDetailList(
        	monitorReportBean.getSelectedMonitorName(),
        	monitorReportBean.getSelectedMonitorType(),
        	monitorReportBean.getFromDate(),
        	monitorReportBean.getToDate(),
        	startIndex, endIndex, sortColumn, isSortAscending);
    }
    
    private int getColumnIndex(final String columnName) {
        int columnIndex = -1;
        List headers = (List) _columnHeaders.getWrappedData();
        for (int i = 0; i < headers.size() && columnIndex == -1; i++) {
            ColumnHeader header = (ColumnHeader) headers.get(i);
            if (header.getLabel().equals(columnName)) {
                columnIndex = i;
            }
        }
        return columnIndex;
    }
    
    
    /**
     * Get the selected tree node (account, lane, service, etc.)
     * @return String
     */
    private MonitorReportBean getMonitorReportBean() {
        Map params = FacesContext.getCurrentInstance().getExternalContext().
        	getSessionMap();
        MonitorReportBean monitorReportBean = 
        	(MonitorReportBean)params.get("MonitorReportBean");
        return monitorReportBean;
    }
    
    /**
     * Get the list of MonitorReport (data rows)
     */
    private List populateMonitorReportList() {
       
    	if (_getMonitorsList == null) {
            // no selection, so no data
            return null;
         } else {
            // node selected so get data for this account, lane, service, etc.
            List rowList = new ArrayList();
            
            // create data rows (list of lists)
            Iterator itr=_getMonitorsList.iterator();
            
            while (itr.hasNext()) {
         	   MonitorReportVO monitorReportVO = (MonitorReportVO) itr.next();
                List monitorReportVOList = new ArrayList();
                
                // Insert the tracking unique number if null
                String trackingUniqueNbr = new String(" ");
                if (monitorReportVO.get_trkng_item_uniq_nbr() == null){
                	monitorReportVO.set_trkng_item_uniq_nbr(trackingUniqueNbr);
                }
                            
                // Insert display string of the ship date
                String shipDateStr = new String(" ");
                if (monitorReportVO.get_ship_dt() != null){
                	DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
                	shipDateStr = df.format(monitorReportVO.get_ship_dt()); 
                }
                monitorReportVO.set_ship_dt_str(shipDateStr);
                
                String commitDateStr = new String(" ");
                if (monitorReportVO.get_commit_dt() != null){
                	DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm"); 
                	df.setTimeZone(monitorReportVO.get_commit_dt().getTimeZone());
                	Date commitDate = monitorReportVO.get_commit_dt().getTime();
                	commitDateStr = df.format(commitDate); 
                }
                monitorReportVO.set_commit_dt_str(commitDateStr);
                  
                
                String phoneNbrStr = new String(" ");
                if (monitorReportVO.get_recp_ph_nbr() == null){
                	monitorReportVO.set_recp_ph_nbr(phoneNbrStr);
                }
                
                String typeCode = RiseIssues.getIssueTypeCode(monitorReportVO.get_issue_type_cd());
                String issueTypeCode = new String(" ");
                if (typeCode != null) {
                	issueTypeCode = typeCode;
                } 
                monitorReportVO.set_issue_type_scan(issueTypeCode);
                
                IssueDesc desc = RiseIssues.getIssueDesc(monitorReportVO.get_issue_type_cd());
                String shortDesc = new String(" ");
                if (desc != null) {
                    shortDesc = desc.getShortTextDesc();
                }
                monitorReportVO.set_issue_type_name(shortDesc);
                
                rowList.add(monitorReportVO); 
            }
            return rowList;
         }
    }
    
    
    /**
     * Determine if the ToDate is before 6 months from today.
     * @return true if the ToDate is before 6 months from today.
     */
    private boolean isToDateBeforeSixMonths(){
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.MONTH, -6);
    	boolean toDateBeforeSixMonths 
    		= getMonitorReportBean().getToDate().before(today.getTime());
    	return toDateBeforeSixMonths;
    	
    }
    
    /**
     * Get the employee number.
     * @return employee number
     */
    private String getEmployeeNumber(){
    	List monitors = getMonitors();
    	String employeeNumber = new String(" ");
    	if (monitors != null) {
    		Iterator itr=monitors.iterator();
    		while (itr.hasNext()) {
    			EmployeeVO employeeVO = (EmployeeVO) itr.next();
    			if (getMonitorReportBean().getSelectedMonitorName().compareToIgnoreCase(
    				employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm())== 0){
    				employeeNumber = employeeVO.get_emp_nbr();
    			}
    		}
    	}
    	return employeeNumber;
    }
    
    /**
     * Determine if the FromDate is before 6 months from today.
     * @return true if the FromDate is before 6 months from today.
     */
    private void isFromDateBeforeSixMonths(){
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.MONTH, -6);
    	boolean fromDateLessThanSixMonths 
    		= getMonitorReportBean().getFromDate().before(today.getTime());
    	if (fromDateLessThanSixMonths){
    		log.info("All tracking numbers may not be displayed, because the detail shipment data is purged after six months.");
        	FacesMessage facesMessage = new FacesMessage(
        		FacesMessage.SEVERITY_WARN, 
        		"All tracking numbers may not be displayed, because the detail shipment data is purged after six months.", 
        		null);
        	facesContext.addMessage(null, facesMessage);
    	}
    }
    
    // ==========================================================================
    // Navigation methods
    // ==========================================================================

    /**
     * Navigation to get the CRN details
     * @return
     */
    public String getCRNDetail() {
    	MawbBean selectedMawbBean = null; 
        FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
        
        String trackingNbr = getMonitorReportBean().getSelectedTrackingNbr();
        String trackingUniqNbr = getMonitorReportBean().getSelectedTrackingUniqueNbr();
        CrnBean  _selectedCrnBean =  shipmentDelegate.getCrn(trackingNbr, trackingUniqNbr);
        
        if (trackingNbr != null && trackingUniqNbr != null) {
        	
        	if (_selectedCrnBean.getAssociatedShipments() != null){
        		List associatedShipmentsList = _selectedCrnBean.getAssociatedShipments();
        		Iterator iter = associatedShipmentsList.iterator();
                while(iter.hasNext()) {
                    AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                    if (assocShipmentVO.get_assoc_track_type_cd() == 'P'){
                    	if (assocShipmentVO.get_assoc_trkng_item_nbr() != null
                    			&& assocShipmentVO.get_assoc_trkng_item_uniq_nbr() != null){
                    		selectedMawbBean = shipmentDelegate.getMAWB(
                    				assocShipmentVO.get_assoc_trkng_item_nbr(), 
                    				assocShipmentVO.get_assoc_trkng_item_uniq_nbr());
                    		
                    	}
                    	
                    }
                }
        		
        	}
        	
            // tell the controller which bean is selected, because the controller is session scope,
            // but we are only request scope
            Map sessionParams = context.getExternalContext().getSessionMap();
            MonitorTreeBean _monitorTreeBean = (MonitorTreeBean)sessionParams.get("monitorTreeBean");
            
            UserBean user = (UserBean)sessionParams.get("UserBean");
            _monitorTreeBean = new MonitorTreeBean(user);
            	
            if (selectedMawbBean == null){
            	ShipmentVO shipment = _selectedCrnBean.getShipment();
            	List shipmentReferences = _selectedCrnBean.getShipmentReferences();
            	List associatedShipments = _selectedCrnBean.getAssociatedShipments();
            	List comments = _selectedCrnBean.getComments();
            	List events = _selectedCrnBean.getEvents();
            	List issues = _selectedCrnBean.getIssues();
            	
            	selectedMawbBean = new MawbBean(shipment, 
            			shipmentReferences, associatedShipments, comments, 
            			events, issues);
            }
            	
            _monitorTreeBean.setSelectedMAWB(selectedMawbBean);
            _monitorTreeBean.setSelectedCRN(_selectedCrnBean);
            sessionParams.put("monitorTreeBean", _monitorTreeBean);
            
       
            // navigate to the detail screen
            return "showCrnDetail";
        } else {
            // shouldn't happen
            return null;
        }
    }
}
