package com.fedex.rise.ejb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PoisonPillHandler {
	
    private static List poisonPillList = Collections.synchronizedList(new ArrayList());
    private static boolean autoDelete = false;

    public static void addPoisionPill(String anId) {
        if (!poisonPillList.contains(anId)) {
            poisonPillList.add(anId);
        }
    }
    
    public static boolean checkPoisonPillList(String anId) {
        if (poisonPillList.size() != 0) {
            if (poisonPillList.contains(anId)) {
                poisonPillList.remove(anId);
                return true;
            }
        }
        return false;
    }
    
    public static void autoDelete(String checked) {
        if (checked != null) {
        	autoDelete = true;
        }else{
        	autoDelete = false;          
        }
    }
    
    public static boolean getAutoDelete() {
        return autoDelete;
    }
    
    public static List getPoisonPillList() {
        return poisonPillList;
    }

}
