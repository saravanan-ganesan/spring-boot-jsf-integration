package com.fedex.rise.format;

/**
 * Format the Lane
 */
public class LaneFormatter {
 
    /**
     * Format lane like "originCountryCd-destCountryCd"
     * 
     * @param originCountryCd
     * @param destCountryCd
     * @return formatted lane
     */
    public static String format(String originCountryCd, String destCountryCd) {
   
        StringBuffer sb = new StringBuffer();
        if (originCountryCd != null) {
            sb.append(originCountryCd).append('-');
            if (destCountryCd != null) 
                sb.append(destCountryCd);
            else
                sb.append('?');
        }
            
        return sb.toString();
    }
}
