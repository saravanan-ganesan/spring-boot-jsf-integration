package com.fedex.rise.auth;

import java.util.Map;

import javax.faces.context.FacesContext;

import org.apache.myfaces.custom.security.SecurityContext;

import com.fedex.rise.bean.UserBean;

/**
 * 
 * @author cagatay
 */
public class SecurityContextImpl extends SecurityContext{

    public String getAuthType() {
        return "FORM";
    }

    public String getRemoteUser() {
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        UserBean userBean = (UserBean)params.get("UserBean");
        return userBean.getUserId();
    }

    public boolean ifGranted(String role) {
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        UserBean userBean = (UserBean)params.get("UserBean");
        if (userBean.getRole().equals(role))
           return true;
        else 
           return false;
    }
}

