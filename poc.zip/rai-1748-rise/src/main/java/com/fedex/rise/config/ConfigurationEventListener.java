package com.fedex.rise.config;

public interface ConfigurationEventListener
{
    public void processConfigurationEvent();
}
