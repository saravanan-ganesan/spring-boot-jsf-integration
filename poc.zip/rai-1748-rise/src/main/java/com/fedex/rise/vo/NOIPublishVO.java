package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

public class NOIPublishVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trk_item_nbr;
    private Date _ship_date;
    private Date _trk_date_time;
    private Date _input_timestamp;
    private Date _publish_date;
    
    /**
     * @return the _trk_item_nbr
     */
    public String get_trk_item_nbr() {
        return _trk_item_nbr;
    }
    /**
     * @param _trk_item_nbr the _trk_item_nbr to set
     */
    public void set_trk_item_nbr(String _trk_item_nbr) {
        this._trk_item_nbr = _trk_item_nbr;
    }
    /**
     * @return the _ship_date
     */
    public Date get_ship_date() {
        return _ship_date;
    }
    /**
     * @param _ship_date the _ship_date to set
     */
    public void set_ship_date(Date _ship_date) {
        this._ship_date = _ship_date;
    }
    /**
     * @return the _trk_date_time
     */
    public Date get_trk_date_time() {
        return _trk_date_time;
    }
    /**
     * @param _trk_date_time the _trk_date_time to set
     */
    public void set_trk_date_time(Date _trk_date_time) {
        this._trk_date_time = _trk_date_time;
    }
    /**
     * @return the _trk_scan_time
     */
    public Date get_input_timestamp() {
        return _input_timestamp;
    }
    /**
     * @param _trk_scan_time the _trk_scan_time to set
     */
    public void set_input_timestamp(Date _input_timestamp) {
        this._input_timestamp = _input_timestamp;
    }
    /**
     * @return the _publish_date
     */
    public Date get_publish_date() {
        return _publish_date;
    }
    /**
     * @param _publish_date the _publish_date to set
     */
    public void set_publish_date(Date _publish_date) {
        this._publish_date = _publish_date;
    }
    public String toString() {
        return _trk_item_nbr;        
    }
}
