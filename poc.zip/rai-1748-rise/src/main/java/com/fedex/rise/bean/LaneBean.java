package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.format.LaneFormatter;
import com.fedex.rise.vo.LaneVO;

/**
 * Backer bean for Lanes.
 * 
 */
public class LaneBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(LaneBean.class);

    /** delegate to get shipper data */
    private ShipperDelegate shipperDelegate = new ShipperDelegate();
    
    private String _selectedLane = null;
    private String _originCountryCd = null;
    private String _destCountryCd = null;
    
    /** cached list of lanes */
    private List _allLanes = new ArrayList();
 
 
    /*---------------------------------------------------------------------
     * Actions
     *--------------------------------------------------------------------- 
     */
    
   
    /**
     * Get all possible Lanes
     * @return List of SelectItems for the lanes
     */
    public List getAllLanes() {
        _allLanes = shipperDelegate.getLanes();
        List laneSelectItems = new ArrayList(_allLanes.size());
        for (Iterator itr=_allLanes.iterator(); itr.hasNext(); ) {
            LaneVO lane = (LaneVO)itr.next();
            String laneStr = LaneFormatter.format(lane.get_orig_cntry_cd(),
                      lane.get_dest_cntry_cd());
            laneSelectItems.add(new SelectItem(Integer.toString(lane.get_lane_nbr()), laneStr));
            
            // reselect the selected lane
            if (lane.get_orig_cntry_cd().equals(_originCountryCd) && 
                lane.get_dest_cntry_cd().equals(_destCountryCd)) {
                _selectedLane = String.valueOf(lane.get_lane_nbr());
            }
        }
        return laneSelectItems;
    }
    
    /**
     * @return the destCountryCd
     */
    public String getDestCountryCd() {
        return _destCountryCd;
    }

    /**
     * @param destCountryCd the destCountryCd to set
     */
    public void setDestCountryCd(String destCountryCd) {
        _destCountryCd = destCountryCd;
    }

    /**
     * @return the originCountryCd
     */
    public String getOriginCountryCd() {
        return _originCountryCd;
    }

    /**
     * @param originCountryCd the originCountryCd to set
     */
    public void setOriginCountryCd(String originCountryCd) {
        _originCountryCd = originCountryCd;
    }

    /**
     * @return the selectedLane
     */
    public String getSelectedLane() {
        return _selectedLane;
    }

    /**
     * @param selectedLane the selectedLane to set
     */
    public void setSelectedLane(String selectedLane) {
        _selectedLane = selectedLane;
    }

    /**
     * @return a list of all 2-letter country codes defined in ISO 3166
     */
    public List getCountryCodes() {
        String[] countries = java.util.Locale.getISOCountries();
        List countryItems = new ArrayList(countries.length);
        for (int i=0; i<countries.length; i++)
            countryItems.add(new SelectItem(countries[i]));
        return countryItems;
    }

    /**
     * Add a new Lane 
     */
    public String addLaneAction() {
        log.info("Add Lane()");

        String laneStr = LaneFormatter.format(_originCountryCd,_destCountryCd);
      
        // Determine if this is a duplicate Lane
        boolean isDup = false;
        for (Iterator itr=_allLanes.iterator(); itr.hasNext(); ) {
            LaneVO lane = (LaneVO)itr.next();
            if (lane.get_orig_cntry_cd().equals(_originCountryCd) && 
                lane.get_dest_cntry_cd().equals(_destCountryCd)) {
                isDup = true;
            }
        }

        FacesContext facesContext = FacesContext.getCurrentInstance(); 
        if (isDup) { 
            // don't allow duplicates, DB contraints won't catch this
            log.info("Lane already exists: " + laneStr);
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Lane already exists: " + laneStr, null);
            facesContext.addMessage(null, facesMessage);
        } else {
            if (shipperDelegate.addLane(_originCountryCd, _destCountryCd)) {
                FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO, "Lane added: " + laneStr, null);
                facesContext.addMessage(null, facesMessage);
            } else {
                log.info("Delete Lane failed: " + _selectedLane);
                FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Add failed", null);
                facesContext.addMessage(null, facesMessage);
            }
        }
       
        // return to same page, for error or success
        return "success";  
    }
   
    /**
     * Delete the selected Lane
     */
    public String deleteLaneAction() {
        log.info("Delete Lane");
        
        // selected lane is the key (lane_nbr)
        FacesContext facesContext = FacesContext.getCurrentInstance(); 
        if (shipperDelegate.deleteLane(_selectedLane)) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO, "Lane deleted", null);
            facesContext.addMessage(null, facesMessage);
        } else {
            log.info("Delete Lane failed: " + _selectedLane);
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                    "Delete failed, make sure the lane isn't assigned to an Account", null);
            facesContext.addMessage(null, facesMessage);
        }
        
        // return to same page, for error or success
        return "success"; 
    }
}
