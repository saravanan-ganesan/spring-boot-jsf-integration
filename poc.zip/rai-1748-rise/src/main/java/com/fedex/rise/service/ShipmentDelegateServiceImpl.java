package com.fedex.rise.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.rise.repository.ShipmentDelegateRepository;

@Service
public class ShipmentDelegateServiceImpl implements ShipmentDelegateService {

	@Autowired
	ShipmentDelegateRepository shipmentDelegateRepository;
	
	@Override
	public List<Integer> getFilterByIssues() {
		
		return shipmentDelegateRepository.getFilterByIssues();

	}

}
