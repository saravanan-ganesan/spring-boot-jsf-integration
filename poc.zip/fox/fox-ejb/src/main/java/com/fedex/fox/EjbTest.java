package com.fedex.fox;

public class EjbTest {

}
