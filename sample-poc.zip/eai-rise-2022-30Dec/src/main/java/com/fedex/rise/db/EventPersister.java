package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EventVO;

public class EventPersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(EventPersister.class);
    
    public EventPersister(Connection con) {
        super(con);
    }
    
    private static final String insertEventSQL =
        "Insert into Event(" +
        "TRKNG_ITEM_NBR," +           // VARCHAR2(12) 
        "TRKNG_ITEM_UNIQ_NBR," +      // VARCHAR2(10)
        "TRACK_TYPE_CD," +            // VARCHAR2(2)
        "EVENT_CRTN_TMSTP," +         // TIMESTAMP(6)
        "EVENT_CRTN_TMZN_OFFST_NBR," + // VARCHAR2(5)
        "TRKNG_ITEM_ENTRY_TYPE_CD," + // VARCHAR2(3),
        "ECCO_TYPE_CD," +             // CHAR(1),
        "ECCO_COMM_CD," +             // CHAR(1),
        "TRACK_EXCP_CD," +            // CHAR(2),
        "TRACK_LOC_CD," +             // VARCHAR2(5),
        "ADMIN_LOC_CD," +             // VARCHAR2(5),
        "SCAN_EMP_NBR," +             // VARCHAR,
        "TRACK_SRC_CD," +             // CHAR(1),
        "EVENT_SQNC_NBR," +           // NUMBER(12) not null,
        "EVENT_NOTE_DESC," +
        "INPUT_TMSTP," +              // TimeStamp
        "LAST_UPDT_TMSTP)" +
        "values(?,?,?,?,?,?,?,?," +   // 8
               "?,?,?,?,?,?,?, SYSDATE, SYSDATE)";    // 16
    
    public boolean persist(EventVO aEventVO) throws SQLException {
        try {
            setSqlSignature( insertEventSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aEventVO.get_trkng_item_nbr());
            pstmt.setString( 2, aEventVO.get_trkng_item_uniq_nbr());
            pstmt.setString( 3, aEventVO.get_track_type_cd());
            //logger.debug("Time into database:" + aEventVO.get_event_crtn_tmstp().getTimeInMillis());
            java.sql.Timestamp timeStamp = new java.sql.Timestamp(aEventVO.get_event_crtn_tmstp().getTimeInMillis());
            pstmt.setTimestamp( 4, timeStamp);
            pstmt.setString( 5, formatTZ(aEventVO.get_event_crtn_tmstp().getTimeZone().getID()));
            pstmt.setString( 6, aEventVO.get_trkng_item_entry_type_cd());
            pstmt.setString( 7, String.valueOf(aEventVO.get_ecco_type_cd()));
            pstmt.setString( 8, String.valueOf(aEventVO.get_ecco_comm_cd()));
            pstmt.setString( 9, aEventVO.get_track_excp_cd());
            pstmt.setString(10, aEventVO.get_track_loc_cd());
            pstmt.setString(11, aEventVO.get_admin_loc_cd());
            pstmt.setString(12, aEventVO.get_scan_emp_nbr());
            pstmt.setString(13, aEventVO.get_track_src_cd());
            pstmt.setString(14, aEventVO.get_event_sqnc_nbr());
            pstmt.setString(15, aEventVO.get_event_note_desc());

            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();
            
            return true;
        } catch (SQLException sqle) {
            if (sqle.getMessage().indexOf("ORA-00001") != -1) {
                return false;
            }
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }    
 
}
