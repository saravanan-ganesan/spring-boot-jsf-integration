package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

/**
 * Note that this will also update the MAWB, have to do that so that the MAWB detail page will show the correct
 * date.
 *
 */

public class CrnCommitDateAdjuster extends OracleBase {
   private static Logger logger = LogManager.getLogger(CrnCommitDateAdjuster.class);
    
    public CrnCommitDateAdjuster(Connection con) {
        super(con);
    }    
    
    private static final String crnAttrUpdaterSQL = "update Shipment s set s.ADJ_COMMIT_DT_OFFST_NBR = ? " +
        "where " +
        "(s.trkng_item_nbr, s.trkng_item_uniq_nbr) in " +
        "(select trkng_item_nbr, trkng_item_uniq_nbr from Associated_Shipment a " +     
        "Where a.assoc_trkng_item_nbr = ? and " +
        "a.assoc_trkng_item_uniq_nbr = ? and " +
        "a.ASSOC_TRACK_TYPE_CODE = 'P')";
    
    public void adjustCRNCommitDates(int aCRNDeliveryDtAdjustment, String aTrkngItemNbr,
            String aTrkngItemUniqNbr) throws SQLException {

        try {
            setSqlSignature(crnAttrUpdaterSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, aCRNDeliveryDtAdjustment);
            pstmt.setString(2, aTrkngItemNbr);
            pstmt.setString(3, aTrkngItemUniqNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
    
    private static final String mawbAttrUpdaterSQL = "update Shipment s set s.ADJ_COMMIT_DT_OFFST_NBR = ? " +
    "where " +
    "s.trkng_item_nbr = ? and " +
    "s.trkng_item_uniq_nbr = ? ";
    
    public void adjustMAWBCommitDates(int aCRNDeliveryDtAdjustment, String aTrkngItemNbr,
            String aTrkngItemUniqNbr) throws SQLException {

        try {
            setSqlSignature(mawbAttrUpdaterSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, aCRNDeliveryDtAdjustment);
            pstmt.setString(2, aTrkngItemNbr);
            pstmt.setString(3, aTrkngItemUniqNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
}
