package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIData;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.tree2.TreeNode;
import org.springframework.beans.factory.annotation.Autowired;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.bo.SearchDelegate;
import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.service.SearchDelegateService;
import com.fedex.rise.util.Pageable;
import com.fedex.rise.util.PagedList;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.AssociatedShipmentVO;
import com.fedex.rise.vo.ShipmentEmployeeVO;
import com.fedex.rise.vo.ShipmentVO;

import lombok.extern.slf4j.Slf4j;

/**
 * MAWB Summary List Backing bean
 */
@JsfController(path = "/searchResultsFindPackagesCRNByRecipientName", page = "/pages/jsp/searchResultsFindPackagesCRNByRecipientName.jsp", value = "MAWBSearchListBeanFindPackagesCRNByRecipientName")
@Slf4j

public class MAWBSearchListBeanFindPackagesCRNByRecipientName extends SortableList implements Serializable, Pageable {
	
	@Autowired
	SearchBeanfindPackagesCRN searchBeanfindPackagesCRN;
	
	@Autowired
	SearchDelegateService searchDelegateService;
	
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(MAWBListBean.class);
    
    private static final int PAGE_SIZE = 50;
    
    /** delegate to get shipment data */
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();    
    
    /** delegate to get shipment data */
    private transient SearchDelegate searchDelegate = new SearchDelegate();
   
    /** list of shipments (MAWBBean) */
    private List _shipments = null;
    private transient DataModel _dataModel = null;
    
    /** UIData component binding to MAWB List table.  Here so we can reset to page 1 after tree node selection */
    private transient UIData _crnListUIData;
    
	/**
     * Constructor
     */
    public MAWBSearchListBeanFindPackagesCRNByRecipientName() {
        super("ship_dt");  // default sort column
        
        if (_crnListUIData != null) {
            _crnListUIData.setFirst(0);  // set MAWB List to page 1 
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        } 
    }

    
    // ==========================================================================
    // Getters
    // ==========================================================================
    /** set MAWBList UI data */
    public void setUIData(UIData uiData) {
    	_crnListUIData = uiData;
    }

    /** get MAWBList UI data */
    public UIData getUIData() {
        return _crnListUIData;
    }
    
    /**
     * Get the MAWB data model list
     */
    public DataModel getData() {
        // shipments are cached here, and since we are request scope, and since getData() can be 
        // called multiple times, we only get from DB once.  And since we are request scope it is 
        // gotten fresh each request.
        if (_shipments == null) {
            _shipments = new PagedList(this, PAGE_SIZE);
        }
        
        _dataModel = new com.fedex.rise.util.ListDataModel(_shipments);
        return _dataModel;
    }

    /**
     * setData only called to update data if 'preservedatamodel=true' in dataTable on jsp
     * @param dataModel
     */
    public void setData(DataModel dataModel) {
        //log.debug("preserved datamodel updated");
        _dataModel = dataModel;
        
        // don't recreate shipment, because after saving state (dimwgt, invoice amt) we
        // want to re-populate the shipment list.
        //_shipments = (List)_dataModel.getWrappedData();
    }
   
    /*-----------------------------------------------------------------------
     * Methods for call back from PagedList 
     *-----------------------------------------------------------------------
     */
   
    /**
     * Get the specified page from the backend/database for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getPage(int, int)
     */
    public List getPage(int page, int pageSize) {
       // Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        //SearchBean _searchBean = (SearchBean)params.get("SearchBean");
      
    
        int startIndex = (page-1) * pageSize;
        int endIndex = (page * pageSize);
          
        List shipments;
        
        shipments = searchDelegateService.searchByRecipientName(searchBeanfindPackagesCRN.getRecipientName(),
            		searchBeanfindPackagesCRN.getLimitOneWeekToDateByCRNRecipientName(), searchBeanfindPackagesCRN.getLimitOneWeekFromDateByCRNRecipientName(),
            		getSort(), isAscending(), startIndex, endIndex); 
            
        
//        if (SearchBean.checkResult.equals("recipientName")){        
//        shipments = searchDelegate.searchByRecipientName(_searchBean.getRecipientName(),
//                _searchBean.getLimitOneWeekToDateByCRNRecipientName(), _searchBean.getLimitOneWeekFromDateByCRNRecipientName(),
//        		getSort(), isAscending(), startIndex, endIndex);        
//        }else if (SearchBean.checkResult.equals("postalCode")){        
//            shipments = searchDelegate.searchByPostalCode(_searchBean.getLimitOneWeekToDateByCRNRecipientPostalCode(), 
//            		_searchBean.getLimitOneWeekFromDateByCRNRecipientPostalCode(), _searchBean.getPostalCode(), 
//             		getSort(), isAscending(), startIndex, endIndex);        
//        }else if (SearchBean.checkResult.equals("withODACRN")){        
//            shipments = searchDelegate.searchByWithODACRN(_searchBean.getAcctNbr(), _searchBean.getLimitOneWeekToDateByCRNWithODA(), 
//            		_searchBean.getLimitOneWeekFromDateByCRNWithODA(), 
//             		getSort(), isAscending(), startIndex, endIndex);        
//        }else if (SearchBean.checkResult.equals("searchByAddress")){        
//            shipments = searchDelegate.searchByAddressCRN(_searchBean.getAddressLineOne(), _searchBean
//                    .getAddressCityName(), _searchBean.getAddressStateProvince(), _searchBean
//                    .getAddressPostalCode(), _searchBean.getLimitOneWeekToDateByCRNRecipientAddress(), 
//            		_searchBean.getLimitOneWeekFromDateByCRNRecipientAddress(), 
//             		getSort(), isAscending(), startIndex, endIndex);        
//        }else if (SearchBean.checkResult.equals("returnTrkngNbr")){        
//            shipments = searchDelegate.searchByReturnTrkngNbr(_searchBean.getReturnTrkngNbr(), 
//             		getSort(), isAscending(), startIndex, endIndex);        
//        }else if (SearchBean.checkResult.equals("trackingNbrMAWB")){        
//            shipments = searchDelegate.searchByTrkngNbrMAWB(_searchBean.getTrackingNbrMAWB(),
//                    _searchBean.getLimitOneWeekToDateByMAWBTrackingNumber(), _searchBean.getLimitOneWeekFromDateByMAWBTrackingNumber(),
//            		getSort(), isAscending(), startIndex, endIndex);        
//        }else if (SearchBean.checkResult.equals("acctNmMAWB")){        
//            shipments = searchDelegate.searchByAcctNmMAWB(_searchBean.getAcctNmMAWB(),
//                    _searchBean.getLimitOneWeekToDateByMAWBShipperName(), _searchBean.getLimitOneWeekFromDateByMAWBShipperName(),
//            		getSort(), isAscending(), startIndex, endIndex);   
//        }else{       	
//        shipments = searchDelegate.rampHubSearch(_searchBean.getShipDate(), 
//        		_searchBean.getSelectMenu(), _searchBean.getClearancePoint(),
//        		getSort(), isAscending(), startIndex, endIndex);
//        }
        
        return shipments;
    }


     /**
     * Get the size of the list of tracking numbers for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getSize()
     */
    public int getSize() {
        int size = 0;
        
        //Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        //SearchBean _searchBean = (SearchBean)params.get("SearchBean");
        
        size = searchDelegateService.getCRNShipmentsCountRecipientName(searchBeanfindPackagesCRN.getRecipientName(),
        		searchBeanfindPackagesCRN.getLimitOneWeekToDateByCRNRecipientName(), searchBeanfindPackagesCRN.getLimitOneWeekFromDateByCRNRecipientName());
        
//        if (SearchBean.checkResult.equals("recipientName")){
//            size = searchDelegate.getCRNShipmentsCountRecipientName(_searchBean.getRecipientName(),
//                    _searchBean.getLimitOneWeekToDateByCRNRecipientName(), _searchBean.getLimitOneWeekFromDateByCRNRecipientName());
//        }else if (SearchBean.checkResult.equals("postalCode")){
//            size = searchDelegate.getCRNShipmentsCountRecipientPostalCode(_searchBean.getPostalCode(), 
//            		_searchBean.getLimitOneWeekToDateByCRNRecipientPostalCode(), _searchBean.getLimitOneWeekFromDateByCRNRecipientPostalCode());
//        }else if (SearchBean.checkResult.equals("withODACRN")){
//            size = searchDelegate.getCRNShipmentsCountWithODA(_searchBean.getAcctNbr(), 
//            		_searchBean.getLimitOneWeekToDateByCRNWithODA(), _searchBean.getLimitOneWeekFromDateByCRNWithODA());
//        }else if (SearchBean.checkResult.equals("searchByAddress")){
//            size = searchDelegate.getCRNShipmentsCountRecipientAddress(_searchBean.getAddressLineOne(), _searchBean
//                    .getAddressCityName(), _searchBean.getAddressStateProvince(), _searchBean
//                    .getAddressPostalCode(), _searchBean.getLimitOneWeekToDateByCRNRecipientAddress(), _searchBean.getLimitOneWeekFromDateByCRNRecipientAddress());
//        }else if (SearchBean.checkResult.equals("returnTrkngNbr")){
//            size = searchDelegate.getCRNShipmentsCountReturnTrackingNumber(_searchBean.getReturnTrkngNbr());
//        }else if (SearchBean.checkResult.equals("trackingNbrMAWB")){
//            size = searchDelegate.getCRNShipmentsCountTrackingNumber(_searchBean.getTrackingNbrMAWB(),
//                    _searchBean.getLimitOneWeekToDateByMAWBTrackingNumber(), _searchBean.getLimitOneWeekFromDateByMAWBTrackingNumber());
//        }else if (SearchBean.checkResult.equals("acctNmMAWB")){
//            size = searchDelegate.getCRNShipmentsCountShipperName(_searchBean.getAcctNmMAWB(),
//                    _searchBean.getLimitOneWeekToDateByMAWBShipperName(), _searchBean.getLimitOneWeekFromDateByMAWBShipperName());
//        }else{       	
//        	size = searchDelegate.getMAWBShipmentsCount(_searchBean.getShipDate(), 
//        		_searchBean.getSelectMenu(), _searchBean.getClearancePoint());
//        }
        
        
        return size;
    }
      
    /**
     * pagingActionListener
     * 
     * @param event
     * @throws AbortProcessingException
     */
    public void pagingAction(ActionEvent event) throws AbortProcessingException {
        if (_crnListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        } 
    }
    
    /** 
     * Navigation to get CRNs (list of CRNs for this account,lane,etc)
     * @return
     */
    public String refreshAction() {
        if (_crnListUIData != null) {
            // clear list so it is refreshed, even after validation error
            _crnListUIData.getChildren().clear(); 
        }
        return "success";
    }
    
    /**
     * Get the total number of packages.
     * 
     */
    public int getTotalNumberPackages() {
        int totalNumberPackages = 0;
        
        if (_shipments!=null){
        	// create data rows (list of lists)
            Iterator itr=_shipments.iterator();
            while (itr.hasNext()) {
            	ShipmentEmployeeVO shipmentEmployeeVO = (ShipmentEmployeeVO)itr.next();
            	totalNumberPackages+=shipmentEmployeeVO.get_shpmt_pkg_qt();
            }
        	
        }
        
        return totalNumberPackages;
    }
    
    /**
     * Get the total weight (Kg).
     * 
     */
    public double getTotalWeight() {
        double totalWeight = 0;
        
        if (_shipments!=null){
        	// create data rows (list of lists)
            Iterator itr=_shipments.iterator();
            while (itr.hasNext()) {
            	ShipmentEmployeeVO shipmentEmployeeVO = (ShipmentEmployeeVO)itr.next();
            	totalWeight+=shipmentEmployeeVO.get_shpmt_wgt_double();
            }
            long totalWeightlong = (long)(totalWeight*10); // truncate
            totalWeight = (double)(totalWeightlong)/10;
        }
        
        return totalWeight;
    }

    
    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        if (sortColumn.equals("ship_dt"))
            return false; // sort descending by default on ship_dt
        else 
            return true; // sort ascending by default
    }
    
    protected void sort(final String column, final boolean ascending) {
        // sort handled by SQL in database, but we still need the column and ascending info
    }
   
    // ==========================================================================
    // Navigation methods
    // ==========================================================================

    /**
     * Navigation to get the MAWB details
     * @return
     */
//    public String getMAWBDetail() {
//		FacesContext context = FacesContext.getCurrentInstance();
//		Map requestParams = context.getExternalContext().getRequestParameterMap();
//
//		String trackingNbr = (String) requestParams.get("trkng_item_nbr");
//		String trackingUniqNbr = (String) requestParams.get("trkng_item_uniq_nbr");
//		
//		MawbBean _selectedMawbBean = shipmentDelegate.getMAWB(trackingNbr,trackingUniqNbr);
//
//		if (trackingNbr != null && trackingUniqNbr != null) {
//			// tell the controller which bean is selected, because the
//			// controller is session scope,
//			// but we are only request scope
//			Map sessionParams = context.getExternalContext().getSessionMap();
//			MonitorTreeBean _monitorTreeBean = (MonitorTreeBean) sessionParams.get("monitorTreeBean");
//
//			//Start WR#:179441 Changes
//			UserBean user = (UserBean) sessionParams.get("UserBean");
//			_monitorTreeBean = new MonitorTreeBean(user);
//			_monitorTreeBean.setCheckMawbDetailsPage("FindShipmentMawbsByTrackingNumber");
//			//End WR#:179441 Changes
//			
//			_monitorTreeBean.setSelectedMAWB(_selectedMawbBean);
//			
//			//Start WR#:179441 Changes
//			_monitorTreeBean.setNodePathDesc(null);
//			sessionParams.put("monitorTreeBean", _monitorTreeBean);
//			//End WR#:179441 Changes
//
//			// navigate to the detail screen
//			log.info("Select MAWB Detail: " + trackingNbr);
//			return "showMawbDetail";
//		} else {
//			// shouldn't happen
//			return null;
//		}
//	}
    
//    public String getCRNDetail() {
//    	MawbBean selectedMawbBean = null; 
//        FacesContext context = FacesContext.getCurrentInstance(); 
//        Map requestParams = context.getExternalContext().getRequestParameterMap();
//    
//        String trackingNbr = (String)requestParams.get("trkng_item_nbr");
//        String trackingUniqNbr = (String)requestParams.get("trkng_item_uniq_nbr");
//        CrnBean  _selectedCrnBean =  shipmentDelegate.getCrn(trackingNbr, trackingUniqNbr);
//        
//        if (trackingNbr != null && trackingUniqNbr != null) {
//        	
//        	if (_selectedCrnBean.getAssociatedShipments() != null){
//        		List associatedShipmentsList = _selectedCrnBean.getAssociatedShipments();
//        		Iterator iter = associatedShipmentsList.iterator();
//                while(iter.hasNext()) {
//                    AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
//                    if (assocShipmentVO.get_assoc_track_type_cd() == 'P'){
//                    	if (assocShipmentVO.get_assoc_trkng_item_nbr() != null
//                    			&& assocShipmentVO.get_assoc_trkng_item_uniq_nbr() != null){
//                    		selectedMawbBean = shipmentDelegate.getMAWB(
//                    				assocShipmentVO.get_assoc_trkng_item_nbr(), 
//                    				assocShipmentVO.get_assoc_trkng_item_uniq_nbr());
//                    		
//                    	}
//                    	
//                    }
//                }
//        		
//        	}
//        	
//            // tell the controller which bean is selected, because the controller is session scope,
//            // but we are only request scope
//            Map sessionParams = context.getExternalContext().getSessionMap();
//            MonitorTreeBean _monitorTreeBean = (MonitorTreeBean)sessionParams.get("monitorTreeBean");
//            
//            UserBean user = (UserBean)sessionParams.get("UserBean");
//            _monitorTreeBean = new MonitorTreeBean(user);
//            	
//            if (selectedMawbBean == null){
//            	ShipmentVO shipment = _selectedCrnBean.getShipment();
//            	List shipmentReferences = _selectedCrnBean.getShipmentReferences();
//            	List associatedShipments = _selectedCrnBean.getAssociatedShipments();
//            	List comments = _selectedCrnBean.getComments();
//            	List events = _selectedCrnBean.getEvents();
//            	List issues = _selectedCrnBean.getIssues();
//            	
//            	selectedMawbBean = new MawbBean(shipment, 
//            			shipmentReferences, associatedShipments, comments, 
//            			events, issues);
//            }
//            	
//            _monitorTreeBean.setSelectedMAWB(selectedMawbBean);
//            _monitorTreeBean.setSelectedCRN(_selectedCrnBean);
//            sessionParams.put("monitorTreeBean", _monitorTreeBean);
//            
//       
//            // navigate to the detail screen
//            return "showCrnDetail";
//        } else {
//            // shouldn't happen
//            return null;
//        }
//    }         
    
    public String backButton(){
    	FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
    
        String fromScreen = (String)requestParams.get("from_screen");
        
        if (fromScreen != null){
        	if (fromScreen.equals("searchResultsFindPackagesCRNByRecipientName")){
        		return "searchResultsFindPackagesCRNByRecipientName";
        	}else if (fromScreen.equals("searchResultsFindPackagesCRNByRecipientPostalCode")){
        		return "searchResultsFindPackagesCRNByRecipientPostalCode";
        	}else if (fromScreen.equals("searchResultsFindPackagesCRNByWithODA")){
        		return "searchResultsFindPackagesCRNByWithODA";
        	}else if (fromScreen.equals("searchResultsFindPackagesCRNByRecipientAddress")){
        		return "searchResultsFindPackagesCRNByRecipientAddress";
        	}else if (fromScreen.equals("searchResultsFindPackagesCRNByReturnTrackingNumber")){
        		return "searchResultsFindPackagesCRNByReturnTrackingNumber";
        	}        	
        }
        return null;
    }    
    // ==========================================================================
    // Private Methods
    // ==========================================================================
   
    /*-----------------------------------------------------------------------
     * Utility methods
     *-----------------------------------------------------------------------
     */
   
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        searchDelegate = new SearchDelegate();
    }

  //Start WR#:179441 Changes
    public String reset(){
    	Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        SearchBean _searchBean = (SearchBean) params.get("SearchBean");
        
    	_searchBean.reset();
    	
    	if(_searchBean.checkResult.equalsIgnoreCase("trackingNbr") || _searchBean.checkResult.equalsIgnoreCase("referenceNbr") ){
    	/*_searchBean.checkResult=null;*/
    	return "FindShipmentMawbs";
    	}
    	else
    	{
    	/*_searchBean.checkResult=null;*/
        return "FindShipmentMawbs";
        }
    //End WR#:179441 Changes
   }
    
}
