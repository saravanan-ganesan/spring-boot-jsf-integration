package com.fedex.rise.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.rise.repository.ShipmentDelegateRepository;

@Service
public class ShipmentDelegateServiceImpl implements ShipmentDelegateService {

	@Autowired
	ShipmentDelegateRepository shipmentDelegateRepository;
	
	@Override
	public List<Integer> getFilterByIssues() {
		
		return shipmentDelegateRepository.getFilterByIssues();

	}

	@Override
	public List getFilterByIssuesDetails(List<String> issueTypeCodes, int dateValue) {
		List<Integer> typeCodes=issueTypeCodes.stream().map(s-> Integer.parseInt(s)).collect(Collectors.toList());
		// System.out.println("Type Codess:: " + typeCodes);
		return shipmentDelegateRepository.getFilterByIssuesDetails(dateValue, typeCodes);
		//return typeCodes;
	}

}
