package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EmployeeVO;

public class EmployeePersister extends OracleBase {

    private static Logger logger = LogManager.getLogger(EmployeePersister.class);
    
    public EmployeePersister(Connection con) {
        super(con);
    }
    
    private static final String addEmployeeSQL =
            "Insert into Employee(" +
            "EMP_NBR, " +
            "EMP_FIRST_NM, " +
            "EMP_LAST_NM, " +
            "EMP_ROLE_CD, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP) " +
             "values(?,?,?,?,SYSDATE,SYSDATE)";        
    
    public void addEmployee(EmployeeVO anEmployeeVO) throws SQLException {
        
        try {
            setSqlSignature( addEmployeeSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anEmployeeVO.get_emp_nbr());
            pstmt.setString( 2, anEmployeeVO.get_emp_first_nm());
            pstmt.setString( 3, anEmployeeVO.get_emp_last_nm());
            pstmt.setString( 4, anEmployeeVO.get_emp_role_cd());
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }       
}
