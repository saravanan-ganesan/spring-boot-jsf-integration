package com.fedex.rise.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.ShipmentEmployeeVO;

@Service
public interface SearchDelegateService {

	public List<ShipmentEmployeeVO> searchByShprNm(String aShprNm);
	public List<ShipmentEmployeeVO> searchByAcctNbr(String aAcctNbr);
	public List<ShipmentEmployeeVO> searchByTrkngNbr(String aTrkngNbr);
	public List<Object> searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu, Date _limitOneWeekFromDate, Date _limitOneWeekToDate);
	public List<Object> searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber,
			Date _limitOneWeekFromDateByMAWBTrackingNumber, String sortColumn, boolean isSortAscending,int startIndex, int endIndex);
	public List<Object> searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName,
			Date _limitOneWeekFromDateByMAWBShipperName, String sortColumn, boolean isSortAscending,int startIndex, int endIndex);
	public List<Object> searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN, String aAcctNbrCRN, Date _toDate4, Date _fromDate4);
	public List<Object> searchByReturnTrkngNbr(String aReturnTrkngNbr, String sortColumn, boolean isSortAscending, int startIndex, int endIndex);
	public List<Object> searchByRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName,
			Date _limitOneWeekFromDateByCRNRecipientName, String sortColumn, boolean isSortAscending,int startIndex, int endIndex);
	public List<Object> searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2, String aSelectedLane2);
	public List<Object> searchByPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode,
			Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, String sortColumn, boolean isSortAscending,int startIndex, int endIndex);
	public List<Object> rampHubSearch(Date _shipDate, String _selectMenu,String aClearancePoint, String sortColumn, boolean isSortAscending,int startIndex, int endIndex);
	public List<Object> searchByFindMonitorAcctNbr(String aAcctNbr);
	public List<Object> searchByFindMonitorTrkngNbr(String aTrackingNbr);
	public List<Object> searchByWithODACRN(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA,
			Date _limitOneWeekToDateByCRNWithODA, String sortColumn, boolean isSortAscending, int startIndex, int endIndex);
	public List<Object> searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2);
	public List<Object> searchByFindMissingData(String aAcctNbr);
	public List<Object> searchByAddressCRN(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince,
			String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress,
			Date _limitOneWeekFromDateByCRNRecipientAddress, String sortColumn, boolean isSortAscending,int startIndex, int endIndex);
	public List<Object> searchByShipDateRange(Date _limitOneWeekToDate3,Date _limitOneWeekFromDate3,
			String aServiceCode,String aAcctNbrMAWB3, String aSelectedLane, String sortColumn,boolean ascending);
	public int getCRNShipmentsCountReturnTrackingNumber(String returnTrkngNbr);
	public int getCRNShipmentsCountRecipientName(String recipientName, Date limitOneWeekToDateByCRNRecipientName,
			Date limitOneWeekFromDateByCRNRecipientName);
	public int getCRNShipmentsCountWithODA(String acctNbr, Date limitOneWeekToDateByCRNWithODA,
			Date limitOneWeekFromDateByCRNWithODA);
	public int getCRNShipmentsCountRecipientPostalCode(String postalCode,
			Date limitOneWeekToDateByCRNRecipientPostalCode, Date limitOneWeekFromDateByCRNRecipientPostalCode);
	public int getCRNShipmentsCountRecipientAddress(String addressLineOne, String addressCityName,
			String addressStateProvince, String addressPostalCode, Date limitOneWeekToDateByCRNRecipientAddress,
			Date limitOneWeekFromDateByCRNRecipientAddress);
	
	
	//Performance Tab - Employee drop down
	public List<EmployeeVO> getSearchByAll();
	
	public List<EmployeeVO> searchByGroupLaneNbr(int groupNbr, int laneNbr);
}
