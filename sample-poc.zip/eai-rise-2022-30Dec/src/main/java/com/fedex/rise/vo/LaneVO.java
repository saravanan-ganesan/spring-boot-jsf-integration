package com.fedex.rise.vo;

import java.io.Serializable;

public class LaneVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int    _lane_nbr;
    private String _orig_cntry_cd;
    private String _dest_cntry_cd;
    
    public LaneVO(int _lane_nbr, String _orig_cntry_cd, String _dest_cntry_cd) {
        super();
        this._lane_nbr = _lane_nbr;
        this._orig_cntry_cd = _orig_cntry_cd;
        this._dest_cntry_cd = _dest_cntry_cd;
    }
    
    public LaneVO() {
    }

    /**
     * @return the _dest_cntry_cd
     */
    public String get_dest_cntry_cd() {
        return _dest_cntry_cd;
    }
    /**
     * @param _dest_cntry_cd the _dest_cntry_cd to set
     */
    public void set_dest_cntry_cd(String _dest_cntry_cd) {
        this._dest_cntry_cd = _dest_cntry_cd;
    }
    /**
     * @return the _lane_nbr
     */
    public int get_lane_nbr() {
        return _lane_nbr;
    }
    /**
     * @param _lane_nbr the _lane_nbr to set
     */
    public void set_lane_nbr(int _lane_nbr) {
        this._lane_nbr = _lane_nbr;
    }
    /**
     * @return the _orig_cntry_cd
     */
    public String get_orig_cntry_cd() {
        return _orig_cntry_cd;
    }
    /**
     * @param _orig_cntry_cd the _orig_cntry_cd to set
     */
    public void set_orig_cntry_cd(String _orig_cntry_cd) {
        this._orig_cntry_cd = _orig_cntry_cd;
    }

}
