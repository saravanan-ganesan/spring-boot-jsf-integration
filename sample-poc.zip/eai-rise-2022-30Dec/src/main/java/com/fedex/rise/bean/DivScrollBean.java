package com.fedex.rise.bean;

import java.io.Serializable;

/**
 * Backer bean for Scrolling DIV, to save the scrolling position between submits.
 * 
 */
public class DivScrollBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    /** 
     * this is to set and get the DIV tag scroller positions, so after browser
     * submits, the scroll position can be restored
     */
    private String divScrollerPosition = null;
    
   
    /** 
     * Get the DIV tag scroller position, so we can restore the position
     * @return divScrollerPosition
     */
    public String getDivScrollerPosition() {
        return divScrollerPosition;
    }
    
    /**
     * Set the DIV tag scroller position, so we can save the position
     * @param divScrollerPosition
     */
    public void setDivScrollerPosition(String divScrollerPosition) {
        this.divScrollerPosition = divScrollerPosition;
    }

}

