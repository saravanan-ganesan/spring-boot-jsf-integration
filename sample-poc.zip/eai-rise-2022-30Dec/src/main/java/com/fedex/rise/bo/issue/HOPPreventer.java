package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class HOPPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(HOPPreventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static HOPPreventer _instance = new HOPPreventer();

    static {
        // The previous scans below will prevent a new issue being created.
    	_preventingScans.add(RiseConstants.ROP);
    	_preventingScans.add(RiseConstants.SIP);
       	_preventingScans.add(RiseConstants.VAN);
       	_preventingScans.add(RiseConstants.DEX);
    }
  
    private HOPPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	// If it has been delivered, do not create any new events.
        if (DeliveryPreventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (_preventingScans.contains(anPastEventVO.get_track_type_cd())) {
            logger.debug("Issue prevented by HOP Preventer.");
            return true;
        }
             
        return false;
    }

    public static HOPPreventer getInstance() {
        return _instance;
    }
}
