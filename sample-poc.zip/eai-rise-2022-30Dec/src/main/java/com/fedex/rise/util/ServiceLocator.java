package com.fedex.rise.util;

import com.fedex.rise.config.*;

import java.util.*;
import javax.ejb.*;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.naming.*;
import javax.rmi.*;
import javax.sql.*;
import javax.transaction.*;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

/**
 * This class is an implementation of the Service Locator pattern. It is used to
 * lookup/locate JNDI resources such as EJBHomes, JMS Destinations, Data Sources
 * and application properties. It also implements the Singleton pattern, so that
 * only once instance of it exists in the Java VM and thus we can cache the
 * looked up resources.
 */

public class ServiceLocator {
    /** Context of container */
    private InitialContext context = null;
    /** Cache of already looked up resources */
    private Map cache = null;
    /** Service locator singleton */
    private static ServiceLocator serviceLocator = null;

    /**
     *  The -D appContainer system property is to indicate that the
     *  ServiceLocator is being referenced from the app container.
     */
    private static final String APP_CONTAINER_KEY = "appContainer";

    /**
     *  The -D webContainer system property is to indicate that the
     *  ServiceLocator is being referenced from the web container.
     */
    private static final String WEB_CONTAINER_KEY = "webContainer";

    /** Logger */
    private static Logger logger = LogManager.getLogger(ServiceLocator.class);


    // Singleton initialization
    static
    {
        serviceLocator = new ServiceLocator();
    }

    /**
     * This constructor instantiates an instance of ServicleLocator. It is
     * private, so we can enforce the singleton pattern.
     */
    private ServiceLocator()
    {
        super();
    }

    /**
     * Intializes the locator and context
     *
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    private void initialize() throws ServiceLocatorException
    {
        try {
            // App Tier within WL Container
            if (isInsideAppContainer()) {
                context = new InitialContext();
                cache = Collections.synchronizedMap(new HashMap(8));
            }
            // Web Tier or outside WL Container
            // To be used by clients to connect to the Weblogic instance.  
            // The ESETestClient uses it to locate the EJB to send in test messages.
            else {
                String providerUrl = ConfigurationManager.get( "EJB_PROVIDER_URL", "t3://localhost:7001").trim();
                String user = ConfigurationManager.get( "WEBLOGIC_USER", "weblogic" ).trim();
                String password = ConfigurationManager.get( "WEBLOGIC_PASSWORD", "weblogi1" ).trim();

                Hashtable env = new Hashtable(4);
                env.put(Context.PROVIDER_URL, providerUrl);
//                env.put(Context.INITIAL_CONTEXT_FACTORY,
//                        weblogic.jndi.WLInitialContextFactory.class.getName());
                env.put( Context.SECURITY_PRINCIPAL, user);
                env.put( Context.SECURITY_CREDENTIALS, password);
                context = new InitialContext(env);

                cache = Collections.synchronizedMap(new HashMap(1));
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't initialize Context", ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }
    }

    /**
     * Determine if the service locator is running in the app container. The
     * presence of the "appContainer" name in the System properties is
     * used to determine this.
     *
     * @return true if running inside app container, otherwise false.
     */
    public static boolean isInsideAppContainer() {
       String name = System.getProperty(APP_CONTAINER_KEY);
       if ((name != null) && (name.equals("false"))) {
          return false;
       } else {
          return true;
       }
    }

    /**
     * Determine if the service locator is running in the web container. The
     * presence of the "webContainer" name in the System properties is
     * used to determine this.
     *
     * @return true if running inside web container, otherwise false.
     */
    public static boolean isInsideWebContainer() {
       String name = System.getProperty(WEB_CONTAINER_KEY);
       if (name == null) {
          return false;
       } else {
          return true;
       }
    }

    /**
     * This method implements singleton for the service locator.
     *
     * @return ServiceLocator
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public static ServiceLocator getInstance() throws ServiceLocatorException
    {
        // Do initialization here and not in the constructor or the static
        // initializer block at top, because if an exception is thrown from the
        // constructor, we'll ultimately get an ExceptionInInitializerError and
        // after that you can't access the class without getting a NoClassDefFoundError.
        if (serviceLocator.context == null) {
            serviceLocator.initialize();
        }

        return serviceLocator;
    }

    /**
     * This method returns the JMS queue connection factory based on the JNDI
     * connection factory name.
     *
     * @param connectionFactoryName The JNDI name for the connection factory.
     * @return javax.jms.QueueConnectionFactory The queue connection factory.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public QueueConnectionFactory getQueueConnectionFactory(String connectionFactoryName) throws ServiceLocatorException
    {
        QueueConnectionFactory queueConnectionFactory = null;

        try {
            if (cache.containsKey(connectionFactoryName))
                queueConnectionFactory = (QueueConnectionFactory) cache.get(connectionFactoryName);
            else {
                queueConnectionFactory = (QueueConnectionFactory) context.lookup(connectionFactoryName);
                cache.put(connectionFactoryName, queueConnectionFactory);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + connectionFactoryName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return queueConnectionFactory;
    }

    /**
     * This method returns the JMS queue bound to the JNDI queue name.
     *
     * @param queueName java.lang.String The JNDI name for the queue.
     * @return javax.jms.Queue
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public Queue getQueue(String queueName) throws ServiceLocatorException
    {
        Queue queue = null;

        try {
            if (cache.containsKey(queueName))
                queue = (Queue) cache.get(queueName);
            else {
                queue = (Queue) context.lookup(queueName);
                cache.put(queueName, queue);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + queueName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return queue;
    }

    /**
     * This method returns the JMS topic connection factory based on the JNDI
     * connection factory name.
     *
     * @param topicConnFactoryName The JNDI name for the topic connection factory.
     * @return javax.jms.TopicConnectionFactory The topic connection factory.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public  TopicConnectionFactory getTopicConnectionFactory(String topicConnFactoryName) throws ServiceLocatorException {
        TopicConnectionFactory factory = null;

        try {
            if (cache.containsKey(topicConnFactoryName)) {
                factory = (TopicConnectionFactory) cache.get(topicConnFactoryName);
            } else {
                factory = (TopicConnectionFactory) context.lookup(topicConnFactoryName);
                cache.put(topicConnFactoryName, factory);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + topicConnFactoryName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return factory;
    }

    /**
     * This method returns the JMS topic destination bound to the JNDI topic name.
     *
     * @param topicName java.lang.String The JNDI name for the topic
     * @return javax.jms.Topic
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public  Topic getTopic(String topicName) throws ServiceLocatorException {
        Topic topic = null;

        try {
            if (cache.containsKey(topicName)) {
                topic = (Topic) cache.get(topicName);
            } else {
                topic = (Topic) context.lookup(topicName);
                cache.put(topicName, topic);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + topicName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return topic;
    }

    /**
     * This method retrieves the data source based on JNDI data source name.
     *
     * @param java.lang.String dataSourceName The JNDI data source name.
     * @return java.sql.DataSource Factory for connection pooling.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public  DataSource getDataSource(String dataSourceName) throws ServiceLocatorException
    {
        DataSource dataSource = null;

        try {
            if (cache.containsKey(dataSourceName))
                dataSource = (DataSource) cache.get(dataSourceName);
            else {
                dataSource = (DataSource) context.lookup(dataSourceName);
                cache.put(dataSourceName, dataSource);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + dataSourceName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return dataSource;
    }

    /**
     * This method returns the LocalHome for the specified JNDI name.
     *
     * @param localHomeName java.lang.String The JNDI ejb local home name.
     * @return javax.ejb.EJBLocalHome
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public EJBLocalHome getLocalHome(String localHomeName) throws ServiceLocatorException
    {
        EJBLocalHome localHome = null;


        try {
            if (cache.containsKey(localHomeName))
                localHome = (EJBLocalHome) cache.get(localHomeName);
            else {
                localHome = (EJBLocalHome) context.lookup(localHomeName);
                cache.put(localHomeName, localHome);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + localHomeName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return localHome;
    }

    /**
     * This method returns the EJBHome for the specified JNDI name and class type.
     *
     * @param remoteHomeName java.lang.String The JNDI ejb remote home name.
     * @param cls java.lang.Class The class to return.
     * @return javax.ejb.EJBHome.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public EJBHome getRemoteHome(String remoteHomeName, Class cls) throws ServiceLocatorException
    {
        EJBHome ejbHome = null;

        try {
            if (cache.containsKey(remoteHomeName))
                ejbHome = (EJBHome) cache.get(remoteHomeName);
            else {
                Object objRef = context.lookup(remoteHomeName);
                ejbHome = (EJBHome) PortableRemoteObject.narrow(objRef, cls);
                cache.put(remoteHomeName, ejbHome);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + remoteHomeName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return ejbHome;
    }

    /**
     * This method retrieves the string value based on the JNDI variable name.
     *
     * @param variableName Pass in the variable name.
     * @return The property value.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public String getString(String variableName) throws ServiceLocatorException
    {
        String value = null;

        try {
            if (cache.containsKey(variableName))
                value = (String) cache.get(variableName);
            else {
                value = (String) context.lookup(variableName);
                cache.put(variableName, value);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + variableName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return value;
    }

    /**
     * This method retrieves the boolean value based on the JNDI variable name.
     *
     * @param variableName Pass in the variable name.
     * @return The property value.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public boolean getBoolean(String variableName) throws ServiceLocatorException {
        Boolean bool = null;

        try {
            if (cache.containsKey(variableName))
                bool = (Boolean) cache.get(variableName);
            else {
                bool = (Boolean) context.lookup(variableName);
                cache.put(variableName, bool);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + variableName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return bool.booleanValue();
    }

    /**
     * This method retrieves the UserTransaction from initial context it is never
     * cached since it is not factory (like DataSource or QueueConnectionFactory).
     * The container is required to make the JTA available at the location
     * java:comp/UserTransaction so no parameter needs to be passed in.
     *
     * @return The UserTransaction to be use for client-initiated or bean managed
     * (programmatic) transactions.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public synchronized UserTransaction getUserTransaction() throws ServiceLocatorException
    {
        String variableName = "java:comp/UserTransaction";
        UserTransaction userTransaction = null;

        try {
            userTransaction = (UserTransaction) context.lookup(variableName);
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + variableName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return userTransaction;
    }

    /**
     * This method retrieves the UserTransaction based on the JNDI variable name.
     *
     * @param variableName Pass in the variable name.
     * @return The UserTransaction to be use for client-initiated or bean managed
     * (programmatic) transactions.
     * @throws ServiceLocatorException Encapsulates all types of exceptions.
     */
    public UserTransaction getUserTransaction(String variableName) throws ServiceLocatorException
    {
        UserTransaction userTransaction = null;

        try {
            if (cache.containsKey(variableName))
              userTransaction = (UserTransaction) cache.get(variableName);
            else {
              userTransaction = (UserTransaction) context.lookup(variableName);
              cache.put(variableName, userTransaction);
            }
        } catch (NamingException ne) {
            throw new ServiceLocatorException("Can't find " + variableName, ne);
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }

        return userTransaction;
    }

   /**
    * This method clears the cache and resets the context.  This
    * method is useful when retry logic is needed to reestablish
    * the connection to the respective tier (back-end).
    */
   public void clearCacheAndContext()
   {
       cache.clear();
       cache = null;
       context = null;
   }

   /**
    * This method resets/clears the key and value from the cache.  This
    * method is useful when used with retry logic to force a lookup to the
    * initial context. The caller must cast to the corresponding object if a
    * non-value is returned. If null value is return to object was found with
    * variable name passed in.
    *
    * @param variableName Pass in the variable name to remove from the cache.
    * @return An object value that was associated with the variable name is returned.
    *
    */
   public Object resetKeyValue(String variableName)
   {
       return cache.remove(variableName);
   }
}
