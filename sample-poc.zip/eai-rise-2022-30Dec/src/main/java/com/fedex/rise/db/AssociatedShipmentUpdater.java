package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AssociatedShipmentVO;

public class AssociatedShipmentUpdater extends OracleBase {
   private static Logger logger = LogManager.getLogger(AssociatedShipmentUpdater.class);
    
    public AssociatedShipmentUpdater(Connection con) {
        super(con);
    }
    
    private static final String updateAssocShipmentSQL = 
        "update Associated_Shipment set " +         
            "ASSOC_TRKNG_ITEM_UNIQ_NBR = ?, " + 
            "LAST_UPDT_TMSTP = SYSDATE " +
        "where " +
          "TRKNG_ITEM_NBR = ? and " +           
          "TRKNG_ITEM_UNIQ_NBR = ? and " +      
          "ASSOC_TRKNG_ITEM_NBR = ?";
  

    public void updateAssocShipment(AssociatedShipmentVO anAssociatedShipmentVO) throws SQLException {
    
        try {
            setSqlSignature( updateAssocShipmentSQL, false, logger.isDebugEnabled() );
           
            pstmt.setString( 1, anAssociatedShipmentVO.get_assoc_trkng_item_uniq_nbr());
            pstmt.setString( 2, anAssociatedShipmentVO.get_trkng_item_nbr());
            pstmt.setString( 3, anAssociatedShipmentVO.get_trkng_item_uniq_nbr());
            pstmt.setString( 4, anAssociatedShipmentVO.get_assoc_trkng_item_nbr());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
         
            int rowsUpdated = executeUpdate();

            if ( rowsUpdated == 0) {
                // Shipment not updated
                logger.error("Associated Shipment not Updated for : " +
                        anAssociatedShipmentVO.get_trkng_item_nbr() + ":" + anAssociatedShipmentVO.get_trkng_item_uniq_nbr());
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
    }
}
