package com.fedex.rise.service;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ShipmentDelegateService {

	public List<Integer> getFilterByIssues();
	public List getFilterByIssuesDetails(List<String> issueTypeCodes, int dateValue);
}
