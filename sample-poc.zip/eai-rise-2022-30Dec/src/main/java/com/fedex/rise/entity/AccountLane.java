package com.fedex.rise.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ACCOUNT_LANE")
public class AccountLane {
	
	@Id
	private int group_nbr;
	
    private String acct_nbr;
    private int    lane_nbr;
    private String rtrn_acct_nbr;
    private String rtrn_addr_line_one_desc;
    private String rtrn_addr_line_two_desc;
    private String rtrn_addr_line_three_desc;
    private String rtrn_city_nm;
    private String rtrn_st_prov_cd;
    private String rtrn_cont_nm;
    private String rtrn_cont_ph_nbr;
    private String im_of_rec_nm;
    private String im_of_rec_addr_line_one_desc;
    private String im_of_rec_addr_line_two_desc;
    private String im_of_rec_city_nm;
    private String im_of_rec_st_prov_cd;
    private String im_of_rec_pstl_cd;
    private String im_of_rec_cont_nm;
    private String im_of_rec_ph_nbr;
    private String im_of_rec_fax_nbr;
    private String im_of_rec_email_desc;
    private String orig_acct_exec_nm;
    private String orig_acct_exec_ph_nbr;
    private String orig_acct_exec_fax_nbr;
    private String orig_acct_exec_email_desc;
    private String dest_acct_exec_nm;
    private String dest_acct_exec_ph_nbr;
    private String dest_acct_exec_fax_nbr;
    private String dest_acct_exec_email_desc;
    private String brkr_nm;
    private String brkr_ph_nbr;
    private String brkr_fax_nbr;
    private String prim_engnr_nm;
    private String prim_engnr_ph_nbr;
    private String prim_engnr_fax_nbr;
    private String prim_engnr_email_desc;
    private String scndy_engnr_nm;
    private String scndy_engnr_ph_nbr;
    private String scndy_engnr_fax_nbr;
    private String scndy_engnr_email_desc;

}
