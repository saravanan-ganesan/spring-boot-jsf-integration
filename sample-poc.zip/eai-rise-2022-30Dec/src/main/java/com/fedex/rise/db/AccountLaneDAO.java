package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.LaneVO;

public class AccountLaneDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AccountLaneDAO.class);
    
    /**
     * Get the Lanes for an account
     * @param shipperNbr
     * @param accountNbr
     * @return List of AccountLaneVO
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public List getAccountLane(int shipperNbr, String accountNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            AccountLaneAccessor accountLaneAccessor 
            	= new AccountLaneAccessor(connection);
            list = accountLaneAccessor.getAccountLanes(shipperNbr, accountNbr);
        } finally {
            closeConnection(connection);
        }
        return list;
    }
    
    /**
     * Get the Lanes for a group number
     * @param groupNbr
     * @return List of AccountLaneVO
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public List getAccountLane(int groupNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            AccountLaneAccessor accountLaneAccessor 
            	= new AccountLaneAccessor(connection);
            list = accountLaneAccessor.getAccountLanes(groupNbr);
        } finally {
            closeConnection(connection);
        }
        return list;
    }
    
    /**
     * Get all of the LaneVOs for a group number.
     * @param groupNbr
     * @return List of LaneVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getAllLanes(int groupNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        List accountLanelist = null;
        List laneList = null;

        try {
            connection = initializeConnection();
            AccountLaneAccessor accountLaneAccessor 
            	= new AccountLaneAccessor(connection);
            LaneAccessor laneAccessor = new LaneAccessor(connection);
            
            accountLanelist= accountLaneAccessor.getAccountLanes(groupNbr);
            laneList = new ArrayList(accountLanelist.size());
            for (Iterator itr= accountLanelist.iterator(); itr.hasNext(); ) {
            	AccountLaneVO accountLaneVO = (AccountLaneVO)itr.next();
            	LaneVO laneVO = laneAccessor.getLane(accountLaneVO.get_lane_nbr());
            	laneList.add(laneVO);
            }
        } finally {
            closeConnection(connection);
        }
        return laneList;
    }
  
    /**
     * Get a AccountLane 
     * @param shipperNbr
     * @param accountNbr
     * @param laneNbr
     * @return AccountLaneVO
     * @throws ServiceLocatorException 
     * @throws Exception 
     */
    public AccountLaneVO getAccountLane(int shipperNbr, String accountNbr, int laneNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        AccountLaneVO accountLaneVO = null;

        try {
            connection = initializeConnection();
            AccountLaneAccessor accountLaneAccessor 
            	= new AccountLaneAccessor(connection);
            accountLaneVO = accountLaneAccessor.getAccountLane(shipperNbr, accountNbr, laneNbr);
        } finally {
            closeConnection(connection);
        }
        return accountLaneVO;
    }
  
    /**
     * Add a lane to an account
     * @param anAccountLaneVO
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public void addAccountLane(AccountLaneVO anAccountLaneVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountLanePersister persister = new AccountLanePersister(connection);
            persister.addAccountLane(anAccountLaneVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Add multiple lanes to an account, will determine which to add, update,
     * delete, based on what is already in the database
     * NOTE: must all be same shipperNbr, accountNbr!
     * @param anAccountLaneVOs
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public void addAccountLanes(List anAccountLaneVOs) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            if (anAccountLaneVOs == null || anAccountLaneVOs.size()<1)
                return;
           
            connection = initializeConnection();
          
            // get groupNbr and accountNbr, must be same on all in list!
            int groupNbr = ((AccountLaneVO)anAccountLaneVOs.get(0)).get_group_nbr();
            String accountNbr = ((AccountLaneVO)anAccountLaneVOs.get(0)).get_acct_nbr();
            
            // first get existing lanes for this account
            AccountLaneAccessor accountLaneAccessor = new AccountLaneAccessor(connection);
            List existingLanes = accountLaneAccessor.getAccountLanes(groupNbr, accountNbr);
           
            AccountLanePersister persister = new AccountLanePersister(connection);
            AccountLaneUpdater updater = new AccountLaneUpdater(connection);
            
            // determine which are adds or updates
            for (Iterator itr=anAccountLaneVOs.iterator(); itr.hasNext(); ) {
                AccountLaneVO accountLaneVO = (AccountLaneVO)itr.next();
                boolean updateIt = false;
                for (Iterator itr2=existingLanes.iterator(); itr2.hasNext(); ) {
                    AccountLaneVO existingAccountLaneVO = (AccountLaneVO)itr2.next();
                    if (accountLaneVO.get_lane_nbr() == existingAccountLaneVO.get_lane_nbr()) {
                        updateIt = true;
                        // remove from list so we don't iterate over it again and we
                        // can use remainder in list as our delete list
                        itr2.remove();
                        break;
                    }
                }
                
                if (updateIt) {
                   // update lane
                   updater.updateAccountLane(accountLaneVO);
                } else if (accountLaneVO.get_lane_nbr() == 0){
                   // laneNbr of 0 is a dummy lane, used to designate that there
                   // are no lanes to be assigned and any existing should be deleted
                } else {
                   // new so add it
                   persister.addAccountLane(accountLaneVO);
                }
            }
            
            // remainder in existing list are our deletes
            AccountLaneDeleter deleter = new AccountLaneDeleter(connection);
            for (Iterator itr=existingLanes.iterator(); itr.hasNext(); ) {
                AccountLaneVO accountLaneVO = (AccountLaneVO)itr.next();
                // we need to cascade deletes...
		        // so, delete all monitors at service level for this shipperNbr, accountNbr, and laneNbr
		        AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
		        acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(accountLaneVO.get_group_nbr(),
		                accountLaneVO.get_acct_nbr(), accountLaneVO.get_lane_nbr());
		        
                // and, delete all services associated with this shipperNbr, accountNbr, laneNbr
                LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
                laneServiceDAO.deleteLaneServices(accountLaneVO.get_group_nbr(), 
                        accountLaneVO.get_acct_nbr(), accountLaneVO.get_lane_nbr());
     
                deleter.deleteAccountLane(accountLaneVO);
            }
        } finally {
            closeConnection(connection);
        }
    }
    
    public void updateAccountLane(AccountLaneVO anAccountLaneVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountLaneUpdater persister = new AccountLaneUpdater(connection);
            persister.updateAccountLane(anAccountLaneVO);
        } finally {
            closeConnection(connection);
        }
    }    
    
    /**
     * Delete the specified lane
     * @param anAccountLaneVO
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public void deleteAccountLane(AccountLaneVO anAccountLaneVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountLaneDeleter deleter = new AccountLaneDeleter(connection);
            deleter.deleteAccountLane(anAccountLaneVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Delete all lanes for the specified groupNbr and accountNbr
     * @param groupNbr
     * @param accountNbr
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public void deleteAccountLanes(int groupNbr, String shipperNbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountLaneDeleter deleter = new AccountLaneDeleter(connection);
            deleter.deleteAccountLanes(groupNbr, shipperNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Get the account lane table,  list of the GROUP_NBR, ACCT_NBR, and 
     * LANE_NBR.
     * @return list of the GROUP_NBR, ACCT_NBR, and LANE_NBR.
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getAccountLaneTable() throws SQLException, ServiceLocatorException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            AccountLaneAccessor accountLaneAccessor 
            	= new AccountLaneAccessor(connection);
            list = accountLaneAccessor.getAccountLaneTable();
        } finally {
            closeConnection(connection);
        }
        return list;
    }
}
