package com.fedex.rise.format;

/**
 * Format the Service Type/Level
 */
public class ServiceTypeFormatter {
   
    /**
     * Format like "svcTypeDesc (SvcTypeCd)"
     * @param svcTypeCd
     * @param svcTypeDesc
     * @return formatted service type/level
     */
    public static String format(String svcTypeCd, String svcTypeDesc) {
        
        if (svcTypeCd == null) {
            return "";
        } else if (svcTypeDesc == null) {
            return svcTypeCd;
        } else {
            StringBuffer sb = new StringBuffer();
            sb.append(svcTypeDesc);   
            sb.append('(');
            sb.append(svcTypeCd);
            sb.append(')');
            
            return sb.toString();
        }
    }
}
