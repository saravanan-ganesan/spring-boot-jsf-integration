package com.fedex.rise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.fedex.rise.constant.AppConstant;

/**
 * This is the main class to start the application
 * 
 * @author saravanan g
 *
 */

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({AppConstant.APP_ROOT_PATH})
public class EaiRise2022Application {

	public static void main(String[] args) {
		SpringApplication.run(EaiRise2022Application.class, args);
	}

}
