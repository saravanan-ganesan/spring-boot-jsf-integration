package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class ConfigurationUpdater extends OracleBase {
private static Logger logger = LogManager.getLogger(PerformanceUpdater.class);
	
	public ConfigurationUpdater(Connection con) {
        super(con);
    }
	
	private static final String updateConfigurationRowSQL =
	    "update Configuration set " +
	    "CONFG_VALUE_DESC = ? " +
	    "where " +
	    "CONFG_VALUE_NM = ?";       

	public void updateConfiguration(String  confgValueNm, String confgValueDesc) 
		throws SQLException {
	    
	    try {
	        setSqlSignature( updateConfigurationRowSQL, false, 
	        		logger.isDebugEnabled() );
    
	        pstmt.setString( 1, confgValueDesc);
	        pstmt.setString(2, confgValueNm);
	            
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        int rowsUpdated = executeUpdate();

	        if ( rowsUpdated == 0) {
	            // Configuration not updated
	            logger.error("Configuration table not Updated for Name: " +
	            		confgValueNm + "value: " 
	                    + confgValueDesc);
	        }

	    } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	            throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
}
