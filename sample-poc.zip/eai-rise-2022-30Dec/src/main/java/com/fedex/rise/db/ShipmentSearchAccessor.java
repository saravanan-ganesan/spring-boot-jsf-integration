package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ShipmentEmployeeVO;

public class ShipmentSearchAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(MonitoredAccountsAccessor.class);

    public ShipmentSearchAccessor(Connection con) {
        super(con);
    }


    /** Sort by ship date and destination */
    private final static String orderByShipDateSQL =  " order by SHIP_DT ";
    private final static String orderByRecipientNameSQL =  " order by RECP_CO_NM ";
    private final static String orderByShipperNameSQL =  " order by SHPR_CO_NM ";
    private final static String orderByAccountNumberSQL =  " order by ACCT_NBR ";
    private final static String orderByTrackingNumberSQL =  " order by TRKNG_ITEM_NBR ";    
    private final static String orderByServiceTypeCodeSQL =  " order by SVC_TYPE_CD ";
    private final static String orderByRecipientCityNameSQL =  " order by RECP_CITY_NM ";
    private final static String orderByRecipientPostalCodeSQL =  " order by RECP_PSTL_CD ";
    private final static String orderByRecipientPhoneNumberSQL =  " order by RECP_PH_NBR ";
    private final static String orderByMonitorSQL =  " order by EMP_LAST_NM ";
    private final static String orderByEmployeeNumberSQL =  " order by EMP_NBR ";    
    
    // FIND SHIPPER BY SHIPPER NAME OR ACCOUNT NUMBER ------------------------------------
    
    private static final String getSearchByShprNmSQL = 
    	"select UNIQUE " +     
     	"ag.GROUP_NM, " + 
     	"a.ACCT_NM, " + 
    	"a.ACCT_NBR, " + 
    	"l.ORIG_CNTRY_CD, " + 
    	"l.DEST_CNTRY_CD, " +    
		"alsm.SVC_TYPE_CD, " + 
    	"e.EMP_FIRST_NM, " + 
    	"e.EMP_LAST_NM, " + 
    	"e.EMP_NBR " + 
    	"from LANE l, ACCOUNT a, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +    
    	"where Upper(ag.GROUP_NM) like Upper(?) " + 
    	"and alsm.GROUP_NBR = ag.GROUP_NBR " +  
    	"and alsm.GROUP_NBR = a.GROUP_NBR " +
     	"and alsm.ACCT_NBR = a.ACCT_NBR " +
    	"and alsm.LANE_NBR = l.LANE_NBR " +  
    	"and alsm.EMP_NBR = e.EMP_NBR";
    
 
    public List searchByShprNm(String aShprNm) throws SQLException {
        ArrayList al = new ArrayList();

        if (aShprNm == null)
            return al;
        
        try {
            setSqlSignature(getSearchByShprNmSQL, false, logger.isDebugEnabled());
            // append wildcards, SQL injection safe way
            StringBuffer shipperName = new StringBuffer("%").append(aShprNm.toUpperCase()).append("%");
            pstmt.setString(1, shipperName.toString());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipperByShipperName(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    private static final String getSearchByAcctNbrSQL = 
    	"select UNIQUE " +    
     	"ag.GROUP_NM, " +
     	"a.ACCT_NM, " +
    	"a.ACCT_NBR, " + 
    	"s.SHPR_CNTRY_CD, " +
    	"s.RECP_CNTRY_CD, " +
		"s.SVC_TYPE_CD, " +
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ACCOUNT a, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +   
    	"where Upper(a.ACCT_NBR) like Upper(?) " +
    	"and s.GROUP_NBR = ag.GROUP_NBR " +
    	"and s.GROUP_NBR = a.GROUP_NBR " +
     	"and s.ACCT_NBR = a.ACCT_NBR " +
    	"and s.GROUP_NBR = alsm.GROUP_NBR " +
     	"and s.ACCT_NBR = alsm.ACCT_NBR " +
    	"and s.LANE_NBR = alsm.LANE_NBR " +
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " +
    	"and alsm.EMP_NBR = e.EMP_NBR";

    public List searchByAcctNbr(String aAcctNbr) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByAcctNbrSQL, false, logger.isDebugEnabled());

            // append wildcards, SQL injection safe way
            StringBuffer accountNbr= new StringBuffer("%").append(aAcctNbr.toUpperCase()).append("%");
            pstmt.setString(1, accountNbr.toString());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipperByAccountNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    
    // FIND SHIPMENT BY TRACKING OR REFERENCE NUMBER -------------------------------------------
  
    private static final String getSearchByTrkngNbrSQL = 
    	"select UNIQUE " + 
    	"s.TRKNG_ITEM_NBR, " + 
    	//Start WR#:179441 Changes		
    	"s.TRKNG_ITEM_UNIQ_NBR, "+
    	//End WR#:179441 Changes
    	"s.SHPMT_TYPE_CD, " + 
    	"s.SHIP_DT, " + 
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " + 
    	"s.ACCT_NBR, " + 
    	"s.SVC_TYPE_CD, " + 
    	"ag.GROUP_NM, " + 
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " + 
    	"e.EMP_LAST_NM, " + 
    	"e.EMP_NBR " + 
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
    	"where s.TRKNG_ITEM_NBR = ? " + 
    	"and s.GROUP_NBR = ag.GROUP_NBR " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR " + 
    	"and s.LANE_NBR = alsm.LANE_NBR " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " + 
    	"and alsm.EMP_NBR = e.EMP_NBR"; 

    public List searchByTrkngNbr(String aTrkngNbr) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByTrkngNbrSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aTrkngNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentByTrackingNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    private static final String getSearchByReferenceNbrSQL = 
    
    	"select UNIQUE " + 
    	"s.TRKNG_ITEM_NBR, " +
    	"s.SHPMT_TYPE_CD, " + 
    	"s.SHIP_DT, " + 
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " + 
    	"s.ACCT_NBR, " + 
    	"s.SVC_TYPE_CD, " + 
    	"ag.GROUP_NM, " + 
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD,  " + 
    	"s.GROUP_NBR, " +
    	"s.LANE_NBR " +
        "from SHIPMENT s, ACCOUNT_GROUP ag, REFERENCE_NOTE r " +
    	"where r.REF_TYPE_CD like ? " +
    	"and r.REF_NOTE_DESC like ? " +
    	"and r.REF_CRTN_TMSTP >= ? " +
    	"and r.REF_CRTN_TMSTP <= ? " +
    	"and s.GROUP_NBR = ag.GROUP_NBR " + 
    	"and s.TRKNG_ITEM_NBR = r.TRKNG_ITEM_NBR " +
    	"and s.TRKNG_ITEM_UNIQ_NBR = r.TRKNG_ITEM_UNIQ_NBR";

    public List searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu, Date _limitOneWeekFromDate, Date _limitOneWeekToDate)
            throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByReferenceNbrSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, "%" + aReferenceNumberMenu + "%");
            pstmt.setString(2, "%" + aReferenceNbr + "%");
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDate.getTime());
            pstmt.setTimestamp(3, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDate.getTime());
            pstmt.setTimestamp(4, timeStampTo);            

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentByReferenceNote(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    
    // FIND SHIPMENTS - MAWBS ------------------------------------------------------------------
    // BY TRACKING #, ACCOUNT NAME, SHIP DATE RANGE OR SHIP DATE WITH
    // MISSING ACCOUNT #


    
//  SEARCH BY TRACKING NUMBER ******************************** 
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByTrackingNumber = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByTrackingNumber = 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByTrackingNumber = 
    	"select " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +    	
    	"s.SHPMT_TYPE_CD, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " +  
    	"s.RECP_PH_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SVC_TYPE_CD, " + 
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"ag.GROUP_NM, " +
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
    	"where s.TRKNG_ITEM_NBR like ? " + 
    	"and SHIP_DT >= ? and SHIP_DT <= ? " + 
    	"and s.SHPMT_TYPE_CD = 'MAWB' " +
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " + 
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " + 
    	"and alsm.EMP_NBR = e.EMP_NBR (+) "; 
    
    /** Sort by ship date and destination */
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByTrackingNumberOrderByShipDateSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByShipDateSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByShipDateDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByShipDateSQL + " DESC " + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByRecipientNameSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientNameSQL + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByRecipientNameDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByShipperNameSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByShipperNameSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByShipperNameDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByShipperNameSQL + " DESC " + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByAccountNumberSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByAccountNumberSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByAccountNumberDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByTrackingNumberSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByTrackingNumberSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByTrackingNumber;    
    private final static String selectByTrackingNumberOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByServiceTypeCodeSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByRecipientCityNameSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientCityNameSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByTrackingNumber;
    private final static String selectByTrackingNumberOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientPostalCodeSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByTrackingNumber;   
    private final static String selectByTrackingNumberOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientPhoneNumberSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByTrackingNumber;    
    private final static String selectByTrackingNumberOrderByMonitorSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByMonitorSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByMonitorDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByMonitorSQL + " DESC " + POSTpagedSQLByTrackingNumber;    
    private final static String selectByTrackingNumberOrderByEmployeeNumberSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByEmployeeNumberSQL + POSTpagedSQLByTrackingNumber;    	
    private final static String selectByTrackingNumberOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByTrackingNumber + getSearchByTrackingNumber + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByTrackingNumber;    
    
    public List searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber, 
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByTrackingNumberOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByTrackingNumberOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByTrackingNumberOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(4, endIndex);
                pstmt.setInt(5, startIndex);
            pstmt.setString(1, "%" + aTrkngNbrMAWB + "%");              
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByMAWBTrackingNumber.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByMAWBTrackingNumber.getTime());
            pstmt.setTimestamp(3, timeStampTo);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentsMAWBsByTrackingNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByTrackingNumberSQL = 
    		"select count(*) count " + 
        	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
        	"where s.TRKNG_ITEM_NBR like ? " + 
        	"and SHIP_DT >= ? and SHIP_DT <= ? " + 
        	"and s.SHPMT_TYPE_CD = 'MAWB' " +
        	"and s.GROUP_NBR = ag.GROUP_NBR (+) " + 
        	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " + 
        	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " + 
        	"and s.LANE_NBR = alsm.LANE_NBR (+) " + 
        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " + 
        	"and alsm.EMP_NBR = e.EMP_NBR (+) "; 
    
    public int getCRNShipmentsCountTrackingNumber(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByTrackingNumberSQL, false, logger.isDebugEnabled() );
//        	}
            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByMAWBTrackingNumber.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByMAWBTrackingNumber.getTime());
            pstmt.setTimestamp(3, timeStampTo);
            pstmt.setString(1, "%" + aTrkngNbrMAWB + "%");

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    
    
    
//  SEARCH BY RECIPIENT POSTAL CODE ******************************** 
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByShipperName = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByShipperName = 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByShipperName = 
    	"select " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +    	
    	"s.SHPMT_TYPE_CD, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " +  
    	"s.RECP_PH_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SVC_TYPE_CD, " + 
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"ag.GROUP_NM, " +
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
    	"where Upper(ag.GROUP_NM) like Upper(?) " + 
    	"and s.SHIP_DT >= ? and s.SHIP_DT <= ? " + 
    	"and SHPMT_TYPE_CD ='MAWB'" + 
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " + 
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " + 
    	"and alsm.EMP_NBR = e.EMP_NBR (+) "; 
    
    /** Sort by ship date and destination */
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByShipperNameOrderByShipDateSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByShipDateSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByShipDateDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByShipDateSQL + " DESC " + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByRecipientNameSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientNameSQL + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByRecipientNameDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByShipperNameSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByShipperNameSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByShipperNameDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByShipperNameSQL + " DESC " + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByAccountNumberSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByAccountNumberSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByAccountNumberDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByTrackingNumberSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByTrackingNumberSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByShipperName;    
    private final static String selectByShipperNameOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByServiceTypeCodeSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByRecipientCityNameSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientCityNameSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByShipperName;
    private final static String selectByShipperNameOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientPostalCodeSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByShipperName;   
    private final static String selectByShipperNameOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientPhoneNumberSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByShipperName;    
    private final static String selectByShipperNameOrderByMonitorSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByMonitorSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByMonitorDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByMonitorSQL + " DESC " + POSTpagedSQLByShipperName;    
    private final static String selectByShipperNameOrderByEmployeeNumberSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByEmployeeNumberSQL + POSTpagedSQLByShipperName;    	
    private final static String selectByShipperNameOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByShipperName + getSearchByShipperName + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByShipperName;    
    
    public List searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName, 
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByShipperNameOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByShipperNameOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByShipperNameOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(4, endIndex);
                pstmt.setInt(5, startIndex);
            pstmt.setString(1, "%" + aAcctNmMAWB + "%");              
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByMAWBShipperName.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByMAWBShipperName.getTime());
            pstmt.setTimestamp(3, timeStampTo);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentsMAWBsByShipperName(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByShipperNameSQL = 
    		"select count(*) count " + 
        	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
        	"where Upper(ag.GROUP_NM) like Upper(?) " + 
        	"and s.SHIP_DT >= ? and s.SHIP_DT <= ? " + 
        	"and SHPMT_TYPE_CD ='MAWB'" + 
        	"and s.GROUP_NBR = ag.GROUP_NBR (+) " + 
        	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " + 
        	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " + 
        	"and s.LANE_NBR = alsm.LANE_NBR (+) " + 
        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " + 
        	"and alsm.EMP_NBR = e.EMP_NBR (+) "; 
    
    public int getCRNShipmentsCountShipperName(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByShipperNameSQL, false, logger.isDebugEnabled() );
//        	}
            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByMAWBShipperName.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByMAWBShipperName.getTime());
            pstmt.setTimestamp(3, timeStampTo);
            pstmt.setString(1, "%" + aAcctNmMAWB + "%");

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }      
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    private static final String getSearchByTrkngNbrMAWBSQL = 
    	"select UNIQUE " + 
    	"s.TRKNG_ITEM_NBR, " + 
    	"s.SHPMT_TYPE_CD, " + 
    	"s.SHIP_DT, " + 
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " + 
    	"s.ACCT_NBR, " + 
    	"s.SVC_TYPE_CD, " + 
    	"ag.GROUP_NM, " + 
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " + 
    	"e.EMP_LAST_NM, " + 
    	"e.EMP_NBR " + 
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
    	"where s.TRKNG_ITEM_NBR = ? " + 
    	"and SHIP_DT >= ? and SHIP_DT <= ? " + 
    	"and s.SHPMT_TYPE_CD = 'MAWB' " +
    	"and s.GROUP_NBR = ag.GROUP_NBR " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR " + 
    	"and s.LANE_NBR = alsm.LANE_NBR " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " + 
    	"and alsm.EMP_NBR = e.EMP_NBR"; 

    public List searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDate, Date _limitOneWeekFromDate)
            throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByTrkngNbrMAWBSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aTrkngNbrMAWB);
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDate.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDate.getTime());
            pstmt.setTimestamp(3, timeStampTo);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentsMAWBsByTrackingNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    private static final String getSearchByAcctNmMAWBSQL = 
    	"select UNIQUE " + 
    	"s.TRKNG_ITEM_NBR, " + 
    	"s.SHPMT_TYPE_CD, " + 
    	"s.SHIP_DT, " + 
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " + 
    	"s.ACCT_NBR, " + 
    	"s.SVC_TYPE_CD, " + 
    	"ag.GROUP_NM, " + 
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " + 
    	"e.EMP_LAST_NM, " + 
    	"e.EMP_NBR " + 
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
    	"where Upper(ag.GROUP_NM) like Upper(?) " + 
    	"and s.SHIP_DT >= ? and s.SHIP_DT <= ? " + 
    	"and SHPMT_TYPE_CD ='MAWB'" + 
    	"and s.GROUP_NBR = ag.GROUP_NBR " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR " + 
    	"and s.LANE_NBR = alsm.LANE_NBR " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " + 
    	"and alsm.EMP_NBR = e.EMP_NBR"; 

    public List searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDate2, Date _limitOneWeekFromDate2)
            throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByAcctNmMAWBSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, "%" + aAcctNmMAWB + "%");
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDate2.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDate2.getTime());
            pstmt.setTimestamp(3, timeStampTo);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentsMAWBsByShipperName(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    private static final String getSearchByShipDateRangeSQL = 
    	"select UNIQUE " + 
    	"s.TRKNG_ITEM_NBR, " + 
    	"s.SHPMT_TYPE_CD, " + 
    	"s.SHIP_DT, " + 
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " + 
    	"s.ACCT_NBR, " + 
    	"s.SVC_TYPE_CD, " + 
    	"ag.GROUP_NM, " + 
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " + 
    	"e.EMP_LAST_NM, " + 
    	"e.EMP_NBR " + 
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
    	"where s.ACCT_NBR = ? " + 
    	"and SHIP_DT >= ? and SHIP_DT <= ? " + 
    	"and s.LANE_NBR like ? " + 
    	"and s.SVC_TYPE_CD like ? " +
    	"and s.SHPMT_TYPE_CD = 'MAWB' " +
    	"and s.GROUP_NBR = ag.GROUP_NBR " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR " + 
    	"and s.LANE_NBR = alsm.LANE_NBR " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " + 
    	"and alsm.EMP_NBR = e.EMP_NBR";
    
    //Start WR#:179441 Changes
    private static final String getSearchByShipDateRangeOrderByTrkngNbr = getSearchByShipDateRangeSQL+orderByTrackingNumberSQL;
    private static final String getSearchByShipDateRangeOrderByDescTrkngNbr = getSearchByShipDateRangeSQL+orderByTrackingNumberSQL+" DESC";
    private static final String getSearchByShipDateRangeOrderByShipDt = getSearchByShipDateRangeSQL+orderByShipDateSQL;
    private static final String getSearchByShipDateRangeOrderByDescShipDt = getSearchByShipDateRangeSQL+orderByShipDateSQL+" DESC";
    private static final String getSearchByShipDateRangeOrderByMonitor = getSearchByShipDateRangeSQL+orderByMonitorSQL;
    private static final String getSearchByShipDateRangeOrderByDescMonitor = getSearchByShipDateRangeSQL+orderByMonitorSQL+" DESC";
    
    public List searchByShipDateRange(Date _limitOneWeekToDate3, Date _limitOneWeekFromDate3, String aServiceCode,
            String aAcctNbrMAWB3, String aSelectedLane, String sortColumn,boolean ascending) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        	
			if (sortColumn.equals("tracking_number")) {
				if (ascending)
					setSqlSignature(getSearchByShipDateRangeOrderByTrkngNbr,
							false, logger.isDebugEnabled());
				else
					setSqlSignature(
							getSearchByShipDateRangeOrderByDescTrkngNbr, false,
							logger.isDebugEnabled());
			}
			else if (sortColumn.equals("ship_dt")) {
				if (ascending)
					setSqlSignature(getSearchByShipDateRangeOrderByShipDt,
							false, logger.isDebugEnabled());
				else
					setSqlSignature(getSearchByShipDateRangeOrderByDescShipDt,
							false, logger.isDebugEnabled());
			}
			else if (sortColumn.equals("monitor")) {
				if (ascending)
					setSqlSignature(getSearchByShipDateRangeOrderByMonitor,
							false, logger.isDebugEnabled());
				else
					setSqlSignature(getSearchByShipDateRangeOrderByDescMonitor,
							false, logger.isDebugEnabled());
			}
			else
			{
				setSqlSignature(getSearchByShipDateRangeSQL,
						false, logger.isDebugEnabled());
			}//End WR#:179441 Changes
            pstmt.setString(1, aAcctNbrMAWB3);            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDate3.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDate3.getTime());
            pstmt.setTimestamp(3, timeStampTo);
            pstmt.setString(4, "%" + aSelectedLane + "%");
            pstmt.setString(5, "%" + aServiceCode + "%");


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentsMAWBsByAccountNumberShipDateRange(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    private static final String getSearchByShipDateSQL = 
    	"select UNIQUE " + 
    	"s.TRKNG_ITEM_NBR, " +
    	"s.SHPMT_TYPE_CD, " + 
    	"s.SHIP_DT, " + 
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " + 
    	"s.ACCT_NBR, " + 
    	"s.SVC_TYPE_CD, " + 
    	"ag.GROUP_NM, " + 
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " + 
    	"e.EMP_LAST_NM, " + 
    	"e.EMP_NBR " + 
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
    	"where s.ACCT_NBR = ? " + 
    	"and SHIP_DT = ? " + 
    	"and s.LANE_NBR like ? " + 
    	"and s.SVC_TYPE_CD like ? " +    	
    	"and s.SHPMT_TYPE_CD = 'MAWB' " +
    	"and s.GROUP_NBR = ag.GROUP_NBR " + 
    	"and s.GROUP_NBR = alsm.GROUP_NBR " + 
    	"and s.ACCT_NBR = alsm.ACCT_NBR " + 
    	"and s.LANE_NBR = alsm.LANE_NBR " + 
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " + 
    	"and alsm.EMP_NBR = e.EMP_NBR"; 

    public List searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2,
            String aSelectedLane2) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByShipDateSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aAcctNbrMAWB2);            
            java.sql.Timestamp timeStampShip = new java.sql.Timestamp(_shipDate.getTime());
            pstmt.setTimestamp(2, timeStampShip);
            pstmt.setString(3, "%" + aSelectedLane2 + "%");
            pstmt.setString(4, "%" + aServiceCode2 + "%");


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindShipmentsMAWBsByAccountNumberShipDate(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    // FIND PACKAGES - CRNS
    // ------------------------------------------------------------------------
    // BY RETURN TRACKING #, RECIPIENT NAME, RECIPIENT POSTAL CODE,
    // ISSUE CODE, WITH ODA, WITHOUT A POD, RECIPEINT ADDRESS

//  SEARCH BY RETURN TRACKING NUMBER ******************************** 
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByReturnTrackingNumber = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByReturnTrackingNumber= 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByReturnTrackingNumber = 
    	"select " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +
    	"s.SHPMT_TYPE_CD, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " +  
    	"s.RECP_PH_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SVC_TYPE_CD, " + 
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"ag.GROUP_NM, " +
    	"aship.ASSOC_TRKNG_ITEM_NBR, " +
       	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ASSOCIATED_SHIPMENT aship, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
    	"where (aship.TRKNG_ITEM_NBR like ? or aship.ASSOC_TRKNG_ITEM_NBR like ? ) " +
    	"and aship.ASSOC_TRACK_TYPE_CODE = 'R' " +
    	"and s.TRKNG_ITEM_NBR = aship.TRKNG_ITEM_NBR (+) " +
    	"and s.TRKNG_ITEM_UNIQ_NBR = aship.TRKNG_ITEM_UNIQ_NBR (+) " +
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " +
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
    	"and alsm.EMP_NBR = e.EMP_NBR (+) ";
    
    /** Sort by ship date and destination */
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByReturnTrackingNumberOrderByShipDateSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByShipDateSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByShipDateDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByShipDateSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByRecipientNameSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientNameSQL + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByRecipientNameDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByShipperNameSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByShipperNameSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByShipperNameDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByShipperNameSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByAccountNumberSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByAccountNumberSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByAccountNumberDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByTrackingNumberSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByTrackingNumberSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;    
    private final static String selectByReturnTrackingNumberOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByServiceTypeCodeSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByRecipientCityNameSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientCityNameSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;
    private final static String selectByReturnTrackingNumberOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientPostalCodeSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;   
    private final static String selectByReturnTrackingNumberOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientPhoneNumberSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;    
    private final static String selectByReturnTrackingNumberOrderByMonitorSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByMonitorSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByMonitorDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByMonitorSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;    
    private final static String selectByReturnTrackingNumberOrderByEmployeeNumberSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByEmployeeNumberSQL + POSTpagedSQLByReturnTrackingNumber;    	
    private final static String selectByReturnTrackingNumberOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByReturnTrackingNumber + getSearchByReturnTrackingNumber + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByReturnTrackingNumber;    
    
    public List searchByReturnTrackingNumber(String aReturnTrkngNbr, 
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByReturnTrackingNumberOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByReturnTrackingNumberOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByReturnTrackingNumberOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(3, endIndex);
                pstmt.setInt(4, startIndex);
            pstmt.setString(1, "%" + aReturnTrkngNbr + "%");   
            pstmt.setString(2, "%" + aReturnTrkngNbr + "%");              


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindPackagesCRNsByReturnTrackingNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByReturnTrackingNumberSQL = 
    		"select count(*) count " + 
        	"from SHIPMENT s, ASSOCIATED_SHIPMENT aship, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
        	"where (aship.TRKNG_ITEM_NBR like ? or aship.ASSOC_TRKNG_ITEM_NBR like ? ) " +
        	"and aship.ASSOC_TRACK_TYPE_CODE = 'R' " +
        	"and s.TRKNG_ITEM_NBR = aship.TRKNG_ITEM_NBR (+) " +
        	"and s.TRKNG_ITEM_UNIQ_NBR = aship.TRKNG_ITEM_UNIQ_NBR (+) " +
        	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
        	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " +
        	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
        	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
        	"and alsm.EMP_NBR = e.EMP_NBR (+) ";
    
    public int getCRNShipmentsCountReturnTrackingNumber(String aReturnTrkngNbr) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByReturnTrackingNumberSQL, false, logger.isDebugEnabled() );
//        	}
            
            pstmt.setString(1, "%" + aReturnTrkngNbr + "%");
            pstmt.setString(2, "%" + aReturnTrkngNbr + "%");            

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }      

//  RAMP HUB SEARCH ********************************     
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQL = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQL = 
       "   ) row_ " + " where rownum <= ? " +
       " ) " +
       "where rownum_ > ?";
    
    private final static String getRampHubSearchSQLCountry = 
    	"select " +
    	"TRKNG_ITEM_NBR, " + 
    	"SHIP_DT, " +
    	"COMMIT_DT, " +
    	"COMMIT_DATE_TMZN_OFFST_NBR, " +
    	"DEST_LOC_CD, " +
    	"SHPR_CNTRY_CD, " +
    	"RECP_CNTRY_CD, " +
    	"SHPR_CO_NM, " +
    	"LAST_STAT_DESC, " +
    	"LAST_EVENT_TRACK_LOC_CD, " +
    	"LAST_EVENT_TMSTP, " +
    	"LAST_EVENT_TMZN_OFFST_NBR, " +
    	"SHPMT_WGT, " +
    	"CLEARED_CSTMS_TMSTP, " +
    	"CLEARED_CSTMS_TMZN_OFFSET_NBR, " +
    	"SHPMT_PKG_QTY " +
    	"from SHIPMENT  " +
    	"where SHPMT_TYPE_CD = 'MAWB' and " +
    	"SHIP_DT = ? and " +
    	"UPPER(RECP_CNTRY_CD) = UPPER(?) ";

    private final static String getRampHubSearchSQLUS = 
    	getRampHubSearchSQLCountry + " and UPPER(RECP_ST_PROV_CD) like UPPER(?) "; 
    			
    
    private final static String getRampHubSearchSQLCA = 
    	getRampHubSearchSQLCountry + " and UPPER(RECP_CITY_NM) like UPPER(?) ";
    
    /** Sort by ship date and destination */
    private final static String orderByAdjCommitDtSQL =  " order by COMMIT_DT ";
    private final static String orderByDestLocCdSQL =  " order by DEST_LOC_CD ";
    private final static String orderByShprCoNmSQL =  " order by SHPR_CO_NM ";
    
    /** Get all MAWBs by country, order by ship date ascending, and paged SQL */
    private final static String selectAllCountryMAWBShipmentOrderByShipDtSQL = 
    	PREpagedSQL + getRampHubSearchSQLCountry + orderByAdjCommitDtSQL + POSTpagedSQL;    	
    private final static String selectAllCountryMAWBShipmentOrderByShipDtDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLCountry + orderByAdjCommitDtSQL + " DESC " + POSTpagedSQL;
    private final static String selectAllCountryMAWBShipmentOrderByDestLocCdSQL = 
    	PREpagedSQL + getRampHubSearchSQLCountry + orderByDestLocCdSQL + POSTpagedSQL;    	
    private final static String selectAllCountryMAWBShipmentOrderByDestLocCdDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLCountry + orderByDestLocCdSQL + " DESC " + POSTpagedSQL;
    private final static String selectAllCountryMAWBShipmentOrderByRecpCityNmSQL = 
    	PREpagedSQL + getRampHubSearchSQLCountry + orderByShprCoNmSQL + POSTpagedSQL;    	
    private final static String selectAllCountryMAWBShipmentOrderByRecpCityNmDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLCountry + orderByShprCoNmSQL + " DESC " + POSTpagedSQL;
    
    /** Get all MAWBs for the US by state, order by ship date ascending, and paged SQL */
    private final static String selectAllUSbyStateMAWBShipmentOrderByShipDtSQL = 
    	PREpagedSQL + getRampHubSearchSQLUS + orderByAdjCommitDtSQL + POSTpagedSQL;    	
    private final static String selectAllUSbyStateMAWBShipmentOrderByShipDtDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLUS + orderByAdjCommitDtSQL + " DESC " + POSTpagedSQL;
    private final static String selectAllUSbyStateMAWBShipmentOrderByDestLocCdSQL = 
    	PREpagedSQL + getRampHubSearchSQLUS + orderByDestLocCdSQL + POSTpagedSQL;    	
    private final static String selectAllUSbyStateMAWBShipmentOrderByDestLocCdDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLUS + orderByDestLocCdSQL + " DESC " + POSTpagedSQL;
    private final static String selectAllUSbyStateMAWBShipmentOrderByRecpCityNmSQL = 
    	PREpagedSQL + getRampHubSearchSQLUS + orderByShprCoNmSQL + POSTpagedSQL;    	
    private final static String selectAllUSbyStateMAWBShipmentOrderByRecpCityNmDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLUS + orderByShprCoNmSQL + " DESC " + POSTpagedSQL;
    
    /** Get all MAWBs for Canada by City, order by ship date ascending, and paged SQL */
    private final static String selectAllCAbyCityMAWBShipmentOrderByShipDtSQL = 
    	PREpagedSQL + getRampHubSearchSQLCA + orderByAdjCommitDtSQL + POSTpagedSQL;    	
    private final static String selectAllCAbyCityMAWBShipmentOrderByShipDtDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLCA + orderByAdjCommitDtSQL + " DESC " + POSTpagedSQL;
    private final static String selectAllCAbyCityMAWBShipmentOrderByDestLocCdSQL = 
    	PREpagedSQL + getRampHubSearchSQLCA + orderByDestLocCdSQL + POSTpagedSQL;    	
    private final static String selectAllCAbyCityMAWBShipmentOrderByDestLocCdDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLCA + orderByDestLocCdSQL + " DESC " + POSTpagedSQL;
    private final static String selectAllCAbyCityMAWBShipmentOrderByRecpCityNmSQL = 
    	PREpagedSQL + getRampHubSearchSQLCA + orderByShprCoNmSQL + POSTpagedSQL;    	
    private final static String selectAllCAbyCityMAWBShipmentOrderByRecpCityNmDescSQL = 
    	PREpagedSQL + getRampHubSearchSQLCA + orderByShprCoNmSQL + " DESC " + POSTpagedSQL;
    
    public List rampHubSearch(Date _shipDate, String _selectMenu, 
    		String aClearancePoint, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        	if (aClearancePoint.equals("")){ // All clearance points for a Country
        		if ("adj_commit_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectAllCountryMAWBShipmentOrderByShipDtSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllCountryMAWBShipmentOrderByShipDtDescSQL, false, logger.isDebugEnabled());
        		}else if ("destination_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectAllCountryMAWBShipmentOrderByDestLocCdSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllCountryMAWBShipmentOrderByDestLocCdDescSQL, false, logger.isDebugEnabled());
        		}else if ("dest_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectAllCountryMAWBShipmentOrderByRecpCityNmSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllCountryMAWBShipmentOrderByRecpCityNmDescSQL, false, logger.isDebugEnabled());
        		}else{
        			setSqlSignature(selectAllCountryMAWBShipmentOrderByDestLocCdSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(3, endIndex);
                pstmt.setInt(4, startIndex);
        	}else if (_selectMenu.equals("US")){ // Specific clearance points for the US.
        		if ("adj_commit_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByShipDtSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByShipDtDescSQL, false, logger.isDebugEnabled());
        		}else if ("destination_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByDestLocCdSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByDestLocCdDescSQL, false, logger.isDebugEnabled());
        		}else if ("dest_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByRecpCityNmSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByRecpCityNmDescSQL, false, logger.isDebugEnabled());
        		}else{
        			setSqlSignature(selectAllUSbyStateMAWBShipmentOrderByDestLocCdSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setString(3, "%" + aClearancePoint + "%");
                pstmt.setInt(4, endIndex);
                pstmt.setInt(5, startIndex);
        	}else if (_selectMenu.equals("CA")){ // Specific clearance points for Canada.
        		if ("adj_commit_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByShipDtSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByShipDtDescSQL, false, logger.isDebugEnabled());
        		}else if ("destination_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByDestLocCdSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByDestLocCdDescSQL, false, logger.isDebugEnabled());
        		}else if ("dest_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByRecpCityNmSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByRecpCityNmDescSQL, false, logger.isDebugEnabled());
        		}else{
        			setSqlSignature(selectAllCAbyCityMAWBShipmentOrderByDestLocCdSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setString(3, "%" + aClearancePoint + "%");
                pstmt.setInt(4, endIndex);
                pstmt.setInt(5, startIndex);
        	}
            

            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_shipDate.getTime());
            pstmt.setTimestamp(1, timeStampFrom);
            pstmt.setString(2, _selectMenu);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchRampHubSearch(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all MAWBs SQL */
    private final static String countRampHubSearchSQLCountrySQL = 
    		"select count(*) count " + 
    		"from SHIPMENT  " +
    		"where SHPMT_TYPE_CD = 'MAWB' and " +
    		"SHIP_DT = ? and " +
    		"UPPER(RECP_CNTRY_CD) = UPPER(?) ";
    
    private final static String countRampHubSearchSQLUSSQL = 
    	countRampHubSearchSQLCountrySQL + " and UPPER(RECP_ST_PROV_CD) like UPPER(?) "; 
    			
    
    private final static String countRampHubSearchSQLCASQL = 
    	countRampHubSearchSQLCountrySQL + " and UPPER(RECP_CITY_NM) like UPPER(?) ";
    
    public int getMAWBShipmentsCount(Date _shipDate, String _selectMenu, 
    		String aClearancePoint) throws SQLException {
    	int count = 0;

        try {
        	if (aClearancePoint.equals("")){ // All clearance points for a Country
        		setSqlSignature( countRampHubSearchSQLCountrySQL, false, logger.isDebugEnabled() );
        	}else if (_selectMenu.equals("US")){ // Specific clearance points for the US.
        		setSqlSignature( countRampHubSearchSQLUSSQL, false, logger.isDebugEnabled() );
        		pstmt.setString(3, "%" + aClearancePoint + "%");
        	}else if (_selectMenu.equals("CA")){ // Specific clearance points for Canada.
        		setSqlSignature( countRampHubSearchSQLCASQL, false, logger.isDebugEnabled() );
        		pstmt.setString(3, "%" + aClearancePoint + "%");
        	}
            

            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_shipDate.getTime());
            pstmt.setTimestamp(1, timeStampFrom);
            pstmt.setString(2, _selectMenu);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    

// SEARCH BY RECIPIENT NAME ******************************** 
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByRecipientName = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByRecipientName = 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByRecipientName = 
    	"select " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +    	
    	"s.SHPMT_TYPE_CD, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " +  
    	"s.RECP_PH_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SVC_TYPE_CD, " + 
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"ag.GROUP_NM, " +
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
        "where (Upper(s.RECP_CO_NM) like Upper(?) or Upper(s.ACTL_DEL_NM) like Upper(?)) " +
        "and SHIP_DT >= ? and SHIP_DT <= ? " +
        "and s.SHPMT_TYPE_CD = 'CRN' " +        
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " +
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
    	"and alsm.EMP_NBR = e.EMP_NBR (+) ";
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByRecipientNameOrderByShipDateSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByShipDateSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByShipDateDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByShipDateSQL + " DESC " + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByRecipientNameSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientNameSQL + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByRecipientNameDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByShipperNameSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByShipperNameSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByShipperNameDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByShipperNameSQL + " DESC " + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByAccountNumberSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByAccountNumberSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByAccountNumberDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByTrackingNumberSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByTrackingNumberSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByRecipientName;    
    private final static String selectByRecipientNameOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByServiceTypeCodeSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByRecipientCityNameSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientCityNameSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByRecipientName;
    private final static String selectByRecipientNameOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientPostalCodeSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByRecipientName;   
    private final static String selectByRecipientNameOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientPhoneNumberSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByRecipientName;    
    private final static String selectByRecipientNameOrderByMonitorSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByMonitorSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByMonitorDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByMonitorSQL + " DESC " + POSTpagedSQLByRecipientName;    
    private final static String selectByRecipientNameOrderByEmployeeNumberSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByEmployeeNumberSQL + POSTpagedSQLByRecipientName;    	
    private final static String selectByRecipientNameOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByRecipientName + getSearchByRecipientName + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByRecipientName;    
    
    public List searchByRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName, 
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientNameOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientNameOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByRecipientNameOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(5, endIndex);
                pstmt.setInt(6, startIndex);
            pstmt.setString(1, "%" + aRecipientName + "%");            
            pstmt.setString(2, "%" + aRecipientName + "%");   
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNRecipientName.getTime());
            pstmt.setTimestamp(3, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNRecipientName.getTime());
            pstmt.setTimestamp(4, timeStampTo);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindPackagesCRNsByRecipientName(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByRecipientNameSQL = 
    		"select count(*) count " + 
    		"from SHIPMENT  " +
    		"where SHPMT_TYPE_CD = 'CRN' and " +    		
    		"SHIP_DT >= ? and SHIP_DT <= ? and " +
    		"(UPPER(RECP_CO_NM) like UPPER(?) or Upper(ACTL_DEL_NM) like Upper(?)) ";
    
    public int getCRNShipmentsCountRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByRecipientNameSQL, false, logger.isDebugEnabled() );
//        	}
            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNRecipientName.getTime());
            pstmt.setTimestamp(1, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNRecipientName.getTime());
            pstmt.setTimestamp(2, timeStampTo);
            pstmt.setString(3, "%" + aRecipientName + "%");
            pstmt.setString(4, "%" + aRecipientName + "%");

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    
  
//  SEARCH BY RECIPIENT POSTAL CODE ******************************** 
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByRecipientPostalCode = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByRecipientPostalCode = 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByRecipientPostalCode = 
    	"select " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +    	
    	"s.SHPMT_TYPE_CD, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " +  
    	"s.RECP_PH_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SVC_TYPE_CD, " + 
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"ag.GROUP_NM, " +
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
        "where s.RECP_PSTL_CD like ? " +
        "and SHIP_DT >= ? and SHIP_DT <= ? " +
        "and s.SHPMT_TYPE_CD = 'CRN' " +       
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " +
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
    	"and alsm.EMP_NBR = e.EMP_NBR (+) ";
    
    /** Sort by ship date and destination */
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByRecipientPostalCodeOrderByShipDateSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByShipDateSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByShipDateDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByShipDateSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByRecipientNameSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientNameSQL + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByRecipientNameDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByShipperNameSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByShipperNameSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByShipperNameDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByShipperNameSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByAccountNumberSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByAccountNumberSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByAccountNumberDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByTrackingNumberSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByTrackingNumberSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;    
    private final static String selectByRecipientPostalCodeOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByServiceTypeCodeSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByRecipientCityNameSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientCityNameSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;
    private final static String selectByRecipientPostalCodeOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientPostalCodeSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;   
    private final static String selectByRecipientPostalCodeOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientPhoneNumberSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;    
    private final static String selectByRecipientPostalCodeOrderByMonitorSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByMonitorSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByMonitorDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByMonitorSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;    
    private final static String selectByRecipientPostalCodeOrderByEmployeeNumberSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByEmployeeNumberSQL + POSTpagedSQLByRecipientPostalCode;    	
    private final static String selectByRecipientPostalCodeOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByRecipientPostalCode + getSearchByRecipientPostalCode + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByRecipientPostalCode;    
    
    public List searchByRecipientPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, 
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientPostalCodeOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientPostalCodeOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByRecipientPostalCodeOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(4, endIndex);
                pstmt.setInt(5, startIndex);
            pstmt.setString(1, "%" + aPostalCode + "%");              
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNRecipientPostalCode.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNRecipientPostalCode.getTime());
            pstmt.setTimestamp(3, timeStampTo);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindPackagesCRNsByRecipientPostalCode(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByRecipientPostalCodeSQL = 
    		"select count(*) count " + 
    		"from SHIPMENT  " +
    		"where SHPMT_TYPE_CD = 'CRN' and " +   		
    		"SHIP_DT >= ? and SHIP_DT <= ? and " +
    		"RECP_PSTL_CD like ? ";
    
    public int getCRNShipmentsCountRecipientPostalCode(String aPostalCode, Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByRecipientPostalCodeSQL, false, logger.isDebugEnabled() );
//        	}
            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNRecipientPostalCode.getTime());
            pstmt.setTimestamp(1, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNRecipientPostalCode.getTime());
            pstmt.setTimestamp(2, timeStampTo);
            pstmt.setString(3, "%" + aPostalCode + "%");

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }      
    
//  SEARCH BY WITH ODA ********************************     
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByWithODA = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByWithODA = 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByWithODA =   	
    	"select UNIQUE " +
    	"ag.GROUP_NM, " + 
    	"s.GROUP_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"alsm.SVC_TYPE_CD, " +
    	"e.EMP_NBR, " +
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " + 
    	"s.RECP_PH_NBR, " +
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"s.SHPMT_TYPE_CD " +
    	"from ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e, SHIPMENT s, EVENT ev " +  
    	"where s.ACCT_NBR like ? " +
    	"and s.SHIP_DT >= ? and s.SHIP_DT <= ? " +
    	"and (ev.TRACK_TYPE_CD = '42' or (ev.TRACK_TYPE_CD = '07' and ev.TRACK_EXCP_CD = '67') or ev.TRACK_TYPE_CD = '75') " +
    	"and ev.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR (+) " +
    	"and ev.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR (+) " +
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " +
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
    	"and alsm.EMP_NBR = e.EMP_NBR(+) ";
    
    /** Sort by ship date and destination */
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByWithODAOrderByShipDateSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByShipDateSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByShipDateDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByShipDateSQL + " DESC " + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByRecipientNameSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientNameSQL + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByRecipientNameDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByShipperNameSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByShipperNameSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByShipperNameDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByShipperNameSQL + " DESC " + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByAccountNumberSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByAccountNumberSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByAccountNumberDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByTrackingNumberSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByTrackingNumberSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByWithODA;    
    private final static String selectByWithODAOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByServiceTypeCodeSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByRecipientCityNameSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientCityNameSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByWithODA;
    private final static String selectByWithODAOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientPostalCodeSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByWithODA;   
    private final static String selectByWithODAOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientPhoneNumberSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByWithODA;    
    private final static String selectByWithODAOrderByMonitorSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByMonitorSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByMonitorDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByMonitorSQL + " DESC " + POSTpagedSQLByWithODA;    
    private final static String selectByWithODAOrderByEmployeeNumberSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByEmployeeNumberSQL + POSTpagedSQLByWithODA;    	
    private final static String selectByWithODAOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByWithODA + getSearchByWithODA + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByWithODA;    
    
    public List searchByWithODA(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA, Date _limitOneWeekToDateByCRNWithODA,  
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByWithODAOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByWithODAOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByWithODAOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(4, endIndex);
                pstmt.setInt(5, startIndex);
            pstmt.setString(1, "%" + aAcctNbr + "%");              
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNWithODA.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNWithODA.getTime());
            pstmt.setTimestamp(3, timeStampTo);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindPackagesCRNsByWithODA(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByWithODASQL = 
//		"select count(*) count " + 
//		"from SHIPMENT  " +
//		"where SHPMT_TYPE_CD = 'CRN' and " +   		
//		"SHIP_DT >= ? and SHIP_DT <= ? and " +
//		"RECP_PSTL_CD like ? ";    	
    		"select count(DISTINCT s.TRKNG_ITEM_NBR) count " + 
        	"from ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e, SHIPMENT s, EVENT ev " +  
        	"where s.ACCT_NBR like ? " +
        	"and s.SHIP_DT >= ? and s.SHIP_DT <= ? " +
        	"and (ev.TRACK_TYPE_CD = '42' or (ev.TRACK_TYPE_CD = '07' and ev.TRACK_EXCP_CD = '67') or ev.TRACK_TYPE_CD = '75') " +
        	"and ev.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR (+) " +
        	"and ev.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR (+) " +
        	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
        	"and s.GROUP_NBR = alsm.GROUP_NBR (+) " +
        	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
        	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
        	"and alsm.EMP_NBR = e.EMP_NBR(+) ";
    
    public int getCRNShipmentsCountWithODA(String aAcctNbr, Date _limitOneWeekToDateByCRNWithODA, Date _limitOneWeekFromDateByCRNWithODA) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByWithODASQL, false, logger.isDebugEnabled() );
//        	}
            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNWithODA.getTime());
            pstmt.setTimestamp(2, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNWithODA.getTime());
            pstmt.setTimestamp(3, timeStampTo);
            pstmt.setString(1, "%" + aAcctNbr + "%");

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    
    
//  SEARCH BY RECIPIENT ADDRESS ********************************     

    /** Paging SQL to get subset of results */
    private final static String PREpagedSQLByRecipientAddress = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQLByRecipientAddress = 
       ") row_ " + " where rownum <= ? " +
       ") " +
       "where rownum_ > ?";

   	
    private final static String getSearchByRecipientAddress = 
    	"select " +
    	"s.TRKNG_ITEM_NBR, " +
    	"s.TRKNG_ITEM_UNIQ_NBR, " +
    	"s.SHPMT_TYPE_CD, " +
    	"s.SHIP_DT, " +
    	"s.RECP_CO_NM, " +  
    	"s.RECP_PH_NBR, " +
    	"s.ACCT_NBR, " +
    	"s.SVC_TYPE_CD, " + 
    	"s.RECP_CITY_NM, " +
    	"s.RECP_PSTL_CD, " +
    	"ag.GROUP_NM, " +
    	"s.SHPR_CNTRY_CD, " + 
    	"s.RECP_CNTRY_CD, " + 
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM, " +
    	"e.EMP_NBR " +
    	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
        "where Upper(s.RECP_ADDR_LINE_ONE_DESC) like Upper(?) and " +
        "Upper(s.RECP_CITY_NM) like Upper(?) and Upper(s.RECP_ST_PROV_CD) = Upper(?) and " +
        "s.RECP_PSTL_CD like ? " +
        "and s.SHIP_DT >= ? and s.SHIP_DT <= ? " +
    	"and s.SHPMT_TYPE_CD = 'CRN' " +
    	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
    	"and s.GROUP_NBR = alsm.GROUP_NBR (+)" +
    	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
    	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
    	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
    	"and alsm.EMP_NBR = e.EMP_NBR (+) ";  
    
    /** Sort by ship date and destination */
    
    /** Get all results, order by Ship Date, Recipient Name, Shipper Name, or Account Numebr and paged SQL */
    private final static String selectByRecipientAddressOrderByShipDateSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByShipDateSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByShipDateDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByShipDateSQL + " DESC " + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByRecipientNameSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientNameSQL + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByRecipientNameDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientNameSQL + " DESC " + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByShipperNameSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByShipperNameSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByShipperNameDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByShipperNameSQL + " DESC " + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByAccountNumberSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByAccountNumberSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByAccountNumberDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByAccountNumberSQL + " DESC " + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByTrackingNumberSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByTrackingNumberSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByTrackingNumberDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByTrackingNumberSQL + " DESC " + POSTpagedSQLByRecipientAddress;    
    private final static String selectByRecipientAddressOrderByServiceTypeCodeSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByServiceTypeCodeSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByServiceTypeCodeDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByServiceTypeCodeSQL + " DESC " + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByRecipientCityNameSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientCityNameSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByRecipientCityNameDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientCityNameSQL + " DESC " + POSTpagedSQLByRecipientAddress;
    private final static String selectByRecipientAddressOrderByRecipientPostalCodeSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientPostalCodeSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByRecipientPostalCodeDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientPostalCodeSQL + " DESC " + POSTpagedSQLByRecipientAddress;   
    private final static String selectByRecipientAddressOrderByRecipientPhoneNumberSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientPhoneNumberSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByRecipientPhoneNumberDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByRecipientPhoneNumberSQL + " DESC " + POSTpagedSQLByRecipientAddress;    
    private final static String selectByRecipientAddressOrderByMonitorSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByMonitorSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByMonitorDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByMonitorSQL + " DESC " + POSTpagedSQLByRecipientAddress;    
    private final static String selectByRecipientAddressOrderByEmployeeNumberSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByEmployeeNumberSQL + POSTpagedSQLByRecipientAddress;    	
    private final static String selectByRecipientAddressOrderByEmployeeNumberDescSQL = 
    	PREpagedSQLByRecipientAddress + getSearchByRecipientAddress + orderByEmployeeNumberSQL + " DESC " + POSTpagedSQLByRecipientAddress;    
    
    public List searchByRecipientAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress, 
    		String sortColumn, boolean isSortAscending, int startIndex, int endIndex) throws SQLException {
        ArrayList al = new ArrayList();

        try {
        		if ("ship_date".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByShipDateSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByShipDateDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_name".equals(sortColumn)) {
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByRecipientNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("shipper_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByShipperNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByShipperNameDescSQL, false, logger.isDebugEnabled());
        		}else if ("account_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByAccountNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByAccountNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("tracking_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByTrackingNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByTrackingNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("service_type_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByServiceTypeCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByServiceTypeCodeDescSQL, false, logger.isDebugEnabled());
        		}else if ("recipient_city_name".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByRecipientCityNameSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByRecipientCityNameDescSQL, false, logger.isDebugEnabled());   
        		}else if ("recipient_postal_code".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByRecipientPostalCodeSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByRecipientPostalCodeDescSQL, false, logger.isDebugEnabled()); 
        		}else if ("recipient_phone_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByRecipientPhoneNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByRecipientPhoneNumberDescSQL, false, logger.isDebugEnabled());
        		}else if ("monitor".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByMonitorSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByMonitorDescSQL, false, logger.isDebugEnabled());
        		}else if ("employee_number".equals(sortColumn)){
        			if (isSortAscending)
        				setSqlSignature(selectByRecipientAddressOrderByEmployeeNumberSQL, false, logger.isDebugEnabled());
        			else
        				setSqlSignature(selectByRecipientAddressOrderByEmployeeNumberDescSQL, false, logger.isDebugEnabled());         			
        		}else{
        			setSqlSignature(selectByRecipientAddressOrderByRecipientNameSQL, false, logger.isDebugEnabled());
        		}
        		pstmt.setInt(7, endIndex);
                pstmt.setInt(8, startIndex);
                pstmt.setString(1, "%" + aAddressLineOne + "%");
                pstmt.setString(2, "%" + aAddressCityName + "%");
                pstmt.setString(3, aAddressStateProvince);
                pstmt.setString(4, "%" + aAddressPostalCode + "%");            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNRecipientAddress.getTime());
            pstmt.setTimestamp(5, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNRecipientAddress.getTime());
            pstmt.setTimestamp(6, timeStampTo);


            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindPackagesCRNsByRecipientAddress(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }    

    /** count all CRNs SQL */
    private final static String countByRecipientAddressSQL = 
    		"select count(*) count " + 
        	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +  
            "where Upper(s.RECP_ADDR_LINE_ONE_DESC) like Upper(?) and " +
            "Upper(s.RECP_CITY_NM) like Upper(?) and Upper(s.RECP_ST_PROV_CD) = Upper(?) and " +
            "s.RECP_PSTL_CD like ? " +
            "and s.SHIP_DT >= ? and s.SHIP_DT <= ? " +
        	"and s.SHPMT_TYPE_CD = 'CRN' " +
        	"and s.GROUP_NBR = ag.GROUP_NBR (+) " +
        	"and s.GROUP_NBR = alsm.GROUP_NBR (+)" +
        	"and s.ACCT_NBR = alsm.ACCT_NBR (+) " +
        	"and s.LANE_NBR = alsm.LANE_NBR (+) " +
        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD (+) " +
        	"and alsm.EMP_NBR = e.EMP_NBR (+) "; 
    
    public int getCRNShipmentsCountRecipientAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress) throws SQLException {
    	int count = 0;

        try {
//        	if (aRecipientName != null){
        		setSqlSignature(countByRecipientAddressSQL, false, logger.isDebugEnabled() );
//        	}
            
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_limitOneWeekFromDateByCRNRecipientAddress.getTime());
            pstmt.setTimestamp(5, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_limitOneWeekToDateByCRNRecipientAddress.getTime());
            pstmt.setTimestamp(6, timeStampTo);
            pstmt.setString(1, "%" + aAddressLineOne + "%");
            pstmt.setString(2, "%" + aAddressCityName + "%");
            pstmt.setString(3, aAddressStateProvince);
            pstmt.setString(4, "%" + aAddressPostalCode + "%"); 

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                if (rs.next()) {
                    count = rs.getInt("COUNT");
                }                
            } else {
                // shipment not found
                logger.info("Shipment not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return count;
    }    
    
    
    
    
    
    
    
    
    
    private static final String getSearchByIssueCodeCRNSQL = "select UNIQUE "
            + "s.TRKNG_ITEM_NBR, " + "s.TRKNG_ITEM_UNIQ_NBR, " + "s.GROUP_NBR, " + "s.ACCT_NBR, "
            + "s.LANE_NBR," + "s.SVC_TYPE_CD, " + "s.SHPMT_TYPE_CD, " + "s.TRKNG_ITEM_FORM_CD, "
            + "s.PACK_TYPE_CD, " + "s.ORIG_LOC_CD, " + "s.DEST_LOC_CD, " + "s.SHPMT_WGT, "
            + "s.SHPMT_UOM_CD, " + "s.SHIP_DT, " + "s.SHPR_CO_NM, " + "s.SHPR_PH_NBR, "
            + "s.SHPR_ADDR_LINE_ONE_DESC, " + "s.SHPR_ADDR_LINE_TWO_DESC, "
            + "s.SHPR_ADDR_LINE_THREE_DESC, " + "s.SHPR_CITY_NM, " + "s.SHPR_PSTL_CD, "
            + "s.SHPR_CNTRY_CD, " + "s.SHPR_ST_PROV_CD, " + "s.RECP_CO_NM, " + "s.RECP_PH_NBR, "
            + "s.RECP_ADDR_LINE_ONE_DESC, " + "s.RECP_ADDR_LINE_TWO_DESC, "
            + "s.RECP_ADDR_LINE_THREE_DESC, " + "s.RECP_CITY_NM, " + "s.RECP_ST_PROV_CD, "
            + "s.RECP_CNTRY_CD, " + "s.RECP_PSTL_CD, " + "s.ACTL_DEL_NM, "
            + "s.ACTL_ADDR_LINE_ONE_DESC, " + "s.DEL_DT, " + "s.DEL_DATE_TMZN_OFFST_NBR, "
            + "s.SPCL_HNDLG_GRP, " + "s.CRTG_AGENT_CO_NM, " + "s.CSTMS_CURR_CD, "
            + "s.CSTMS_VALUE_AMT, " + "s.DIMNL_WGT, " + "s.INV_AMT, " + "s.SHPMT_PKG_QTY, "
            + "s.LAST_EVENT_TMSTP, " + "s.LAST_EVENT_TMZN_OFFST_NBR, "
            + "s.LAST_EVENT_TRACK_TYPE_CD, " + "s.COMMIT_DT, " + "s.ADJ_COMMIT_DT, "
            + "s.COMMIT_DATE_TMZN_OFFST_NBR, " + "s.ADJ_COMMIT_DT_OFFST_NBR, "
            + "s.PERF_RSULT_CD, " + "s.INPUT_TMSTP, " + "s.LAST_UPDT_TMSTP, " + "s.DEL_QTY, "
            + "s.SKID_INTACT_FLG, " + "s.QTY_OBSER_FLG, " + "s.PKG_PIECE_QTY, "
            + "i.ISSUE_TYPE_CD, " + "i.TRKNG_ITEM_NBR, " + "e.EMP_NBR, " + "e.EMP_FIRST_NM, "
            + "e.EMP_LAST_NM, " + "e.EMP_ROLE_CD "
            + "FROM SHIPMENT s, ACCT_LANE_SERVICE_MONITORING m, EMPLOYEE e, ISSUE i where "
            + "i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR and "
            + "i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR and "
            + "i.ISSUE_TYPE_CD = ? and s.TRKNG_ITEM_NBR like ? and s.ACCT_NBR = ? and "
            + "s.SHIP_DT >= ? and s.SHIP_DT <= ? and " + "s.SHPMT_TYPE_CD = 'CRN' and "
            + "s.ACCT_NBR = m.ACCT_NBR and m.EMP_NBR = e.EMP_NBR and "
            + "s.SVC_TYPE_CD = m.SVC_TYPE_CD and s.GROUP_NBR = m.GROUP_NBR and "
            + "s.LANE_NBR = m.LANE_NBR and " + "rownum <= 200";

    public List searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN,
            String aAcctNbrCRN, Date _toDate4, Date _fromDate4) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByIssueCodeCRNSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aIssueCodeCRN);
            pstmt.setString(2, "%" + aTrackingNbrCRN + "%");
            pstmt.setString(3, aAcctNbrCRN);
            java.sql.Timestamp timeStampFrom = new java.sql.Timestamp(_fromDate4.getTime());
            pstmt.setTimestamp(4, timeStampFrom);
            java.sql.Timestamp timeStampTo = new java.sql.Timestamp(_toDate4.getTime());
            pstmt.setTimestamp(5, timeStampTo);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchAllShipmentEmployeeColumns(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }



    private static final String getSearchByWithoutPODCRNSQL = "select UNIQUE "
            + "s.TRKNG_ITEM_NBR, " + "s.TRKNG_ITEM_UNIQ_NBR, " + "s.GROUP_NBR, " + "s.ACCT_NBR, "
            + "s.LANE_NBR," + "s.SVC_TYPE_CD, " + "s.SHPMT_TYPE_CD, " + "s.TRKNG_ITEM_FORM_CD, "
            + "s.PACK_TYPE_CD, " + "s.ORIG_LOC_CD, " + "s.DEST_LOC_CD, " + "s.SHPMT_WGT, "
            + "s.SHPMT_UOM_CD, " + "s.SHIP_DT, " + "s.SHPR_CO_NM, " + "s.SHPR_PH_NBR, "
            + "s.SHPR_ADDR_LINE_ONE_DESC, " + "s.SHPR_ADDR_LINE_TWO_DESC, "
            + "s.SHPR_ADDR_LINE_THREE_DESC, " + "s.SHPR_CITY_NM, " + "s.SHPR_PSTL_CD, "
            + "s.SHPR_CNTRY_CD, " + "s.SHPR_ST_PROV_CD, " + "s.RECP_CO_NM, " + "s.RECP_PH_NBR, "
            + "s.RECP_ADDR_LINE_ONE_DESC, " + "s.RECP_ADDR_LINE_TWO_DESC, "
            + "s.RECP_ADDR_LINE_THREE_DESC, " + "s.RECP_CITY_NM, " + "s.RECP_ST_PROV_CD, "
            + "s.RECP_CNTRY_CD, " + "s.RECP_PSTL_CD, " + "s.ACTL_DEL_NM, "
            + "s.ACTL_ADDR_LINE_ONE_DESC, " + "s.DEL_DT, " + "s.DEL_DATE_TMZN_OFFST_NBR, "
            + "s.SPCL_HNDLG_GRP, " + "s.CRTG_AGENT_CO_NM, " + "s.CSTMS_CURR_CD, "
            + "s.CSTMS_VALUE_AMT, " + "s.DIMNL_WGT, " + "s.INV_AMT, " + "s.SHPMT_PKG_QTY, "
            + "s.LAST_EVENT_TMSTP, " + "s.LAST_EVENT_TMZN_OFFST_NBR, "
            + "s.LAST_EVENT_TRACK_TYPE_CD, " + "s.COMMIT_DT, " + "s.ADJ_COMMIT_DT, "
            + "s.COMMIT_DATE_TMZN_OFFST_NBR, " + "s.ADJ_COMMIT_DT_OFFST_NBR, "
            + "s.PERF_RSULT_CD, " + "s.INPUT_TMSTP, " + "s.LAST_UPDT_TMSTP, " + "s.DEL_QTY, "
            + "s.SKID_INTACT_FLG, " + "s.QTY_OBSER_FLG, " + "s.PKG_PIECE_QTY, "
            + "i.TRKNG_ITEM_NBR, " + "i.TRKNG_ITEM_UNIQ_NBR, " + "i.TRACK_TYPE_CD, "
            + "e.EMP_NBR, " + "e.EMP_FIRST_NM, " + "e.EMP_LAST_NM, " + "e.EMP_ROLE_CD "
            + "FROM SHIPMENT s, ACCT_LANE_SERVICE_MONITORING m, EMPLOYEE e, ISSUE i where "
            + "s.TRKNG_ITEM_NBR = i.TRKNG_ITEM_NBR and "
            + "s.TRKNG_ITEM_UNIQ_NBR = i.TRKNG_ITEM_UNIQ_NBR and s.ACCT_NBR = ? and "
            + "s.TRKNG_ITEM_NBR like ? and i.TRACK_TYPE_CD = '20' and "
            + "s.SHPMT_TYPE_CD = 'CRN' and "
            + "s.ACCT_NBR = m.ACCT_NBR and m.EMP_NBR = e.EMP_NBR and "
            + "s.SVC_TYPE_CD = m.SVC_TYPE_CD and s.GROUP_NBR = m.GROUP_NBR and "
            + "s.LANE_NBR = m.LANE_NBR and " + "rownum <= 200";

    public List searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2)
            throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByWithoutPODCRNSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aAcctNbr2);
            pstmt.setString(2, "%" + aTrackingNbrMAWB2 + "%");

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchAllShipmentEmployeeColumns(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    

    // FIND MISSING DATA BY ACCOUNT #
    // ------------------------------------------------------------

    private static final String getSearchByFindMissingDataSQL = "select UNIQUE "
            + "s.TRKNG_ITEM_NBR, " + "s.TRKNG_ITEM_UNIQ_NBR, " + "s.GROUP_NBR, " + "s.ACCT_NBR, "
            + "s.LANE_NBR," + "s.SVC_TYPE_CD, " + "s.SHPMT_TYPE_CD, " + "s.TRKNG_ITEM_FORM_CD, "
            + "s.PACK_TYPE_CD, " + "s.ORIG_LOC_CD, " + "s.DEST_LOC_CD, " + "s.SHPMT_WGT, "
            + "s.SHPMT_UOM_CD, " + "s.SHIP_DT, " + "s.SHPR_CO_NM, " + "s.SHPR_PH_NBR, "
            + "s.SHPR_ADDR_LINE_ONE_DESC, " + "s.SHPR_ADDR_LINE_TWO_DESC, "
            + "s.SHPR_ADDR_LINE_THREE_DESC, " + "s.SHPR_CITY_NM, " + "s.SHPR_PSTL_CD, "
            + "s.SHPR_CNTRY_CD, " + "s.SHPR_ST_PROV_CD, " + "s.RECP_CO_NM, " + "s.RECP_PH_NBR, "
            + "s.RECP_ADDR_LINE_ONE_DESC, " + "s.RECP_ADDR_LINE_TWO_DESC, "
            + "s.RECP_ADDR_LINE_THREE_DESC, " + "s.RECP_CITY_NM, " + "s.RECP_ST_PROV_CD, "
            + "s.RECP_CNTRY_CD, " + "s.RECP_PSTL_CD, " + "s.ACTL_DEL_NM, "
            + "s.ACTL_ADDR_LINE_ONE_DESC, " + "s.DEL_DT, " + "s.DEL_DATE_TMZN_OFFST_NBR, "
            + "s.SPCL_HNDLG_GRP, " + "s.CRTG_AGENT_CO_NM, " + "s.CSTMS_CURR_CD, "
            + "s.CSTMS_VALUE_AMT, " + "s.DIMNL_WGT, " + "s.INV_AMT, " + "s.SHPMT_PKG_QTY, "
            + "s.LAST_EVENT_TMSTP, " + "s.LAST_EVENT_TMZN_OFFST_NBR, "
            + "s.LAST_EVENT_TRACK_TYPE_CD, " + "s.COMMIT_DT, " + "s.ADJ_COMMIT_DT, "
            + "s.COMMIT_DATE_TMZN_OFFST_NBR, " + "s.ADJ_COMMIT_DT_OFFST_NBR, "
            + "s.PERF_RSULT_CD, " + "s.INPUT_TMSTP, " + "s.LAST_UPDT_TMSTP, " + "s.DEL_QTY, "
            + "s.SKID_INTACT_FLG, " + "s.QTY_OBSER_FLG, " + "s.PKG_PIECE_QTY, "
            + "i.TRKNG_ITEM_NBR, " + "i.TRKNG_ITEM_UNIQ_NBR, " + "i.ISSUE_TYPE_CD, "
            + "e.EMP_NBR, " + "e.EMP_FIRST_NM, " + "e.EMP_LAST_NM, " + "e.EMP_ROLE_CD "
            + "FROM SHIPMENT s, ACCT_LANE_SERVICE_MONITORING m, EMPLOYEE e, ISSUE i where "
            + "s.TRKNG_ITEM_NBR = i.TRKNG_ITEM_NBR and "
            + "s.TRKNG_ITEM_UNIQ_NBR = i.TRKNG_ITEM_UNIQ_NBR and " + "s.ACCT_NBR = ? and "
            + "(i.ISSUE_TYPE_CD = '76' or i.ISSUE_TYPE_CD = '77' or i.ISSUE_TYPE_CD = '78') and "
            + "s.ACCT_NBR = m.ACCT_NBR and m.EMP_NBR = e.EMP_NBR and "
            + "s.SVC_TYPE_CD = m.SVC_TYPE_CD and s.GROUP_NBR = m.GROUP_NBR and "
            + "s.LANE_NBR = m.LANE_NBR and " + "rownum <= 200";

    public List searchByFindMissingData(String aAcctNbr) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByFindMissingDataSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aAcctNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchAllShipmentEmployeeColumns(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;
            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    // FIND MONITOR BY ACCOUNT OR TRACKING NUMBER
    // ------------------------------------------------
    private static final String getSearchByFindMonitorAcctNbrSQL = "select UNIQUE " +
    	"alsm.ACCT_NBR, " +
    	"e.EMP_NBR, " +
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM " +
    	"from ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +
    	"where alsm.ACCT_NBR = ? and " +
    	"alsm.EMP_NBR = e.EMP_NBR";

    public List searchByFindMonitorAcctNbr(String aAcctNbr) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByFindMonitorAcctNbrSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aAcctNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindMonitorByAccountNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;

            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }

    private static final String getSearchByFindMonitorTrkngNbrSQL = "select UNIQUE " +
    	"s.TRKNG_ITEM_NBR, " + 
    	"s.ACCT_NBR, " +
    	"e.EMP_NBR, " +
    	"e.EMP_FIRST_NM, " +
    	"e.EMP_LAST_NM " +
    	"from SHIPMENT s, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +
    	"where s.TRKNG_ITEM_NBR = ? and " +
    	"s.GROUP_NBR = alsm.GROUP_NBR and " +
    	"s.ACCT_NBR = alsm.ACCT_NBR and " +
    	"s.LANE_NBR = alsm.LANE_NBR and " +
    	"s.SVC_TYPE_CD = alsm.SVC_TYPE_CD and " +
    	"alsm.EMP_NBR = e.EMP_NBR";

    public List searchByFindMonitorTrkngNbr(String aTrackingNbr) throws SQLException {
        ArrayList al = new ArrayList();

        try {
            setSqlSignature(getSearchByFindMonitorTrkngNbrSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, aTrackingNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {

                while (rs.next()) {
                    ShipmentEmployeeVO shipmentemployeeVO = new ShipmentEmployeeVO();
                    fetchSearchFindMonitorByTrackingNumber(shipmentemployeeVO);
                    al.add(shipmentemployeeVO);
                }
                return al;

            }
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return null;
    }


    
    // FIND SHIPPER BY SHIPPER NAME OR ACCOUNT NUMBER ------------------------------------
    
    private void fetchSearchFindShipperByShipperName(ShipmentEmployeeVO shipmentemployeeVO)
    		throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_grp_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_acct_nm(rs.getString("ACCT_NM"));
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("ORIG_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("DEST_CNTRY_CD"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    }

    private void fetchSearchFindShipperByAccountNumber(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_grp_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_acct_nm(rs.getString("ACCT_NM"));
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    }      
    
    // FIND SHIPMENT BY TRACKING OR REFERENCE NUMBER -------------------------------------------    
    
    private void fetchSearchFindShipmentByTrackingNumber(ShipmentEmployeeVO shipmentemployeeVO)
    		throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	//Start WR#:179441 Changes
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
    	//End WR#:179441 Changes
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    }
    
    private void fetchSearchFindShipmentByReferenceNote(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
    	shipmentemployeeVO.set_lane_nbr(rs.getInt("LANE_NBR"));
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    }    
    
    // FIND SHIPMENTS - MAWBS ------------------------------------------------------------------
    // BY TRACKING #, ACCOUNT NAME, SHIP DATE RANGE OR SHIP DATE WITH
    // MISSING ACCOUNT #
    
    private void fetchSearchFindShipmentsMAWBsByTrackingNumber(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));    	
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);    	
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
    	shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_lane_string(rs.getString("SHPR_CNTRY_CD")
    			+ "-" + rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR")); 
    }
    
    private void fetchSearchFindShipmentsMAWBsByShipperName(ShipmentEmployeeVO shipmentemployeeVO)
    		throws SQLException {
        shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
        shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
        shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
        shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));  
        shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD")); 
        shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR")); 
        shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
        shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));  
        shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));        
        Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
        shipmentemployeeVO.set_ship_dt(shipDt);
    } 
    
    private void fetchSearchFindShipmentsMAWBsByAccountNumberShipDateRange(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    }
    
    private void fetchSearchFindShipmentsMAWBsByAccountNumberShipDate(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    }    
    
    // FIND PACKAGES - CRNS
    // ------------------------------------------------------------------------
    // BY RETURN TRACKING #, RECIPIENT NAME, RECIPIENT POSTAL CODE,
    // ISSUE CODE, WITH ODA, WITHOUT A POD, RECIPEINT ADDRESS    
    
    private void fetchSearchFindPackagesCRNsByReturnTrackingNumber(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));        	
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
        shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
        shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));    	
    	shipmentemployeeVO.set_assoc_trkng_item_nbr(rs.getString("ASSOC_TRKNG_ITEM_NBR"));  
    } 
    
    private void fetchSearchFindPackagesCRNsByRecipientName(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));    	
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);    	
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
    	shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
        shipmentemployeeVO.set_lane_string(rs.getString("SHPR_CNTRY_CD")
        		+ "-" + rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));    	
    	
    }     
    
    private void fetchSearchFindPackagesCRNsByRecipientPostalCode(ShipmentEmployeeVO shipmentemployeeVO)
	throws SQLException {

    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));    	
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);    	
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
    	shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_lane_string(rs.getString("SHPR_CNTRY_CD")
    			+ "-" + rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));    	

}   
    
    private void fetchSearchFindPackagesCRNsByWithODA(ShipmentEmployeeVO shipmentemployeeVO)
	throws SQLException {   	
    	
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));    	
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);    	
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
    	shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_lane_string(rs.getString("SHPR_CNTRY_CD")
    			+ "-" + rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR")); 
    	shipmentemployeeVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
}   
    
    private void fetchSearchFindPackagesCRNsByRecipientAddress(ShipmentEmployeeVO shipmentemployeeVO)
			throws SQLException {
    	shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
    	shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
    	shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("GROUP_NM"));
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));     	
    	shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
    	shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
    	shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
    	shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
    	shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));    	       
    }    

    // FIND MONITOR BY ACCOUNT OR TRACKING NUMBER
    // ------------------------------------------------    
    
    private void fetchSearchFindMonitorByAccountNumber(ShipmentEmployeeVO shipmentemployeeVO) 
    		throws SQLException {
        shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
        shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
        shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
        shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    }

    private void fetchSearchFindMonitorByTrackingNumber(ShipmentEmployeeVO shipmentemployeeVO)
            throws SQLException {
        shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
        shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
        shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
        shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
        shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    }
 
    // RAMP HUB SEARCH
    private void fetchRampHubSearch(ShipmentEmployeeVO shipmentemployeeVO)
    		throws SQLException {
    	shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
    	shipmentemployeeVO.set_ship_dt(shipDt);
    	Date commitDt = (java.util.Date)rs.getTimestamp("COMMIT_DT");   
        if (commitDt != null) {
            String dtTmstpTzOffset = rs.getString("COMMIT_DATE_TMZN_OFFST_NBR");
            TimeZone dtTz = TimeZone.getTimeZone("GMT" + dtTmstpTzOffset);
            Calendar dtCalendar = Calendar.getInstance(dtTz);
            dtCalendar.setTime(commitDt);
            shipmentemployeeVO.set_commit_date(dtCalendar.getTime());
        }
    	shipmentemployeeVO.set_dest_loc_cd(rs.getString("DEST_LOC_CD"));
        shipmentemployeeVO.set_lane_string(rs.getString("SHPR_CNTRY_CD")
        		+ "-" + rs.getString("RECP_CNTRY_CD"));
    	shipmentemployeeVO.set_shpr_co_nm(rs.getString("SHPR_CO_NM"));
    	shipmentemployeeVO.set_shpmt_pkg_qt(rs.getInt("SHPMT_PKG_QTY"));
    	double wgtDouble = (double)rs.getInt("SHPMT_WGT")/100.0;
    	shipmentemployeeVO.set_shpmt_wgt_double(wgtDouble);
    	shipmentemployeeVO.set_last_stat_desc(rs.getString("LAST_STAT_DESC"));
    	shipmentemployeeVO.set_last_event_track_loc_cd(rs.getString("LAST_EVENT_TRACK_LOC_CD")); 
    	Date lastEventTMstp = (java.util.Date)rs.getTimestamp("LAST_EVENT_TMSTP");
        if (lastEventTMstp != null) {
            String dtTmstpTzOffset = rs.getString("LAST_EVENT_TMZN_OFFST_NBR");
            TimeZone dtTz = TimeZone.getTimeZone("GMT" + dtTmstpTzOffset);
            Calendar dtCalendar = Calendar.getInstance(dtTz);
            dtCalendar.setTime(lastEventTMstp);
            shipmentemployeeVO.set_last_event_tmstp(dtCalendar); 
        }
        Date clearedCstmsTmstp = (java.util.Date)rs.getTimestamp("CLEARED_CSTMS_TMSTP");
        if (clearedCstmsTmstp != null) {
            String clearedCstmsTmstpTzOffset = rs.getString("CLEARED_CSTMS_TMZN_OFFSET_NBR");
            TimeZone clearedCstmsTz = TimeZone.getTimeZone("GMT" + clearedCstmsTmstpTzOffset);
            Calendar clearedCstmsCal = Calendar.getInstance(clearedCstmsTz); 
            clearedCstmsCal.setTime(clearedCstmsTmstp);
            shipmentemployeeVO.set_cleared_cstms_tmstp(clearedCstmsCal);
        }
    }    
    
    
    // MISC SEARCH RESOURCES ------------------------------------------------------
    
    private void fetchAllShipmentEmployeeColumns(ShipmentEmployeeVO shipmentemployeeVO)
            throws SQLException {
    	
        shipmentemployeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
        shipmentemployeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
        shipmentemployeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
        shipmentemployeeVO.set_emp_role_cd(rs.getString("EMP_ROLE_CD"));

        shipmentemployeeVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
        shipmentemployeeVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
        shipmentemployeeVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
        shipmentemployeeVO.set_acct_nbr(rs.getString("ACCT_NBR"));
        shipmentemployeeVO.set_lane_nbr(rs.getInt("LANE_NBR"));
        shipmentemployeeVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
        shipmentemployeeVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
        shipmentemployeeVO.set_trkng_item_form_cd(rs.getInt("TRKNG_ITEM_FORM_CD"));
        shipmentemployeeVO.set_pack_type_cd(rs.getInt("PACK_TYPE_CD"));
        shipmentemployeeVO.set_orig_loc_cd(rs.getString("ORIG_LOC_CD"));
        shipmentemployeeVO.set_dest_loc_cd(rs.getString("DEST_LOC_CD"));
        shipmentemployeeVO.set_shpmt_wgt(rs.getInt("SHPMT_WGT"));
        shipmentemployeeVO.set_shpmt_uom_cd(rs.getString("SHPMT_UOM_CD").charAt(0));

        Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
        shipmentemployeeVO.set_ship_dt(shipDt);

        shipmentemployeeVO.set_shpr_co_nm(rs.getString("SHPR_CO_NM"));
        shipmentemployeeVO.set_shpr_ph_nbr(rs.getString("SHPR_PH_NBR"));
        shipmentemployeeVO.set_shpr_addr_line_one_desc(rs.getString("SHPR_ADDR_LINE_ONE_DESC"));
        shipmentemployeeVO.set_shpr_addr_line_two_desc(rs.getString("SHPR_ADDR_LINE_TWO_DESC"));
        shipmentemployeeVO.set_shpr_addr_line_three_desc(rs.getString("SHPR_ADDR_LINE_THREE_DESC"));
        shipmentemployeeVO.set_shpr_city_nm(rs.getString("SHPR_CITY_NM"));
        shipmentemployeeVO.set_shpr_pstl_cd(rs.getString("SHPR_PSTL_CD"));
        shipmentemployeeVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
        shipmentemployeeVO.set_shpr_st_prov_cd(rs.getString("SHPR_ST_PROV_CD"));
        shipmentemployeeVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
        shipmentemployeeVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
        shipmentemployeeVO.set_recp_addr_line_one_desc(rs.getString("RECP_ADDR_LINE_ONE_DESC"));
        shipmentemployeeVO.set_recp_addr_line_two_desc(rs.getString("RECP_ADDR_LINE_TWO_DESC"));
        shipmentemployeeVO.set_recp_addr_line_three_desc(rs.getString("RECP_ADDR_LINE_THREE_DESC"));
        shipmentemployeeVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
        shipmentemployeeVO.set_recp_st_prov_cd(rs.getString("RECP_ST_PROV_CD"));
        shipmentemployeeVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
        shipmentemployeeVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
        shipmentemployeeVO.set_actl_del_nm(rs.getString("ACTL_DEL_NM"));
        shipmentemployeeVO.set_actl_addr_line_one_desc(rs.getString("ACTL_ADDR_LINE_ONE_DESC"));

        Date delDtTmstp = (java.util.Date) rs.getTimestamp("DEL_DT");
        if (delDtTmstp != null) {
            String deldtTmstpTzOffset = rs.getString("DEL_DATE_TMZN_OFFST_NBR");
            TimeZone delDtTz = TimeZone.getTimeZone("GMT" + deldtTmstpTzOffset);
            Calendar delDtCalendar = Calendar.getInstance(delDtTz);
            delDtCalendar.setTime(delDtTmstp);
            shipmentemployeeVO.set_del_dt(delDtCalendar);
        }

        shipmentemployeeVO.set_spcl_hndlg_grp(rs.getString("SPCL_HNDLG_GRP"));
        shipmentemployeeVO.set_crtg_agent_co_nm(rs.getString("CRTG_AGENT_CO_NM"));
        shipmentemployeeVO.set_cstms_curr_cd(rs.getString("CSTMS_CURR_CD"));
        shipmentemployeeVO.set_cstms_value_amt(rs.getInt("CSTMS_VALUE_AMT"));
        shipmentemployeeVO.set_dimnl_wgt(rs.getInt("DIMNL_WGT"));
        shipmentemployeeVO.set_inv_amt(rs.getInt("INV_AMT"));
        shipmentemployeeVO.set_shpmt_pkg_qt(rs.getInt("SHPMT_PKG_QTY"));

        Date lastEventTmstp = (java.util.Date) rs.getTimestamp("LAST_EVENT_TMSTP");
        if (lastEventTmstp != null) {
            String lastEventTmstpTzOffset = rs.getString("LAST_EVENT_TMZN_OFFST_NBR");
            TimeZone lastEventTz = TimeZone.getTimeZone("GMT" + lastEventTmstpTzOffset);
            Calendar lastEventCalendar = Calendar.getInstance(lastEventTz);
            lastEventCalendar.setTime(lastEventTmstp);
            shipmentemployeeVO.set_last_event_tmstp(lastEventCalendar);
        }

        shipmentemployeeVO.set_last_event_track_type_cd(rs.getString("LAST_EVENT_TRACK_TYPE_CD"));

        TimeZone commitDtTz = null;
        Date commitDt = (java.util.Date) rs.getTimestamp("COMMIT_DT");
        if (commitDt != null) {
            String commitDtTzOffset = rs.getString("COMMIT_DATE_TMZN_OFFST_NBR");
            commitDtTz = TimeZone.getTimeZone("GMT" + commitDtTzOffset);
            Calendar commitCalendar = Calendar.getInstance(commitDtTz);
            commitCalendar.setTime(commitDt);
            shipmentemployeeVO.set_commit_dt(commitCalendar);
        }

        Date adjCommitDt = null;
        adjCommitDt = (java.util.Date) rs.getTimestamp("ADJ_COMMIT_DT");
        if (adjCommitDt != null && commitDtTz != null) {
            Calendar adjCommitCalendar = Calendar.getInstance(commitDtTz);
            adjCommitCalendar.setTime(adjCommitDt);
            shipmentemployeeVO.set_adj_commit_dt(adjCommitCalendar);
        }

        shipmentemployeeVO.set_adj_commit_dt_offst_nbr(rs.getInt("ADJ_COMMIT_DT_OFFST_NBR"));

        shipmentemployeeVO.set_perf_rsult_cd(rs.getString("PERF_RSULT_CD"));

        shipmentemployeeVO.set_delivery_qty(rs.getInt("DEL_QTY"));
        String skidIntactFlg = rs.getString("SKID_INTACT_FLG");
        if (skidIntactFlg != null) {
            shipmentemployeeVO.set_skid_intact_flag(skidIntactFlg.charAt(0));
        }

        String qtyObserFlg = rs.getString("QTY_OBSER_FLG");
        if (qtyObserFlg != null) {
            shipmentemployeeVO.set_quantity_observed_flag(qtyObserFlg.charAt(0));
        }

        shipmentemployeeVO.set_package_piece_qty(rs.getInt("PKG_PIECE_QTY"));
    }

}
