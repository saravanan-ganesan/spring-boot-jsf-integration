package com.fedex.rise.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "EMPLOYEE")
public class EmployeeEntity {

	@Id
	@Column(name = "emp_nbr")
    private String empNbr;
	
    private String emp_first_nm;
    private String emp_last_nm;
    private String emp_role_cd;
}
