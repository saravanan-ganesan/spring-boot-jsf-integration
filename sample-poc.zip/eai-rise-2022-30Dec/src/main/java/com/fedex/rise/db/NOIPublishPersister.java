package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.NOIPublishVO;

/**
 * Class to persist and delete data to the NOI_PUBLISH table.
 * 
 * @author be379961
 *
 */
public class NOIPublishPersister extends OracleBase {
    
    private static Logger logger = LogManager.getLogger(NOIPublishPersister.class);
    
    /**
     * Constructor
     * 
     * @param con Connection instance
     */
    public NOIPublishPersister(Connection con) {
        super(con);
    }
   
    /** 
     * SQL for insert a row 
     */
    private static final String insertNOIPublishSQL = "Insert into NOTIFICATION_OF_INTEREST(" +
                 "RTRN_TRKNG_ITEM_NBR, " +
                 "SHIP_DT, " +
                 "NOI_RQST_TMSTP, " +
                 "PBLSH_DT, " +
                 "NOI_INPUT_TMSTP)" +
                 "values(?,?,?,?,sysdate)";
    
    /**
     * Persist a row to the NOI_PUBLISH table.
     * 
     * @param aNOIPublishVO a NOIPublishVO to be persisted
     * @throws SQLException 
     */
    public void persist(NOIPublishVO aNOIPublishVO) throws SQLException {
        try {
            setSqlSignature( insertNOIPublishSQL, false, logger.isDebugEnabled() );

            pstmt.setString(1, aNOIPublishVO.get_trk_item_nbr());
            
            if (aNOIPublishVO.get_ship_date() != null) {
            	java.sql.Date sqlDate = 
            		new java.sql.Date(aNOIPublishVO.get_ship_date().getTime());
            	pstmt.setDate(2, sqlDate);
            } else {
            	pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            if (aNOIPublishVO.get_trk_date_time() != null) {
            	
            	java.sql.Timestamp sqlTimestamp = 
            		new java.sql.Timestamp(aNOIPublishVO.get_trk_date_time().getTime());
            	
            	pstmt.setTimestamp(3, sqlTimestamp);
            } else {
            	pstmt.setNull(  3, java.sql.Types.DATE);
            }
            
            if (aNOIPublishVO.get_publish_date() != null) {
            	
            	java.sql.Timestamp sqlTimestamp = 
            		new java.sql.Timestamp(aNOIPublishVO.get_publish_date().getTime());
            	
            	pstmt.setTimestamp(4, sqlTimestamp);
            } else {
            	pstmt.setNull(  4, java.sql.Types.DATE);
            }
                     
            execute();
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
        } catch (SQLException sqle) {
            // Duplicate
            if (sqle.getMessage().indexOf("ORA-00001") != -1) {
            	logger.info("Duplicate NOI");
            	logger.info(pstmt.toString());
                return;
            }
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;

        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
              logger.error("persist SQL exception: ", sqle2);
            }
        }    
    }
    
    /** SQL for delete a row */
    private static final String deleteNOIPublishSQL = "delete from " +
    		"NOTIFICATION_OF_INTEREST where RTRN_TRKNG_ITEM_NBR = ?"; 
    
    /**
     * Delete a row from the NOI_PUBLISH table.
     * 
     * @param aNOIPublishVO the NOIPublishVO to be deleted
     * @throws SQLException 
     */
    public void deleteRow(NOIPublishVO aNOIPublishVO) throws SQLException {
        try {
            setSqlSignature( deleteNOIPublishSQL );
            pstmt.setString(1, aNOIPublishVO.get_trk_item_nbr());
            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
              sqle2.printStackTrace();
              logger.error("persist SQL exception: ", sqle2);
            }
        }    
    }
    
}

