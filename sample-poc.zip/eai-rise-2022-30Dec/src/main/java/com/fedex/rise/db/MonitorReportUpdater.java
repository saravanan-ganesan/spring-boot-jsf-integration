package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.MonitorReportVO;

public class MonitorReportUpdater extends OracleBase {
	private static Logger logger = LogManager.getLogger(MonitorReportUpdater.class);
	
	public MonitorReportUpdater(Connection con) {
        super(con);
    }
	
	private static final String updateMonitorReportRowSQL =
	    "update Monitor_Report set " +
	    "EMP_NBR = ?, " +
	    "WORK_DT = ?, " +
	    "BEGIN_HAND_QTY = ?, " +       
	    "ISSUE_RCVD_QTY = ?, " +
	    "END_HAND_QTY = ?, " +
	    "ISSUE_RSLV_QTY = ?, " +
	    "ACCOUNT_QTY = ?, " +
	    "MAWB_RSLV_QTY = ?, " +
	    "CRN_RSLV_QTY = ?  " +
	    "where " +
	    "EMP_NBR = ? and WORK_DT = ? ";   
	
	private static final String updateDurationTimeSQL =
	    "update Monitor_Report set " +
	    "DURATION_QTY = ?  " +
	    "where " +
	    "EMP_NBR = ? and WORK_DT = ? ";
	
	private static final String updateNumberHitsSQL =
	    "update Monitor_Report set " +
	    "HIT_QTY = ?  " +
	    "where " +
	    "EMP_NBR = ? and WORK_DT = ? ";
	
	private final String selectDurationTimeForUpdateSQL = "select " +
    "DURATION_QTY " +
    "from Monitor_Report where WORK_DT = ? and EMP_NBR = ? ";


	public void updateMonitorReport(MonitorReportVO aMonitorReportVO) throws SQLException {
	    
	    try {
	        setSqlSignature( updateMonitorReportRowSQL, false, logger.isDebugEnabled() );
    
	        pstmt.setString( 1, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  2, sqlDate);
	        } else {
	            pstmt.setNull(  2, java.sql.Types.DATE);
	        }
	        pstmt.setInt(3, aMonitorReportVO.get_num_issues_begin_shift());
	        pstmt.setInt(4, aMonitorReportVO.get_num_issues_presented());
	        pstmt.setInt(5, aMonitorReportVO.get_num_issues_end_shift());
	        pstmt.setInt(6, aMonitorReportVO.get_num_issues_resolved());
	        pstmt.setInt(7, aMonitorReportVO.get_total_number_accounts());
	        pstmt.setInt(8, aMonitorReportVO.get_num_mawb_resolved());
	        pstmt.setInt(9, aMonitorReportVO.get_num_crn_resolved());
	        
	        pstmt.setString( 10, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  11, sqlDate);
	        } else {
	            pstmt.setNull(  11, java.sql.Types.DATE);
	        }
	            
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        int rowsUpdated = executeUpdate();

	        if ( rowsUpdated == 0) {
	            // row not updated
	            logger.error("monitor report table not Updated for emp nbr: " +
	            		aMonitorReportVO.get_emp_nbr() + "work date:" 
	                    + aMonitorReportVO.get_work_dt().toString());
	        }

	    } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	            throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
	
	public void updateDurationTime(MonitorReportVO aMonitorReportVO) throws SQLException {
	    
	    try {
	        setSqlSignature( updateDurationTimeSQL, false, logger.isDebugEnabled() );
    
	        pstmt.setInt(1, aMonitorReportVO.get_total_duration());
	        
	        pstmt.setString( 2, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  3, sqlDate);
	        } else {
	            pstmt.setNull(  3, java.sql.Types.DATE);
	        }
	            
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        int rowsUpdated = executeUpdate();

	        if ( rowsUpdated == 0) {
	            // row not updated
	            logger.error("monitor report table not Updated for emp nbr: " +
	            		aMonitorReportVO.get_emp_nbr() + "work date:" 
	                    + aMonitorReportVO.get_work_dt().toString());
	        }

	    } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	            throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
	
	public void updateNumberHits(MonitorReportVO aMonitorReportVO) throws SQLException {
	    
	    try {
	        setSqlSignature( updateNumberHitsSQL, false, logger.isDebugEnabled() );
    
	        pstmt.setInt(1, aMonitorReportVO.get_num_hits());
	        
	        pstmt.setString( 2, aMonitorReportVO.get_emp_nbr());
	        if (aMonitorReportVO.get_work_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
	            pstmt.setDate(  3, sqlDate);
	        } else {
	            pstmt.setNull(  3, java.sql.Types.DATE);
	        }
	            
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        int rowsUpdated = executeUpdate();

	        if ( rowsUpdated == 0) {
	            // row not updated
	            logger.error("monitor report table not Updated for emp nbr: " +
	            		aMonitorReportVO.get_emp_nbr() + "work date:" 
	                    + aMonitorReportVO.get_work_dt().toString());
	        }

	    } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	            throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
	
    public int getDurationTimeForUpdate(MonitorReportVO aMonitorReportVO) 
		throws SQLException {
    
    	int durationTime = 0;
    	if (aMonitorReportVO.get_work_dt() != null){
    		try {
    			setSqlSignature( selectDurationTimeForUpdateSQL, false, logger.isDebugEnabled() );
    			if (aMonitorReportVO.get_work_dt() != null) {
    				java.sql.Date sqlDate =
    					new java.sql.Date(aMonitorReportVO.get_work_dt().getTimeInMillis());
    				pstmt.setDate(  1, sqlDate);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.DATE);
    			}
    			pstmt.setString(  2, aMonitorReportVO.get_emp_nbr());
    		
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if (hasResults & rs.next()) {
    				durationTime = rs.getInt("DURATION_QTY");
    			} else {
    				return 0;
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
    					+ sqle.getSQLState() + ": ErrorCode: " 
    					+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
    	return durationTime;
    }
}
