package com.fedex.rise.vo;

import java.io.Serializable;

public class AccountGroupVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int _group_nbr;
    private String _group_nm;
    private String _group_desc;
    
    public AccountGroupVO(int _group_nbr, String _group_nm, String _group_desc) {
        super();
        this._group_nbr = _group_nbr;
        this._group_nm = _group_nm;
        this._group_desc = _group_desc;
    }
    
    public AccountGroupVO() {
    }
    /**
     * @return the _group_nbr
     */
    public int get_group_nbr() {
        return _group_nbr;
    }
    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_group_nbr(int _group_nbr) {
        this._group_nbr = _group_nbr;
    }
    /**
     * @return the _group_desc
     */
    public String get_group_desc() {
        return _group_desc;
    }
    /**
     * @param _group_desc the _group_desc to set
     */
    public void set_group_desc(String _group_desc) {
        this._group_desc = _group_desc;
    }
    /**
     * @return the _group_nm
     */
    public String get_group_nm() {
        return _group_nm;
    }
    /**
     * @param _group_nm the _group_nm to set
     */
    public void set_group_nm(String _group_nm) {
        this._group_nm = _group_nm;
    }



}
