package com.fedex.rise.bo.issue;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.bo.issue.Preventer;
import com.fedex.rise.cache.AccountCacheDAO;
import com.fedex.rise.config.ConfigurationManager;
import com.fedex.rise.db.EventDAO;
import com.fedex.rise.db.IssueDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AssociatedShipmentVO;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IPDShipmentVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;
import com.fedex.rise.xref.TrackDesc;
import com.fedex.rise.xref.TrackTypes;
import com.fedex.rise.util.RiseConstants;

/**
 * Issues are created as events arrive, if an issue is found for a specific event 
 * then an issue is created.  The issue may be "real" immediately or at some 
 * later time.  Issues are resolved by events arriving or human resolving events
 * on the GUI.
 */
public class IssueProcessor extends RiseIssues {
    
    /**
     * Right now, resolving issues with update and or delete does
     * not consider the location code.  It will resolve all of
     * the issues regardless of the location.  I think this is
     * ok.
     */
    
    // Logger
    private static Logger logger = LogManager.getLogger(IssueProcessor.class);
    
    // For debugging the times in a pretty format
    SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
 
    /**
     * Get a list of non resolved issues, non resolved issues don't have
     * a resolved date in the database
     * @param aTrkngItemNbr
     * @param aTrkngItemUniqNbr
     * @return a list of unresolved issues
     * @throws ServiceLocatorException
     * @throws SQLException
     */
    public List getUnresolvedIssues(String aTrkngItemNbr,  String aTrkngItemUniqNbr) throws ServiceLocatorException, SQLException {
        IssueDAO issueDAO = new IssueDAO();
        return issueDAO.getUnresolvedIssues(aTrkngItemNbr, aTrkngItemUniqNbr);       
    }
    
    /**
     * Persists a list of new issues
     * @param aListOfIssues
     * @throws ServiceLocatorException
     * @throws SQLException
     */
    public void persistNewIssues(List aListOfIssues) throws ServiceLocatorException, SQLException {
        IssueDAO issueDAO = new IssueDAO();
        Iterator iter = aListOfIssues.iterator();
        while (iter.hasNext()) {
            issueDAO.persistIssue((IssueVO)iter.next());
        }
    }
    
    /**
     * Gets a list of events from the database, some events are excluded in the SQL
     *  to enhance performance
     * @param aTrkngItemNbr
     * @param aTrkngItemUniqNbr
     * @param aDate
     * @return
     * @throws ServiceLocatorException
     * @throws SQLException
     */
    public List getEvents(String aTrkngItemNbr,  String aTrkngItemUniqNbr, Date aDate) throws ServiceLocatorException, SQLException {
        EventDAO eventDAO = new EventDAO();
        return eventDAO.getEventsForIssues(aTrkngItemNbr, aTrkngItemUniqNbr, aDate);       
    }
    
    /**
     * Used to update issues with new issue timestamps if we receive a duplicate event.  Also, used to update
     * issues to be resolved with resolved timestamp or delete them if configured to do so.
     * @param aListOfIssues
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void updateIssues(List aListOfIssues) throws SQLException, ServiceLocatorException {
        IssueDAO issueDAO = new IssueDAO();
        
        boolean deleteResolvedIssues = false;
        String deleteResolvedIssuesStr = ConfigurationManager.get("DELETE_RESOLVED_ISSUES");
        if (deleteResolvedIssuesStr != null) {
            deleteResolvedIssues  = deleteResolvedIssuesStr.equals("Y") || deleteResolvedIssuesStr.equals("y");
        }
        
        Iterator iter = aListOfIssues.iterator();
        while (iter.hasNext()) {
            IssueVO issue = (IssueVO)iter.next();
            if ((deleteResolvedIssues) && (issue.getRes_dt() != null)) {
                issueDAO.deleteIssue(issue);
            } else {
                issueDAO.updateIssue(issue);
            }
        }        
    }
    
    
    /**
     * Contains all the logic to create/update and resolve issues
     * @param anIPDShipmentVO this events data ONLY
     * @param newShipment true if this is a new shipment
     * @param aMergedShipmentVO this events data merged with database, useful
     *    for seeing transitions based on this event
     * @throws ServiceLocatorException
     * @throws SQLException
     */
    public void doIssues(IPDShipmentVO anIPDShipmentVO, boolean newShipment, ShipmentVO aMergedShipmentVO) 
        throws ServiceLocatorException, SQLException {
        
        ShipmentVO shipmentVO = anIPDShipmentVO.get_shipment();
        int laneNbr = shipmentVO.get_lane_nbr();
        int grpNbr = shipmentVO.get_grp_nbr();
        String acctNbr = shipmentVO.get_acct_nbr();
        String issueLocCd = anIPDShipmentVO.get_event().get_track_loc_cd();
        String status = null;
        String trackTypeCd = anIPDShipmentVO.get_event().get_track_type_cd();
        String excpCd = anIPDShipmentVO.get_event().get_track_excp_cd();
        
        if (aMergedShipmentVO != null){
        	status = aMergedShipmentVO.get_last_stat_desc();
        }
        
        // If shipment is delivered, don't calculate any new issues, but let POD's and DDEX's process
        // Allow DEX, 03, 07, 09 & 10 to process an issue after shipment delivered
        if (!trackTypeCd.equals(RiseConstants.POD) && !trackTypeCd.equals(RiseConstants.DDEX)) {
            if ((status != null) &&
                ((status.equals(RiseConstants.STATUS_DLVRD)) ||
                 (status.equals(RiseConstants.STATUS_DDLVRD)))) {
                if (trackTypeCd.equals(RiseConstants.DEX) && (excpCd != null)) {
                    if (excpCd.equals("03") || excpCd.equals("07") || excpCd.equals("09") || excpCd.equals("10")) {
                        logger.info("Processing event for new issues even though delivered");   
                    }
                } else {
                    logger.info("Not calculating issue, shipment already delivered");
                    return;
                }
            }
        }
        
        // We can't show the users any exceptions without this
        // data, so don't create an issue without it
        if ((laneNbr == 0) || (grpNbr == 0) || (issueLocCd == null)) {
            logger.info("Missing critical data to create issue.");
            return;
        }
        
        if ((acctNbr == null) || (!AccountCacheDAO.containsKey(acctNbr))) {
            logger.info("Missing account number or non monitored account");
            return;
        }      
        
        // Note: An event can create more than one issue
        
        // if not new shipment, find unresolved issues
        List unresolvedIssues = null;
        EventVO eventVO = anIPDShipmentVO.get_event();
        String trkngItemNbr = eventVO.get_trkng_item_nbr();
        String trkngItemUniqNbr = eventVO.get_trkng_item_uniq_nbr();
        
        if (!newShipment) {

            unresolvedIssues = getUnresolvedIssues(trkngItemNbr, trkngItemUniqNbr);

            logger.info("There are " + unresolvedIssues.size() + " issues to be resolved.");
            // *** DEBUG *** //
            if (logger.isDebugEnabled()) {
                Iterator iter = unresolvedIssues.iterator();
                while (iter.hasNext()) {
                    IssueVO issue  = (IssueVO)iter.next();
                    logger.debug("\nUnresolved:" + issue);
                }
            }
            // *** DEBUG *** //
        }
        
        // Some events are excluded in the SQL for performance
        List allEvents = getAllEvents(trkngItemNbr, trkngItemUniqNbr);
        
        // Calculate new issues based on this event
        List newIssues = doNewIssues(anIPDShipmentVO);
        checkForUnusalIssues(newIssues, anIPDShipmentVO, newShipment, aMergedShipmentVO);
        
        // *** DEBUG *** //
        if (logger.isDebugEnabled()) {
            Iterator itery = newIssues.iterator();
            while (itery.hasNext()) {
                IssueVO issue  = (IssueVO)itery.next();
                logger.debug("\nNewIssue:" + issue);
            }
        }
        // *** DEBUG *** //
        
        ArrayList updateList = new ArrayList();
        
        // See if any of the new issues are already in the unresolved
        // issues list.  If the issue tmstmp of the new event is later,
        // than we must have gotten another duplicate event with a later
        // time, so just update the issue that we have, with the new time,
        // and remove this issue from the list of new issues
        if ((unresolvedIssues != null) && (newIssues != null) &&
            (newIssues.size() > 0) && (unresolvedIssues.size() > 0)) {
            
            logger.info("Merging issues.");
            ArrayList mergeList = new ArrayList();
            
            Iterator iter = newIssues.iterator();
            while (iter.hasNext()) { // iterate over new Issues
                IssueVO newIssue  = (IssueVO)iter.next();
                Iterator iterII = unresolvedIssues.iterator();
                while (iterII.hasNext()) { // iterate over unresolved issues
                    IssueVO unresolvedIssue = (IssueVO)iterII.next();
                    if (newIssue.getIssue_type_cd() == unresolvedIssue.getIssue_type_cd()) {
                        // this issue already exists in database
                        Date newIssueTmstp = newIssue.getIssue_tmstp();
                        Date unresolvedIssueTmstp = unresolvedIssue.getIssue_tmstp();
                        if (newIssueTmstp.after(unresolvedIssueTmstp)) {
                            // update timestamp with new time
                            unresolvedIssue.setIssue_tmstp(newIssueTmstp); 
                            unresolvedIssue.setEvent_crtn_tmstp(newIssue.getEvent_crtn_tmstp());
                            updateList.add(unresolvedIssue);
                        }
                        // these will be removed from the new issues list
                        mergeList.add(unresolvedIssue);
                    }
                }
            }         
            
            // Remove the issues that were merged from the new issues list
            if (mergeList.size() > 0) {
                Iterator iterx = mergeList.iterator();
                while (iterx.hasNext()) {
                    IssueVO existingIssue = (IssueVO)iterx.next();
                    boolean b = newIssues.remove(existingIssue);
                    if (b) {
                        logger.debug("\nFound existing issue:" + existingIssue);
                    }
                }
            }            
            
            // These issues have been merged, and will be merged with the resolved issues and
            // updated together
            if (updateList.size() > 0) {
                logger.info("Updating " + updateList.size() + " issues with new timestamp.");
            }
        }
        
        // Prevent creating issue if prevention rule states so.
        ArrayList preventedList = new ArrayList();
        for (Iterator iter = newIssues.iterator(); iter.hasNext();) {
            IssueVO issue = (IssueVO)iter.next();
            boolean preventIssue = doPreventionIssue(eventVO, issue, shipmentVO, allEvents);
            if (preventIssue) {
                preventedList.add(issue);
            }
        }
        if (preventedList.size() > 0) {
            for (Iterator iter = preventedList.iterator();iter.hasNext();) {
                IssueVO preventedIssue = (IssueVO)iter.next();
                newIssues.remove(preventedIssue);
            }
        }

        // Resolve any issues that can be resolved, get any events newer than
        // the earliest timestamp in the unresolved issues
        List resolvedIssues = new ArrayList();
        if ((unresolvedIssues != null) && (unresolvedIssues.size() > 0)) {
            List events = null;
            IssueVO earliestIssue = (IssueVO)unresolvedIssues.get(0);
            Date d = earliestIssue.getEvent_crtn_tmstp();
            // Some events are excluded in the SQL for performance
            events = getEvents(trkngItemNbr, trkngItemUniqNbr, d);
            Iterator iter = events.iterator();
            while (iter.hasNext()) {
                doResolveIssues((EventVO)iter.next(), unresolvedIssues, resolvedIssues);
            }
            // Commented out for now, since we are not creating the missing data issue
            //resolveUnusualIssues(resolvedIssues, unresolvedIssues, anIPDShipmentVO, aMergedShipmentVO);
            
            if ((resolvedIssues != null) && (resolvedIssues.size() > 0)) {
                logger.info("Updating " + resolvedIssues.size() + " resolved issues.");
            }
        }
        
        if ((resolvedIssues != null) && (resolvedIssues.size() > 0)) {
            // Merge the update list into the resolved list, unless already there
            Iterator iter = updateList.iterator();
            while (iter.hasNext()) {
                IssueVO issue = (IssueVO)iter.next();
                if (!resolvedIssues.contains(issue)) {
                    resolvedIssues.add(issue);
                }
            }
        }
        
        // Now update the resolved issues and those with new timestamps that were not resolved
        if ((resolvedIssues != null) && (resolvedIssues.size() > 0)) {
            updateIssues(resolvedIssues);
        }
        
        logger.info("Persisting: " + newIssues.size() + " new issues");
        persistNewIssues(newIssues);
    }  
    
    
    /**
     * Scan the IssuesList with the new event and see if there is a match on 
     * issues or issues to created
     * @param anIPDShipmentVO
     * @return list of new issues, some of which may already be in the database
     */
    public List doNewIssues(IPDShipmentVO anIPDShipmentVO) {
        EventVO event = anIPDShipmentVO.get_event();
        ShipmentVO shipment = anIPDShipmentVO.get_shipment();
        String trackTypeCd = event.get_track_type_cd();
        String trackExcpCd = event.get_track_excp_cd();
        String shpmtTypeCd = shipment.get_shpmt_type_cd();
        
        logger.info("Searching for Issue for trackTypeCd:" + trackTypeCd + " trackExcpCd:" + trackExcpCd 
                + " shpmtTypeCd:" + shpmtTypeCd);
        ArrayList newIssues = new ArrayList();
        for (int i = 0; i < IssueList.length; i++) {
            if (trackTypeCd.equals(IssueList[i].trackTypeCd)) {
                if (trackExcpCd != null) {
                    if (!trackExcpCd.equals(IssueList[i].trackExcpCd)) {
                        continue;
                    }
                } else {
                    if (IssueList[i].trackExcpCd != null) {
                        continue;
                    }
                }
                
                if (shpmtTypeCd.charAt(0) != IssueList[i].shpmtTypeCd) {
                    continue;
                }
                
                if (IssueList[i].issueCriteria != null) {
                    IssueCriteria criteria = IssueList[i].issueCriteria;
                    if (!criteria.meetsCriteria(event)) {
                        continue;
                    }
                }
                
                // At this point the track type, track Exception Cd, if there is one
                // and the shipment Type Cd('MAWB','CRN','UNK') match
                IssueVO newIssue = createIssue(event, shipment, IssueList[i].issueTypeCd,
                        IssueList[i].timeCalcMethod, IssueList[i].timeHourOffset);
                
                newIssues.add(newIssue);
            }
        }        
        return newIssues;
    }
    

    /**
     * This method is used to calculate a timestamp for when the issue will become "real"
     * @param aTimeCalcMethod
     * @param aHourOffset
     * @param aEventCrtnTmstp
     * @return
     */
    public Calendar calculateIssueTmstp(int aTimeCalcMethod, int aHourOffset,
    		Calendar aEventCrtnTmstp, Calendar aCommitDt) {
        
        Calendar temp = (Calendar)aEventCrtnTmstp.clone();
        
        outputFormat.setCalendar(temp);
        if (logger.isDebugEnabled()) {
            logger.debug("CalculateTmstp:" + outputFormat.format(temp.getTime()));
        }
              
        if (aTimeCalcMethod == IMMEDIATE) {
            logger.info("Immediate:" + outputFormat.format(temp.getTime()));
            return temp;
        } else {
            if (aTimeCalcMethod == ADD_HRS_TO_EVENT) {
                // add forces re-computation
                temp.add(Calendar.HOUR_OF_DAY, aHourOffset);
                logger.info("Add Hours to Event: " + aHourOffset + ":" + outputFormat.format(temp.getTime()));
                return temp;
            } else if (aTimeCalcMethod == ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT){ // Add hour(s) to scan or hour(s) after commit time, which ever is greater.	
                temp.add(Calendar.HOUR_OF_DAY, aHourOffset); // Add requested hours.
        		if (aCommitDt != null) {
                    Calendar cloneCommitDt = (Calendar)aCommitDt.clone();
                    cloneCommitDt.add(Calendar.HOUR_OF_DAY, aHourOffset); // Add hour(s) to the commit date.
                    logger.info("Add an hour after commit time:" + outputFormat.format(cloneCommitDt.getTime()));
                    return cloneCommitDt;
        		} 
                logger.info("Add Hours to Event: " + aHourOffset + ":" + outputFormat.format(temp.getTime()));       		
                return temp;
            } else {
                if (aTimeCalcMethod == MIDNIGHT) {
                    temp.set(Calendar.HOUR_OF_DAY, 0);
                    temp.set(Calendar.MINUTE, 0);
                    temp.set(Calendar.SECOND, 0);
                    // add forces re-computation
                    temp.add(Calendar.DAY_OF_YEAR, 1); 
                    logger.info("Midnight:" + outputFormat.format(temp.getTime()));
                    return temp;
                }
            }
        }
        return null;
    }
    
    /**
     * See if any issues can be resolved by the current event.  The event being examined
     * may be the current arriving event or an event already persisted that has a
     * later timestamp than that of the issue
     * @param anEventVO
     * @param aIssuesList
     * @param aResolvedList
     */
    public void doResolveIssues(EventVO anEventVO, List aIssuesList, List aResolvedList) {
        String trackTypeCd = anEventVO.get_track_type_cd();
        String excpTypeCd = anEventVO.get_track_excp_cd();
        Iterator iter = aIssuesList.iterator();
        while (iter.hasNext()) {
            IssueVO issue = (IssueVO)iter.next();
            // This event should be later than the event which created the issue
            //  otherwise we are processing the events out of order and we should
            //  not consider this event as a resolving event
            if (logger.isDebugEnabled()) {
                TrackDesc trackDesc = TrackTypes.getTrackTypeDesc(anEventVO.get_track_type_cd());
                if (trackDesc != null) {
                    logger.debug(trackDesc.get_shortName() + " Event time: " + anEventVO.get_event_crtn_tmstp().getTime().getTime() + " issue time:" + issue.getEvent_crtn_tmstp().getTime());
                }
            }
            if ((anEventVO.get_event_crtn_tmstp().getTime().getTime() > issue.getEvent_crtn_tmstp().getTime()) || 
            		(anEventVO.get_event_crtn_tmstp().getTime().getTime() == issue.getEvent_crtn_tmstp().getTime() &&
            				anEventVO.get_track_type_cd() != issue.get_trackTypeCd())) {
                int issueTypeCd = issue.getIssue_type_cd();
                Resolver resolver = (Resolver)resolveList.get(new Integer(issueTypeCd));
                if (resolver != null) {
                    boolean resolved = resolver.isResolved(anEventVO, issue);
                    if (resolved) {
                        // Issue may already have been resolved by another issue, so don't add again
                        // can't remove resolved issues from the IssuesList because we are iterating over it
                        if (!aResolvedList.contains(issue)) {
                            // dismiss    
                            resolveIssue(issue, trackTypeCd, excpTypeCd);

                            aResolvedList.add(issue);
                            
                            if (logger.isDebugEnabled()) {
                                logger.debug("Issue resolved by specific event");
                                logger.debug(issue);
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * A method to compare two events and determine if they are the same event or not
     * @param a
     * @param b
     * @return true if same event
     */
    public static boolean isSameEvent(EventVO a, EventVO b) {
        Calendar aCal = a.get_event_crtn_tmstp();
        Calendar bCal = b.get_event_crtn_tmstp();
        if (aCal.getTimeInMillis() == bCal.getTimeInMillis()) {
            String aTrackType = a.get_track_type_cd();
            String bTrackType = b.get_track_type_cd();
            if (aTrackType.equals(bTrackType)) {
                String aExcpCd = a.get_track_excp_cd();
                String bExcpCd = b.get_track_excp_cd();
                if ( ((aExcpCd == null) && (bExcpCd == null)) ||
                     (((aExcpCd != null) && (bExcpCd != null)) && aExcpCd.equals(bExcpCd))) {
                    String aSqncNbr = a.get_event_sqnc_nbr();
                    String bSqncNbr = b.get_event_sqnc_nbr();
                    if (aSqncNbr.equals(bSqncNbr)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * See if current issue can be can be prevented by past events.  
     * @param anEventVO
     * @param aIssuesList
     */
    public boolean doPreventionIssue(EventVO anEventVO, IssueVO issue, ShipmentVO anShipmentVO, List aListOfEvents) {
        int issueTypeCd = issue.getIssue_type_cd();
        Preventer preventer = (Preventer)preventionList.get(new Integer(issueTypeCd));
        if (preventer != null) {
            Iterator iter = aListOfEvents.iterator();
            while (iter.hasNext()) {
                EventVO pastEvent = (EventVO)iter.next();
                // consider only events that occurred before this event, don't consider future events
                if (anEventVO.get_event_crtn_tmstp().getTimeInMillis() >=
                    pastEvent.get_event_crtn_tmstp().getTimeInMillis()) {
                    // Event is before or same time, now is it the same event?
                    if (!isSameEvent(anEventVO, pastEvent)) {
                        if (preventer.isPrevented(anEventVO, pastEvent, issue, anShipmentVO)) {
                            logger.info("Prevented an Issue from being created : Issue number " + issueTypeCd);
                            return true;
                        }
                    }
       		    }
       		}
        }
        return false;
    }
    
    /**
     * Gets a list of events from the database, some events are excluded in the SQL
     *  to enhance performance
     * @param aTrkngItemNbr
     * @param aTrkngItemUniqNbr
     * @return a list of all events
     * @throws ServiceLocatorException
     * @throws SQLException
     */
    public List getAllEvents(String aTrkngItemNbr,  String aTrkngItemUniqNbr) throws ServiceLocatorException, SQLException {
        EventDAO eventDAO = new EventDAO();
        return eventDAO.getEvents(aTrkngItemNbr, aTrkngItemUniqNbr);       
    }
    
    /**
     * A convience method to fill in an IssueVO object so that it can be
     * persisted.  The "real" timestamp of when the issue becomes is 
     * calculated.
     * @param anEventVO
     * @param aShipmentVO
     * @param anIssueTypeCd
     * @param aTimeCalcMethod
     * @param anHourOffset
     * @return
     */
    private IssueVO createIssue(EventVO anEventVO, ShipmentVO aShipmentVO, int 
            anIssueTypeCd, int aTimeCalcMethod, int anHourOffset) {
        
        IssueVO newIssue = new IssueVO();
        newIssue.setTrkng_item_nbr(anEventVO.get_trkng_item_nbr());
        newIssue.setTrkng_item_uniq_nbr(anEventVO.get_trkng_item_uniq_nbr());
        newIssue.setIssue_type_cd(anIssueTypeCd);
        newIssue.setIssue_loc_cd(anEventVO.get_track_loc_cd());
        newIssue.setEvent_crtn_tmstp(anEventVO.get_event_crtn_tmstp().getTime());
        
        Calendar d = calculateIssueTmstp(aTimeCalcMethod, anHourOffset,
                anEventVO.get_event_crtn_tmstp(), aShipmentVO.get_commit_dt());
        if (d != null) {
            newIssue.setIssue_tmstp(d.getTime());
        }
        
        newIssue.setGrp_nbr(aShipmentVO.get_grp_nbr());
        newIssue.setAcct_nbr(aShipmentVO.get_acct_nbr());
        newIssue.setLane_nbr(aShipmentVO.get_lane_nbr());
        newIssue.setSvc_type_cd(aShipmentVO.get_svc_type_cd());
        newIssue.set_trackTypeCd(anEventVO.get_track_type_cd());
        return newIssue;
    }
    
    /**
     * A convenience method to fill in the fields for an issue that is being resolved.
     * @param anIssue
     * @param aTrackTypeCd
     * @param aExcpTypeCd
     */
    private void resolveIssue(IssueVO anIssue, String aTrackTypeCd, String aExcpTypeCd) {
        TimeZone tz = TimeZone.getTimeZone("GMT+0000");
        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(tz);
        anIssue.setRes_dt(cal.getTime());
        StringBuffer sb = new StringBuffer();
        sb.append(aTrackTypeCd);
        if (aExcpTypeCd != null) {
            sb.append(':');
            sb.append(aExcpTypeCd);
        }
        anIssue.set_res_desc(sb.toString());
    }
    
    // ----------------------- Unusual Issues, not handled in the really cool table manner
    
    private void checkForUnusalIssues(List aListofNewIssues, IPDShipmentVO anIPDShipmentVO,
                                      boolean newShipment, ShipmentVO aMergedShipmentVO) 
        throws SQLException, ServiceLocatorException {
        
        IssueVO issueVO = returnsOnMawb(anIPDShipmentVO, newShipment, aMergedShipmentVO);
        if (issueVO != null) {
            logger.info("Issue: There are returns on a MAWB");
            aListofNewIssues.add(issueVO);
        }
        issueVO = multiPodOnMawb(anIPDShipmentVO, newShipment, aMergedShipmentVO);
        if (issueVO != null) {
            logger.info("Issue: There are multiple PODs on a MAWB");
            aListofNewIssues.add(issueVO);
        }
        // Removed for now, too confusing, and how and who to work the missing 
        // data not defined.  Also, if account number, origin country code, 
        // or destination country code missing, will never get here because
        // there is a check at the start of the issue processing to bail if
        // these items are missing.
        // Perhaps just a database query with paging would work better.
        //issueVO = missingData(anIPDShipmentVO, newShipment, aMergedShipmentVO);
        //if (issueVO != null) {
        //    logger.info("Issue: There is missing Data");
        //    aListofNewIssues.add(issueVO);
        //}
    }
    
    /**
     * This method looks for operational errors on a MAWB where a return has been
     * done using the MAWB tracking number.  If the shipment is a MAWB we will look
     * at the Associated Group and see if there are any returns.  In the case of
     * a CRN we will look in the associated group and see if we have a Return
     * who's tracking number matches the Parent, which is the MAWB.
     * @param anIPDShipmentVO
     * @param newShipment
     * @param aMergedShipmentVO
     * @return
     */
    private IssueVO returnsOnMawb(IPDShipmentVO anIPDShipmentVO,
                                  boolean newShipment, ShipmentVO aMergedShipmentVO) {
        
        ShipmentVO shipmentVO = anIPDShipmentVO.get_shipment();
        if (shipmentVO.get_shpmt_type_cd().equals(RiseConstants.MAWB)) {
            List associatedShipmentList = anIPDShipmentVO.get_associatedShipments();
            Iterator iter = associatedShipmentList.iterator();
            while(iter.hasNext()) {
                AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.RETURN) {
                    return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                                       RETURN_MAWB, IMMEDIATE, 0);
                }
            }
        } else {
            if (shipmentVO.get_shpmt_type_cd().equals(RiseConstants.CRN)) {
                List associatedShipmentList = anIPDShipmentVO.get_associatedShipments();
                Iterator iter = associatedShipmentList.iterator();
                String parentTrkngNbr = null;
                String parentTrkngUniqNbr = null;
                String returnTrkngNbr = null;
                String returnTrkngUniqNbr = null;
                while(iter.hasNext()) {
                    AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                    if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.RETURN) {
                        returnTrkngNbr = assocShipmentVO.get_assoc_trkng_item_nbr();
                        returnTrkngUniqNbr = assocShipmentVO.get_assoc_trkng_item_uniq_nbr();
                    } else {
                        if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.PARENT) {
                            parentTrkngNbr = assocShipmentVO.get_assoc_trkng_item_nbr();
                            parentTrkngUniqNbr = assocShipmentVO.get_assoc_trkng_item_uniq_nbr();
                        }
                    }
                }
                if ((parentTrkngNbr != null) && (returnTrkngNbr != null)) {
                    if (parentTrkngNbr.equals(returnTrkngNbr)) {
                        if ((parentTrkngUniqNbr != null) && (returnTrkngUniqNbr != null)) {
                            if (parentTrkngUniqNbr.equals(returnTrkngUniqNbr)) {
                                return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                                        RETURN_MAWB, IMMEDIATE, 0);
                            }
                        } else {
                            return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                                    RETURN_MAWB, IMMEDIATE, 0);
                        }
                    }
                }                
            }
        }
        return null;
    }
    
    /**
     * Look to see if there are multiple POD's on a MAWB.  See if the shipmentVO in
     *   the database had a delivery date, if so we already have a POD, if this event
     *   is a POD, then we have multiple POD's on the MAWB
     * @param anIPDShipmentVO
     * @param newShipment
     * @param aMergedShipmentVO
     * @return
     * @throws ServiceLocatorException 
     * @throws SQLException 
     */
    private IssueVO multiPodOnMawb(IPDShipmentVO anIPDShipmentVO,
                                   boolean newShipment, ShipmentVO aMergedShipmentVO)
        throws SQLException, ServiceLocatorException {
        
        if (newShipment) {
            return null;
        }
        ShipmentVO shipmentVO = anIPDShipmentVO.get_shipment();
        if (shipmentVO.get_shpmt_type_cd().equals("MAWB")) {
            if (anIPDShipmentVO.get_event().get_track_type_cd().equals(RiseConstants.POD)) {
                EventDAO eventDAO = new EventDAO();
                int count = eventDAO.getCountPodsOnMawb(anIPDShipmentVO.get_event().get_trkng_item_nbr(),
                                                        anIPDShipmentVO.get_event().get_trkng_item_uniq_nbr());
                if (count > 1) {
                    return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                                       MULTI_POD_MAWB, IMMEDIATE, 0);
                }
            }
        }
        return null;
    }
     
    /**
    private IssueVO missingData(IPDShipmentVO anIPDShipmentVO,
            boolean newShipment, ShipmentVO aMergedShipmentVO) {

        // Number of hours to wait before this is a "real" issue
        final int MSSNG_DATA_DLY = 13;
        
        String shpmtTypeCd = null;
        ShipmentVO shipmentVO = null;
        if (newShipment) {
            shpmtTypeCd = anIPDShipmentVO.get_shipment().get_shpmt_type_cd();
            shipmentVO = anIPDShipmentVO.get_shipment();
        } else {
            shpmtTypeCd = aMergedShipmentVO.get_shpmt_type_cd();
            shipmentVO = aMergedShipmentVO;            
        }

        int issueTypeCd = -1;
        if (shpmtTypeCd.equals(RiseConstants.MAWB)) {
            issueTypeCd = MISSING_DATA_MAWB;
        } else {
            if (shpmtTypeCd.equals(RiseConstants.CRN)) {
                issueTypeCd = MISSING_DATA_CRN;
            } else {
                if (shpmtTypeCd.equals(RiseConstants.UNK)) {
                    issueTypeCd = MISSING_DATA_UNK;
                } else {
                    return null;
                }
            }
        }
        
        boolean result = false;
        
        // These fields are checked for MAWB, CRN and UNK
        result |= (shipmentVO.get_acct_nbr() == null);
        result |= (shipmentVO.get_shpr_cntry_cd() == null);
        result |= (shipmentVO.get_recp_cntry_cd() == null);
        result |= (shipmentVO.get_ship_dt() == null);
        result |= (shipmentVO.get_dest_loc_cd() == null);
        result |= (shipmentVO.get_shpmt_wgt() == 0);
        result |= (shipmentVO.get_shpr_co_nm()== null);
        
        if (result) {
            return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                    issueTypeCd, ADD_HRS_TO_EVENT, MSSNG_DATA_DLY);
        }

        // These fields are checked for CRN's only
        result |= (shipmentVO.get_recp_co_nm() == null);
        result |= (shipmentVO.get_recp_city_nm() == null);
        
        if (result && shpmtTypeCd.equals(RiseConstants.CRN)) {
            return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                    issueTypeCd, ADD_HRS_TO_EVENT, MSSNG_DATA_DLY);            
        }
        
        // These fields are checked for MAWB's only
        result = false;
        result |= (shipmentVO.get_shpmt_wgt() == 0);
        if (result && shpmtTypeCd.equals(RiseConstants.MAWB)) {
            return createIssue(anIPDShipmentVO.get_event(), shipmentVO,
                    issueTypeCd, ADD_HRS_TO_EVENT, MSSNG_DATA_DLY);              
        }
        
        // Yes, hopefully a UNK will become a MAWB or a CRN
        //   but I don't know which
        
        return null;
    }
    

    // Resolvers for unusual issues, really just checking for Missing data issues
    // at this point.
    private void resolveUnusualIssues(List aListofResolvedIssues, List aListofUnresolvedIssues,
            IPDShipmentVO anIPDShipmentVO, ShipmentVO aMergedShipmentVO) {
        
        IssueVO issue = new IssueVO();
        issue.setTrkng_item_nbr(aMergedShipmentVO.get_trkng_item_nbr());
        issue.setTrkng_item_uniq_nbr(aMergedShipmentVO.get_trkng_item_uniq_nbr());
        // could have been an unknown when we created the issue, now it may be a MAWB or CRN
        // So look for all types
        int [] missingDataTypes = { MISSING_DATA_MAWB, MISSING_DATA_CRN, MISSING_DATA_UNK };
        for (int i = 0; i < missingDataTypes.length; i++) {
            issue.setIssue_type_cd(missingDataTypes[i]);
            if (aListofUnresolvedIssues.contains(issue)) {
                int index = aListofUnresolvedIssues.indexOf(issue);
                IssueVO issueToBeResolved = (IssueVO)aListofUnresolvedIssues.get(index);
                boolean resolved = resolveMissingData(anIPDShipmentVO, aMergedShipmentVO);
                if (resolved) {
                    resolveIssue(issueToBeResolved, anIPDShipmentVO.get_event().get_track_type_cd(),
                                 anIPDShipmentVO.get_event().get_track_excp_cd());
                    aListofResolvedIssues.add(issueToBeResolved);
                }
            }
        }
    }
    
    private boolean resolveMissingData(IPDShipmentVO anIPDShipmentVO, ShipmentVO aMergedShipmentVO) {
        
        String shpmtTypeCd = aMergedShipmentVO.get_shpmt_type_cd();
        boolean result = true;
        
        // These fields are checked for MAWB, CRN and UNK
        result &= (aMergedShipmentVO.get_acct_nbr() != null);
        result &= (aMergedShipmentVO.get_shpr_cntry_cd() != null);
        result &= (aMergedShipmentVO.get_recp_cntry_cd() != null);
        result &= (aMergedShipmentVO.get_ship_dt() != null);
        result &= (aMergedShipmentVO.get_dest_loc_cd() != null);
        result &= (aMergedShipmentVO.get_shpmt_wgt() != 0);
        result &= (aMergedShipmentVO.get_shpr_co_nm() != null);

        if (!result) {
            return false;
        }
        
        // These fields are checked for CRN's only
        result &= (aMergedShipmentVO.get_recp_co_nm() != null);
        result &= (aMergedShipmentVO.get_recp_city_nm() != null);
        
        if (result && shpmtTypeCd.equals(RiseConstants.CRN)) {
            return true;          
        }
        
        result = true;
        // These fields are checked for MAWB's only
        result &= (aMergedShipmentVO.get_shpmt_wgt() != 0);
        if (result && shpmtTypeCd.equals(RiseConstants.MAWB)) {
            return true;             
        }
        
        return false;
    }
    **/
}
