package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.service.SearchDelegateService;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.ShipmentEmployeeVO;

import lombok.extern.slf4j.Slf4j;

@JsfController(path = "/searchResultsFindShipper", page = "/pages/jsp/searchResultsFindShipperAccountNumber.jsp", value = "SearchResultsBeanShipper")
@Slf4j
public class SearchResultsBeanShipper extends SortableList implements Serializable {
	/** serializing version */
	private static final long serialVersionUID = 1L;

	/** logger */
	private static Log log = LogFactory.getLog(SearchResultsBeanShipper.class);

	@Autowired
	SearchDelegateService searchDelegateService;

	@Autowired
	SearchBeanShipper searchBeanshipper;

	private DataModel _data;

	private DataModel _columnHeaders;

	private List results = null;

	public int getColumnValue300() {
		int columnValue300 = 0;
		if (_data == null) {
			columnValue300 = 0;
		} else {
			columnValue300 = _data.getRowCount();
		}
		return columnValue300;
	}

	public SearchResultsBeanShipper() {
		super("ship_date");
		//System.out.println("Within Constructorrrrr.....");
		List headerList = new ArrayList();
		headerList.add(new ColumnHeader("Tracking Nbr", "10", false));
		_columnHeaders = new ListDataModel(headerList);
	}

	// ==========================================================================
	// Getters
	// ==========================================================================

	// Get Column Value For Shipment Table

	public Object getColumnValue() {
		Object columnValue = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue = ((ShipmentEmployeeVO) _data.getRowData()).get_trkng_item_nbr();
		}
		return columnValue;
	}

	public Object getColumnValue2() {
		Object columnValue2 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue2 = ((ShipmentEmployeeVO) _data.getRowData()).get_shpmt_type_cd();
		}
		return columnValue2;
	}

	public Object getColumnValue3() {
		Object columnValue3 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue3 = ((ShipmentEmployeeVO) _data.getRowData()).get_acct_nbr();
		}
		return columnValue3;
	}

	public Object getColumnValue4() {
		Object columnValue4 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue4 = ((ShipmentEmployeeVO) _data.getRowData()).get_ship_dt();
		}
		return columnValue4;
	}

	public Object getColumnValue5() {
		Object columnValue5 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue5 = ((ShipmentEmployeeVO) _data.getRowData()).get_svc_type_cd();
		}
		return columnValue5;
	}

	public Object getColumnValue6() {
		Object columnValue6 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue6 = ((ShipmentEmployeeVO) _data.getRowData()).get_shpr_co_nm();
		}
		return columnValue6;
	}

	public Object getColumnValue7() {
		Object columnValue7 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue7 = ((ShipmentEmployeeVO) _data.getRowData()).get_shpr_cntry_cd();
		}
		return columnValue7;
	}

	public Object getColumnValue8() {
		Object columnValue8 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue8 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_co_nm();
		}
		return columnValue8;
	}

	public Object getColumnValue9() {
		Object columnValue9 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue9 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_cntry_cd();
		}
		return columnValue9;
	}

	public Object getColumnValue10() {
		Object columnValue10 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue10 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_ph_nbr();
		}
		return columnValue10;
	}

	public Object getColumnValue11() {
		Object columnValue11 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue11 = Integer.toString(((ShipmentEmployeeVO) _data.getRowData()).get_lane_nbr());
		}
		return columnValue11;
	}

	public Object getColumnValue12() {
		Object columnValue12 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue12 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_city_nm();
		}
		return columnValue12;
	}

	public Object getColumnValue13() {
		Object columnValue13 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue13 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_pstl_cd();
		}
		return columnValue13;
	}

	public Object getColumnValue15() {
		Object columnValue15 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue15 = ((ShipmentEmployeeVO) _data.getRowData()).get_recp_st_prov_cd();
		}
		return columnValue15;
	}

	// Get Column Values for Employee Table

	public Object getColumnValue100() {
		Object columnValue100 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue100 = ((ShipmentEmployeeVO) _data.getRowData()).get_emp_first_nm();
		}
		return columnValue100;
	}

	public Object getColumnValue101() {
		Object columnValue101 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue101 = ((ShipmentEmployeeVO) _data.getRowData()).get_emp_last_nm();
		}
		return columnValue101;
	}

	public Object getColumnValue102() {
		Object columnValue102 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue102 = ((ShipmentEmployeeVO) _data.getRowData()).get_emp_nbr();
		}
		return columnValue102;
	}

	// Start WR#:179441 Changes
	public Object getColumnValue103() {
		Object columnValue103 = null;
		if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
			columnValue103 = ((ShipmentEmployeeVO) _data.getRowData()).get_trkng_item_uniq_nbr();
		}
		return columnValue103;
	}

	public DataModel getData() {
		//System.out.println("Within Get DATA");

		if (null == results && searchBeanshipper.checkResult.equals("acctNbr")) {
			results = searchDelegateService.searchByAcctNbr(searchBeanshipper.getAcctNbr());
		} else if (null == results && searchBeanshipper.checkResult.equals("shprNm")) {
			results = searchDelegateService.searchByShprNm(searchBeanshipper.getShprNm());
		}

		if (results != null) {
			_data = new ListDataModel(results);
		}
		return _data;
	}

	// Start WR#:179441 Changes
	protected void sort(String column, boolean ascending) {
		// TODO Auto-generated method stub

	}

	@Override
	protected boolean isDefaultAscending(String sortColumn) {
		// TODO Auto-generated method stub
		if (sortColumn.equals("ship_date"))
			return false; // sort descending by default on ship_dt
		else
			return true; // sort ascending by default
	}// End WR#:179441 Changes
}