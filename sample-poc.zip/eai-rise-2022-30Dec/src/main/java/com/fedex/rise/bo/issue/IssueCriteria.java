package com.fedex.rise.bo.issue;

import com.fedex.rise.vo.EventVO;

public abstract class IssueCriteria {

    public abstract boolean meetsCriteria(EventVO anEventVO);
    
}
