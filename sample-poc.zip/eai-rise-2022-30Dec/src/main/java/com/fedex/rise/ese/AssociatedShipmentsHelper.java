package com.fedex.rise.ese;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.AssociatedShipmentVO;

public class AssociatedShipmentsHelper {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AssociatedShipmentsHelper.class);
    
    List _listOfAssocShipments;
        
    public AssociatedShipmentsHelper(List aListOfAssocShipments) {
        _listOfAssocShipments = aListOfAssocShipments;
    }
    
    private AssociatedShipmentVO search(char anAssocTypeCd) {
        Iterator iter = _listOfAssocShipments.iterator();
        while (iter.hasNext()) {
            AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
            if (anAssocTypeCd == assocShipmentVO.get_assoc_track_type_cd()) {
                return assocShipmentVO;                
            }
        }
        return null;
    }
    
    private List searchAll(char anAssocTypeCd) {
        ArrayList al = new ArrayList();
        Iterator iter = _listOfAssocShipments.iterator();
        while (iter.hasNext()) {
            AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
            if (anAssocTypeCd == assocShipmentVO.get_assoc_track_type_cd()) {
                al.add(assocShipmentVO);                
            }
        }
        if (al.size() > 0) {
            return al;
        } else {
            return null;
        }
    }
    
    /**
     * Returns the single parent found in the association or null
     * if there isn't one.
     * @return 
     */
    public AssociatedShipmentVO getParent() {
        return search(RiseConstants.PARENT);
    }

    public List getReturns() {
        return searchAll(RiseConstants.RETURN);
    }

    public List getPaperWorks() {
        return searchAll(RiseConstants.PAPERWORK);
    }

    /**
     * Log the associations.
     *
     */
    public void log() {
        if (!logger.isDebugEnabled()) {
            return;
        }
        StringBuffer sb = new StringBuffer();
        
        int parent = 0;
        int returns = 0;
        int paperwork = 0;
        Iterator iter = _listOfAssocShipments.iterator();
        while (iter.hasNext()) {
            AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
            if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.PARENT) {
                parent++;
            } else {
                if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.RETURN) {
                    returns++;
                } else {
                    if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.PAPERWORK) {
                        paperwork++;
                    }
                }
            }            
        }
        sb.append("Associations:" + parent + ":" + returns + ":" + paperwork);

        iter = _listOfAssocShipments.iterator();
        while (iter.hasNext()) {
            sb.append("|" + (AssociatedShipmentVO)iter.next());
        }
        logger.info(sb.toString());
    }
}
