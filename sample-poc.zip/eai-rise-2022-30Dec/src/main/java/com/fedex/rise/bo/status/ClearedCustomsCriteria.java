package com.fedex.rise.bo.status;

import com.fedex.rise.bo.issue.ClearedCustomsResolver;
import com.fedex.rise.vo.EventVO;

public class ClearedCustomsCriteria extends StatusCriteria {

    public boolean meetsCriteria(EventVO anEventVO) {
        return ClearedCustomsResolver.getInstance().isResolved(anEventVO, null);
    }

}
