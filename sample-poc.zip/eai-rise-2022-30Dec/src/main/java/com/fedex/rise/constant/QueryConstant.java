package com.fedex.rise.constant;

public interface QueryConstant {

	String GET_FILTER_BY_ISSUES = "SELECT DISTINCT issue.issueTypeCd "
									+ "FROM IssueEntity issue "
									+ "WHERE issue.resDt is null "
									+ "AND  issue.issueTmstp <= CURRENT_TIMESTAMP";
	
	
	String GET_FILTER_BY_ISSUES_DETAILS = "select distinct a.ASSOC_TRKNG_ITEM_NBR, \n"
			+ "			s.TRKNG_ITEM_NBR,  s.TRKNG_ITEM_UNIQ_NBR,  \n"
			+ "            actg.GROUP_NM,  act.ACCT_NM,  s.SHPR_CNTRY_CD,  \n"
			+ "            s.RECP_CNTRY_CD,  s.SVC_TYPE_CD,   s.ACCT_NBR, \n"
			+ "            s.SHPMT_TYPE_CD,  s.ORIG_LOC_CD,  s.DEST_LOC_CD, \n"
			+ "			s.SHIP_DT,  s.COMMIT_DT,  s.COMMIT_DATE_TMZN_OFFST_NBR, \n"
			+ "            s.LAST_EVENT_TRACK_LOC_CD,  s.LAST_STAT_TRACK_LOC_CD,  \n"
			+ "            s.LAST_STAT_DESC,  s.LAST_STAT_TMSTP,  e.EMP_FIRST_NM, \n"
			+ "			e.EMP_LAST_NM,  alsm.EMP_NBR\n"
			+ "            from SHIPMENT s, ISSUE i, EMPLOYEE e, ASSOCIATED_SHIPMENT a , ACCT_LANE_SERVICE_MONITORING alsm , ACCOUNT_GROUP actg , ACCOUNT act \n"
			+ "             where s.TRKNG_ITEM_NBR= a.TRKNG_ITEM_NBR \n"
			+ "			and s.TRKNG_ITEM_UNIQ_NBR=a.TRKNG_ITEM_UNIQ_NBR and s.TRKNG_ITEM_NBR=i.TRKNG_ITEM_NBR \n"
			+ "			and s.TRKNG_ITEM_UNIQ_NBR=i.TRKNG_ITEM_UNIQ_NBR and s.ACCT_NBR=alsm.ACCT_NBR and s.ACCT_NBR=act.ACCT_NBR and s.group_nbr=actg.group_nbr \n"
			+ "			and alsm.EMP_NBR=e.EMP_NBR and i.RES_DT is null and s.SHIP_DT >= trunc(SYSDATE - ?1)\n"
			+ "                        and ISSUE_TYPE_CD IN (?2)";


	String GET_ACCOUNT_GROUP_NAMES = "select GROUP_NBR, GROUP_NM, GROUP_DESC from Account_Group order by GROUP_NM";
	
	String GET_ACCOUNT_LANES_BY_GROUP_NUMBER = "select GROUP_NBR, ACCT_NBR, LANE_NBR from Account_Lane WHERE GROUP_NBR = :aGroupNbr";
	
	
	String GET_LANE = "select LANE_NBR, ORIG_CNTRY_CD, DEST_CNTRY_CD from Lane where LANE_NBR = :?";

	
	String GET_LABE_BY_GROUP_NBR = "SELECT DISTINCT b.LANE_NBR, b.ORIG_CNTRY_CD, b.DEST_CNTRY_CD from Account_Lane a inner join Lane b "
			+ " where a.GROUP_NBR = :groupNbr AND a.LANE_NBR = b.LANE_NBR ";
	
	
	String getSearchByAll = "select distinct(a.EMP_NBR), b.EMP_FIRST_NM, b.EMP_LAST_NM from Acct_Lane_Service_Monitoring a "
			+ "INNER JOIN EMPLOYEE b WHERE a.EMP_NBR = b.EMP_NBR";
	
	String searchByGroupLane = "select distinct(EMP_NBR) from Acct_Lane_Service_Monitoring where group_nbr= :groupNbr and lane_nbr= :laneNbr ";
	
	
	
	 String selectPerformanceSumAllLanesAllGroupsList = "select " +
		    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
		    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
		    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
		    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
		    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
		    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
		    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
		    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
		    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
		     "from Performance where SHIP_DT >= ? " +
		     "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "; 
		    
		    String selectPerformanceSumAllLanesList = "select " +
		    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
		    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
		    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
		    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
		    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
		    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
		    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
		    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
		    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
		     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
		     "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )"; 
		    
		     String selectPerformanceSumList = "select " +
		    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
		    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
		    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
		    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
		    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
		    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
		    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
		    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
		    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
		     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
		     "and SHIP_DT <= ? and LANE_NBR = ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )"; 
			
			//Start WR#:179441 Changes    
		    String selectPerformanceSumListEmp = "select " +
		    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
		    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
		    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
		    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
		    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
		    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
		    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
		    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
		    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
		    "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
		    "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "+
		    "and acct_nbr in (select acct_nbr from acct_lane_service_monitoring where "+
		    "GROUP_NBR= ? and EMP_NBR= ?)"; 
		    
		    String selectPerformanceSumListLaneEmp = "select " +
		    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
		    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
		    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
		    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
		    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
		    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
		    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
		    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
		    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
		    "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
		    "and SHIP_DT <= ? and LANE_NBR = ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "+
		    "and acct_nbr in (select acct_nbr from acct_lane_service_monitoring where "+
		    "LANE_NBR = ? and GROUP_NBR= ? and EMP_NBR= ?)"; 
		    
		    String selectPerformanceSumOfAllGroupLaneListByEmp = "select " +
		    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
		    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
		    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
		    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
		    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
		    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
		    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
		    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
		    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
		    "from Performance p,(select distinct(acct_nbr),lane_nbr from  acct_lane_service_monitoring a where a.emp_nbr= :empNbr)r " +
		    "where p.acct_nbr=r.acct_nbr and p.lane_nbr=r.lane_nbr and "+
		    "p.SHIP_DT >= :fromDate and p.SHIP_DT <= :toDate and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )";
		    
		    
		    
		    
		    ///////////// Serach TAB/////////////////////
		    
		    
		    
		    String getSearchByAcctNbrSQL = 
		        	"select UNIQUE " +    
		         	"ag.GROUP_NM, " +
		         	"a.ACCT_NM, " +
		        	"a.ACCT_NBR, " + 
		        	"s.SHPR_CNTRY_CD, " +
		        	"s.RECP_CNTRY_CD, " +
		    		"s.SVC_TYPE_CD, " +
		        	"e.EMP_FIRST_NM, " +
		        	"e.EMP_LAST_NM, " +
		        	"e.EMP_NBR " +
		        	"from SHIPMENT s, ACCOUNT a, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +   
		        	"where Upper(a.ACCT_NBR) like Upper(?) " +
		        	"and s.GROUP_NBR = ag.GROUP_NBR " +
		        	"and s.GROUP_NBR = a.GROUP_NBR " +
		         	"and s.ACCT_NBR = a.ACCT_NBR " +
		        	"and s.GROUP_NBR = alsm.GROUP_NBR " +
		         	"and s.ACCT_NBR = alsm.ACCT_NBR " +
		        	"and s.LANE_NBR = alsm.LANE_NBR " +
		        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " +
		        	"and alsm.EMP_NBR = e.EMP_NBR";
		    
		    
		    String getSearchByTrkngNbrSQL = 
		        	"select UNIQUE " + 
		        	"s.TRKNG_ITEM_NBR, " + 
		        	"s.TRKNG_ITEM_UNIQ_NBR, "+
		        	"s.SHPMT_TYPE_CD, " + 
		        	"s.SHIP_DT, " + 
		        	"s.RECP_CO_NM, " + 
		        	"s.RECP_PH_NBR, " + 
		        	"s.ACCT_NBR, " + 
		        	"s.SVC_TYPE_CD, " + 
		        	"ag.GROUP_NM, " + 
		        	"s.SHPR_CNTRY_CD, " + 
		        	"s.RECP_CNTRY_CD, " + 
		        	"e.EMP_FIRST_NM, " + 
		        	"e.EMP_LAST_NM, " + 
		        	"e.EMP_NBR " + 
		        	"from SHIPMENT s, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " + 
		        	"where s.TRKNG_ITEM_NBR = ? " + 
		        	"and s.GROUP_NBR = ag.GROUP_NBR " + 
		        	"and s.GROUP_NBR = alsm.GROUP_NBR " + 
		        	"and s.ACCT_NBR = alsm.ACCT_NBR " + 
		        	"and s.LANE_NBR = alsm.LANE_NBR " + 
		        	"and s.SVC_TYPE_CD = alsm.SVC_TYPE_CD " + 
		        	"and alsm.EMP_NBR = e.EMP_NBR";
		    
		    
		    
		    String getSearchByFindMonitorTrkngNbrSQL = "select UNIQUE " +
		        	"s.TRKNG_ITEM_NBR, " + 
		        	"s.ACCT_NBR, " +
		        	"e.EMP_NBR, " +
		        	"e.EMP_FIRST_NM, " +
		        	"e.EMP_LAST_NM " +
		        	"from SHIPMENT s, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +
		        	"where s.TRKNG_ITEM_NBR = ? and " +
		        	"s.GROUP_NBR = alsm.GROUP_NBR and " +
		        	"s.ACCT_NBR = alsm.ACCT_NBR and " +
		        	"s.LANE_NBR = alsm.LANE_NBR and " +
		        	"s.SVC_TYPE_CD = alsm.SVC_TYPE_CD and " +
		        	"alsm.EMP_NBR = e.EMP_NBR";
		    
		    String getSearchByShprNmSQL = 
		        	"select UNIQUE " +     
		         	"ag.GROUP_NM, " + 
		         	"a.ACCT_NM, " + 
		        	"a.ACCT_NBR, " + 
		        	"l.ORIG_CNTRY_CD, " + 
		        	"l.DEST_CNTRY_CD, " +    
		    		"alsm.SVC_TYPE_CD, " + 
		        	"e.EMP_FIRST_NM, " + 
		        	"e.EMP_LAST_NM, " + 
		        	"e.EMP_NBR " + 
		        	"from LANE l, ACCOUNT a, ACCOUNT_GROUP ag, ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +    
		        	"where Upper(ag.GROUP_NM) like Upper(?) " + 
		        	"and alsm.GROUP_NBR = ag.GROUP_NBR " +  
		        	"and alsm.GROUP_NBR = a.GROUP_NBR " +
		         	"and alsm.ACCT_NBR = a.ACCT_NBR " +
		        	"and alsm.LANE_NBR = l.LANE_NBR " +  
		        	"and alsm.EMP_NBR = e.EMP_NBR";
		    
		    String getSearchByReferenceNbrSQL =	    
		        	"select UNIQUE " + 
		        	"s.TRKNG_ITEM_NBR, " +
		        	"s.SHPMT_TYPE_CD, " + 
		        	"s.SHIP_DT, " + 
		        	"s.RECP_CO_NM, " + 
		        	"s.RECP_PH_NBR, " + 
		        	"s.ACCT_NBR, " + 
		        	"s.SVC_TYPE_CD, " + 
		        	"ag.GROUP_NM, " + 
		        	"s.SHPR_CNTRY_CD, " + 
		        	"s.RECP_CNTRY_CD,  " + 
		        	"s.GROUP_NBR, " +
		        	"s.LANE_NBR " +
		            "from SHIPMENT s, ACCOUNT_GROUP ag, REFERENCE_NOTE r " +
		        	"where r.REF_TYPE_CD like ? " +
		        	"and r.REF_NOTE_DESC like ? " +
		        	"and r.REF_CRTN_TMSTP >= ? " +
		        	"and r.REF_CRTN_TMSTP <= ? " +
		        	"and s.GROUP_NBR = ag.GROUP_NBR " + 
		        	"and s.TRKNG_ITEM_NBR = r.TRKNG_ITEM_NBR " +
		        	"and s.TRKNG_ITEM_UNIQ_NBR = r.TRKNG_ITEM_UNIQ_NBR";
		    
		    
		    String getSearchByFindMonitorAcctNbrSQL = "select UNIQUE " +
		        	"alsm.ACCT_NBR, " +
		        	"e.EMP_NBR, " +
		        	"e.EMP_FIRST_NM, " +
		        	"e.EMP_LAST_NM " +
		        	"from ACCT_LANE_SERVICE_MONITORING alsm, EMPLOYEE e " +
		        	"where alsm.ACCT_NBR = ? and " +
		        	"alsm.EMP_NBR = e.EMP_NBR";
		    
		    

}
