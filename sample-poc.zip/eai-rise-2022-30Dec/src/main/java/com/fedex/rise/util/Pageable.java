package com.fedex.rise.util;

import java.util.List;

/**
 * Interface to allow paging of data for large datasets
 */
public interface Pageable {

    /** 
     * Get the size of all the data (total rows)
     * @return total rows of data
     */
    public int getSize();

    /**
     * Get a page of data (subset of the total rows)
     * 
     * @param page the page to get (1 = first page)
     * @param pageSize the number of rows per page
     * @return List of rows for the page requested
     */
    public List getPage(int page, int pageSize);

}