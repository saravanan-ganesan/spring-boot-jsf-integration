package com.fedex.rise.bo.issue;

import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public class HumanOnlyResolver extends Resolver {
    
    private static HumanOnlyResolver _instance = new HumanOnlyResolver();
    
    private HumanOnlyResolver() {}
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        return false;
    }
    
    public static HumanOnlyResolver getInstance() {
        return _instance;
    }
}
