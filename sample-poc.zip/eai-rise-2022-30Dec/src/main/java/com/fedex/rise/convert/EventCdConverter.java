package com.fedex.rise.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.xref.TrackTypes;

/**
 * This class will convert an EventCd to a FedEx Event description
 * Example: 08 = PUP = Pickup Scan
 * Note: EventCd = TrackType
 */
public class EventCdConverter implements Converter {

    /** logger */
    private static final Log log = LogFactory.getLog(EventCdConverter.class);
    
    /**
     * Default constructor
     */
    public EventCdConverter() {
        super();
        //if (log.isDebugEnabled()) log.debug("Constructed");
    }

    /**
     * Convert the event cd to a event description
     */
    public Object getAsObject(FacesContext context, UIComponent component, String eventCd) {
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + eventCd);
        return getAsString(context, component, eventCd);
    }   

    /**
     * Convert the event cd to a event description
     */
    public String getAsString(FacesContext context,  UIComponent component, Object eventCd) {
        //if (log.isDebugEnabled()) log.debug("GetAsString(): " + eventCd);
        if (eventCd == null || StringUtils.isEmpty(eventCd.toString())){ return null;}

        String eventDesc =  TrackTypes.getTrackTypeDesc(eventCd.toString().trim()).get_shortName();
        if (eventDesc == null) {
            log.warn("EventCd not found: " + eventCd);
            return eventCd.toString();
        } else {
            //if (log.isDebugEnabled()) log.debug("EventCd desc=" + eventDesc);
            return eventDesc;
        }
    }
}
