/**
 * 
 */
package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.auth.LDAPAuth;
import com.fedex.rise.bo.UserDelegate;
import com.fedex.rise.vo.EmployeeVO;

public class UserPreferencesBean implements Serializable {
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    private static Log log = LogFactory.getLog(UserPreferencesBean.class);
   
    /** max number of rows of CRNs to show on a page */
    private int maxCrnRows = 100;
    
    /**
     * Default Constructor
     */
    public UserPreferencesBean() {
    }
    
    /**
     * @return the maxCrnRows
     */
    public int getMaxCrnRowsInt() {
        return maxCrnRows;
    }

    /**
     * @return the maxCrnRows
     */
    public String getMaxCrnRows() {
        return String.valueOf(maxCrnRows);
    }

    /**
     * @param maxRows the maximum CRN Rows to set
     */
    public void setMaxCrnRows(String maxRows ) {
        this.maxCrnRows = Integer.parseInt(maxRows);
    }


}