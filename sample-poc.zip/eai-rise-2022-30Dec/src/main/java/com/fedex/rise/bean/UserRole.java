package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;

import com.fedex.rise.convert.UserRoleConverter;

public class UserRole implements Serializable {
    
    private static final long serialVersionUID = 1L;
  
    /**
     * Get the list of all possible user roles in order of priority
     * @return HashMap of roles (code, description)
     */
    public static HashMap getUserRoles() {
        return UserRoleConverter.getUserRoles();
    }
   
    /**
     * Get the description of the user role code
     * @param aUserRoleCd
     * @return user role description
     */
    public static String lookupUserRoleDesc(String aUserRoleCd) {
        return (String)UserRoleConverter.lookupUserRoleDesc(aUserRoleCd);
    }
    
    /**
     * Determine if user role has permissions to monitor shipments
     * M, FA, A can be setup to monitor, look at UserRoleConverter for codes. 
     * @param aUserRoleCd
     * @return true if can monitor (assigned to shipments)
     */
    public static boolean isMonitor(String aUserRoleCd) {
        if (aUserRoleCd.equals("M") 
            || aUserRoleCd.equals("FA") || aUserRoleCd.equals("A"))
            return true;
        else 
            return false;
                
    }
    
    /**
     * Determine if user role has permissions to monitor shipments
     * @param aUserRoleCd
     * @return true if can monitor (assigned to shipments)
     */
    public static boolean isAdmin(String aUserRoleCd) {
        if (aUserRoleCd.equals("A"))
            return true;
        else 
            return false;
                
    }
    
    /**
     * Determine if user role has permissions to monitor shipments
     * @param aUserRoleCd
     * @return true if can monitor (assigned to shipments)
     */
    public static boolean isSuper(String aUserRoleCd) {
        if (aUserRoleCd.equals("A"))
            return true;
        else 
            return false;
                
    }
}
