package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class REXorODAPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(REXorODAPreventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static REXorODAPreventer _instance = new REXorODAPreventer();

    static {
        // The previous scans below will prevent a new issue being created.
       	_preventingScans.add(RiseConstants.REX);
       	_preventingScans.add(RiseConstants.ODA);
    }
  
    private REXorODAPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	// If it has been delivered, do not create any new events.
        if (DeliveryPreventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (_preventingScans.contains(anPastEventVO.get_track_type_cd())) {
            logger.debug("Issue prevented by REX ODA Preventer.");
            return true;
        }
        
        // If a STAT42 event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("42")){
        	logger.debug("Issue prevented by STAT 42");
        	return true;
        }
        // If a STAT14 event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("14")){
        	logger.debug("Issue prevented by STAT 14");
        	return true;
        }
    	// If a STAT67 (ODA equivalent) event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("67")){
        	logger.debug("Issue prevented by STAT 67");
        	return true;
        }
    	// If a STAT33 (ODA equivalent) event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("33")){
        	logger.debug("Issue prevented by STAT 33");
        	return true;
        }
             
        return false;
    }

    public static REXorODAPreventer getInstance() {
        return _instance;
    }
}
