package com.fedex.rise.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

//@Data
//@Entity
//@Table(name = "Acct_Lane_Service_Monitoring")
public class AcctLaneServiceMonitoringEntity {

	@Id
	private String _emp_nbr;
	
    private int _group_nbr;
    private String _acct_nbr;
    private int    _lane_nbr;
    private String _svc_type_cd;
}
