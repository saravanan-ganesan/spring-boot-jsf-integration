package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.IssueVO;

public class IssuePersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(IssuePersister.class);
    
    public IssuePersister(Connection con) {
        super(con);
    }
    
    private static final String addIssueSQL =
        "Insert into Issue(" +
            "TRKNG_ITEM_NBR, " +
            "TRKNG_ITEM_UNIQ_NBR, " +
            "ISSUE_TYPE_CD, " +
            "ISSUE_LOC_CD, " +
            "ISSUE_TMSTP, " +
            "GROUP_NBR, " +
            "ACCT_NBR, " +
            "LANE_NBR, " +
            "SVC_TYPE_CD, " +
            "RES_DT, " +
            "RES_DESC, " +
            "TRACK_TYPE_CD, " +
            "EVENT_CRTN_TMSTP, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP) " +
            "values(?,?,?,?,?,?,?,?,?,?,?,?,?,SYSDATE,SYSDATE)";   
    
    public boolean persistIssue(IssueVO anIssueVO) throws SQLException {
        
        try {
            setSqlSignature( addIssueSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anIssueVO.getTrkng_item_nbr());
            pstmt.setString( 2, anIssueVO.getTrkng_item_uniq_nbr());
            pstmt.setInt( 3, anIssueVO.getIssue_type_cd());
            pstmt.setString(4, anIssueVO.getIssue_loc_cd());
            
            if (anIssueVO.getIssue_tmstp() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(anIssueVO.getIssue_tmstp().getTime());
                pstmt.setTimestamp(  5, sqlDate);
            } else {
                pstmt.setNull(  5, java.sql.Types.TIMESTAMP);
            }           
            pstmt.setInt(6, anIssueVO.getGrp_nbr());
            pstmt.setString(7, anIssueVO.getAcct_nbr());
            pstmt.setInt(8, anIssueVO.getLane_nbr());
            pstmt.setString(9, anIssueVO.getSvc_type_cd());
            if (anIssueVO.getRes_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(anIssueVO.getRes_dt().getTime());
                pstmt.setTimestamp(10, sqlDate);
            } else {
                pstmt.setNull(10, java.sql.Types.TIMESTAMP);
            }
            pstmt.setString(11, anIssueVO.get_res_desc());
            
            pstmt.setString(12, anIssueVO.get_trackTypeCd());
            
            if (anIssueVO.getEvent_crtn_tmstp() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(anIssueVO.getEvent_crtn_tmstp().getTime());
                pstmt.setTimestamp(  13, sqlDate);                
            } else {
                pstmt.setNull(  13, java.sql.Types.TIMESTAMP);
            }
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch (SQLException sqle) {
            if (sqle.getMessage().indexOf("ORA-00001") != -1) {
                logger.info("Duplicate issue detected.");
                return false;
            }
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
        return true;
    }       
}
