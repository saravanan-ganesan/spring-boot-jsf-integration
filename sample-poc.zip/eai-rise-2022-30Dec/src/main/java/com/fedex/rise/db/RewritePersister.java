package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.RewriteVO;


public class RewritePersister extends OracleBase {
    
    private static Logger logger = LogManager.getLogger(RewritePersister.class);
    
    public RewritePersister(Connection con) {
        super(con);
    }
   
    /** SQL for insert a label */
    private static final String insertRewriteSQL = "Insert into Rewrite(" +
                 "TRK_TYPE_CD, " +
                 "TRK_ITEM_NBR, " +
                 "TRK_ITEM_UNIQUE_ID, " +
                 "TRK_ITEM_FORM_CD, " +
                 "RISE_TRK_TYPE_CD, " +
                 "RETURN_TRK_ITEM_NBR, " +
                 "TRK_EXCEPTION_CD, " +
                 "SHPR_ACCT_NBR, " +
                 "SHIP_DATE, " +
                 "DECLARED_VALUE_CURRENCY_CD, " +
                 "CUSTOMS_CURRENCY_CD, " +
                 "CE_CUSTOMS_VALUE, " +
                 "ML_CUSTOMS_VALUE, " +
                 "SHIPMENT_PKG_COUNT, " +
                 "PACKAGING_TYPE, " +
                 "BASE_SERVICE_CD, " +
                 "SHIPPER_COMPANY_NAME, " +
                 "SHIPPER_ADDR_DESC, " +
                 "SHIPPER_ADDL_ADDR_DESC, " +
                 "SHIPPER_CITY_NAME, " +
                 "SHIPPER_POSTAL_CD, " +
                 "SHIPPER_COUNTRY_CD, " +
                 "SHIPPER_STATE_PROVINCE_CD, " +
                 "SHIPPER_PHONE_NBR, " +
                 "CONSIGNEE_COMPANY_NAME, " +
                 "CONSIGNEE_ADDR_DESC, " +
                 "CONSIGNEE_ADDL_ADDR_DESC, " +
                 "CONSIGNEE_CITY_NAME, " +
                 "CONSIGNEE_POSTAL_CD, " +
                 "CONSIGNEE_COUNTRY_CD, " +
                 "CONSIGNEE_STATE_PROVINCE_CD, " +
                 "CONSIGNEE_PHONE_NBR, " +
                 "ODA_COMPANY_NAME, " +
                 "LOC_CD, " +
                 "ADMIN_LOC_CD, " +
                 "REF_TYPE_CD, " +
                 "SHIPPER_REF_NOTES, " +
                 "SPECIAL_HANDLING, " +
                 "SP_SHPMT_WEIGHT, " +
                 "SP_SHPMT_WEIGHT_UOM, " +
                 "SP_PKG_WEIGHT, " +
                 "SP_PKG_WEIGHT_UOM, " +
                 "ACCEPTANCE_DT_TM, " + 
                 "DELIVERY_DT_TM, " +
                 "EVENT_CREATION_TMSTP, " +
                 "TRK_DATE, " +
                 "TRK_SCAN_TIME, " +
                 "ECCO_TYP_CD, " +
                 "ECCO_COMMENT_CD, " +
                 "ML_RELATION_SHIPS, " +
                 "SP_RELATION_SHIPS, " +
                 "ACTUAL_DELIVERY_NAME, " +
                 "ACTUAL_DELIVERY_ADDR_DESC, " +                 
                 "EMPLOYEE_NBR," +
                 "TRACK_SRC_CD," +
                 "EVENT_SEQUENCE_NBR," + 
                 "PARENT_TRK_ITEM_NBR," +
                 "PARENT_TRK_ITEM_UNIQUE_ID," +
                 "AIRBILL_ENTRY_TYPE, " +
                 "ORIG_LOC_CD, " +
                 "DEST_LOC_CD)" +
                 "values(?,?,?,?,?,?,?,?," + // 8
                        "?,?,?,?,?,?,?,?," + // 16
                        "?,?,?,?,?,?,?,?," + // 24
                        "?,?,?,?,?,?,?,?," + // 32
                        "?,?,?,?,?,?,?,?," + // 40
                        "?,?,?,?,?,?,?,?," + // 48
                        "?,?,?,?,?,?,?,?," + // 56
                        "?,?,?,?,?)";
    
    
    public void persist(RewriteVO aRiseVO) throws SQLException {
        try {
            setSqlSignature( insertRewriteSQL, false, logger.isDebugEnabled() );

            pstmt.setString(1, aRiseVO.get_trk_type_cd());
            pstmt.setString(2, aRiseVO.get_trk_item_nbr());
            pstmt.setString(3, aRiseVO.get_trk_item_unique_id());
            pstmt.setString(4, aRiseVO.get_trk_item_form_cd());
            pstmt.setString(5, aRiseVO.get_rise_trk_type_cd());
            pstmt.setString(6, aRiseVO.get_return_trk_item_nbr());
            pstmt.setString(7, aRiseVO.get_trk_exception_cd());          
            pstmt.setString(8, aRiseVO.get_shpr_acct_nbr());
            java.sql.Date sqlDate = new java.sql.Date(aRiseVO.get_ship_date().getTime());
            pstmt.setDate(9, sqlDate);
            pstmt.setString(10, aRiseVO.get_declared_value_currency_cd());
            pstmt.setString(11, aRiseVO.get_customs_currency_cd());
            pstmt.setString(12, aRiseVO.get_ce_customs_value());
            pstmt.setString(13, aRiseVO.get_ml_customs_value());  
            if (aRiseVO.get_shipment_pkg_count() != null ) {
                pstmt.setInt(14, Integer.parseInt(aRiseVO.get_shipment_pkg_count()));
            } else {
                pstmt.setNull(14, java.sql.Types.INTEGER);
            }
            pstmt.setString(15, aRiseVO.get_packaging_type());
            pstmt.setString(16, aRiseVO.get_base_service_cd());
            pstmt.setString(17, aRiseVO.get_shipper_company_name());
            pstmt.setString(18, aRiseVO.get_shipper_addr_desc());
            pstmt.setString(19, aRiseVO.get_shipper_addl_addr_desc());
            pstmt.setString(20, aRiseVO.get_shipper_city_name());
            pstmt.setString(21, aRiseVO.get_shipper_postal_cd());
            pstmt.setString(22, aRiseVO.get_shipper_country_cd());
            pstmt.setString(23, aRiseVO.get_shipper_state_province_cd());
            pstmt.setString(24, aRiseVO.get_shipper_phone_nbr());
            pstmt.setString(25, aRiseVO.get_consignee_company_name());
            pstmt.setString(26, aRiseVO.get_consignee_addr_desc());
            pstmt.setString(27, aRiseVO.get_consignee_addl_addr_desc());
            pstmt.setString(28, aRiseVO.get_consignee_city_name());
            pstmt.setString(29, aRiseVO.get_consignee_postal_cd());
            pstmt.setString(30, aRiseVO.get_consignee_country_cd());
            pstmt.setString(31, aRiseVO.get_consignee_state_province_cd());
            pstmt.setString(32, aRiseVO.get_consignee_phone_nbr());
            pstmt.setString(33, aRiseVO.get_oda_company_name());
            pstmt.setString(34, aRiseVO.get_loc_cd());
            pstmt.setString(35, aRiseVO.get_admin_loc_cd());
            pstmt.setString(36, aRiseVO.get_ref_type_cd());
            pstmt.setString(37, aRiseVO.get_shipper_ref_notes());
            pstmt.setString(38, aRiseVO.get_special_handling());
            pstmt.setString(39, aRiseVO.get_sp_shpmt_weight());
            pstmt.setString(40, aRiseVO.get_sp_shpmt_weight_uom());
            pstmt.setString(41, aRiseVO.get_sp_pkg_weight());
            pstmt.setString(42, aRiseVO.get_sp_pkg_weight_uom());
            pstmt.setString(43, aRiseVO.get_acceptance_dt_tm()); 
            pstmt.setString(44, aRiseVO.get_delivery_dt_tm());
            pstmt.setString(45, aRiseVO.get_event_creation_tmstp()); 
            pstmt.setString(46, aRiseVO.get_trk_date());
            pstmt.setString(47, aRiseVO.get_trk_scan_time());
            pstmt.setString(48, aRiseVO.get_ecco_typ_cd());
            pstmt.setString(49, aRiseVO.get_ecco_comment_cd());
            pstmt.setString(50, aRiseVO.get_ml_relation_ships());
            pstmt.setString(51, aRiseVO.get_sp_relation_ships());
            pstmt.setString(52, aRiseVO.get_actual_delivery_name());
            pstmt.setString(53, aRiseVO.get_actual_delivery_addr_desc());
            pstmt.setString(54, aRiseVO.get_employee_nbr());
            pstmt.setString(55, aRiseVO.get_track_source_cd());
            pstmt.setString(56, aRiseVO.get_event_sequence_nbr());
            pstmt.setString(57, aRiseVO.get_parent_trk_item_nbr());
            pstmt.setString(58, aRiseVO.get_parent_trk_item_unique_id());
            pstmt.setString(59, aRiseVO.get_airbill_entry_type());
            pstmt.setString(60, aRiseVO.get_orig_loc_cd());
            pstmt.setString(61, aRiseVO.get_dest_loc_cd());

            if (logger.isDebugEnabled()) {
                //logger.debug(pstmt.toString());
            }
            execute();

        } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
              sqle2.printStackTrace();
              throw sqle2;
            }
        }    
    }
    
}

