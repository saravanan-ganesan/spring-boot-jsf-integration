package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.IssueVO;

public class IssuesAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(IssuesAccessor.class);
    
    public IssuesAccessor(Connection con) {
        super(con);
    }
    
    private final String selectIssuesSQL = "select " +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "ISSUE_TYPE_CD, " +
        "ISSUE_LOC_CD, " +
        "ISSUE_TMSTP, " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "LANE_NBR, " +
        "SVC_TYPE_CD, " +
        "RES_DT, " +
        "RES_DESC, " +
        "RES_EMP_NBR, " +
        "TRACK_TYPE_CD, " +
        "EVENT_CRTN_TMSTP " +
        "from Issue where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND " +
            "RES_DESC is NULL AND " + // not programatically resolved, description used only by auto resolve
            "ISSUE_TMSTP <= SYSDATE"; // issues is active

    /**
     * Get the Issues for this tracking number, but ignore issues that have been resolved 
     * automatically/programatically by another SEP event coming in.  If programatically resolved, 
     * the resolving event type cd is stored * in the Res_desc field, thus if it is null, then it's 
     * ok to return.  We still want the issues resolved by a human.  Also, the issue_tmstp date tells
     * us when the issue becomes active if it hasn't been resolved already, and we only want active
     * issues returned.
     * 
     * @param aTrkngItemNbr
     * @param aTrkngItemUniqNbr
     * @return List of IssueVO
     * @throws SQLException 
     */
    public List getActiveIssues(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
        
        try {
            setSqlSignature( selectIssuesSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
         
            execute();

            if ( hasResults ) {
               
                while(rs.next()) {
                    // issue(s) found
                    IssueVO issueVO = new IssueVO();
                    issueVO.setTrkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    issueVO.setTrkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    issueVO.setIssue_type_cd(rs.getInt("ISSUE_TYPE_CD"));
                    issueVO.setIssue_loc_cd(rs.getString("ISSUE_LOC_CD"));
                    issueVO.setIssue_tmstp(rs.getTimestamp("ISSUE_TMSTP"));
                    issueVO.setGrp_nbr(rs.getInt("GROUP_NBR"));
                    issueVO.setAcct_nbr(rs.getString("ACCT_NBR"));
                    issueVO.setLane_nbr(rs.getInt("LANE_NBR"));
                    issueVO.setSvc_type_cd(rs.getString("SVC_TYPE_CD"));
                    issueVO.setRes_dt(rs.getDate("RES_DT"));
                    issueVO.set_res_emp_nbr(rs.getString("RES_EMP_NBR"));
                    issueVO.set_trackTypeCd(rs.getString("TRACK_TYPE_CD"));
                    issueVO.setEvent_crtn_tmstp(rs.getTimestamp("EVENT_CRTN_TMSTP"));
                    al.add(issueVO);
                }
            } else {
                // Issue not found
                logger.error("Issue not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }

    // going to use the earliest event_crtn_tmstp as the key to selecting only the events that can apply
    private final String selectUnresolvedIssuesSQL = "select " +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "ISSUE_TYPE_CD, " +
        "ISSUE_TMSTP, " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "LANE_NBR, " +
        "SVC_TYPE_CD, " +
        "RES_DT, " +
        "RES_DESC, " +
        "TRACK_TYPE_CD, " +
        "EVENT_CRTN_TMSTP " +
        "from Issue where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND " +
            "RES_DT is NULL order by EVENT_CRTN_TMSTP";
    
    public List getUnresolvedIssues(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
        
        try {
            setSqlSignature( selectUnresolvedIssuesSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
         
            execute();

            if ( hasResults ) {
               
                while(rs.next()) {
                    // issue(s) found
                    IssueVO issueVO = new IssueVO();
                    issueVO.setTrkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    issueVO.setTrkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    issueVO.setIssue_type_cd(rs.getInt("ISSUE_TYPE_CD"));
                    issueVO.setIssue_tmstp(rs.getTimestamp("ISSUE_TMSTP"));
                    issueVO.setGrp_nbr(rs.getInt("GROUP_NBR"));
                    issueVO.setAcct_nbr(rs.getString("ACCT_NBR"));
                    issueVO.setLane_nbr(rs.getInt("LANE_NBR"));
                    issueVO.setSvc_type_cd(rs.getString("SVC_TYPE_CD"));
                    issueVO.setRes_dt(rs.getDate("RES_DT"));
                    issueVO.set_trackTypeCd(rs.getString("TRACK_TYPE_CD"));
                    issueVO.setEvent_crtn_tmstp(rs.getTimestamp("EVENT_CRTN_TMSTP"));
                    al.add(issueVO);
                }
            } else {
                // Issue not found
                logger.error("Issue not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    
    private static String getFilterByIssuesType = "select " +
    	    "distinct ISSUE_TYPE_CD from ISSUE " + 
    	    "where RES_DT is null  " +
    	    "and ISSUE_TMSTP <= SYSDATE";
    
    
    public List getFilterByIssues() throws SQLException {
        ArrayList issueTypeCdsList = new ArrayList();
    
        try {
                        
            setSqlSignature( getFilterByIssuesType, false, logger.isDebugEnabled() );

                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

            if (hasResults) {
                while (rs.next()) {
                    Integer issueTypeCd = new Integer(rs.getInt("ISSUE_TYPE_CD"));
                    issueTypeCdsList.add(issueTypeCd);
                }                
            } else {
                // shipment not found
                logger.info("Issue Type Code not found");
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
                    + "; ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return issueTypeCdsList;        
    }
    
    
    
    
}
