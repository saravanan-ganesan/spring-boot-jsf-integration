package com.fedex.rise.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.MonitorReportVO;

/**
 * Monitor Detail List Backing bean
 */
public class MonitorReportListBean extends SortableList implements Serializable {
	/** serializing version */
    private static final long serialVersionUID = 1L;
    
	private static final Log log 
		= LogFactory.getLog(MonitorReportListBean.class);
	private static final int MAX_ROWS = 1000;
	
	private static final int SORT_ASCENDING = 1;
    private static final int SORT_DESCENDING = -1;
    
    private DataModel _data;
    private DataModel _columnHeaders;
    
    /** selected account */
    private MonitorReportBean _selectedMonitorReportBean =  null;
    
    private List _getMonitorReportList = null;
    private List _getMonitorsList = null;
    private String _monitorReportSelect = null;
    
    /**
     * Constructor
     */
    public MonitorReportListBean() {
    	super("EE Name");
    	
        // create header row
        List headerList = new ArrayList();
        headerList.add(new ColumnHeader("EE Name", "10", false));
        headerList.add(new ColumnHeader("BOH", "6", false));
        headerList.add(new ColumnHeader("RCVD", "10", false));
        headerList.add(new ColumnHeader("EOH", "10", false));
        headerList.add(new ColumnHeader("Resolved", "10", false));
        headerList.add(new ColumnHeader("Acct Total", "10", false));
        headerList.add(new ColumnHeader("MAWB Total Resolved", "10", false));
        headerList.add(new ColumnHeader("CRN Total Resolved", "10", false));
        headerList.add(new ColumnHeader("Hits", "10", false));
        headerList.add(new ColumnHeader("Duration", "10", false));
        
        _columnHeaders = new ListDataModel(headerList);
        
        // Get data from the back end monitor report data.
        if (getMonitorReportBean() != null){
        	_getMonitorReportList = getMonitorReportList(getMonitorReportBean());
        }
        
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
        
        _monitorReportSelect = new String(
        		" > From Date: " 
        		+ outputFormat.format(getMonitorReportBean().getFromDate()) +
        		" | To Date: " 
        		+ outputFormat.format(getMonitorReportBean().getToDate()) );
    }
    
    // ==========================================================================
    // Getters and Setters
    // ==========================================================================

    /**
     * @param get the _monitorReportSelect 
     */
    public String getMonitorReportSelect(){
    	return _monitorReportSelect;
    }
    /**
     * Get the column value for the table.
     * @return column value
     */
    public Object getColumnValue() {
        Object columnValue = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue = ((List) _data.getRowData()).get(_columnHeaders.getRowIndex());
        }
        return columnValue;
    }
    
    public String getMonitorName() {
        Object monitorName = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
        	monitorName = ((List) _data.getRowData()).get(0);
        }
        if (monitorName == null){
        	String defaultName = new String("Anita Shaw");
        	return defaultName;
        }
        return monitorName.toString(); 
    }
    
    /**
     * Get the monitor type, BOH, RCVD, EOH, and Resolved
     * @return monitor type.
     */
    public String getMonitorType(){
    	String monitorType = null;
    	if (_columnHeaders.getRowIndex() == 1){
    		monitorType = new String("BOH");
    	}else if (_columnHeaders.getRowIndex() == 2){
    		monitorType = new String("RCVD");
    	}else if (_columnHeaders.getRowIndex() == 3){
    		monitorType = new String("EOH");
    	}else if (_columnHeaders.getRowIndex() == 4){
    		monitorType = new String("Resolved");
    	}
    	return monitorType;
    }
    /**
     * Get the column width for the table.
     * @return column width
     */
    public String getColumnWidth() {
        String columnWidth = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnWidth = ((ColumnHeader) _columnHeaders.getRowData()).getWidth();
        }
        return columnWidth;
    }
    
    /**
     * First column (account) is a link to get to details
     * @return true if it is first column
     */
    public boolean isLink() {
        boolean valueLink = false;
        if (_data != null){
        	if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()){
        		valueLink = ((_columnHeaders.getRowIndex() == 1 ||
            		_columnHeaders.getRowIndex() == 2 ||
            		_columnHeaders.getRowIndex() == 3 ||
            		_columnHeaders.getRowIndex() == 4) && 
            		!getColumnValue().equals("0"));
        	}
        }
       
        return valueLink;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getRowsPerPage() {
        // if no data then no rows 
        if (_data == null) return 0;
       
        // if less than a page, then return actual number of rows
        int rows = _data.getRowCount();
        if (rows > MAX_ROWS)
            return MAX_ROWS;
        else
            return rows;
    }
    
    public DataModel getColumnHeaders() {
        return _columnHeaders;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getCount() {
        // if no data then no rows 
        if (_data == null) return 0;
       
        return _data.getRowCount();
    }
    
    /**
     * Get the Monitor that is selected in the list
     * @return
     */
    public MonitorReportBean getSelectedMonitor() {
        return _selectedMonitorReportBean;
    }
    
    /**
     * Get the Monitor data model list
     * @return DataModel
     */
    public DataModel getData() {
        populateMonitorReportList();
        sort(getSort(), isAscending());   
        return _data;
    }
    
    public String monitorDetail(){
    	return "monitorReportDetailList";
    }

    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        return true;
    }

    protected void sort(final String column, final boolean ascending) {
        if (column != null) {
            int columnIndex = getColumnIndex(column);
            int direction = (ascending) ? SORT_ASCENDING : SORT_DESCENDING;
            sort(columnIndex, direction);
        }
    }

    protected void sort(final int columnIndex, final int direction) {
    	if (columnIndex == 0){
        	sortString(columnIndex, direction);
        }else if (columnIndex > 0 && columnIndex < 9){
        	sortInteger(columnIndex, direction);
        }else {
        	sortString(columnIndex, direction);
        }
    }
     
    protected void sortInteger(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Integer column1 = Integer.parseInt(((List) o1).get(columnIndex).toString());
                Integer column2 = Integer.parseInt(((List) o2).get(columnIndex).toString());
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) _data.getWrappedData(), comparator);
    }
    
    protected void sortString(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Object column1 = ((List) o1).get(columnIndex);
                Object column2 = ((List) o2).get(columnIndex);
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) _data.getWrappedData(), comparator);
    }
    // =========================================================================
    // Private Methods
    // =========================================================================
    
    private int getColumnIndex(final String columnName) {
        int columnIndex = -1;
        List headers = (List) _columnHeaders.getWrappedData();
        for (int i = 0; i < headers.size() && columnIndex == -1; i++) {
            ColumnHeader header = (ColumnHeader) headers.get(i);
            if (header.getLabel().equals(columnName)) {
                columnIndex = i;
            }
        }
        return columnIndex;
    }
    
    /**
     * Return a list of monitor data.
     * @return
     */
    private List getMonitorReportList(MonitorReportBean monitorReportBean) {
    	log.debug("Entering getPerformanceAcctSumList()");
    	ShipperDelegate shipperDelegate = new ShipperDelegate();
        
    	
        return shipperDelegate.getMonitorReportList(
        	monitorReportBean.getFromDate(),
        	monitorReportBean.getToDate());
    }
    
    
    /**
     * Get the selected MonitorReportBean
     * @return String
     */
    private MonitorReportBean getMonitorReportBean() {
        Map params = FacesContext.getCurrentInstance().getExternalContext().
        	getSessionMap();
        MonitorReportBean monitorReportBean = 
        	(MonitorReportBean)params.get("MonitorReportBean");
        return monitorReportBean;
    }
    
    /**
     * Get the list of MonitorReport (data rows)
     */
    private void populateMonitorReportList() {
       
        if (_getMonitorReportList == null) {
           // no selection, so no data
           _data = null;
        } else {
           // node selected so get data for this account, lane, service, etc.
           List rowList = new ArrayList();
           
           // create data rows (list of lists)
           Iterator itr=_getMonitorReportList.iterator();
           
           while (itr.hasNext()) {
        	   MonitorReportVO monitorReportVO = (MonitorReportVO) itr.next();
               List colList = new ArrayList();
               
               // Insert Performance results into a display list.
               colList.add(monitorReportVO.get_emp_first_nm()+ " " + monitorReportVO.get_emp_last_nm());
               colList.add(String.valueOf(monitorReportVO.get_num_issues_begin_shift()));      
               colList.add(String.valueOf(monitorReportVO.get_num_issues_presented()));  
               colList.add(String.valueOf(monitorReportVO.get_num_issues_end_shift())); 
               colList.add(String.valueOf(monitorReportVO.get_num_issues_resolved()));
               colList.add(String.valueOf(monitorReportVO.get_total_number_accounts()));      
               colList.add(String.valueOf(monitorReportVO.get_num_mawb_resolved()));  
               colList.add(String.valueOf(monitorReportVO.get_num_crn_resolved()));
               colList.add(String.valueOf(monitorReportVO.get_num_hits()));
               
               String durationTime = secondsToString(monitorReportVO.get_total_duration());
               colList.add(durationTime);
               
               rowList.add(colList); 
           }
           
           _data = new ListDataModel(rowList);
        }
    }
    /**
     * Converts time in seconds to a String in the format Days HH:mm:ss.
     * 
     * @param time the time in seconds.
     * @return a <code>String</code> representing the time in the format Days HH:mm:ss.SSS.
     */
    private String secondsToString(int time) {
        int seconds = (int)((time) % 60);
        int minutes = (int)((time/60) % 60);
        int hours = (int)((time/3600) % 24);
        
        String secondsStr = (seconds<10 ? "0" : "")+seconds;
        String minutesStr = (minutes<10 ? "0" : "")+minutes;
        String hoursStr = (hours<10 ? "0" : "")+hours;
        return new String(hoursStr+":"+minutesStr+":"+secondsStr);
    }
}
