package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.util.DateUtility;
import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.AccountVO;
import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.LaneVO;
import com.fedex.rise.vo.PerformanceVO;
import com.fedex.rise.vo.AccountGroupVO;

/**
 * DAO class to persits, update and access the Performance DB table.
 * @author be379961
 *
 */
public class PerformanceDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(LaneDAO.class);
    
    /**
     * Persist a PerformanceVO to the Performance table.
     * @param aPerformanceVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void doPersist(PerformanceVO aPerformanceVO) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection();
            PerformancePersister persister = 
            	new PerformancePersister(connection);
            persister.doPersist(aPerformanceVO);
        } finally {
            closeConnection(connection);
        }
    }
    /**
     * Update a PerformanceVO to the Performance table.
     * @param aPerformanceVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public void updatePerformance(PerformanceVO aPerformanceVO) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection(true);
            PerformanceUpdater performanceUpdater 
            	= new PerformanceUpdater(connection);
            performanceUpdater.updatePerformance(aPerformanceVO);
        } finally {
            closeConnection(connection);
        }
    }
    /**
     * Get the ShipmentVO from the Shipment table, based on the AccountLaneVO, 
     * and ship date.
     * @param anAccountLaneVO
     * @param shipDate
     * @return
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getShipmentViaAcctNbrLaneShipDate(AccountLaneVO anAccountLaneVO, 
       Calendar shipDate) throws SQLException, ServiceLocatorException {
        	
        Connection connection = null;
        try {
            connection = initializeConnection();
            PerformanceAccessor accessor = new PerformanceAccessor(connection);
            return accessor.getShipmentViaAcctNbrLaneShipDate(
                    anAccountLaneVO, shipDate);
        } finally {
            closeConnection(connection);
        }        
    }
    /**
     * Determine if a row already exists in the Performance table.
     * @param anAccountLaneVO
     * @param shipDate
     * @return
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public boolean shipmentExist(AccountLaneVO anAccountLaneVO,	
    		Calendar shipDate) throws SQLException, ServiceLocatorException {
        	
        Connection connection = null;
        try {
            connection = initializeConnection();
            PerformanceAccessor accessor = new PerformanceAccessor(connection);
            if (accessor.getPerformance(anAccountLaneVO.get_acct_nbr(), 
                    shipDate, 
                    anAccountLaneVO.get_lane_nbr()) != null){
                	    return true;
            }
        } finally {
            closeConnection(connection);
        }
        return false;        
    }
    /**
     * Get a list of PerformanceVOs from the Performance table, based on the 
     * group number, ship date range, and lane.
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbrStr
     * @return
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getPerformanceList(String groupNbr, Date fromDate, Date toDate,
    		String laneNbrStr) throws SQLException, 
    		ServiceLocatorException {
    	        	
    	        Connection connection = null;
    	        try {
    	            connection = initializeConnection();
    	            PerformanceAccessor accessor = 
    	            	new PerformanceAccessor(connection);
    	            int laneNbr = Integer.parseInt(laneNbrStr);
    	            
    	            if (laneNbr <= 0){
    	            	logger.info("Non monitored lane: " + laneNbrStr);
    	            	return null;
    	            }
    	            
    	            return accessor.getPerformanceList(groupNbr, fromDate, 
    	            		toDate, laneNbr);
    	        } finally {
    	            closeConnection(connection);
    	        }        
    	    }    	   
	 //WR#:179441 Changes    	     
    /**
     * Get a list of the sum of PerformanceVOs from the Performance table, 
     * based on the group number, ship date range, and lane. 
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbrStr
	 * @param empNbr
     * @return List of PerformanceVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getPerformanceSumList(String groupNbr, Date fromDate, 
    		Date toDate, String laneNbrStr, String empNbr) throws SQLException, 
    		ServiceLocatorException {
    	        	
    	        Connection connection = null;
    	        ArrayList al = new ArrayList();
    	        PerformanceVO performanceVO;
    	        try {
    	            connection = initializeConnection();
    	            PerformanceAccessor accessor = 
    	            	new PerformanceAccessor(connection);
    	            
    	            int laneNbr = 0;
    	            boolean allLanes = false;
    	            if (laneNbrStr.equals("All")) {
    	            	allLanes = true;
    	            }else{
    	            	laneNbr = Integer.parseInt(laneNbrStr);
    	            }
    	            
    	            if (laneNbr < 0){
    	            	logger.info("Non monitored lane: " + laneNbrStr);
    	            	return null;
    	            }
    	            DateUtility monthDate = new DateUtility(
    	            		fromDate, toDate);
    	            int numberOfMonths = monthDate.getNumberOfMonths();
    	            for (int count=0; count< numberOfMonths; count++ ){    
    	            	
    	            	logger.debug("startDate = " + 
    	            			monthDate.getstartDate().toString() + 
    	            			" endDate = " + monthDate.getEndDate());
    	            	
    	            	performanceVO = accessor.getPerformanceSum(groupNbr, 
    	            		monthDate.getstartDate(), 
    	            		monthDate.getEndDate(), laneNbr, allLanes, empNbr);
    	            	String month = monthDate.getStartMonthName();
    	            	performanceVO.set_month(month);
    	            	
    	            	monthDate.incrementMonth();
    	            	al.add(performanceVO);
    	            }
    	            return al;
    	        } finally {
    	            closeConnection(connection);
    	        }        
    	    }
    
    //WR#:179441 Changes
    /**
     * Get a list of the sum of PerformanceVOs of all Group Numbers from the 
     * Performance table, based on the ship date range.
     * @param fromDate
     * @param toDate 
     * @param monthNbr 0-11 represents January to December
     * @param monthSelectedNumber The month selected, independent of monthNbr.
     * @return List of PerformanceVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getPerformanceGroupSumList(Date fromDate, Date toDate, 
    		int monthNbr, int monthSelectedNumber) throws SQLException, 
    			ServiceLocatorException {
    	        	
    	        Connection connection = null;
    	        ArrayList al = new ArrayList();
    	        List groupNbrList;
    	        try {
    	            connection = initializeConnection();
    	            PerformanceAccessor accessor = 
    	            	new PerformanceAccessor(connection);
    	            
    	            AccountGroupAccessor accountGroupAccessor =
    	            	new AccountGroupAccessor(connection);
    	            
    	            DateUtility monthDate = new DateUtility(
    	            		fromDate, toDate, monthNbr, monthSelectedNumber);
    	            	
    	            logger.debug("startDate = " + 
    	            		monthDate.getstartDate().toString() 
    	            		+ " endDate = " + monthDate.getEndDate() );
    	            
    	            groupNbrList = accessor.getPerformanceGroupNbrList( 
    	            		monthDate.getstartDate(), 
    	            		monthDate.getEndDate());
    	            if (groupNbrList != null){
    	            	Iterator itr= groupNbrList.iterator();
    	            
    	            	while (itr.hasNext()) {
    	            		PerformanceVO performanceVO 
    	            			= (PerformanceVO) itr.next();
    	         	   		int groupNbr = performanceVO.get_group_nbr();
    	         	   		
    	         	   
    	         	   		performanceVO = accessor.getPerformanceSum( 
    	         	   				Integer.toString(groupNbr), 
    	         	   				monthDate.getstartDate(), 
    	         	   				monthDate.getEndDate());
    	         	   		performanceVO.set_group_nbr(groupNbr);
    	         	   		// Get the Group Name.
    	         	   		AccountGroupVO accountGroupVO = 
    	         	   			accountGroupAccessor.getAccountGroup(groupNbr);
    	         	   		if (accountGroupVO != null && accountGroupVO.get_group_nm() != null){
    	         	   	    	performanceVO.set_acct_nbr(accountGroupVO.get_group_nm());// Actually Company Name
    	         	   		}else{ // Company no longer exists in ACCOUNT_GROUP
    	         	   			// Get the account numbers for this group from the Performance table.
    	         	   			List acctNbrList = accessor.getPerformanceAcctNbrList( 
        	         	   				Integer.toString(groupNbr), 
        	         	   				monthDate.getstartDate(), 
        	         	   				monthDate.getEndDate(), 0, true, "All");
    	         	   			String acctNbr = new String("Acct #'s:");
    	         	   			if (acctNbrList != null){
    	         	   				Iterator itr2= acctNbrList.iterator();
    	     	                    // Build a string of account numbers found
    	         	   				// for this group number in the performance
    	         	   				// table.
    	         	   				while (itr2.hasNext()) {
    	         	   					PerformanceVO performanceVO2 
    	         	   						= (PerformanceVO) itr2.next();
    	         	   					if (performanceVO2.get_acct_nbr() != null){
    	         	   						acctNbr = acctNbr + performanceVO2.get_acct_nbr() + ";";
    	         	   					}
    	         	   				}
    	         	   			}	
    	         	   			performanceVO.set_acct_nbr(acctNbr);
    	         	   		}
    	         	   		al.add(performanceVO);
    	            	}
    	            }
    	            
    	            return al;
    	        } finally {
    	            closeConnection(connection);
    	        }        
    	    }
    //WR#:179441 Changes
    /**
     * Get a list of the sum of PerformanceVOs by account number from the 
     * Performance table, based on the Group number, ship date range,  and lane.
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbrStr  
     * @param monthNbr 0-11 represents January to December
     * @param monthSelectedNumber The month selected, independent of monthNbr.
     * @return List of PerformanceVO
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public List getPerformanceAcctSumList(String groupNbr, Date fromDate, 
    		Date toDate, String laneNbrStr, int monthNbr, 
    		int monthSelectedNumber, String empNbr) throws SQLException, 
    			ServiceLocatorException {
    	        	
    	        Connection connection = null;
    	        ArrayList al = new ArrayList();
    	        List acctNbrList;
    	        try {
    	            connection = initializeConnection();
    	            PerformanceAccessor accessor = 
    	            	new PerformanceAccessor(connection);
    	            AccountAccessor accountAccessor =
    	            		new AccountAccessor(connection);
    	            LaneAccessor laneAccessor =
    	            		new LaneAccessor(connection);
    	            
    	            int laneNbr = 0;
    	            boolean allLanes = false;
    	            if (laneNbrStr.equals("All")) {
    	            	allLanes = true;
    	            }else{
    	            	laneNbr = Integer.parseInt(laneNbrStr);
    	            }
    	            
    	            if (laneNbr < 0){
    	            	logger.info("Non monitored lane: " + laneNbrStr);
    	            	return null;
    	            }
    	            DateUtility monthDate = new DateUtility(
    	            		fromDate, toDate, monthNbr, monthSelectedNumber);
    	            	
    	            logger.debug("startDate = " + 
    	            		monthDate.getstartDate().toString() 
    	            		+ " endDate = " + monthDate.getEndDate() );
    	            if((groupNbr.equals("All")) && (allLanes) && (!empNbr.equals("All")))
    	            {
    	            	acctNbrList =accessor.getPerformanceAcctNbrListByEmp(groupNbr, 
        	            		monthDate.getstartDate(), 
        	            		monthDate.getEndDate(), 
        	            		laneNbr, 
        	            		allLanes,
        	            		empNbr);
    	            	
    	            	 if (acctNbrList != null){
    	    	            	Iterator itr= acctNbrList.iterator();
    	    	            
    	    	            	while (itr.hasNext()) {
    	    	            		PerformanceVO performanceVO 
    	    	            			= (PerformanceVO) itr.next();
    	    	         	   		String acctNbr = performanceVO.get_acct_nbr();
    	    	         	   		int lane = performanceVO.get_lane_nbr();
    	    	         	   		int grpNbr = performanceVO.get_group_nbr();
    	    	         	   
    	    	         	   		performanceVO = accessor.getPerformanceSum(groupNbr, 
    	    	         	   				monthDate.getstartDate(), 
    	    	         	   				monthDate.getEndDate(), lane, acctNbr, 
    	    	         	   				allLanes);
    	    	         	   		
    	    	         	   		
    	    	         	   		AccountVO accountVO = accountAccessor.getAccount(grpNbr, acctNbr);
    	    	         	   		LaneVO laneVO  =  laneAccessor.getLane(lane);
    	    	         	   	
    	    	         	   		performanceVO.set_acct_nbr(accountVO.get_acct_nm()+" [Lane:"+laneVO.get_orig_cntry_cd()+"-"+laneVO.get_dest_cntry_cd()+"]");
    	    	         	   		performanceVO.set_lane_nbr(lane);
    	    	         	   		al.add(performanceVO);
    	    	            		}
    	    	            	}
    	            }else{
    	            acctNbrList = accessor.getPerformanceAcctNbrList(groupNbr, 
    	            		monthDate.getstartDate(), 
    	            		monthDate.getEndDate(), 
    	            		laneNbr, 
    	            		allLanes,
    	            		empNbr);
    	            
    	            if (acctNbrList != null){
    	            	Iterator itr= acctNbrList.iterator();
    	            
    	            	while (itr.hasNext()) {
    	            		PerformanceVO performanceVO 
    	            			= (PerformanceVO) itr.next();
    	         	   		String acctNbr = performanceVO.get_acct_nbr();
    	         	   
    	         	   		performanceVO = accessor.getPerformanceSum(groupNbr, 
    	         	   				monthDate.getstartDate(), 
    	         	   				monthDate.getEndDate(), laneNbr, acctNbr, 
    	         	   				allLanes);
    	         	   		performanceVO.set_acct_nbr(acctNbr);
    	         	   		al.add(performanceVO);
    	            		}
    	            	}
    	            }
    	            return al;
    	        } finally {
    	            closeConnection(connection);
    	        }        
    	    }
    /**
     * Get the MAX ship date from the configuration table.
     * @return MAX ship date
     * @throws SQLException
     * @throws ServiceLocatorException
     */
    public Calendar getMaxShipDate() throws SQLException, 
    	ServiceLocatorException {
    	        	
        Connection connection = null;
    	Calendar shipDate = null;
        try {
        	connection = initializeConnection();
        	ConfigurationAccessor accessor = 
        		new ConfigurationAccessor(connection);  
    	       	String maxShipDateStr = accessor.getValue("MAX_SHIP_DT");
    	        if (maxShipDateStr == null){
    	        	return null;
    	        }else{
    	        	SimpleDateFormat inputFormat = 
    	        		new SimpleDateFormat("yyyyMMdd");
    	            Date d = null;
    	            try {
    	            	d = inputFormat.parse(maxShipDateStr);
    	            	if (d == null){
    	            		return null;
    	            	}
    	            } catch (ParseException e) {
    	            	logger.error("ParseException: ", e);
    	            }
    	            shipDate = Calendar.getInstance();
    	            shipDate.setTime(d);
    	        }
    	        return shipDate;
        	} finally {
        		closeConnection(connection);
        }        
    }
    
    /**
     * Get a shipment list from the shipment table of CRNS that meet the 
     * criteria below.
     * 
     * @param acctNbr The account number of interest.
     * @param fromDate The ship date from range.
     * @param toDate The ship date to range.
     * @param laneNbrStr The lane number of interest.
     * @param monthNbr interested in all lanes. true for all.
     * @param performanceType the performance type of interest.
     * @param issuesOnly currently NOT USED.  May be used in the future.
     * @return
     * @throws SQLException
     */
    public List getCRNShipments(String acctNbr, 
    		Date fromDate, Date toDate, String laneNbrStr, int monthNbr, 
    		String performanceType, int startIndex, int endIndex, String sortColumn, 
    		boolean isSortAscending) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            PerformanceAccessor accessor = new PerformanceAccessor(connection);
            List crns = null;
            int laneNbr = 0;
            boolean allLanes = false;
            
            if (laneNbrStr.equals("All")) {
            	allLanes = true;
            }else{
            	laneNbr = Integer.parseInt(laneNbrStr);
            }
            
            if (laneNbr < 0){
            	logger.info("Non monitored lane: " + laneNbrStr);
            	return null;
            }
            DateUtility monthDate = new DateUtility(
            		fromDate, toDate, monthNbr);
            crns = accessor.getCRNShipments(acctNbr, 
            		monthDate.getstartDate(), monthDate.getEndDate(),
            		laneNbr, allLanes, performanceType, startIndex, endIndex, 
            		sortColumn, isSortAscending);
            return crns;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    /**
     * Get a shipment list from the shipment table of CRNS that meet the 
     * criteria below.
     * 
     * @param acctNbr The account number of interest.
     * @param fromDate The ship date from range.
     * @param toDate The ship date to range.
     * @param laneNbrStr The lane number of interest.
     * @param monthNbr interested in all lanes. true for all.
     * @param performanceType the performance type of interest.
     * @return
     * @throws SQLException
     */
    public int getShipmentsCount(String acctNbr, Date fromDate, Date toDate,
    		String laneNbrStr, int monthNbr, String performanceType) throws SQLException {
        Connection connection = null;
        int count = 0;

        try {
            connection = initializeConnection();
            PerformanceAccessor accessor = new PerformanceAccessor(connection);
            
            int laneNbr = 0;
            boolean allLanes = false;
            
            if (laneNbrStr.equals("All")) {
            	allLanes = true;
            }else{
            	laneNbr = Integer.parseInt(laneNbrStr);
            }
            
            if (laneNbr < 0){
            	logger.info("Non monitored lane: " + laneNbrStr);
            	return count;
            }
            DateUtility monthDate = new DateUtility(
            		fromDate, toDate, monthNbr);
            count = accessor.getShipmentsCount(acctNbr, 
            		monthDate.getstartDate(), monthDate.getEndDate(),
            		laneNbr, allLanes, performanceType);
            return count;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return count;        
    }
}
