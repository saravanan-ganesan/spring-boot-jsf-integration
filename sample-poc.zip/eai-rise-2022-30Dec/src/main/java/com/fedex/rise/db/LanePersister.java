package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.LaneVO;

public class LanePersister extends OracleBase {

    private static Logger logger = LogManager.getLogger(LanePersister.class);

    public LanePersister(Connection con) {
        super(con);
    }

    private static final String addLaneSQL =
        "Insert into Lane(" +
        "LANE_NBR, " +
        "ORIG_CNTRY_CD, " +
        "DEST_CNTRY_CD, " +
        "INPUT_TMSTP, " +
        "LAST_UPDT_TMSTP) " +
         "values(LANE_NBR_SQ.NEXTVAL,?,?,SYSDATE,SYSDATE)";        

    public void addLane(LaneVO aLaneVO) throws SQLException {
    
        try {
            setSqlSignature( addLaneSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aLaneVO.get_orig_cntry_cd());
            pstmt.setString( 2, aLaneVO.get_dest_cntry_cd());
        
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
        
            execute();

        } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
}       

