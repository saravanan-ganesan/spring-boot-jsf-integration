 package com.fedex.rise.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fedex.rise.constant.QueryConstant;
import com.fedex.rise.entity.AccountGroupEntity;


@Repository
@SuppressWarnings("rawtypes")
public interface ShipperDelegateRepository extends JpaRepository<AccountGroupEntity, Integer> {
	
	@Query(value=QueryConstant.GET_ACCOUNT_GROUP_NAMES, nativeQuery=true)
	public List getAccountGroups();
	
	@Query(value=QueryConstant.GET_ACCOUNT_LANES_BY_GROUP_NUMBER, nativeQuery=true)
	public List getAccountLanes(int aGroupNbr);
	
	@Query(value=QueryConstant.GET_LANE, nativeQuery=true)
	public List getLane(int laneNbr);
	
	@Query(value=QueryConstant.GET_LABE_BY_GROUP_NBR, nativeQuery=true)
	public List getLaneByGroupNbr(int groupNbr);
	
	@Query(value=QueryConstant.selectPerformanceSumOfAllGroupLaneListByEmp, nativeQuery=true)
	public List selectPerformanceSumOfAllGroupLaneListByEmp(Date fromDate, Date toDate, String empNbr);
}
