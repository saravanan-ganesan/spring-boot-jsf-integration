package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ReferenceNoteVO;

public class ReferenceNotesAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(ReferenceNotesAccessor.class);
        
    public ReferenceNotesAccessor(Connection con) {
        super(con);
    }
        
    private final String selectReferenceNotesSQL = "select " +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "REF_TYPE_CD, " +
        "REF_NOTE_DESC " +
        "from Reference_Note where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ?";

        
    public List getReferenceNotes(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
            
        try {
            setSqlSignature( selectReferenceNotesSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aTrkngItemNbr);
            pstmt.setString( 2, aTrkngItemUniqNbr);
             
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if ( hasResults ) {
                   
                while(rs.next()) {
                    // event(s) found
                    ReferenceNoteVO referenceNoteVO = new ReferenceNoteVO();
                    referenceNoteVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    referenceNoteVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    referenceNoteVO.set_ref_type_cd(rs.getString("REF_TYPE_CD"));
                    referenceNoteVO.set_ref_note_desc(rs.getString("REF_NOTE_DESC"));
                    al.add(referenceNoteVO);
                }
            } else {
                // Reference Note not found
                logger.error("Refernce note not found for : " + aTrkngItemNbr + ":" + aTrkngItemUniqNbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode());
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }    
}
