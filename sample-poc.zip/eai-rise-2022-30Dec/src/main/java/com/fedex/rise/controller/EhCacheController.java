package com.fedex.rise.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EhCacheController {

	@Autowired
	private CacheManager cacheManager; 
	
	@RequestMapping("/cache")
	public ResponseEntity<String> getAllCaches() {
		
		String html = "";
		
		if(!ObjectUtils.isEmpty(cacheManager) && !ObjectUtils.isEmpty(cacheManager.getCacheNames())) {
			
			html = "<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\n"
					+ "	<tbody>\n"
					+ "		<tr>\n"
					+ "			<td style=\"width:225px\"><strong>Name</strong></td>\n"
					+ "		</tr>\n";
//					+ "		<tr>\n";
						for (String name : cacheManager.getCacheNames()) {
							html = html + "<tr>\n<td style=\"width:225px\">" +  cacheManager.getCache(name).getName() +  "</td>\n</tr>\n";
						}
					html = html 
//					+ "		</tr>\n"
					+ "		<tr>\n"
					+ "			<td style=\"width:225px\">&nbsp;</td>\n"
					+ "		</tr>\n"
					+ "	</tbody>\n"
					+ "</table>";
		}
		return new ResponseEntity<>(html, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/cache/clear")
	public ResponseEntity<String> clearAllCaches() {
		
		if(!ObjectUtils.isEmpty(cacheManager) && !ObjectUtils.isEmpty(cacheManager.getCacheNames())) {
			
			for (String name : cacheManager.getCacheNames()) {
				cacheManager.getCache(name).invalidate();
				//cacheManager.getCache(name).clear(); 
			}
			return new ResponseEntity<>("Successfully cleared all caches!!!", HttpStatus.OK);
		}
		return new ResponseEntity<>("There is an error while clearing cache, please try again", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(value = "/cache/clear/{name}")
	public ResponseEntity<String> clearCache(@PathVariable("name") String name) {
		
		if(!ObjectUtils.isEmpty(cacheManager) && !ObjectUtils.isEmpty(name)) {
			
			Cache cache = cacheManager.getCache(name);
			if(!ObjectUtils.isEmpty(cache)) {
				cache.clear();
			}
			return new ResponseEntity<>("Successfully cleared cache " + name + "!!!", HttpStatus.OK);
		}
		return new ResponseEntity<>("There is an error while clearing cache, please try again", HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
