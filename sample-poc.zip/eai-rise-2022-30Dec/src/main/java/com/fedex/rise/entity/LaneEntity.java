package com.fedex.rise.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "LANE")
public class LaneEntity {

	@Id
    private int    lane_nbr;
	
    private String orig_cntry_cd;
    private String dest_cntry_cd;
}
