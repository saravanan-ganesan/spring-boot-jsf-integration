package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;
import com.fedex.rise.vo.MAWBAttributesVO;

public class MawbAttributesUpdater extends OracleBase {
    private static Logger logger = LogManager.getLogger(MawbAttributesUpdater.class);
    
    public MawbAttributesUpdater(Connection con) {
        super(con);
    }    
    
    private static final String mawbAttrUpdaterSQL = "update Shipment set " +
        "DIMNL_WGT = ?, " +
        "INV_AMT = ?, " +
        "LAST_UPDT_TMSTP = SYSDATE " +
        "Where trkng_item_nbr = ? and trkng_item_uniq_nbr = ?"; 
    
    public void updateMawbAttributes(MAWBAttributesVO aVO) throws SQLException {

        try {
            setSqlSignature(mawbAttrUpdaterSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, aVO.get_dimnlWgt());
            pstmt.setInt(2, aVO.get_inv_amt());
            pstmt.setString(3, aVO.get_trkng_item_nbr());
            pstmt.setString(4, aVO.get_trkng_item_uniq_nbr());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
       
}
