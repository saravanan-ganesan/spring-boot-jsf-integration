package com.fedex.rise.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.xref.ExceptionTypes;

/**
 * This class will convert an ExceptionCd to a FedEx Exception description
 */
public class ExceptionCdConverter implements Converter {

    /** logger */
    private static final Log log = LogFactory.getLog(ExceptionCdConverter.class);
    
    /**
     * Default constructor
     */
    public ExceptionCdConverter() {
        super();
        //if (log.isDebugEnabled()) log.debug("Constructed");
    }

    /**
     * Convert the Exception cd to a Exception description
     */
    public Object getAsObject(FacesContext context, UIComponent component, String exceptionCd) {
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + exceptionCd);
        return getAsString(context, component, exceptionCd);
    }   

    /**
     * Convert the Exception cd to a Exception description
     */
    public String getAsString(FacesContext context,  UIComponent component, Object exceptionCd) {
        //if (log.isDebugEnabled()) log.debug("GetAsString(): " + exceptionCd);
        if (exceptionCd == null || StringUtils.isEmpty(exceptionCd.toString())){ return null;}

        String exceptionDesc =  ExceptionTypes.lookupExceptionType(exceptionCd.toString().trim());
        if (exceptionDesc == null) {
            log.warn("ExceptionCd not found: " + exceptionCd);
            return exceptionCd.toString();
        } else {
            //if (log.isDebugEnabled()) log.debug("ExceptionCd desc=" + exceptionDesc);
            return exceptionDesc;
        }
    }
}
