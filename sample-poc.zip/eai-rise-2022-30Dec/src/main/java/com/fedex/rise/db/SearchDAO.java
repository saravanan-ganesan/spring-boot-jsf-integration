package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocator;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;
import com.fedex.rise.vo.ShipmentEmployeeVO;

import java.util.Date;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

public class SearchDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(DatabaseDAO.class);
    
    /**
     * 
     * @param aShprNm
     * @return
     * @throws SQLException
     */    
    public List searchByShprNm(String aShprNm) throws SQLException {    	
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByShprNm(aShprNm);            
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    
    
    /**
     * 
     * @param aAcctNbr
     * @return
     * @throws SQLException
     */    
    public List searchByAcctNbr(String aAcctNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByAcctNbr(aAcctNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    
    
    /**
     * 
     * @param aTrkngNbr
     * @return
     * @throws SQLException
     */
    public List searchByTrkngNbr(String aTrkngNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByTrkngNbr(aTrkngNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }

	//Start WR#:179441 Changes    
    /**
     * 
     * @param groupNbr
     * @return
     * @throws SQLException
     */
    public List searchByAll() throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringAccessor accountLaneServiceMonitorAccessor 
        	= new AcctLaneServiceMonitoringAccessor(connection);
            EmployeeAccessor employeeAccessor = new EmployeeAccessor(connection);
            
            List EmployeeNbrList =  accountLaneServiceMonitorAccessor.searchByAll();
            List EmployeeNmList = new ArrayList(EmployeeNbrList.size());
            
            for (Iterator itr= EmployeeNbrList.iterator(); itr.hasNext(); ) {
            	AcctLaneServiceMonitoringVO accountLaneServiceMonitoringVO 
            		= (AcctLaneServiceMonitoringVO)itr.next();
            	EmployeeVO employeeVO = employeeAccessor.getEmployee(accountLaneServiceMonitoringVO.get_emp_nbr());
            	EmployeeNmList.add(employeeVO);
            }
            return EmployeeNmList;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }
	
	 /**
     * 
     * @param groupNbr,laneNbr
     * @return
     * @throws SQLException
     */
    public List searchByGroupLaneNbr(int groupNbr,int laneNbr) throws SQLException {
        	Connection connection = null;
        try {
            connection = initializeConnection();
            AcctLaneServiceMonitoringAccessor accountLaneServiceMonitorAccessor 
        	= new AcctLaneServiceMonitoringAccessor(connection);
            EmployeeAccessor employeeAccessor = new EmployeeAccessor(connection);
            
            List EmployeeNbrList =  accountLaneServiceMonitorAccessor.searchByGroupLaneNbr(groupNbr,laneNbr);
            List EmployeeNmList = new ArrayList(EmployeeNbrList.size());
            
            for (Iterator itr= EmployeeNbrList.iterator(); itr.hasNext(); ) {
            	AcctLaneServiceMonitoringVO accountLaneServiceMonitoringVO 
            		= (AcctLaneServiceMonitoringVO)itr.next();
            	EmployeeVO employeeVO = employeeAccessor.getEmployee(accountLaneServiceMonitoringVO.get_emp_nbr());
            	EmployeeNmList.add(employeeVO);
            }
            return EmployeeNmList;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }//End WR#:179441 Changes

    
  
    /**
     * 
     * @param aReferenceNbr, aReferenceNumberMenu
     * @return
     * @throws SQLException
     */    
    public List searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu, Date _limitOneWeekFromDate, Date _limitOneWeekToDate) throws SQLException {
        Connection connection = null;
        ArrayList al = new ArrayList();
        
        //      transaction part of event processing
        UserTransaction userTransaction = null;

        try {
        	// Initialize transaction, set time out and begin it.
        	userTransaction = ServiceLocator.getInstance().getUserTransaction();
        	userTransaction.setTransactionTimeout(60);
        	userTransaction.begin();
        	
            // Initialize connection for transaction.
            connection = initializeConnection(true);
            
            // Connect accessors.
            ShipmentSearchAccessor shipmentAccessor 
            	= new ShipmentSearchAccessor(connection);
            AcctLaneServiceMonitoringAccessor accountLaneAccessor 
            	= new AcctLaneServiceMonitoringAccessor(connection);
            EmployeeAccessor employeeAccessor 
            	= new EmployeeAccessor(connection);
            // Get list of tracking numbers and other shimment table data with reference number of interest.
            List referenceNbrlist = shipmentAccessor.searchByReferenceNbr(aReferenceNbr, aReferenceNumberMenu, _limitOneWeekFromDate, _limitOneWeekToDate);
            Iterator referenceNbrIterator = referenceNbrlist.iterator();
            while (referenceNbrIterator.hasNext()) {
            	ShipmentEmployeeVO shipmentemployeeVO = 
                		(ShipmentEmployeeVO)referenceNbrIterator.next();
            	// Find employee who monitors this account, lane, service.
                List acctList = 
                	accountLaneAccessor.getAcctLaneServiceMonitoring(
                			shipmentemployeeVO.get_grp_nbr(), 
                			shipmentemployeeVO.get_acct_nbr(), 
                			shipmentemployeeVO.get_lane_nbr(), 
                			shipmentemployeeVO.get_svc_type_cd());
                Iterator acctIterator = acctList.iterator();
                while (acctIterator.hasNext()){
                	ShipmentEmployeeVO shipEmployeeVO = new ShipmentEmployeeVO();
                	shipEmployeeVO = shipmentemployeeVO;
                	AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = 
                		(AcctLaneServiceMonitoringVO)acctIterator.next();
                	// Find employees first and last name.
                	EmployeeVO employeeVO = 
                		employeeAccessor.getEmployee(acctLaneServiceMonitoringVO.get_emp_nbr());
                	
                	shipEmployeeVO.set_emp_first_nm(employeeVO.get_emp_first_nm());
                	shipEmployeeVO.set_emp_last_nm(employeeVO.get_emp_last_nm());
                	shipEmployeeVO.set_emp_nbr(employeeVO.get_emp_nbr());
                	
                	al.add(shipEmployeeVO);
                } 
            }
            userTransaction.commit();
        	return al;
            // These exceptions really have to do with starting a transaction
        } catch (NotSupportedException e) {     // begin
        	logger.error("Not Supported Exception: ", e);
        } catch (SystemException e) {           // begin
        	logger.error("System Exception: ", e);
        // These exception have to do with commit exceptions
        } catch (RollbackException e) {         // commit
            // Logged to indicate that the transaction has been rolled back rather than committed
        	logger.error("Rollback Exception: ", e);
        } catch (HeuristicMixedException e) {   // commit
            // Logged to indicate that a heuristic decision was made and that some relevant updates have been committed
            // while others have been rolled back. 
        	logger.error("Heuristic Mixed Exception: ", e);
        } catch (HeuristicRollbackException e) { // commit
            // Logged to indicate that a heuristic decision was made and that all relevant updates have been rolled back.
        	logger.error("Heuristic Rollback Exception: ", e);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } catch (Exception e) {
        	logger.info("Catching unexpected exception in transaction.");
            try {
                logger.info("Rolling back.");
                userTransaction.rollback();
            } catch (IllegalStateException e1) {
                logger.error(e1);
            } catch (SecurityException e1) {
                logger.error(e1);
            } catch (SystemException e1) {
                logger.error(e1);
            }
        } finally {
            closeConnection(connection);
            
            int status = Status.STATUS_UNKNOWN;
            try {
                status = userTransaction.getStatus();
            } catch (SystemException e) {
                logger.debug("Exception getting transaction status.", e);
            }
            logger.debug("Transaction Status: " + logUserTransStatus(status));
        }      
        return null;
    }    
    
    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountTrackingNumber(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountTrackingNumber(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }       
    
    /**
     * 
     * @param aTrkngNbrMAWB
     * @return
     * @throws SQLException
     */
    public List searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByTrkngNbrMAWB(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber, sortColumn, isSortAscending, 
            		startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }      

    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountShipperName(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountShipperName(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }      
    
    /**
     * 
     * @param aAcctNmMAWB
     * @return
     * @throws SQLException
     */    
    public List searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByAcctNmMAWB(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName, sortColumn, isSortAscending, 
            		startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }      
 
    /**
     * 
     * @param aIssueCodeCRN, aAcctNbrCRN
     * @return
     * @throws SQLException
     */    
    public List searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN, String aAcctNbrCRN, Date _toDate4, Date _fromDate4) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByIssueCodeCRN(aTrackingNbrCRN, aIssueCodeCRN, aAcctNbrCRN, _toDate4, _fromDate4);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }     

    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountReturnTrackingNumber(String aReturnTrkngNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountReturnTrackingNumber(aReturnTrkngNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }     
    
    /**
     * 
     * @param aReturnTrkngNbr
     * @return
     * @throws SQLException
     */    
    public List searchByReturnTrkngNbr(String aReturnTrkngNbr, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByReturnTrackingNumber(aReturnTrkngNbr, sortColumn, isSortAscending, 
            	 startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }     

    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, _limitOneWeekFromDateByCRNRecipientName);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }     
    
    /**
     * 
     * @param aRecipientName, _toDate2, _fromDate2
     * @return
     * @throws SQLException
     */    
    public List searchByRecipientName(String aRecipientName, Date _limitOneWeekToDate2, Date _limitOneWeekFromDate2, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByRecipientName(aRecipientName, _limitOneWeekToDate2, _limitOneWeekFromDate2, sortColumn, isSortAscending, 
            		startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    
 
    /**
     * 
     * @param shipDate
     * @return
     * @throws SQLException
     */    
    public List searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2, String aSelectedLane2) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByShipDate(_shipDate, aServiceCode2, aAcctNbrMAWB2, aSelectedLane2);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    
    
  //WR#:179441 Changes
    /**
     * 
     * @param shipDateRange
     * @return
     * @throws SQLException
     */    
    public List searchByShipDateRange(Date _limitOneWeekToDate3, Date _limitOneWeekFromDate3, String aServiceCode, String aAcctNbrMAWB3, String aSelectedLane, String sortColumn,boolean ascending) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByShipDateRange(_limitOneWeekToDate3, _limitOneWeekFromDate3, aServiceCode, aAcctNbrMAWB3, aSelectedLane,sortColumn,ascending);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    

    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountRecipientPostalCode(String aPostalCode, Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountRecipientPostalCode(aPostalCode, _limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }      
    
    /**
     * 
     * @param postalCode
     * @return
     * @throws SQLException
     */    
    public List searchByPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByRecipientPostalCode(_limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode, aPostalCode, sortColumn, isSortAscending, 
            		startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }       

    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getMAWBShipmentsCount(Date _shipDate, String _selectMenu, 
    		String aClearancePoint) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getMAWBShipmentsCount(_shipDate, _selectMenu, aClearancePoint);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }    
    
    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public List rampHubSearch(Date _shipDate, String _selectMenu, 
    		String aClearancePoint, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.rampHubSearch(_shipDate, _selectMenu, aClearancePoint, 
            		sortColumn, isSortAscending, startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    
    
    /**
     * 
     * @param aAcctNbr
     * @return
     * @throws SQLException
     */    
    public List searchByFindMonitorAcctNbr(String aAcctNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByFindMonitorAcctNbr(aAcctNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    } 
    
    /**
     * 
     * @param aTrackingNbr
     * @return
     * @throws SQLException
     */    
    public List searchByFindMonitorTrkngNbr(String aTrackingNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByFindMonitorTrkngNbr(aTrackingNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    } 
    
    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountWithODA(String aPostalCode, Date _limitOneWeekToDateByCRNWithODA, Date _limitOneWeekFromDateByCRNWithODA) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountWithODA(aPostalCode, _limitOneWeekToDateByCRNWithODA, _limitOneWeekFromDateByCRNWithODA);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }    
    
    /**
     * 
     * @param aAcctNbr, aTrackingNbrMAWB
     * @return
     * @throws SQLException
     */    
    public List searchByWithODACRN(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA, Date _limitOneWeekToDateByCRNWithODA, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByWithODA(aAcctNbr, _limitOneWeekFromDateByCRNWithODA, _limitOneWeekToDateByCRNWithODA, sortColumn, isSortAscending, 
            		startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }    
    
    /**
     * 
     * @param aAcctNbr2, aTrackingNbrMAWB2
     * @return
     * @throws SQLException
     */    
    public List searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByWithoutPODCRN(aAcctNbr2, aTrackingNbrMAWB2);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }  
    
    /**
     * 
     * @param aAcctNbr
     * @return
     * @throws SQLException
     */    
    public List searchByFindMissingData(String aAcctNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByFindMissingData(aAcctNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }  
    
    /**
     * 
     * @param _selectMenu, clearancePoint
     * @return
     * @throws SQLException
     */    
    public int getCRNShipmentsCountRecipientAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.getCRNShipmentsCountRecipientAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return 0;
    }      
    
    /**
     * 
     * @param aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode
     * @return
     * @throws SQLException
     */    
    public List searchByAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentSearchAccessor accessor = new ShipmentSearchAccessor(connection);
            return accessor.searchByRecipientAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress, sortColumn, isSortAscending, 
            		startIndex, endIndex);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }     
    
    private String logUserTransStatus(int aStatus) {
        switch (aStatus) {
            // A transaction is associated with the target object and it is in the active state.
            case Status.STATUS_ACTIVE:
                return "Status Active";
            // A transaction is associated with the target object and it has been committed.  
            case Status.STATUS_COMMITTED: 
                return "Status Committed";
            // A transaction is associated with the target object and it is in the process of committing.  
            case Status.STATUS_COMMITTING: 
                return "Status Committing";
            // A transaction is associated with the target object and it has been marked for rollback, perhaps as a result of a setRollbackOnly operation. 
            case Status.STATUS_MARKED_ROLLBACK:
                return "Status Marked Rollback";
            // No transaction is currently associated with the target object.  
            case Status.STATUS_NO_TRANSACTION:
                return "Status No Transaction";
            // A transaction is associated with the target object and it has been prepared.  
            case Status.STATUS_PREPARED:
                return "Status Prepared";
            // A transaction is associated with the target object and it is in the process of preparing.  
            case Status.STATUS_PREPARING: 
                return "Status Preparing";
            // A transaction is associated with the target object and the outcome has been determined to be rollback.  
            case Status.STATUS_ROLLEDBACK: 
                return "Status Rolledback";
            // A transaction is associated with the target object and it is in the process of rolling back.  
            case Status.STATUS_ROLLING_BACK: 
                return "Status Rolling Back";
            //case Status.STATUS_UNKNOWN  
        }
        return "Status Unknown";

    }
}
