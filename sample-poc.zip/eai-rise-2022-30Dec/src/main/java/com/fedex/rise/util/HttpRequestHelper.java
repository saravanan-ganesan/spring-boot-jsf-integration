// Added as part of RISE WSSO Integration
//WR#TBD - WSSO Integration changes
package com.fedex.rise.util;

import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class HttpRequestHelper {

	public static final String WL_PATH_TRIM_HEADER = "WL-PATH-TRIM";
	private static Logger logger = LogManager.getLogger(HttpRequestHelper.class);
	private HttpServletRequest request;
	private Map<String, String> cookieValuesByName;

	private void initCookieValuesByName() {
		logger.debug("Method: initCookieValuesByName()");
		Cookie[] cookies = request.getCookies();
		if (cookies == null) {
			cookieValuesByName = Collections.emptyMap();
		} else {
			cookieValuesByName = new HashMap<String, String>(cookies.length);
			for (Cookie cookie : cookies) {
				cookieValuesByName.put(cookie.getName(), cookie.getValue());
			}
		}
	}

	private String getPathTrimValue() {
		String wlPathTrimHeaderValue = request.getHeader(WL_PATH_TRIM_HEADER);
		if (wlPathTrimHeaderValue == null) {
			return null;
		}
		wlPathTrimHeaderValue = wlPathTrimHeaderValue.trim();
		if (wlPathTrimHeaderValue.isEmpty()) {
			return null;
		}
		logger.debug("GetPathTrimValue: " + wlPathTrimHeaderValue);
		return wlPathTrimHeaderValue;
	}

	public HttpRequestHelper(HttpServletRequest request) {
		logger.debug("Initializing HttpRequestHelper");
		this.request = request;
		initCookieValuesByName();
	}

	public HttpRequestHelper(ServletRequest req) {
		this((HttpServletRequest) req);
	}

	public String getHeaderOrNull(String name) {
		return request.getHeader(name);
	}

	@SuppressWarnings("unchecked")
	public Collection<String> getCookieNames() {
		return cookieValuesByName == null ? Collections.EMPTY_LIST : cookieValuesByName.keySet();
	}

	public String getCookieValueOrNull(String name) {
		return getCookieValue(name, null);
	}

	public String getValueFromHeaderOrCookieOrNull(String name) {
		String value = getHeaderOrNull(name);
		return value == null ? getCookieValueOrNull(name) : value;
	}

	public HttpSession getSession(boolean createNew) {
		return request.getSession(createNew);
	}

	public String getRequestURI() {
		return request.getRequestURI();
	}

	public String[] getParametersOrNull(String name, String[] defaultValue) {
		return getParameters(name, null);
	}

	public String[] getParameters(String name, String[] defaultValue) {
		String[] values = request.getParameterValues(name);
		return values == null ? defaultValue : values;
	}

	public String getParameterOrNull(String name) {
		return getParameter(name, null);
	}

	public String getParameter(String name, String defaultValue) {
		String paramValue = request.getParameter(name);
		return paramValue == null ? defaultValue : paramValue;
	}

	@SuppressWarnings("unchecked")
	public Map<String, String> getHeaderValuesMap() {
		Map<String, String> headerValuesMap = new HashMap<String, String>();
		for (Enumeration<String> headerNames = request.getHeaderNames(); headerNames
				.hasMoreElements();) {
			String headerName = headerNames.nextElement();
			headerValuesMap.put(headerName, request.getHeader(headerName));
		}
		return headerValuesMap;
	}

	public Map<String, String> getCookieValuesMap() {
		return cookieValuesByName;
	}

	public String getContextPath() {
		if(request.getContextPath()!=null && logger.isDebugEnabled())
		logger.debug(request.getContextPath());
		return request.getContextPath();
	}

	public String getPathAdjustedForPathTrim(String path) {
		logger.debug("GetPathAdjustedForPathTrim: " + path);
		String pathTrimValue = getPathTrimValue();
		if (pathTrimValue == null || !path.startsWith("/")
				|| path.startsWith(pathTrimValue)) {
			return path;
		}
		logger.debug("Appending Trim Value to Path: "
				+ new StringBuilder(pathTrimValue).append(path).toString());
		return new StringBuilder(pathTrimValue).append(path).toString();
	}

	public String getCookieValue(String name, String defaultValue) {
		String cookieValue = cookieValuesByName.get(name);
		return cookieValue == null ? defaultValue : cookieValue;
	}

	public String getPathInfo() {
		String pathInfo = request.getPathInfo();
		return pathInfo == null || pathInfo.trim().isEmpty() ? null : pathInfo .trim().substring(1);
	}

	public String getScheme() {
		return request.getScheme();
	}

	public String getServerName() {
		return request.getServerName();
	}

	public int getServerPort() {
		return request.getServerPort();
	}
}

