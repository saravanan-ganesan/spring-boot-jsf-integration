package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * Issue Value Object (or Transfer Object) used to encapsulate the issue
 * data for transport.
 */
public class IssueVO implements Serializable{
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;
    private String _trkng_item_uniq_nbr;
    private int    _issue_type_cd;
    private String _issue_loc_cd;
    private Date   _issue_tmstp;
    private int    _grp_nbr;
    private String _acct_nbr;
    private int    _lane_nbr;
    private String _svc_type_cd;
    /** resolved date */
    private Date   _res_dt;   
    private Date   _event_crtn_tmstp;
    /**  resolved description, contains scan type cd that automatically resolved it. */
    private String _res_desc; 
    /**  emp_nbr, contains employee number who manually resolved it. */
    private String _res_emp_nbr;   
    private String _trackTypeCd;
    
    /**
     * Default Constructor
     */
    public IssueVO() {
    }
    
    /**
     * Construct an Issue for a shipment
     * @param trkng_item_nbr
     * @param trkng_item_uniq_nbr
     * @param issue_type_cd
     * @param issue_tmstp
     * @param grp_nbr
     * @param acct_nbr
     * @param lane_nbr
     * @param svc_type_cd
     * @param res_dt
     */
    public IssueVO(String trkng_item_nbr, String trkng_item_uniq_nbr, int issue_type_cd, 
            Date issue_tmstp, int grp_nbr, String acct_nbr, int lane_nbr, 
            String svc_type_cd, Date res_dt, Date event_crtn_tmstp) {
        super();
        this._trkng_item_nbr = trkng_item_nbr;
        this._trkng_item_uniq_nbr = trkng_item_uniq_nbr;
        this._issue_type_cd = issue_type_cd;
        this._issue_tmstp = issue_tmstp;
        this._grp_nbr = grp_nbr;
        this._acct_nbr = acct_nbr;
        this._lane_nbr = lane_nbr;
        this._svc_type_cd = svc_type_cd;
        this._res_dt = res_dt;
        this._event_crtn_tmstp = event_crtn_tmstp;
    }
    
    /**
     * @return the _trackTypeCd
     */
    public String get_trackTypeCd() {
        return _trackTypeCd;
    }

    /**
     * @param typeCd the _trackTypeCd to set
     */
    public void set_trackTypeCd(String typeCd) {
        _trackTypeCd = typeCd;
    }

    /**
     * @return the acct_nbr
     */
    public String getAcct_nbr() {
        return _acct_nbr;
    }
    /**
     * @param acct_nbr the acct_nbr to set
     */
    public void setAcct_nbr(String acct_nbr) {
        this._acct_nbr = acct_nbr;
    }
    /**
     * @return the grp_nbr
     */
    public int getGrp_nbr() {
        return _grp_nbr;
    }
    /**
     * @param grp_nbr the grp_nbr to set
     */
    public void setGrp_nbr(int grp_nbr) {
        this._grp_nbr = grp_nbr;
    }
    /**
     * @return the issue_tmstp
     */
    public Date getIssue_tmstp() {
        return _issue_tmstp;
    }
    /**
     * @param issue_tmstp the issue_tmstp to set
     */
    public void setIssue_tmstp(Date issue_tmstp) {
        this._issue_tmstp = issue_tmstp;
    }
    /**
     * @return the issue_type_cd
     */
    public int getIssue_type_cd() {
        return _issue_type_cd;
    }
    /**
     * @param issue_type_cd the issue_type_cd to set
     */
    public void setIssue_type_cd(int issue_type_cd) {
        this._issue_type_cd = issue_type_cd;
    }
    /**
     * @return the lane_nbr
     */
    public int getLane_nbr() {
        return _lane_nbr;
    }
    /**
     * @param lane_nbr the lane_nbr to set
     */
    public void setLane_nbr(int lane_nbr) {
        this._lane_nbr = lane_nbr;
    }
    /**
     * @return the res_dt
     */
    public Date getRes_dt() {
        return _res_dt;
    }
    /**
     * @param res_dt the res_dt to set
     */
    public void setRes_dt(Date res_dt) {
        this._res_dt = res_dt;
    }
    /**
     * @return the svc_type_cd
     */
    public String getSvc_type_cd() {
        return _svc_type_cd;
    }
    /**
     * @param svc_type_cd the svc_type_cd to set
     */
    public void setSvc_type_cd(String svc_type_cd) {
        this._svc_type_cd = svc_type_cd;
    }
    /**
     * @return the trkng_item_nbr
     */
    public String getTrkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param trkng_item_nbr the trkng_item_nbr to set
     */
    public void setTrkng_item_nbr(String trkng_item_nbr) {
        this._trkng_item_nbr = trkng_item_nbr;
    }
    /**
     * @return the trkng_item_uniq_nbr
     */
    public String getTrkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param trkng_item_uniq_nbr the trkng_item_uniq_nbr to set
     */
    public void setTrkng_item_uniq_nbr(String trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = trkng_item_uniq_nbr;
    }

    /**
     * @return the _res_desc
     */
    public String get_res_desc() {
        return _res_desc;
    }

    /**
     * @param _res_desc the _res_desc to set
     */
    public void set_res_desc(String _res_desc) {
        this._res_desc = _res_desc;
    }
    
    /**
     * @return the _track_loc_cd
     */
    public String getIssue_loc_cd() {
        return _issue_loc_cd;
    }

    /**
     * @param _track_loc_cd the _track_loc_cd to set
     */
    public void setIssue_loc_cd(String _issue_loc_cd) {
        this._issue_loc_cd = _issue_loc_cd;
    }

    /**
     * @return the _issue_tmstp
     */
    public Date get_issue_tmstp() {
        return _issue_tmstp;
    }

    /**
     * @param _issue_tmstp the _issue_tmstp to set
     */
    public void set_issue_tmstp(Date _issue_tmstp) {
        this._issue_tmstp = _issue_tmstp;
    }

    /**
     * @return the event_crtn_tmstp
     */
    public Date getEvent_crtn_tmstp() {
        return _event_crtn_tmstp;
    }

    /**
     * @param event_crtn_tmstp the event_crtn_tmstp to set
     */
    public void setEvent_crtn_tmstp(Date event_crtn_tmstp) {
        this._event_crtn_tmstp = event_crtn_tmstp;
    }

    /**
     * @return the _res_emp_nbr
     */
    public String get_res_emp_nbr() {
        return _res_emp_nbr;
    }

    /**
     * @param _res_emp_nbr the _res_emp_nbr to set
     */
    public void set_res_emp_nbr(String _res_emp_nbr) {
        this._res_emp_nbr = _res_emp_nbr;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("trkngItemNbr:");
        sb.append(_trkng_item_nbr);
        sb.append(" trkngItemUniqNbr:");
        sb.append(_trkng_item_uniq_nbr);
        sb.append(" trackTypeCd:");
        sb.append(_trackTypeCd);
        sb.append(" issueCd:");
        sb.append(_issue_type_cd);
        sb.append(" issueTmstp:");
        sb.append(_issue_tmstp);
        sb.append(" groupNbr:");
        sb.append(_grp_nbr);
        sb.append(" acctNbr:");
        sb.append(_acct_nbr);
        sb.append(" laneNbr:");
        sb.append(_lane_nbr);
        sb.append(" svcTypeCd:");
        sb.append(_svc_type_cd);
        sb.append(" resDt:");
        sb.append(_res_dt);
        sb.append(" resDesc:");
        sb.append(_res_desc);
        sb.append(" res_emp_Nbr:");
        sb.append(_res_emp_nbr);
        sb.append(" event_crtn_tmstp:");
        sb.append(_event_crtn_tmstp);
        return sb.toString();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + _issue_type_cd;
        result = PRIME * result + ((_trkng_item_nbr == null) ? 0 : _trkng_item_nbr.hashCode());
        result = PRIME * result + ((_trkng_item_uniq_nbr == null) ? 0 : _trkng_item_uniq_nbr.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final IssueVO other = (IssueVO) obj;
        if (_issue_type_cd != other._issue_type_cd)
            return false;
        if (_trkng_item_nbr == null) {
            if (other._trkng_item_nbr != null)
                return false;
        } else if (!_trkng_item_nbr.equals(other._trkng_item_nbr))
            return false;
        if (_trkng_item_uniq_nbr == null) {
            if (other._trkng_item_uniq_nbr != null)
                return false;
        } else if (!_trkng_item_uniq_nbr.equals(other._trkng_item_uniq_nbr))
            return false;
        return true;
    }

}
