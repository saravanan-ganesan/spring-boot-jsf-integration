package com.fedex.rise.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fedex.rise.vo.AccountGroupVO;
import com.fedex.rise.vo.PerformanceVO;

@Service
@SuppressWarnings("rawtypes")
public interface ShipperService {
	
	public List<AccountGroupVO> getAccountGroupNames();
	
	public String getAccountGroupNamesByGrpNbr(String groupNbr);
	
	public List getAccountLanes(int aGroupNbr);
	
	public List getLane(int LaneNbr);
	
	public List getLaneByGroupNbr(int groupNbr);
	
	public String getLaneByLaneNbr(int laneNbr);
	
	public List<PerformanceVO> getPerformanceSum(String groupNbr, Date fromDate, 
    		Date toDate, String laneNbr, String empNbr);
	
	

}
