package com.fedex.rise.bean;

import com.fedex.rise.annotation.JsfController;

@JsfController(path = "/", page = "/pages/jsp/home.jsp", value = "homeBean")
public class HomeBean extends BaseBean {

	
	
//	private boolean loginRedirect;
//	
//	public boolean isLoginRedirect() {
//
//		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		
//		if(!ObjectUtils.isEmpty(authentication) && !(authentication instanceof AnonymousAuthenticationToken)) {
//			setLoginRedirect(true);
//			return true;			
//		} else {
//			return false;
//		}
//	}
//
//	public void setLoginRedirect(boolean loginRedirect) {
//		this.loginRedirect = loginRedirect;
//	}
//
//	public void loginRedirect(Principal principal)  {
//		
//		if(!ObjectUtils.isEmpty(principal)) {
//			
//			DefaultOidcUser defaultOidcUser = (DefaultOidcUser) principal;
//			if(!ObjectUtils.isEmpty(defaultOidcUser)) {
//				
//				Map<String , Object> userDetails = defaultOidcUser.getAttributes();
//				if(!ObjectUtils.isEmpty(userDetails)) {
//					userDetails.forEach((key, value) -> {
//						System.out.println(key + ":::" + value);
//					});
//				}
//			}
//			redirect("home");
//			
//		} else {
//			redirect("error");
//		}
//	    redirect(null);
//	}
}
