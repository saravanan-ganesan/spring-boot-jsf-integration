package com.fedex.rise.bo;

/**
 * Shipment Business Delegate which is resposible for getting data from or 
 * setting data in the persistent storage, e.g. the backend database. 
 * 
 */
public class ShipmentDelegate {
//    private static final Log log = LogFactory.getLog(ShipmentDelegate.class);
//
//    /**
//     * Get All Shipments for this shipper, account, lane, and service
//     * including those with issues
//     * @param shipper
//     * @param account
//     * @param lane
//     * @param service
//     * @return List of shipments with issues
//     */
//    public List getShipments(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd,
//            int startIndex, int endIndex, String sortColumn, boolean isSortAscending) {
//        List shipments = getShipments(shipperNbr, accountNbr, laneNbr, serviceTypeCd, false, 
//            startIndex, endIndex, sortColumn, isSortAscending, 0);
//        return shipments;
//    }
//    
//    /**
//     * Get Shipments with Issues for this shipper, account, lane, and service
//     * including those with issues
//     * @param shipperNbr
//     * @param accountNbr
//     * @param laneNbr
//     * @param serviceTypeCd
//     * @param startIndex
//     * @param endIndex
//     * @param sortColumn
//     * @param isSortAscending
//     * @param shipDateOffsetInt
//     * 
//     * @return List of shipments with issues
//     */
//    public List getShipmentsWithIssues(int shipperNbr, String accountNbr, 
//    		int laneNbr, String serviceTypeCd, int startIndex, int endIndex, 
//    		String sortColumn, boolean isSortAscending, int shipDateOffsetInt) {
//        List shipments = getShipments(shipperNbr, accountNbr, laneNbr, 
//        		serviceTypeCd, true, startIndex, endIndex, sortColumn, 
//        		isSortAscending, shipDateOffsetInt);
//        return shipments;
//    }
//    
//    /**
//     * Get Shipments for this shipper, account, lane, and service
//     * @param shipperNbr
//     * @param accountNbr
//     * @param laneNbr
//     * @param serviceTypeCd
//     * @param issuesOnly true if only want shipments with issues
//     * @param startIndex
//     * @param endIndex
//     * @param sortColumn
//     * @param isSortAscending
//     * @param shipDateOffsetInt
//     * 
//     * @return List of shipments 
//     */
//    public List getShipments(int shipperNbr, String accountNbr, int laneNbr, 
//    		String serviceTypeCd, boolean issuesOnly, int startIndex, 
//    		int endIndex, String sortColumn, boolean isSortAscending, 
//    		int shipDateOffsetInt) {
//        List shipments = new ArrayList();
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        try {
//            ShipmentRemote mb = mh.create();
//
//            List mawbShipments = mb.getMAWBShipments(shipperNbr, accountNbr, laneNbr, serviceTypeCd, issuesOnly,
//                    startIndex, endIndex, sortColumn, isSortAscending, shipDateOffsetInt);
//            Iterator iter = mawbShipments.iterator();
//            while(iter.hasNext()) {
//                ShipmentVO shipmentVO = (ShipmentVO)iter.next();
//               
//                // Issues needed to show the Issues text shown on the MAWB list
//                List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//                // encapsulate IssueVOs into UI Bean so we can get/set resolved and use its actions on UI
//                List issueBeans = xlateIssues(issues);
//                
//                // At MAWB list level, we don't need comments, ref notes, related, or events but we do need the issues
//                MawbBean mawb = new MawbBean(shipmentVO, null, null, null, null, issueBeans);
//               
//                
//                //WR#161572:RISE Performance Issue removed the code for below logic
//                	// Get the Total CRNs (all or just with issues) that we have knowledge of
//
//                shipments.add(mawb);
//            }
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//       
//        return shipments;
//    }
//    
//    
//    public List getFilterByIssues() {
//		ServiceLocator sl = null;
//		ShipmentHome mbh = null;
//		try {
//			sl = ServiceLocator.getInstance();
//			mbh = (ShipmentHome) sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//		} catch (ServiceLocatorException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		ShipmentRemote mb = null;
//		try {
//			mb = mbh.create();
//			List issueTypeCds = mb.getFilterByIssues();
//			return issueTypeCds;
//		} catch (RemoteException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (CreateException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		return null;
//	}
//    
//	public List getShipmentFilteredIssues(String[] filterByIssues, int shipDateOffsetInt) {
//		List shipments = getfilterByIssueDetails(filterByIssues, shipDateOffsetInt);
//		return shipments;
//	}
//	
//	
//	public List getfilterByIssueDetails(String[] filterByIssues, int shipDateOffsetInt) {
//		List shipments = new ArrayList();
//		ServiceLocator sl = null;
//		ShipmentHome mbh = null;
//		try {
//			sl = ServiceLocator.getInstance();
//			mbh = (ShipmentHome) sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//		} catch (ServiceLocatorException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		try {
//			ShipmentRemote mb = mbh.create();
//
//			List IssueDetails = mb.getfilterByIssueDetails(filterByIssues, shipDateOffsetInt);
//			if (log.isDebugEnabled()) {
//				log.debug("Returning IssueDetails");
//			}
//		
//
//			Iterator iter = IssueDetails.iterator();
//			while (iter.hasNext()) {
//				FilterByIssueVO FilterByIssueVO = (FilterByIssueVO) iter.next();
//
//				// Issues needed to show the Issues text shown on the shipment
//				// list
//				// List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(),
//							
//				List issues = mb.getIssues(FilterByIssueVO.get_trkng_item_nbr(),
//						FilterByIssueVO.get_trkng_item_uniq_nbr());
//
//			
//				// encapsulate IssueVOs into UI Bean so we can get/set resolved
//				// and use its actions on UI
//				List issueBeans = xlateIssues(issues);
//				
//				FilterDataBean shipment = new FilterDataBean(FilterByIssueVO.get_assoc_trkng_item_nbr(),
//						FilterByIssueVO.get_trkng_item_nbr(), FilterByIssueVO.get_ship_dt(),FilterByIssueVO.get_group_nm(), FilterByIssueVO.get_acct_nm(),FilterByIssueVO.get_acct_nbr(),FilterByIssueVO.get_shpr_cntry_cd(),FilterByIssueVO.get_recp_cntry_cd(),FilterByIssueVO.get_SVC_TYPE_CD(), FilterByIssueVO.get_commit_dt(),
//						FilterByIssueVO.get_dest_loc_cd(), FilterByIssueVO,
//						issueBeans, FilterByIssueVO.get_emp_nbr(), FilterByIssueVO.get_emp_first_nm(), FilterByIssueVO.get_emp_last_nm());			
//				shipments.add(shipment);
//			
//			}
//		} catch (RemoteException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (CreateException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	
//		return shipments;
//	}
//    
//    
//    
//    /**
//     * Get the number of Shipments for this shipper, account, lane, and service
//     * @param shipperNbr
//     * @param accountNbr
//     * @param laneNbr
//     * @param serviceTypeCd
//     * @param issuesOnly true if only want shipments with issues
//     * @param shipDateOffsetInt
//     * 
//     * @return count of shipments
//     */
//    public int getShipmentsCount(int shipperNbr, String accountNbr, int laneNbr, 
//    		String serviceTypeCd, boolean issuesOnly, int shipDateOffsetInt) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        int count = 0;
//        try {
//            ShipmentRemote mb = mh.create();
//
//            count = mb.getMAWBShipmentsCount(shipperNbr, accountNbr, laneNbr, 
//            		serviceTypeCd, issuesOnly, shipDateOffsetInt);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//       
//        return count;
//    }
//    
//    /**
//     * Get the number of Shipments for this account, date range, lane, month, 
//     * and performance type.
//     * @param acctNbr account number
//     * @param fromDate from date range
//     * @param toDate to date range
//     * @param laneNbrStr lane number
//     * @param monthNbr month number of interest.
//     * @param performanceType The type of performance interested in.
//     * @return count of shipments
//     */
//    public int getShipmentsCount(String acctNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, int monthNbr, String performanceType) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        int count = 0;
//        try {
//            ShipmentRemote mb = mh.create();
//
//            // TODO: handle count
//            count = mb.getCRNShipmentsCount(acctNbr, fromDate, toDate, 
//            		laneNbrStr, monthNbr, performanceType );
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//       
//        return count;
//    }
//    
//    /**
//     * Get a MAWB
//     * @param trackingNbr MAWB tracking number
//     * @param uniqueNbr MAWB tracking number unique id
//     * @return CrnBean
//     */
//    public List getEvents(String trackingNbr, String uniqueNbr) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        List eventBeans = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, 
//                    ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            List events = mb.getEvents(trackingNbr, uniqueNbr);
//            // encapsulate EventVOs into UI Bean so we can format attributes for display on UI
//            eventBeans = xlateEvents(events);            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        return eventBeans;
//    }
//            
//    /**
//     * Get a MAWB
//     * @param trackingNbr MAWB tracking number
//     * @param uniqueNbr MAWB tracking number unique id
//     * @return CrnBean
//     */
//    public MawbBean getMAWB(String trackingNbr, String uniqueNbr) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        MawbBean mawb = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, 
//                    ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            
//            ShipmentVO shipmentVO = mb.getShipment(trackingNbr, uniqueNbr);
//               
//            List comments = mb.getComments(shipmentVO.get_trkng_item_nbr(),
//                                           shipmentVO.get_trkng_item_uniq_nbr());
//            
//            List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//            // encapsulate IssueVOs into UI Bean so we can get/set resolved and use its actions on UI
//            List issueBeans = xlateIssues(issues);
//            
//            List referenceNotes = mb.getReferenceNotes(shipmentVO.get_trkng_item_nbr(),
//                                           shipmentVO.get_trkng_item_uniq_nbr());
//             
//            List relatedAWBs = mb.getRelatedAirbills(shipmentVO.get_trkng_item_nbr(),
//                    shipmentVO.get_trkng_item_uniq_nbr());
//            List assocShipmentBeans = xlateAssociatedShipments(relatedAWBs);
//              
//            // Create UI MAWB Bean, which encapsulates all shipment items
//            mawb = new MawbBean(shipmentVO, referenceNotes, assocShipmentBeans, comments, null, 
//                    issueBeans);
//           
//          //WR#161572:RISE Performance Issue removed the code for below logic but reverted back on client request
//            // initialize the CRN Status Counts, since this is mawb detail
//            List counts = this.getCRNStateCounts(shipmentVO.get_trkng_item_nbr(),
//                    shipmentVO.get_trkng_item_uniq_nbr());
//            mawb.setCRNStateCounts(counts);
//            
//            
//            
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        return mawb;
//    }
//    /**
//     * Get a CRN 
//     * @param trackingNbr CRN tracking number
//     * @param uniqueNbr CRN tracking number unique id
//     * @return CrnBean
//     */
//    public CrnBean getCrn(String trackingNbr, String uniqueNbr) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        CrnBean crn = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            ShipmentVO shipmentVO = mb.getShipment(trackingNbr, uniqueNbr);
//            
//            List comments = mb.getComments(shipmentVO.get_trkng_item_nbr(),
//                                           shipmentVO.get_trkng_item_uniq_nbr());
//                    
//            List events = getEvents(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//            
//            List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//            // encapsulate IssueVOs into UI Bean so we can get/set resolved and use its actions on UI
//            List issueBeans = xlateIssues(issues);
//            
//            List referenceNotes = mb.getReferenceNotes(shipmentVO.get_trkng_item_nbr(),
//                                           shipmentVO.get_trkng_item_uniq_nbr());
//
//            List relatedAWBs = mb.getRelatedAirbills(shipmentVO.get_trkng_item_nbr(),
//                    shipmentVO.get_trkng_item_uniq_nbr());
//            List returnAWBs = filterReturnAWBs(relatedAWBs);
//               
//            crn = new CrnBean(shipmentVO, referenceNotes, returnAWBs, comments, events, issueBeans);
//                
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        return crn;
//    }
//    
//    /**
//     * Get CRNs 
//     * @param acctNbr account number
//     * @param fromDate from date range
//     * @param toDate to date range
//     * @param laneNbrStr lane number
//     * @param monthNbr month number of interest.
//     * @param performanceType The type of performance interested in.
//     * @param issuesOnly true to get only CRNs with issues.
//     * @return List of CrnBeans
//     */
//    public List getCRNShipments(String acctNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, int monthNbr, String performanceType, 
//    		int startIndex, int endIndex, String sortColumn, 
//    		boolean isSortAscending) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        List crns = new ArrayList();
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            List crnShipments = mb.getCRNShipments(acctNbr, fromDate, toDate, 
//            		laneNbrStr, monthNbr, performanceType, startIndex, 
//            		endIndex, sortColumn, isSortAscending);
//
//            Iterator iter = crnShipments.iterator();
//            while (iter.hasNext()) {
//               ShipmentVO shipmentVO = (ShipmentVO)iter.next();
//               
//               CrnBean crn = null;
//               
//               // Issues needed to show the Issues text shown on the MAWB list
//               List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//               // encapsulate IssueVOs into UI Bean so we can get/set resolved and use its actions on UI
//               List issueBeans = xlateIssues(issues);
//               
//               // don't need comments, ref notes, or related airbills, but we do need event status and the issues
//               crn = new CrnBean(shipmentVO, null, null, null, null, issueBeans);
//               
//               crns.add(crn);
//            }
//                
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return crns;
//    }
//    
//    /**
//     * Get the list of CRNs for a MAWB 
//     * Allows "paging" the results by selecting the first and last index to retrieve.
//     * 
//     * @param aParntTrkngItemNbr MAWB tracking number
//     * @param aParntTrkngUniqItemNbr MAWB tracking unique number
//     * @param issuesOnly true to get only CRNs with issue
//     * @param aStartIndex start rownum, for paging results
//     * @param anEndIndex end rownum, for paging results
//     * @param sortColumn column to sort on
//     * @param isSortAscending true to filter by Ascending, false for descending
//     * @param filterByIssues the Issue Type Cd(s) to filter on 
//     * @param shipDt of the MAWB 
//     * @return List of CrnBeans
//     * @throws SQLException
//     */
//    public List getCrns(String trackingNbr, String uniqueNbr, boolean issuesOnly,
//            int startIndex, int endIndex, String sortColumn, boolean isSortAscending, 
//            String[] filterByIssues, Date shipDt) {
//        
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        List eventBeans = null;
//        List crns = new ArrayList();
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            List crnShipments = mb.getCRNShipments(trackingNbr, uniqueNbr, issuesOnly,
//                startIndex, endIndex, sortColumn, isSortAscending, filterByIssues, shipDt);
//            
//            Iterator iter = crnShipments.iterator();
//            while (iter.hasNext()) {
//               ShipmentVO shipmentVO = (ShipmentVO)iter.next();
//               
//               CrnBean crn = null;
//               // Issues needed to show the Issues text shown on the CRN list
//               List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//               // encapsulate IssueVOs into UI Bean so we can get/set resolved and use its actions on UI
//               List issueBeans = xlateIssues(issues);
//               // Events needed to show the DEX column
//               List events = mb.getEvents(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//               // encapsulate EventVOs into UI Bean so we can format attributes for display on UI
//               eventBeans = xlateEvents(events);
//               
//               // At CRN list level, we don't need comments, ref notes, related, or events but we do need the issues
//               crn = new CrnBean(shipmentVO, null, null, null, eventBeans, issueBeans);
//                  
//               crns.add(crn);
//            }
//                
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return crns;
//    }
//   
//    //WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
//    public List getAllCrns(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd,
//            int startIndex, int endIndex, String sortColumn, boolean isSortAscending, int shipDateOffsetInt,
//            String[] filterByIssues) {
//        
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        List eventBeans = null;
//        List crns = new ArrayList();
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            List crnShipments = mb.getAllCrns(shipperNbr, accountNbr, laneNbr, serviceTypeCd,
//            		startIndex, endIndex, sortColumn, isSortAscending,shipDateOffsetInt, filterByIssues);
//            
//            Iterator iter = crnShipments.iterator();
//            while (iter.hasNext()) {
//               ShipmentVO shipmentVO = (ShipmentVO)iter.next();
//               
//               CrnBean crn = null;
//               // Issues needed to show the Issues text shown on the CRN list
//               List issues = mb.getIssues(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//               // encapsulate IssueVOs into UI Bean so we can get/set resolved and use its actions on UI
//               List issueBeans = xlateIssues(issues);
//               // Events needed to show the DEX column
//               List events = mb.getEvents(shipmentVO.get_trkng_item_nbr(), shipmentVO.get_trkng_item_uniq_nbr());
//               // encapsulate EventVOs into UI Bean so we can format attributes for display on UI
//               eventBeans = xlateEvents(events);
//               
//               // At CRN list level, we don't need comments, ref notes, related, or events but we do need the issues
//               crn = new CrnBean(shipmentVO, null, null, null, eventBeans, issueBeans);
//                  
//               crns.add(crn);
//            }
//                
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return crns;
//    }
//    /**
//     * Get the list of CRN Issues for a MAWB 
//     * 
//     * @param aParntTrkngItemNbr MAWB tracking number
//     * @param aParntTrkngUniqItemNbr MAWB tracking unique number
//     * @return List of Issue Type Cds
//     * @throws SQLException
//     */
//    public List getCRNIssues(String aParntTrkngItemNbr, String aParntTrkngItemUniqueNbr) {    
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        try {
//            ShipmentRemote mb = mh.create();
//
//            List issues = mb.getCRNIssues(aParntTrkngItemNbr, aParntTrkngItemUniqueNbr);
//            return issues;
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//       
//        return new ArrayList();
//        
//    }
//     
//    /**
//     * Get the number of CRN Shipments for this MAWB
//     * 
//     * @param trackingNbr MAWB tracking number
//     * @param uniqueNbr MAWB tracking number unique id
//     * @param detail true for get issues, events, etc.
//     * @param issuesOnly true if only want shipments with issues
//     * @param filterByIssues the Issue Type Cd(s) to filter on 
//     * @return count of CRN shipments
//     */
//    public int getCrnCount(String trackingNbr, String uniqueNbr, boolean issuesOnly, String[] filterByIssues) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        int count = 0;
//        try {
//            ShipmentRemote mb = mh.create();
//
//            // TODO: handle count
//            count = mb.getCrnCount(trackingNbr, uniqueNbr, issuesOnly, filterByIssues);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//       
//        return count;
//    }
//    
//    //WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
//    public int getAllCrnsCount(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd, int shipDateOffsetInt)
//    {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        
//        int count = 0;
//        try {
//            ShipmentRemote mb = mh.create();
//
//            // TODO: handle count
//            count = mb.getAllCrnsCount(shipperNbr, accountNbr, laneNbr, serviceTypeCd,shipDateOffsetInt);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//       
//        return count;
//    }
//    
//    
//    /**
//     * Save the invoice amount and dimensional weight changes to the MAWB
//     * @param aVO
//     */
//    public boolean saveMawbAttributes(MAWBAttributesVO aVO) {
//       
//        boolean success = false;
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        ShipmentRemote mb = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//            mb = mh.create();
//            mb.saveMawbAttributes(aVO);
//            success = true;
//        } catch (ServiceLocatorException e) {
//            log.error("Can't save InvAmt and DimWgt", e);
//        } catch (SQLException e) {
//            log.error("Can't save InvAmt and DimWgt", e);
//        } catch (RemoteException e) {
//            log.error("Can't save InvAmt and DimWgt", e);
//        } catch (CreateException e) {
//            log.error("Can't save InvAmt and DimWgt", e);
//        }
//        
//        return success;
//    }
//    
//    public List getCRNStateCounts(String aTrkngItemNbr, String aTrkngItemUniqNbr) {   
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            return mb.getCrnStateCounts(aTrkngItemNbr, aTrkngItemUniqNbr);
//        } catch (SQLException sqle) {
//            sqle.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }        
//        return null;
//    }
//    
//    
//    /**
//     * Used to adjust the commit date for CRNS
//     * @param aCRNDeliveryDtAdjustment
//     * @return true for success
//     */
//    public boolean adjustCRNCommitDates(int aCRNDeliveryDtAdjustment, String aTrkngItemNbr,
//                                     String aTrkngItemUniqNbr) {
//        boolean success = false; 
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        ShipmentRemote mb = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//            mb = mh.create();
//            mb.adjustCRNCommitDates(aCRNDeliveryDtAdjustment, aTrkngItemNbr, aTrkngItemUniqNbr);
//            success = true;
//        } catch (ServiceLocatorException e) {
//            log.error("Can't save Adjusted Commit Date", e);
//        } catch (SQLException e) {
//            log.error("Can't save Adjusted Commit Date", e);
//        } catch (RemoteException e) {
//            log.error("Can't save Adjusted Commit Date", e);
//        } catch (CreateException e) {
//            log.error("Can't save Adjusted Commit Date", e);
//        }
//        
//        return success;
//    }
//    
//    /**
//     * Save Issue changes (resolved) to database
//     * @param issue IssueVO
//     */
//    public void saveChanges(IssueVO issue) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        List crns = new ArrayList();
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            mb.updateIssue(issue);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }
//    }
//    
//    public void saveComment(ShipmentCommentVO aShipmentCommentVO) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            mb.saveComment(aShipmentCommentVO);
//        } catch (SQLException sqle) {
//            sqle.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//    }
//    
//    public void createMonitorIssue(IssueVO anIssue) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            mb.createMonitorIssue(anIssue);
//        } catch (SQLException sqle) {
//            sqle.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }
//    }
//    
//    public void saveWorkedStatus(String statusCd, String trkngItemNbr, String trkngItemUniqNbr) {
//        ServiceLocator sl = null;
//        ShipmentHome mh = null;
//        try {
//            sl = ServiceLocator.getInstance();
//            mh = (ShipmentHome)sl.getRemoteHome(ServiceLocatorConstants.ShipmentRemoteJNDIName, ShipmentHome.class);
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        ShipmentRemote mb = null;
//        try {
//            mb = mh.create();
//            mb.saveWorkedStatus(statusCd, trkngItemNbr, trkngItemUniqNbr);
//        } catch (SQLException sqle) {
//            sqle.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }
//    }
//    
//    /**
//     * This method is used to convert a list of EventVOs to list of EventBeans.  
//     * The EventBean has the proper logic for displaying events to meet
//     * the user requirements.
//     * @param events
//     * @return
//     */
//    private List xlateEvents(List events) {
//        Iterator iter2 = events.iterator();
//        ArrayList eventBeans = new ArrayList();
//        while (iter2.hasNext()) {
//            eventBeans.add(new EventBean((EventVO)iter2.next()));
//        }
//        return eventBeans;
//    }
//  
//    /**
//     * This method is used to convert a list of IssueVOs to list of IssueBeans.  
//     * The IssuesBean has the proper logic for displaying issues.
//     * @param issues
//     * @return
//     */
//    private List xlateIssues(List issues) {
//        // encasulate Issues into Bean so we can get/set resolved and use its actions on UI
//        List issueBeans = new ArrayList(issues.size());
//        for (Iterator itr=issues.iterator(); itr.hasNext(); ) {
//            issueBeans.add(new IssueBean((IssueVO)itr.next()));
//        }
//        return issueBeans;
//    }
//    
//    private List xlateAssociatedShipments(List aListOfAssocShipments) {
//        // encasulate Issues into Bean so we can get/set resolved and use its actions on UI
//        List assocShipmentBeans = new ArrayList(aListOfAssocShipments.size());
//        for (Iterator itr=aListOfAssocShipments.iterator(); itr.hasNext(); ) {
//            assocShipmentBeans.add(new AssociatedShipmentBean((AssociatedShipmentVO)itr.next()));
//        }    
//        return assocShipmentBeans;      
//    }
//    
//    private List filterReturnAWBs(List aListOfRelatedShipments) {
//        List filteredList = new ArrayList();
//        if (aListOfRelatedShipments != null) {
//            ListIterator iter = aListOfRelatedShipments.listIterator();
//            while (iter.hasNext()) {
//                AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
//                if (assocShipmentVO.get_assoc_track_type_cd() == RiseConstants.RETURN) {
//                    filteredList.add(assocShipmentVO);
//                }
//            }
//        }
//        return filteredList;
//    }
//    
  }    
