package com.fedex.rise.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ACCT_LANE_SERVICE_MONITORING")
public class AccountLaneServiceMonitoringEntity {

	@Id
	@Column(name = "EMP_NBR")
	private String empNmr;

	@Column(name = "GROUP_NBR")
	private int groupNbr;

	@Column(name = "ACCT_NBR")
	private String acctNbr;

	@Column(name = "LANE_NBR")
	private int laneNbr;

	@Column(name = "SVC_TYPE_CD")
	private String svcTypeCd;

	@Column(name = "INPUT_TMSTP")
	private Instant inputTmstp;

	@Column(name = "LAST_UPDT_TMSTP")
	private Instant lastUpdtTmstp;

	@Column(name = "DFLT_EMP_NBR")
	private String DeftEmpNmr;

}
