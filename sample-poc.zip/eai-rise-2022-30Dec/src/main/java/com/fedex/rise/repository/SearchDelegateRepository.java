package com.fedex.rise.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fedex.rise.constant.QueryConstant;
import com.fedex.rise.entity.AccountLaneServiceMonitoringEntity;

@Repository
@SuppressWarnings("rawtypes")
public interface SearchDelegateRepository extends JpaRepository<AccountLaneServiceMonitoringEntity, String> {

	
	@Query(value=QueryConstant.getSearchByAcctNbrSQL, nativeQuery=true)
	public List searchByAcctNbr(String acctNbr);
	
	@Query(value=QueryConstant.getSearchByShprNmSQL, nativeQuery=true)
	public List searchByShipperName(String shprNm);
	
	
	@Query(value=QueryConstant.getSearchByTrkngNbrSQL, nativeQuery=true)
	public List searchByTrkngNbr(String trkngNbr);
	

	@Query(value=QueryConstant.getSearchByFindMonitorAcctNbrSQL, nativeQuery=true)
	public List searchByFindMonitorAcctNbr(String acctNbr);
	
	
	
	@Query(value=QueryConstant.getSearchByFindMonitorTrkngNbrSQL, nativeQuery=true)
	public List searchByFindMonitorTrkngNbr(String trackingNbr);

	// Performance Tab - Get Employee	
	@Query(value=QueryConstant.getSearchByAll, nativeQuery=true)
	public List getSearchByAll();
	
	@Query(value=QueryConstant.searchByGroupLane, nativeQuery=true)
	public List searchByGroupLaneNbr(int groupNbr, int laneNbr);

}
