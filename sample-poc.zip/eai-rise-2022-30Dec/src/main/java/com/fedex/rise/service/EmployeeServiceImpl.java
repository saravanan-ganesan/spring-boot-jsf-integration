package com.fedex.rise.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.entity.EmployeeEntity;
import com.fedex.rise.repository.EmployeeRepository;
import com.fedex.rise.vo.EmployeeVO;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@Cacheable(cacheNames = "getUserByEmpNo", keyGenerator="customKeyGenerator")
	public EmployeeVO getUser(String empNo) {
		
		EmployeeVO employeeVO = null;
		EmployeeEntity employeeEntity = employeeRepository.findByEmpNbr(empNo);
		
		if(!ObjectUtils.isEmpty(employeeEntity)) {
			
			employeeVO = new EmployeeVO();
			employeeVO.set_emp_first_nm(employeeEntity.getEmp_first_nm());
			employeeVO.set_emp_last_nm(employeeEntity.getEmp_last_nm());
			employeeVO.set_emp_nbr(employeeEntity.getEmpNbr());
			employeeVO.set_emp_role_cd(employeeEntity.getEmp_role_cd());
		}
		return employeeVO;
	}
}
