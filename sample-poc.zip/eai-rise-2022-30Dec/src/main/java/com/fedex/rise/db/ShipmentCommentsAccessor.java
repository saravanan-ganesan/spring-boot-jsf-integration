package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ShipmentCommentVO;

public class ShipmentCommentsAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(ShipmentCommentsAccessor.class);
    
    public ShipmentCommentsAccessor(Connection con) {
        super(con);
    }
        
    private final String selectShipmentCommentsSQL = "select " +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "COM_TMSTP, " +
        "EMP_NBR, " +
        "COM_DESC " +
        "from Shipment_Comment where " +
            "TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ?";

        
    public List getShipmentComments(String trkng_item_nbr, String trkng_item_uniq_nbr) throws SQLException {
        ArrayList al = new ArrayList(); 
            
        try {
            setSqlSignature( selectShipmentCommentsSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, trkng_item_nbr);
            pstmt.setString( 2, trkng_item_uniq_nbr);
             
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if ( hasResults ) {
                   
                while(rs.next()) {
                    // Shipment Comment(s) found
                    ShipmentCommentVO shipmentCommentVO = new ShipmentCommentVO();
                    shipmentCommentVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
                    shipmentCommentVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
                    shipmentCommentVO.set_com_tmstp(rs.getTimestamp("COM_TMSTP"));
                    shipmentCommentVO.set_emp_nbr(rs.getString("EMP_NBR"));
                    shipmentCommentVO.set_com_desc(rs.getString("COM_DESC"));

                    al.add(shipmentCommentVO);
                }
            } else {
                // Shipment Comment not found
                logger.error("Shipment Comment not found for : " + trkng_item_nbr + ":" + trkng_item_uniq_nbr);
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode());
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }    
}
