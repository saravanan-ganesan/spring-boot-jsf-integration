package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountGroupVO;

public class AccountGroupUpdater extends OracleBase {

    private static Logger logger = LogManager.getLogger(AccountGroupUpdater.class);

    public AccountGroupUpdater(Connection con) {
        super(con);
    }

    private static final String updateAccountSQL = "Update Account_Group set " +
        "GROUP_DESC = ?, " +
        "GROUP_NM = ?, " +
        "LAST_UPDT_TMSTP = SYSDATE " +
            "where GROUP_NBR = ?";

    public void updateAccountGroup(AccountGroupVO anAccountGroupVO) throws SQLException {

        try {
            setSqlSignature(updateAccountSQL, false, logger.isDebugEnabled());

            pstmt.setString( 1, anAccountGroupVO.get_group_desc());
            pstmt.setString( 2, anAccountGroupVO.get_group_nm());
            pstmt.setInt( 3, anAccountGroupVO.get_group_nbr());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
}
