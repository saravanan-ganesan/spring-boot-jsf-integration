package com.fedex.rise.timer;

/**
 * WebLogic Server includes a timer service that you can configure to emit 
 * notifications at specific dates and times or at a constant interval. To 
 * listen and respond to these timer notifications, you create a JMX 
 * notification listener and register it with the timer service. This class
 * shall be used to publish NOIs at periodic intervals.
 * 
 * @author be379961
 *
 */
public class NOITimerScheduler { //implements NotificationListener {
//
//	private static Logger logger = LogManager.getLogger(NOITimerScheduler.class);
//	/**
//	 * Ten minute period.
//	 */
//	private static final long PERIOD_MINUTE = Timer.ONE_MINUTE;    
//	private Timer _timer = null;    
//	private Integer _notificationId;    
//	private NOIPublishBO _noiPublishBO = null;
//	
//	/**
//	 * Constructor which instantiates Timer MBean, register a listener, and 
//	 * adding the notification to the Timer.
//	 *
//	 */
//	public NOITimerScheduler() {        
//		logger.info("TimerScheduler: class instantiated");      
//		/**
//		 * Instantiating the Timer MBean
//		 */   
//		_timer = new Timer(); 
//		_noiPublishBO = new NOIPublishBO();
//		
//		/**
//		 * Set the NOI publish period from the property file.  If it is not
//		 * set, use a default value of 10 minutes.
//		 */
//		String numberMinutesString = 
//			ConfigurationManager.get("NOI_PERIOD_IN_MINUTES");
//		if (numberMinutesString == null){
//			numberMinutesString = "10";
//			logger.error("NOI_PERIOD_IN_MINUTES property is null");
//		}
//		long periodLong = PERIOD_MINUTE * Long.parseLong(numberMinutesString);
//		/**
//		 * Registering this class as a listener
//		 */        
//		_timer.addNotificationListener(this, null, "some handback object");
//		
//		/**
//		 * Adding the notification to the Timer and assigning the
//		 * ID that the Timer returns to a variable
//		 */        
//		Date timerTriggerAt = new Date((new Date()).getTime() + 5000L); 
//		_notificationId = null;
//		_notificationId = _timer.addNotification("tenMinuteTimer", 
//				"a recurring call", this, timerTriggerAt, periodLong);        
//		_timer.start();    
//		
//		logger.info("TimerScheduler:timer started. notificationId = " 
//				+ _notificationId.toString());   
//	}
//	
//	/**
//	 * Stop the timer and remove the notification while shutting down.
//	 *
//	 */
//	public synchronized void cleanUp()
//	{
//		logger.info("cleanUp");
//		
//	    try
//	    {     
//	    	if (_timer != null) {
//	    		_timer.stop();
//	    		if (_notificationId != null) {
//	    			_timer.removeNotification(_notificationId);
//	    			_notificationId = null;
//	    			logger.info("cleanUp: stopped");
//	    		}
//	    	}
//	    }
//	    catch (InstanceNotFoundException e)
//	    {
//	    	logger.error("Instance Not Found Exception", e);
//	    }
//	}
//	
//	/**
//	 * finalize method used while shutting down.
//	 */
//	protected void finalize() 
//	{
//		logger.info("finalize");
//	    cleanUp();
//	    try {
//	    	super.finalize();
//	    } catch (Throwable e) {
//	    	logger.error("Throwable exception ", e);
//	    }
//	}
//    
//	/**
//	 * Callback method.
//	 */
//	public void handleNotification(Notification notif, Object handback) {  
//		logger.info("handleNotification ");
//				    
//		if (_noiPublishBO != null){
//			_noiPublishBO.NOIPublishTransaction();
//		}
//	}
}
