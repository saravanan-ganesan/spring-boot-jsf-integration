package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.SystemMessageVO;

public class SystemMessageAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(SystemMessageAccessor.class);
    
    public SystemMessageAccessor(Connection con) {
        super(con);
    }   
    
    private static final String getSystemMessagesSQL = "select " +
        "MESSAGE_NBR, START_DT, END_DT, EMP_ROLE_CD, EMP_NBR, MESSAGE_DESC from SYSTEM_MESSAGE";
    
    public List getSystemMessages() throws SQLException {
        ArrayList al = new ArrayList();
        
        try {
            setSqlSignature( getSystemMessagesSQL, false, logger.isDebugEnabled() );

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    // rows found
                    SystemMessageVO systemMessageVO = new SystemMessageVO();
                    systemMessageVO.set_msgNbr(rs.getInt("MESSAGE_NBR"));
                    systemMessageVO.set_startDt(rs.getTimestamp("START_DT"));
                    systemMessageVO.set_endDt(rs.getTimestamp("END_DT"));
                    systemMessageVO.set_empNbr(rs.getString("EMP_NBR"));
                    systemMessageVO.set_empRoleCd(rs.getString("EMP_ROLE_CD"));
                    systemMessageVO.set_msgDesc(rs.getString("MESSAGE_DESC"));
                    
                    al.add(systemMessageVO);
                }
            } else {
                return null;
            }            

        } catch ( SQLException e ) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return al;
    }
    
}
