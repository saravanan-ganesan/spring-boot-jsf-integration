package com.fedex.rise.bean;

import java.time.Month;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.service.EmployeeService;
import com.fedex.rise.service.SearchDelegateService;
import com.fedex.rise.service.ShipperService;
import com.fedex.rise.vo.AccountGroupVO;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.LaneVO;

/**
 * Backing Bean class for the Performance screen.
 * 
 * @author be379961
 *
 */
@JsfController(path = "/performance", page = "/pages/jsp/performance.jsp", value = "PerformanceBean")
public class PerformanceBean extends BaseBean {

	private static final long serialVersionUID = 1L;

	private static final Log log = LogFactory.getLog(PerformanceBean.class);

	@Autowired
	ShipperService shipperService;

	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	SearchDelegateService searchDelegateService;
	
	/** delegate to get shipper data */
	private Date _fromDate = null;
	private Date _toDate = null;
	private String _selectRadio = "one";
	private Calendar _calendar = Calendar.getInstance();
	private String _thisYear = String.valueOf(_calendar.get(Calendar.YEAR));
	private String _threeYearsAgo = String.valueOf(_calendar.get(Calendar.YEAR) - 3);
	private String _twoYearsAgo = String.valueOf(_calendar.get(Calendar.YEAR) - 2);
	private String _lastYear = String.valueOf(_calendar.get(Calendar.YEAR) - 1);
	private String _selectYear = new String(_thisYear);
	private String _selectMonth = new String("Jan");
	private String _groupNbr = new String();
	private String _groupName = new String();
	private String _laneNbrStr = new String();
	private String _origCntryCd = new String();
	private String _destCntryCd = new String();
	
	private String _empNbr = new String();
	private String _empName = new String();
	private Map _attribute = new HashMap();
	private String _laneValue = null;
	private String _laneOrgDest = null;
	private boolean _lanegetFlag;
	private boolean _lanesetFlag;
	private List<List<SelectItem>> _allLanesList = new ArrayList<>();
	private String _monitorName = new String();
	
	private static SelectItem[] selectRadioItems = { new SelectItem("one", "Date Range"),
			new SelectItem("two", "Month and Year"), new SelectItem("three", "Year") };

	private static SelectItem[] selectMonthItems = new SelectItem[12];
	static {
		Month[] monthArr = Month.values();
		for (int i = 0; i < monthArr.length; i++) {
			selectMonthItems[i] = new SelectItem(i, monthArr[i].getDisplayName(TextStyle.FULL, Locale.US));
		}
	}

	private SelectItem[] selectYearItems = { new SelectItem(_threeYearsAgo, _threeYearsAgo),
			new SelectItem(_twoYearsAgo, _twoYearsAgo), new SelectItem(_lastYear, _lastYear),
			new SelectItem(_thisYear, _thisYear)

	};


	/**
	 * Get the selected month attribute.
	 * 
	 * @return String of the selected month attribute.
	 */
	public String getSelectedMonth() {
		return (String) _attribute.get("selected_month");
	}

	/**
	 * Get the selected month attribute.
	 * 
	 * @return String of the selected month attribute.
	 */
	public String getSelectedMonthNumber() {
		return (String) _attribute.get("selected_month_number");
	}

	/**
	 * Sets the selected month through the action listener for the
	 * performanceList.jsp
	 * 
	 * @param event the ActionEvent from the action listener.
	 */
	public void selectedMonth(ActionEvent event) {
		UIComponent component = event.getComponent();
		setSelectedMonth(component);
	}

	/**
	 * Sets the selected month in the hash attribute hash table.
	 * 
	 * @param component the UIComponent from the action listener.
	 */
	@SuppressWarnings("unchecked")
	private void setSelectedMonth(UIComponent component) {

		Object value = (Object) component.getAttributes().get("selected_month");

		Month[] monthArr = Month.values();
		for (int i = 0; i < monthArr.length; i++) {
			if (value.toString().equals(monthArr[i].getDisplayName(TextStyle.FULL, Locale.US))) {
				_attribute.put("selected_month", String.valueOf(i));
				_attribute.put("selected_month_number",
						((Object) component.getAttributes().get("selected_month_number")).toString());
				break;
			}
		}
	}

	/**
	 * Get the selected number of CRNSs attribute.
	 * 
	 * @return String of the number of CRNSs attribute.
	 */
	public String getSelectedNbrCrns() {
		return (String) _attribute.get("number_crns");
	}

	/**
	 * Get the selected number of performance type attribute.
	 * 
	 * @return String of the performance type attribute.
	 */
	public String getSelectedPerformanceType() {
		return (String) _attribute.get("performance_type");
	}

	/**
	 * Get the selected account number attribute.
	 * 
	 * @return String of the account number attribute.
	 */
	public String getSelectedAcctNbr() {
		return (String) _attribute.get("acct_nbr");
	}

	/**
	 * Sets the number of CRNs, Account number, and the performance type in the hash
	 * attribute hash table.
	 * 
	 * @param component the UIComponent from the action listener.
	 */
	public void selectedCrns(ActionEvent event) {
		UIComponent component = event.getComponent();
		setSelectedNbrCrns(component);
	}

	/**
	 * Sets the number of CRNs, Account number, and the performance through the
	 * action listener for the performanceDetailList.jsp
	 * 
	 * @param event the ActionEvent from the action listener.
	 */
	private void setSelectedNbrCrns(UIComponent component) {
		// Store number of CRNs in the hash table.
		Object value = (Object) component.getAttributes().get("number_crns");
		_attribute.put("number_crns", value.toString());
		// Store the performance type in the hash table.
		String stringValue = (String) component.getAttributes().get("performance_type");
		_attribute.put("performance_type", stringValue);
		// Store the account number in the hash table.
		stringValue = (String) component.getAttributes().get("acct_nbr");
		_attribute.put("acct_nbr", stringValue);
	}

	/**
	 * @return selectRadioItems
	 */
	public SelectItem[] getSelectRadioItems() {
		return selectRadioItems;
	}

	/**
	 * 
	 * @return selectMonthItems
	 */
	public SelectItem[] getSelectMonthItems() {
		return selectMonthItems;
	}

	/**
	 * 
	 * @return selectYearItems
	 */
	public SelectItem[] getSelectYearItems() {
		return selectYearItems;
	}

	/**
	 * @return the _fromDate
	 */
	public Date getFromDate() {
		// Set the default date.
		if (_fromDate == null) {
			_fromDate = new Date();
			Calendar startDate = Calendar.getInstance();
			int day = 1;
			int month = startDate.get(Calendar.MONTH);
			int year = startDate.get(Calendar.YEAR);
			if (month == Calendar.JANUARY) {
				month = Calendar.DECEMBER;
				year--;
			} else {
				month--;
			}
			startDate.set(year, month, day);
			_fromDate = startDate.getTime();
		}
		return _fromDate;
	}

	/**
	 * @param fromDate the _fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		_fromDate = fromDate;
	}

	/**
	 * @param edit the _fromDate
	 */
	private void editFromDate() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		if (_fromDate != null) {
			Calendar oldestStartDate = Calendar.getInstance();

			// If fromDate is more than a year less than _toDate, restrict
			// fromDate to a year.
			oldestStartDate.setTime(_toDate);
			oldestStartDate.add(Calendar.YEAR, -1);
			if (_fromDate.before(oldestStartDate.getTime())) {
				_fromDate = oldestStartDate.getTime();

				log.info(
						"From date is more than one year before the To date, and has been reset to the To date minus one year.");
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_WARN,
						"From date is more than one year before the To date, and has been reset to the To date minus one year.",
						null);
				facesContext.addMessage(null, facesMessage);
			}

			// Don't let from date to go back more than the day 10/8/2007.
			oldestStartDate = Calendar.getInstance();
			int day = 8;
			int month = 9;
			int year = 2007;

			oldestStartDate.set(year, month, day);
			// Check if start date is back more than 10/8/2007.
			if (_fromDate.before(oldestStartDate.getTime())) {
				_fromDate = oldestStartDate.getTime();

				log.info("From date is less than the day 10/8/2007, and has been reset to 10/8/2007.");
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_WARN,
						"From date is less than the day 10/8/2007, and has been reset to 10/8/2007.", null);
				facesContext.addMessage(null, facesMessage);
			}
		}
		// If fromDate is greater than _toDate shall set them equal.
		if (_fromDate.after(_toDate)) {
			_fromDate = _toDate;

			log.info("From date is greater the To date, and has been reset equal to the To date.");
			FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_WARN,
					"From date is greater the To date, and has been reset equal to the To date.", null);
			facesContext.addMessage(null, facesMessage);
		}
	}

	/**
	 * @return the _toDate
	 */
	public Date getToDate() {
		if (_toDate == null) {
			Calendar toDate = Calendar.getInstance();
			toDate.add(Calendar.HOUR, -120); // subtract 5 days in hours.
			_toDate = new Date(toDate.getTimeInMillis());
		}
		return _toDate;
	}

	/**
	 * @param toDate the _toDate to set
	 */
	public void setToDate(Date toDate) {
		_toDate = toDate;
	}

	/**
	 * @param edit the _toDate
	 */
	private void editToDate() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		if (_toDate != null) {
			// If toDate is more than a year after than _fromDate, restrict
			// toDate to a year.
			Calendar greatestToDate = Calendar.getInstance();
			greatestToDate.setTime(_fromDate);
			greatestToDate.add(Calendar.YEAR, 1);
			if (_toDate.after(greatestToDate.getTime())) {
				_toDate.setTime(greatestToDate.getTimeInMillis());

				log.info(
						"To date is more than one year after the From date, and has been reset to the From date plus one year.");
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_WARN,
						"To date is more than one year after the From date, and has been reset to the From date plus one year.",
						null);
				facesContext.addMessage(null, facesMessage);
			}
			// If toDate is before the _fromDate shall set them equal.
			if (_toDate.before(_fromDate)) {
				_toDate.setTime(_fromDate.getTime());

				log.info("To date is less than the From date, and has been reset equal to the From date.");
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_WARN,
						"To date is less than the From date, and has been reset equal to the From date.", null);
				facesContext.addMessage(null, facesMessage);
			}

			// Max To date is todays date - 5.
			Calendar maxToDate = Calendar.getInstance();
			maxToDate.add(Calendar.HOUR, -120); // subtract 5 days in hours.
			if (_toDate.after(maxToDate.getTime())) {
				_toDate.setTime(maxToDate.getTimeInMillis());

				log.info("To date is more than 5 days minus todays date.");
				FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_WARN,
						"To date is more than 5 days minus todays date.", null);
				facesContext.addMessage(null, facesMessage);
			}
		}
	}

	/**
	 * @return the _selectRadio
	 */
	public String getSelectRadio() {
		if (_selectRadio == null) {
			_selectRadio = "one";
		}
		return _selectRadio;
	}

	/**
	 * @param selectRadio the _selectRadio to set
	 */
	public void setSelectRadio(String selectRadio) {
		_selectRadio = selectRadio;
	}

	/**
	 * @return the _selectRadio
	 */
	public boolean getSelectRadioOne() {
		return _selectRadio.equalsIgnoreCase("one");
	}

	/**
	 * @return the _selectRadio
	 */
	public boolean getSelectRadioTwo() {
		return _selectRadio.equalsIgnoreCase("two");
	}

	/**
	 * @return the _selectRadio
	 */
	public boolean getSelectRadioThree() {
		return _selectRadio.equalsIgnoreCase("three");
	}

	/**
	 * @return the _selectYear
	 */
	public String getYear() {
		return _selectYear;
	}

	/**
	 * @param selectYear the selectYear to set
	 */
	public void setYear(String selectYear) {
		_selectYear = selectYear;

		// Set the from date.
		int year = Integer.parseInt(selectYear);
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, Calendar.JANUARY, 1);
		_fromDate.setTime(fromDate.getTimeInMillis());

		// Set the to date.
		Calendar toDate = Calendar.getInstance();
		if (year == toDate.get(Calendar.YEAR)) {
			setToDate(new Date());
		} else {
			toDate.set(year, Calendar.DECEMBER, 31);
			setToDate(toDate.getTime());
		}
	}

	/**
	 * @return the _selectYear
	 */
	public String getSelectYear() {
		return _selectYear;
	}

	/**
	 * @param selectYear the selectYear to set
	 */
	public void setSelectYear(String selectYear) {
		_selectYear = selectYear;

		// Set the from date.
		int month = Integer.parseInt(getSelectMonth());
		int year = Integer.parseInt(selectYear);
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, month, 1);
		_fromDate.setTime(fromDate.getTimeInMillis());

		// Set the to date.
		int lastDayMonth = fromDate.getActualMaximum(Calendar.DAY_OF_MONTH);
		Calendar toDate = Calendar.getInstance();
		toDate.set(year, month, lastDayMonth);
		setToDate(toDate.getTime());
	}

	/**
	 * @return the selectMonth
	 */
	public String getSelectMonth() {
		if (_selectMonth == null) {
			_selectMonth = "0";
		}
		return _selectMonth;
	}

	/**
	 * @param selectMonth the _selectMonth to set
	 */
	public void setSelectMonth(String selectMonth) {
		_selectMonth = selectMonth;

		// Set the from date.
		int month = Integer.parseInt(selectMonth);
		int year = Integer.parseInt(getSelectYear());
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, month, 1);
		_fromDate.setTime(fromDate.getTimeInMillis());

		// Set the to date.
		int lastDayMonth = fromDate.getActualMaximum(Calendar.DAY_OF_MONTH);
		Calendar toDate = Calendar.getInstance();
		toDate.set(year, month, lastDayMonth);
		setToDate(toDate.getTime());
	}

	/**
	 * 
	 * @return the _groupName
	 */
	public String getGroupName() {
		return _groupName;
	}

	/**
	 * 
	 * @param groupName the _groupName to set
	 */
	public void setGroupName(String groupName) {
		_groupName = groupName;
	}

	/**
	 * @return the groupNbr
	 */
	public String getGroupNbr() {
		return _groupNbr;
	}

	public void setGroupNbr(String groupNbr) {
		
		String groupName = shipperService.getAccountGroupNamesByGrpNbr(groupNbr);
		_groupNbr = groupNbr;
		
		if (groupNbr != null) {
			
			if (groupNbr.equals("All")) {
				setGroupName("All");
				setLaneNbrStr("All");
			} else {
				_laneValue = "All";
				_lanesetFlag = true;
				setGroupName(groupName);
			}
		}
	}


	public List<SelectItem> getAllGroupNames() {

		List<AccountGroupVO> allGroupNamesVO = shipperService.getAccountGroupNames();

		_lanegetFlag = true;

		List<SelectItem> groupNameSelectItems = new ArrayList<>(allGroupNamesVO.size() + 1);
		groupNameSelectItems.add(new SelectItem("All", "All"));

		for (Iterator<AccountGroupVO> itr = allGroupNamesVO.iterator(); itr.hasNext();) {

			AccountGroupVO accountGroupVO = itr.next();
			groupNameSelectItems.add(
					new SelectItem(Integer.toString(accountGroupVO.get_group_nbr()), accountGroupVO.get_group_nm()));

			if (getGroupNbr().equalsIgnoreCase("")) {
				setGroupNbr("All");
			}
		}
		return groupNameSelectItems;
	}

	/**
	 * @return the _laneNbrStr
	 */
	public String getLaneNbrStr() {
		return _laneNbrStr;
	}

	/**
	 * @param lane the _laneNbrStr to set
	 */
	// WR#:179441 Changes
	public void setLaneNbrStr(String laneNbrStr) {
		
		setLaneOrgDest(laneNbrStr);
		
		if (_laneValue != "All") {
			_laneNbrStr = laneNbrStr;
		} else
			_laneNbrStr = _laneValue;
		
		if (laneNbrStr.equals("All")) {
			
			_laneNbrStr = laneNbrStr;
			setOrigCntryCd("All");
			setDestCntryCd("All");
			_lanesetFlag = false;
			return;
		}
		if (_lanesetFlag) {
			_lanesetFlag = false;
			Integer groupNbr = Integer.valueOf(_groupNbr);
			String groupName = shipperService.getLaneByLaneNbr(groupNbr.intValue());
			setGroupName(groupName);
		}
	}

	// Start WR#:179441 Changes
	/**
	 * @return the _empNbr
	 */
	public String getEmpNbr() {
		return _empNbr;
	}

	/**
	 * @param _empNbr the _empNbr to set
	 */
	public void setEmpNbr(String _empNbr) {
		this._empNbr = _empNbr;
	}

	/**
	 * @return the _empName
	 */
	public String getEmpName() {
		return _empName;
	}

	/**
	 * @param _empName the _empName to set
	 */
	public void setEmpName(String _empName) {
		
		if (_empName.equalsIgnoreCase("All")) {
			setMonitorName("All");
			this._empName = _empName;
		} else {
			EmployeeVO employeeVO = employeeService.getUser(_empName);
			setMonitorName(employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
			this._empName = _empName;
		}
	}

	/**
	 * @return the _laneOrgDest
	 */
	public String getLaneOrgDest() {
		return _laneOrgDest;
	}

	/**
	 * @param _laneOrgDest the _laneOrgDest to set
	 */
	public void setLaneOrgDest(String _laneOrgDest) {
		this._laneOrgDest = _laneOrgDest;
	}

	// End WR#:179441 Changes
	/**
	 * @return the _origCntryCd
	 */
	public String getOrigCntryCd() {
		return _origCntryCd;
	}

	/**
	 * @param lane the _origCntryCd to set
	 */
	public void setOrigCntryCd(String origCntryCd) {
		_origCntryCd = origCntryCd;
	}

	/**
	 * @return the _destCntryCd
	 */
	public String getDestCntryCd() {
		return _destCntryCd;
	}

	/**
	 * @param lane the _destCntryCd to set
	 */
	public void setDestCntryCd(String destCntryCd) {
		_destCntryCd = destCntryCd;
	}

	/**
	 * @return a list of all destination country codes for the company of interest.
	 */
	// WR#:179441 Changes
	public List getAllLanes() {

		List allLaneList = new ArrayList();
		List<SelectItem> allLanesSelectItems = new ArrayList<>(1);

		if (_groupNbr.equals("All")) {
			allLanesSelectItems = new ArrayList<>(1);
			allLanesSelectItems.add(new SelectItem("All", "All"));
		} else {
			Integer groupNbr = Integer.valueOf(_groupNbr);
			if (_lanegetFlag) {
				allLaneList = shipperService.getLaneByGroupNbr(groupNbr.intValue());
				_lanegetFlag = false;
				List laneList = removeDuplicatesLanes(allLaneList);
				allLanesSelectItems = new ArrayList(laneList.size() + 1);
				_allLanesList = new ArrayList(laneList.size() + 1);
				allLanesSelectItems.add(new SelectItem("All", "All"));

				for (Iterator itr = laneList.iterator(); itr.hasNext();) {

					LaneVO laneVO = (LaneVO) itr.next();
					allLanesSelectItems.add(new SelectItem(String.valueOf(laneVO.get_lane_nbr()),
							laneVO.get_orig_cntry_cd() + "-" + laneVO.get_dest_cntry_cd()));
					_allLanesList = new ArrayList(allLanesSelectItems);
					//_allLanesList.add(allLanesSelectItems);

				}
				return allLanesSelectItems;
			}
			return _allLanesList;
		}
		return allLanesSelectItems;
	}

	/**
	 * @return a list of all employees country codes for the selected customer and
	 *         lanes.
	 */
	// Start WR#:179441 Changes
	public List getAllEmployees() {
		
		List<EmployeeVO> employeeNumbersList = new ArrayList<>();
		List<SelectItem> employeeSelectItems = new ArrayList<>(1);
		List employeeNumbers = new ArrayList();

		if (_groupNbr.equals("All")) {
			setEmpName("All");
			employeeNumbersList = searchDelegateService.getSearchByAll();
			
			if(!ObjectUtils.isEmpty(employeeNumbersList))
				employeeNumbers = new ArrayList(employeeNumbersList.size() + 1);
			
			employeeSelectItems.add(new SelectItem("All", "All"));
			
			for (Iterator<EmployeeVO> itr = employeeNumbersList.iterator(); itr.hasNext();) {
				EmployeeVO employeeVO = itr.next();
				employeeSelectItems.add(new SelectItem(employeeVO.get_emp_nbr(),
						employeeVO.get_emp_first_nm() + "  " + employeeVO.get_emp_last_nm()));
			}
		} else if (!(_groupNbr.equals("All")) && (_laneNbrStr.equals("All"))) {
			employeeSelectItems = new ArrayList<>(1);
			employeeSelectItems.add(new SelectItem("All", "All"));
		} else {
			setEmpName("All");
			Integer groupNbr = Integer.valueOf(_groupNbr);
			Integer laneNbr = Integer.valueOf(_laneNbrStr);
			employeeNumbersList = searchDelegateService.searchByGroupLaneNbr(groupNbr.intValue(), laneNbr.intValue());
			employeeNumbers = new ArrayList(employeeNumbersList.size() + 1);
			employeeSelectItems.add(new SelectItem("All", "All"));
			
			for (Iterator<EmployeeVO> itr = employeeNumbersList.iterator(); itr.hasNext();) {
				EmployeeVO employeeVO = (EmployeeVO) itr.next();
				employeeSelectItems.add(new SelectItem(employeeVO.get_emp_nbr(),
						employeeVO.get_emp_first_nm() + "  " + employeeVO.get_emp_last_nm()));
			}
		}
		_laneValue = null;
		return employeeSelectItems;
	}

	/**
	 * @return the _monitorName
	 */
	public String getMonitorName() {
		return _monitorName;
	}

	/**
	 * @param _monitorName the _monitorName to set
	 */
	public void setMonitorName(String monitorName) {
		_monitorName = monitorName;
	}

	// End WR#:179441 Changes
	/**
	 * Action method to go to the Performance List screen.
	 * 
	 * @return "performanceList"
	 */
	public void viewReportAction() {
		editFromDate();
		editToDate();
		//return "performanceList";
		redirect("performanceList");
	}

	/**
	 * Action method to reset the Performance screen.
	 *
	 */
	@SuppressWarnings("rawtypes")
	public void resetAction() {
		_fromDate = null;
		_toDate = null;
		_selectRadio = "one";
		_calendar = Calendar.getInstance();
		_thisYear = String.valueOf(_calendar.get(Calendar.YEAR));
		_threeYearsAgo = String.valueOf(_calendar.get(Calendar.YEAR) - 3);
		_twoYearsAgo = String.valueOf(_calendar.get(Calendar.YEAR) - 2);
		_lastYear = String.valueOf(_calendar.get(Calendar.YEAR) - 1);
		_selectYear = new String(_thisYear);
		_selectMonth = new String("Jan");
		_groupNbr = new String();
		_groupName = new String();
		_laneNbrStr = new String();
		_origCntryCd = new String();
		_destCntryCd = new String();
		_attribute = new HashMap();
	}

	/**
	 * Remove LaneVOs with duplicate lane numbers from a List.
	 * 
	 * @param hasDuplicates List of LaneVOs with duplicate lane numbers.
	 * @return List of unique LaneVOs
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List removeDuplicatesLanes(List hasDuplicates) {

		final List<LaneVO> laneVOList = new ArrayList<>();

		if (hasDuplicates == null) {
			List noDuplicates = new ArrayList(1);
			return noDuplicates;
		} else {

			// convert object[] into LaneVO
			if (!ObjectUtils.isEmpty(hasDuplicates)) {
				hasDuplicates.forEach(obj -> {
					if (obj instanceof Object[]) {
						Object[] LanArr = (Object[]) obj;
						LaneVO laneVO = new LaneVO();
						laneVO.set_lane_nbr(Integer.parseInt(LanArr[0].toString()));
						laneVO.set_orig_cntry_cd(LanArr[1].toString());
						laneVO.set_dest_cntry_cd(LanArr[2].toString());
						laneVOList.add(laneVO);
					}
				});
			}
		}
		List noDuplicates = new ArrayList(hasDuplicates.size());
		List noDuplicatesStr = new ArrayList(hasDuplicates.size());

		for (Iterator<LaneVO> itr = laneVOList.iterator(); itr.hasNext();) {
			LaneVO dupLaneVO = itr.next();
			String str = new String(dupLaneVO.get_orig_cntry_cd() + "-" + dupLaneVO.get_dest_cntry_cd());
			if (!noDuplicatesStr.contains(str)) {
				LaneVO laneVO = dupLaneVO;
				noDuplicates.add(laneVO);
				noDuplicatesStr.add(str);
			}
		}
		return noDuplicates;
	}
	

}
