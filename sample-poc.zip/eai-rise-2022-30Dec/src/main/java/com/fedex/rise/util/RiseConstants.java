package com.fedex.rise.util;

import com.fedex.rise.bo.status.StatusRule;

public class RiseConstants {

    // Types of airbills
    public static final String MAWB = "MAWB";  // Master airbill
    public static final String CRN = "CRN";    // Child of a master
    public static final String AWB = "AWB";    // A related AWB, don't know yet if paperwork or return
    public static final String PWRK = "PWRK";  // A related AWB, associated with paperwork
    public static final String RTRN = "RTRN";  // A related AWB, associated with returns
    public static final String UNK = "UNK";    // Unknown
    
    // Valid flavors/service codes for IPD
    public static final String ED = "17";      // Economy
    public static final String ID = "18";      // Priority
    public static final String DF = "84";      // Freight
    
    // Shipment Associations
    public static final char PARENT = 'P';
    public static final char RETURN = 'R';
    public static final char PAPERWORK = 'W';   
    
    public final static String SOP =  "01";
    public final static String SIP =  "02";
    public final static String STAT = "07";
    public final static String PUP =  "08";
    public final static String HLD =  "09";
    public final static String HOP =  "10";
    public final static String VAN =  "11";
    public final static String CON =  "12";
    public final static String HIP =  "13";
    public final static String POD =  "20";
    public final static String ROP =  "22";
    public final static String RIP =  "24";
    public final static String PUX =  "29";
    public final static String DEX =  "30";
    public final static String DDEX = "31";
    public final static String REX =  "32";
    public final static String HAL =  "41";
    public final static String ODA =  "42";
    public final static String MIS =  "48";
    public final static String MDD =  "60";
    public final static String MDE1_70 =  "70";
    public final static String MDE_CANCEL = "71";
    public final static String MDE1_72 = "72";
    public final static String MDE2_73 = "73";
    public final static String MDE3_74 = "74";
    public final static String ECCO = "79";
    public final static String COMM = "90";
    public final static String CER =  "92";
    public final static String CE =   "CE";
    public final static String DC =   "DC";
    public final static String RE =   "RE";
    
    // Piece count verification, special handling code
    public final static String PCV = "18";
    // Appointment Delivery, special handling code
    public final static String APD = "17";
    
    // Status
    public final static String STATUS_DLVRD = "DLVRD";
    public final static String STATUS_DDLVRD = "DDLVRD";
    
}
