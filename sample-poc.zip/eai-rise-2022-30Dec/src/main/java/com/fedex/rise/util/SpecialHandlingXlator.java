package com.fedex.rise.util;

import com.fedex.rise.xref.HandlingCodesDesc;

public class SpecialHandlingXlator {
    
    public static String getSpecialHandlingCdTranlation(String aHandlingCdGrp) {
        StringBuffer sb = new StringBuffer((String)aHandlingCdGrp);
        StringBuffer titleText = new StringBuffer();

        while (sb.length() > 0) {
            String handlingCd = sb.substring(0, 2);
            sb.delete(0, 2);
            String xlation = HandlingCodesDesc.lookupHandlinCdDesc(handlingCd);
            titleText.append(handlingCd);
            titleText.append('-');
            if (xlation != null) {
               titleText.append(xlation);
            } else {
               titleText.append("Unknown");
            }
            if (sb.length() > 0) {
                titleText.append("\r");
            }
        }
        return titleText.toString();
    }     
}
