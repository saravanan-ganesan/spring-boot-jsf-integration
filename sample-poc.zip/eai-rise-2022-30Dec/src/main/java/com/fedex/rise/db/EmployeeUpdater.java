package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;
import com.fedex.rise.vo.EmployeeVO;

public class EmployeeUpdater extends OracleBase {
    private static Logger logger = LogManager.getLogger(EmployeeUpdater.class);

    public EmployeeUpdater(Connection con) {
        super(con);
    }

    private static final String updateEmployeeSQL = "Update Employee set " +
            "EMP_FIRST_NM = ?, " +
            "EMP_LAST_NM = ?, " +
            "EMP_ROLE_CD = ?, " +
            "LAST_UPDT_TMSTP = SYSDATE " +
            "where EMP_NBR = ?";

    public void updateEmployee(EmployeeVO anEmployeeVO) throws SQLException {

        try {
            setSqlSignature(updateEmployeeSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, anEmployeeVO.get_emp_first_nm());
            pstmt.setString(2, anEmployeeVO.get_emp_last_nm());
            pstmt.setString(3, anEmployeeVO.get_emp_role_cd());
            pstmt.setString(4, anEmployeeVO.get_emp_nbr());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
}
