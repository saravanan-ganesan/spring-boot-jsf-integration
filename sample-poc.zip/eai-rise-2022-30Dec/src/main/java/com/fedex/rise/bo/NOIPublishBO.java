package com.fedex.rise.bo;

import java.io.ByteArrayOutputStream;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.ThreadContext;


//import com.fedex.rise.MCD.RISEMcd;
import com.fedex.rise.config.ConfigurationManager;
import com.fedex.rise.db.NOIPublishDAO;
import com.fedex.rise.jms.JMSPublishConfig;
import com.fedex.rise.jms.publishDAO;
import com.fedex.rise.util.ServiceLocator;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.NOIPublishVO;

/**
 * NOI Publish request BO.
 * 
 * @author be379961
 *
 */
public class NOIPublishBO extends publishDAO { 
    /** Logger */
    private static Logger logger = LogManager.getLogger(NOIPublishBO.class);
   
	private JMSPublishConfig _jmsPublishConfig;
    
    private String shortClassName = null;
	
    /**
     * This method is the default constructor for the class.
     */
    public NOIPublishBO(){
    	_jmsPublishConfig = loadParameters();
        shortClassName = this.getClass().getName();
        shortClassName = shortClassName.substring(shortClassName.lastIndexOf('.')+1); 
    }
    
    /**
     * Within a transaction an NOI publish shall be executed.
     *  1.) Connect to the JMS queues.
     *  2.) While loop
     * 	3.) Read a row from the NOI table, if no data get out of while loop.
     * 	4.) Encode an NOI message.
     * 	5.) Publish the message.
     * 	6.) Delete the row from the NOI table.
     *  7.) Close JMS connection.
     */
    public void NOIPublishTransaction(){       
    	if (!doConnectJMS(_jmsPublishConfig)) {
    		doReconnectJMS(_jmsPublishConfig);
    	}

        while (true) {
            UserTransaction userTransaction = null;
                
            try {
                ThreadContext.push(""); // place holder in case we have an exception, the finally clause will pop
                
                // Begin the transaction
                userTransaction = ServiceLocator.getInstance().getUserTransaction();
                userTransaction.begin();
            
                NOIPublishDAO dbdao = new NOIPublishDAO();
                
                // Read a row from the NOI table. Only row with publish date = null will return
                NOIPublishVO noiPublishVO = dbdao.getNOIPublishRow();
                if (noiPublishVO == null) {
                    logger.info("No NOI's to send");
                    userTransaction.rollback();  
                    close();
                    return;
                }
         	
                String trkngNbr = noiPublishVO.get_trk_item_nbr();
                ThreadContext.pop();
                ThreadContext.push(trkngNbr);
            	
                logger.info("Begin publishing NOI.");            
                    
                // Build MCD event
                /*StringBuffer mcdString = new StringBuffer();
                mcdString.append("NOI.publish");
                Properties mcdProp = new Properties();
                mcdProp.setProperty("trkngNbr", trkngNbr);
                RISEMcd.sendMCDEvent(shortClassName, RISEMcd.EVENT_OCCURRED,  mcdString.toString(), -1, mcdProp); */ 
                
                // Encode an NOI message.
                ByteArrayOutputStream encodeMessage = doEncodeNOIRequest(noiPublishVO);
                if (encodeMessage == null) {
                    logger.info("Error encoding message");
                    userTransaction.rollback();  
                    close();
                    return;
                }              
                
                // Publish the message.
                if (doPublish(encodeMessage)) {	
                    // Update the row with publish time.
                    dbdao.update(noiPublishVO);
                    // Commit Transaction.
                    userTransaction.commit();
                    logger.info("Successfully published NOI.");
                } else {
                    logger.error("Failed to publish NOI.");
                    userTransaction.rollback();
                    close();
                    return;
                }
            } catch (Exception e) {
                logger.error("Exception", e);
                try {
                    if (userTransaction != null) {
                        userTransaction.rollback();
                    }
                } catch (Exception e2) {
                    logger.error("Exception ", e2);
                }
                return;
            } finally {
            	ThreadContext.pop();
            }
        } // End of while loop.
    }
    
    /**
     * Persist the return_trk_item_nbr, ship date, track date and time to the
     * NOI publish table.
     * 
     * @param aVO Event VO.
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void doPersist(String aTrkngNbr, Date anEventCrtnTmstp) throws ServiceLocatorException, SQLException {
		/**
		 * Since the _trk_item_nbr exists, it is an NOI. Create
		 * the NOIPublishVO and store the NOI_PUBLISH table.
		 */
    	ThreadContext.push(":" + aTrkngNbr);
        try {
            NOIPublishVO noiPublishVO = new NOIPublishVO();
            noiPublishVO.set_trk_item_nbr(aTrkngNbr);
            noiPublishVO.set_trk_date_time(anEventCrtnTmstp);
            noiPublishVO.set_ship_date(anEventCrtnTmstp);
		
            NOIPublishDAO dbdao = new NOIPublishDAO();

		    dbdao.doPersist(noiPublishVO);
		} finally {
			ThreadContext.pop();
		}
    }

	/**
	 * Encode an NOI Request message to publish to the JMS queues.
	 * @return ByteArrayOutputStream of the encoded NOI Request message.
	 */
	public ByteArrayOutputStream doEncodeNOIRequest (NOIPublishVO aNOIPublishVO) {
		EncodeNOIRequest encodeNOIRequest =  null;
		ByteArrayOutputStream byteArrayOutputStream = null;
		encodeNOIRequest = new EncodeNOIRequest();
		
		/**
		 * Set the track date and track scan time.
		 */
		SimpleDateFormat trackDate = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat trackScanTime = new SimpleDateFormat("HHmm");
		
		String track_date = trackDate.format(
				aNOIPublishVO.get_trk_date_time()); 
		String track_scan_time = trackScanTime.format(
				aNOIPublishVO.get_trk_date_time());  
			
		byteArrayOutputStream = encodeNOIRequest.encode(
			aNOIPublishVO.get_trk_item_nbr(), // Required field, SEP uses.
			aNOIPublishVO.get_ship_date(), // Required field, SEP uses.
			track_date,       // Required field, NOT used by SEP.
			track_scan_time,  // Required field, NOT used by SEP.        
			_jmsPublishConfig.get_noiUser(), // So NOIs returned to RISE.
			_jmsPublishConfig.get_noiSystem());	// So NOIs returned to RISE.
			
		return byteArrayOutputStream;	
	} 
	
    /**
     * This function is used to load the parameters to be used to
     * set
     * @return return true on success, false on failure
     */
    private JMSPublishConfig loadParameters() {
    	JMSPublishConfig jmsPublishConfig = new JMSPublishConfig();
    	
    	jmsPublishConfig.set_noiUser(ConfigurationManager.get("NOI_USER"));
        if (ConfigurationManager.get("NOI_USER") == null)
        {
        	logger.error("NOI_USER property is null");
        }
        jmsPublishConfig.set__noiSystem(ConfigurationManager.get("NOI_SYSTEM"));
        if (ConfigurationManager.get("NOI_SYSTEM") == null)
        {
        	logger.error("NOI_SYSTEM property is null");
        }
        jmsPublishConfig.set_connFactoryStr(ConfigurationManager.
        		get("JMS_DESTINATION_CONN_FACTORY"));
        if (ConfigurationManager.get("JMS_DESTINATION_CONN_FACTORY") == null)
        {
        	logger.error("JMS_DESTINATION_CONN_FACTORY property is null");
        }
        jmsPublishConfig.set_queueStr(ConfigurationManager.get("JMS_DESTINATION_QUEUE"));
        if (ConfigurationManager.get("JMS_DESTINATION_QUEUE") == null)
        {
        	logger.error("JMS_DESTINATION_QUEUE property is null");
        }
        jmsPublishConfig.set_tibjmsInitalContextFactoryStr(ConfigurationManager.
        		get("JMS_DESTINATION_TIBJMS_INITIAL_CONTEXT_FACTORY"));
        if (ConfigurationManager.
        		get("JMS_DESTINATION_TIBJMS_INITIAL_CONTEXT_FACTORY") == null)
        {
        	logger.error("JMS_DESTINATION_TIBJMS_INITIAL_CONTEXT_FACTORY property is null");
        }
        jmsPublishConfig.set_providerURLStr(ConfigurationManager.
        		get("JMS_DESTINATION_PROVIDER_URL"));
        if (ConfigurationManager.
        		get("JMS_DESTINATION_PROVIDER_URL") == null)
        {
        	logger.error("JMS_DESTINATION_PROVIDER_URL property is null");
        }
        return jmsPublishConfig;
    }
    
	/** 
	 * Publish NOIs to JMS queue. 
	 * 
	 * @param byteArrayOutputStream XER encoded NOI message.
	 */
	private boolean doPublish(ByteArrayOutputStream byteArrayOutputStream) {
		return sendAndCommit(byteArrayOutputStream, _jmsPublishConfig);
	}
	

	
    
}
