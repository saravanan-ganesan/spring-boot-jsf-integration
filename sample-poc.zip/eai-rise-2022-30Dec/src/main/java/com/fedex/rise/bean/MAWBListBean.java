package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.tree2.TreeNode;
import org.apache.myfaces.renderkit.html.util.AddResource;
import org.apache.myfaces.renderkit.html.util.AddResourceFactory;
import org.springframework.stereotype.Component;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.util.Pageable;
import com.fedex.rise.util.PagedList;
import com.fedex.rise.util.SortableList;

/**
 * MAWB Summary List Backing bean
 */
@Component("mwabListBean")
public class MAWBListBean extends SortableList implements Serializable, Pageable {
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(MAWBListBean.class);
    
    private static final int PAGE_SIZE = 100;
    
    /** delegate to get shipment data */
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();
   
    

	/** list of shipments (MAWBBean) */
    private List _shipments = null;
    private transient DataModel _dataModel = null;
    
    //start WR#161572:RISE Performance Issue
    

    private boolean flag = false;
    
    private String trackingNo = null;

	private int crnCount = 0;

	/**
     * Getter for crnCount
     */
	public int getCrnCount() {
		return crnCount;
	}
	/**
     * Setter for crnCount
     */
	public void setCrnCount(int nCrnCount) {
		crnCount = nCrnCount;
	}

	/**
     * Getter for flag
     */
	public boolean isFlag() {
		return flag;
	}
	/**
     * setter for flag
     */
	public void setFlag(boolean bFlag) {
		flag = bFlag;
	}
	/**
     * Getter for trackingNo
     */
	
	 public String getTrackingNo() {
			return trackingNo;
	}
	 /**
     * setter for trackingNo
     */ 
	public void setTrackingNo(String strTrackingNo) {
			this.trackingNo = strTrackingNo;
	}
	//end WR#161572:RISE Performance Issue

	/**
     * Constructor
     */
    public MAWBListBean() {
        super("ship_dt");  // default sort column
    }

    
    // ==========================================================================
    // Getters
    // ==========================================================================
    
    /**
     * Get the MAWB data model list
     */
    public DataModel getData() {
        // shipments are cached here, and since we are request scope, and since getData() can be 
        // called multiple times, we only get from DB once.  And since we are request scope it is 
        // gotten fresh each request.
        if (_shipments == null) {
            _shipments = new PagedList(this, PAGE_SIZE);
        }
        
        _dataModel = new com.fedex.rise.util.ListDataModel(_shipments);
        return _dataModel;
    }

    /**
     * setData only called to update data if 'preservedatamodel=true' in dataTable on jsp
     * @param dataModel
     */
    public void setData(DataModel dataModel) {
        //log.debug("preserved datamodel updated");
        _dataModel = dataModel;
        
        // don't recreate shipment, because after saving state (dimwgt, invoice amt) we
        // want to re-populate the shipment list.
        //_shipments = (List)_dataModel.getWrappedData();
    }
   
    /*-----------------------------------------------------------------------
     * Methods for call back from PagedList 
     *-----------------------------------------------------------------------
     */
   
    /**
     * Get the specified page from the backend/database for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getPage(int, int)
     */
    public List getPage(int page, int pageSize) {
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        MonitorTreeBean _monitorTreeBean = (MonitorTreeBean)params.get("monitorTreeBean");
        TreeNode node = _monitorTreeBean.getSelectedNode();
               
        if (node == null) 
            return null;
            
        String nodeId = node.getIdentifier();
        String[] nodes = nodeId.split(":");
        String shipper = nodes[0].trim();
        String accountNbr = nodes[1].trim();
        String lane = nodes[2].trim();
        String serviceTypeCd = nodes[3].trim();
        String issuesOrAll = nodes[4].trim();
       
        int shipDateOffsetInt = 0;
        if (_monitorTreeBean.getShipDateOffsetStr()!=null){
        	shipDateOffsetInt = Integer.valueOf(
        			_monitorTreeBean.getShipDateOffsetStr()).intValue();
        }
        
        int shipperNbr = Integer.valueOf(shipper).intValue();
        int laneNbr = Integer.valueOf(lane).intValue();
    
        int startIndex = (page-1) * pageSize;
        int endIndex = (page * pageSize);
          
        List shipments=null;
//        if (issuesOrAll.equals("All")) 
////            shipments = shipmentDelegate.getShipments(shipperNbr, accountNbr, 
////            		laneNbr, serviceTypeCd, false, startIndex, endIndex, getSort(), 
//            		isAscending(), shipDateOffsetInt);
//        else  // get shipments with issues only
//            shipments = shipmentDelegate.getShipmentsWithIssues(shipperNbr, 
//            		accountNbr, laneNbr, serviceTypeCd, startIndex, endIndex, 
//            		getSort(), isAscending(), shipDateOffsetInt);
        return shipments;
    }
    

    /**
     * New method added for WR#161572:RISE Performance Issue
     * Get the CRN count to display in a pop-up window 
     * for particular tracking number for the selected tree node.
     * 
     */
public String getCRNCountOnClickHereLink() {
		
		log.debug("WR#161572: Entered getCRNCountOnClickHereLink() in MAWBListBean");

		FacesContext context = FacesContext.getCurrentInstance();
		Map requestParams = context.getExternalContext()
				.getRequestParameterMap();
		Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		
		String strTrackingNbr = (String) requestParams.get("trkng_item_nbr");
		String strTrackingUniqNbr = (String) requestParams.get("trkng_item_uniq_nbr");
		String strIssues_Only = (String) requestParams.get("issuesOnly");
		boolean bIssuesOnly = Boolean.parseBoolean(strIssues_Only);

		//If Tracking no and Tracking unique no are not null then 
		//fetch the CRN count for that tracking no and unique tracking no		
		
		if (strTrackingNbr != null && strTrackingUniqNbr != null) {
//			int crnCountValue = shipmentDelegate.getCrnCount(strTrackingNbr,
//					strTrackingUniqNbr, bIssuesOnly, null);
//
//			this.setCrnCount(crnCountValue);
			flag = bIssuesOnly;
			this.setTrackingNo(strTrackingNbr);
			
		}
		else{
			log.info("Could not fetch CRN count as tracking and " +
					"tracking unique no(s) is or are null");
		}

				 
		log.debug("exiting action getCRNCountOnClickHereLink()");
		return null;

	}
 


	/**
     * Get the size of the list of tracking numbers for the selected tree node.
     * @see com.fedex.rise.util.Pageable#getSize()
     */
    public int getSize() {
        int size = 0;
        
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        MonitorTreeBean _monitorTreeBean = (MonitorTreeBean)params.get("monitorTreeBean");
        TreeNode node = _monitorTreeBean.getSelectedNode();
               
        if (node == null) 
            return 0;
            
        String nodeId = node.getIdentifier();
        String[] nodes = nodeId.split(":");
        String shipper = nodes[0].trim();
        String accountNbr = nodes[1].trim();
        String lane = nodes[2].trim();
        String serviceTypeCd = nodes[3].trim();
        String issuesOrAll = nodes[4].trim();
        
        int shipDateOffsetInt = 0;
        if (_monitorTreeBean.getShipDateOffsetStr()!=null){
        	shipDateOffsetInt = Integer.valueOf(
        			_monitorTreeBean.getShipDateOffsetStr()).intValue();
        }
       
        int shipperNbr = Integer.valueOf(shipper).intValue();
        int laneNbr = Integer.valueOf(lane).intValue();
      
        boolean issuesOnly;
        if (issuesOrAll.equals("All")) 
            issuesOnly = false;
        else 
            issuesOnly = true;
        
//        size = shipmentDelegate.getShipmentsCount(shipperNbr, accountNbr, 
//        		laneNbr, serviceTypeCd, issuesOnly, shipDateOffsetInt);
        
        return size;
    }
    
    
    // ==========================================================================
    // Action methods
    // ==========================================================================

    /**
     * Save the DimWgt and Invoice amounts
     * @return navigation
     */
    public String save() {
        // assuming preserveDataModel=true in JSP, then we can just get from the model
        if (_dataModel.isRowAvailable()) {
            MawbBean mawbBean = (MawbBean)_dataModel.getRowData();
            if (!mawbBean.saveDimnlWgtAndInvAmt()) {
                FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,  "Error saving", null); 
                FacesContext facesContext = FacesContext.getCurrentInstance(); 
                facesContext.addMessage(null, facesMessage);
            }
                
            log.info("Save MAWB: " + mawbBean.getShipment().get_trkng_item_nbr());
        }
        
        // returning null so no navigation used and page is re-rendered, this keeps us
        // on the correct page (e.g. page 2 of 4).
        return null;  
    }
   
    

    
    // ==========================================================================
    // Navigation methods
    // ==========================================================================

    /**
     * Navigation to get the MAWB details
     * @return
     */
    public String getMAWBDetail() {
        FacesContext context = FacesContext.getCurrentInstance(); 
        Map requestParams = context.getExternalContext().getRequestParameterMap();
        
        String trackingNbr = (String)requestParams.get("trkng_item_nbr");
        String trackingUniqNbr = (String)requestParams.get("trkng_item_uniq_nbr");
        MawbBean _selectedMawbBean = new MawbBean(); //shipmentDelegate.getMAWB(trackingNbr, trackingUniqNbr);

        if (trackingNbr != null && trackingUniqNbr != null) {
            // tell the controller which bean is selected, because the controller is session scope,
            // but we are only request scope
            Map sessionParams = context.getExternalContext().getSessionMap();
            MonitorTreeBean _monitorTreeBean = (MonitorTreeBean)sessionParams.get("monitorTreeBean");
            _monitorTreeBean.setSelectedMAWB(_selectedMawbBean);
            
            //Start WR#:179441 Changes
            _monitorTreeBean.setCheckMawbDetailsPage(null);
            //End WR#:179441 Changes
            
            // navigate to the detail screen
            log.info("Select MAWB Detail: " + trackingNbr);
            return "showMawbDetail";
        } else {
            // shouldn't happen
            return null;
        }
    }
    

    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        if (sortColumn.equals("ship_dt"))
            return false; // sort descending by default on ship_dt
        else 
            return true; // sort ascending by default
    }
    
    protected void sort(final String column, final boolean ascending) {
        // sort handled by SQL in database, but we still need the column and ascending info
    }

    // ==========================================================================
    // Private Methods
    // ==========================================================================
   
    /*-----------------------------------------------------------------------
     * Utility methods
     *-----------------------------------------------------------------------
     */
   
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        shipmentDelegate = new ShipmentDelegate();
    }

    
}
