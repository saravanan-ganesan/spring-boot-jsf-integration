package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ShipmentCommentVO;

public class ShipmentCommentPersister extends OracleBase {

    private static Logger logger = LogManager.getLogger(ShipmentCommentPersister.class);
    
    public ShipmentCommentPersister(Connection con) {
        super(con);
    }
    
    private static final String insertShipmentCommentSQL =
            "Insert into Shipment_Comment(" +
            "TRKNG_ITEM_NBR," +       // VARCHAR2(12)
            "TRKNG_ITEM_UNIQ_NBR," +  // VARCHAR2(10)
            "COM_TMSTP," +            // DATE
            "EMP_NBR," +              // VARCHAR2(10)
            "COM_DESC," +            // VARCHAR2(2000)
            "INPUT_TMSTP," +
            "LAST_UPDT_TMSTP)" +
             "values(?,?,?,?,?, SYSDATE, SYSDATE)";        
      
    public void persist(ShipmentCommentVO aShipmentCommentVO) throws SQLException {
        try {
            setSqlSignature( insertShipmentCommentSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aShipmentCommentVO.get_trkng_item_nbr());
            pstmt.setString( 2, aShipmentCommentVO.get_trkng_item_uniq_nbr());
            java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentCommentVO.get_com_tmstp().getTime());
            pstmt.setTimestamp( 3, sqlDate);
            pstmt.setString( 4, aShipmentCommentVO.get_emp_nbr());
            pstmt.setString( 5, aShipmentCommentVO.get_com_desc());        
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }        
    
}

