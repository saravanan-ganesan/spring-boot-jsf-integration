package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.LaneServiceVO;

public class LaneServiceDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(LaneServiceDAO.class);
    
    public void addLaneService(LaneServiceVO anLaneServiceVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LaneServicePersister persister = new LaneServicePersister(connection);
            persister.addLaneService(anLaneServiceVO);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Add multiple services to an account, will determine which to add, update,
     * delete, based on what is already in the database
     * NOTE: must all be same shipperNbr, accountNbr, laneNbr!
     * @param aLaneServiceVOs
     * @throws SQLException
     * @throws ServiceLocatorException 
     */
    public void addLaneServices(List aLaneServiceVOs) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
          
            // get groupNbr, accountNbr, laneNbr, must be same on all in list!
            int groupNbr = ((LaneServiceVO)aLaneServiceVOs.get(0)).get_group_nbr();
            String accountNbr = ((LaneServiceVO)aLaneServiceVOs.get(0)).get_acct_nbr();
            int laneNbr = ((LaneServiceVO)aLaneServiceVOs.get(0)).get_lane_nbr();
            
            // first get existing lanes for this account
            LaneServiceAccessor laneServiceAccessor = new LaneServiceAccessor(connection);
            List existingServices = laneServiceAccessor.getLaneServices(groupNbr, accountNbr, laneNbr);
           
            LaneServicePersister persister = new LaneServicePersister(connection);
            LaneServiceUpdater updater = new LaneServiceUpdater(connection);
            
            // determine which are adds or updates
            for (Iterator itr=aLaneServiceVOs.iterator(); itr.hasNext(); ) {
                LaneServiceVO laneServiceVO = (LaneServiceVO)itr.next();
                boolean updateIt = false;
                for (Iterator itr2=existingServices.iterator(); itr2.hasNext(); ) {
                    LaneServiceVO existingLaneService = (LaneServiceVO)itr2.next();
                    if (existingLaneService.get_svc_type_cd().equals(laneServiceVO.get_svc_type_cd())) {
                        updateIt = true;
                        // remove from list so we don't iterate over it again and we
                        // can use remainder in list as our delete list
                        itr2.remove();  
                        break;
                    }
                }
                
                if (updateIt) {
                   // update lane
                   updater.updateLaneService(laneServiceVO);
                } else if (laneServiceVO.get_svc_type_cd() == null) {
                   // svc_type_cd of null is a dummy service, used to designate that there
                   // are no services to be assigned and any existing should be deleted
                } else {
                   // new so add it
                   persister.addLaneService(laneServiceVO);
                }
            }
            
            // remainder in existing list are our deletes
            LaneServiceDeleter deleter = new LaneServiceDeleter(connection);
            for (Iterator itr=existingServices.iterator(); itr.hasNext(); ) {
                LaneServiceVO laneSvcVO = (LaneServiceVO)itr.next();
                
                // we need to cascade deletes...
		        // so, delete all monitors at service level for this shipperNbr, accountNbr, and laneNbr, service
		        AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
		        acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(laneSvcVO.get_group_nbr(),
		                laneSvcVO.get_acct_nbr(), laneSvcVO.get_lane_nbr(), laneSvcVO.get_svc_type_cd());
		        
                deleter.deleteLaneService(laneSvcVO);
            }
        } finally {
            closeConnection(connection);
        }
    }
    
    public void updateLaneService(LaneServiceVO anLaneServiceVO) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LaneServiceUpdater persister = new LaneServiceUpdater(connection);
            persister.updateLaneService(anLaneServiceVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }    
   
    /**
     * Delete the specified service
     * @param anLaneServiceVO
     * @throws SQLException
     */
    public void deleteLaneService(LaneServiceVO anLaneServiceVO) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LaneServiceDeleter deleter = new LaneServiceDeleter(connection);
            deleter.deleteLaneService(anLaneServiceVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Delete all services for the specified groupNbr, accountNbr, laneNbr
     * @param groupNbr
     * @param accountNbr
     * @param laneNbr
     * @throws SQLException
     */
    public void deleteLaneServices(int groupNbr, String accountNbr, int laneNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LaneServiceDeleter deleter = new LaneServiceDeleter(connection);
            deleter.deleteLaneServices(groupNbr, accountNbr, laneNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }
    /**
     * Delete all services for the specified groupNbr, accountNbr
     * @param groupNbr
     * @param accountNbr
     * @throws SQLException
     */
    public void deleteLaneServices(int groupNbr, String accountNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            LaneServiceDeleter deleter = new LaneServiceDeleter(connection);
            deleter.deleteLaneServices(groupNbr, accountNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }
    
    public LaneServiceVO getLaneService(int groupNbr, String accountNbr, int laneNbr,
            String serviceTypeCd) throws SQLException {
        Connection connection = null;
        LaneServiceVO service = null;

        try {
            connection = initializeConnection();
            LaneServiceAccessor laneServiceAccessor 
            	= new LaneServiceAccessor(connection);
            service = laneServiceAccessor.getLaneService(groupNbr, accountNbr, laneNbr,
                    serviceTypeCd);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return service;
    }
    
    public List getLaneServices(int groupNbr, String accountNbr, int laneNbr) throws SQLException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            LaneServiceAccessor laneServiceAccessor 
            	= new LaneServiceAccessor(connection);
            list = laneServiceAccessor.getLaneServices(groupNbr, accountNbr, laneNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return list;
    }
    
    public List getLaneServiceTable() throws SQLException {
        Connection connection = null;
        List list = null;

        try {
            connection = initializeConnection();
            LaneServiceAccessor laneServiceAccessor 
            	= new LaneServiceAccessor(connection);
            list = laneServiceAccessor.getLaneServiceTable();
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return list;
    }
}
