package com.fedex.rise.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ACCOUNT_GROUP")
public class AccountGroupEntity {
	
	@Id
	@Column(name = "GROUP_NBR")
	private String grpNumber; // Track type
	
	@Column(name = "GROUP_NM")
	private String grpName; // Exception cd

	@Column(name = "GROUP_DESC")
	private String grpDesc;
	
	@Column(name = "INPUT_TMSTP")
	private Instant inputTmstp;
	
	@Column(name = "LAST_UPDT_TMSTP")
	private Instant lastUpdtTmstp;

}
