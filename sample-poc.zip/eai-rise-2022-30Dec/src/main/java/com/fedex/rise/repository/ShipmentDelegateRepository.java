package com.fedex.rise.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fedex.rise.constant.QueryConstant;
import com.fedex.rise.entity.IssueEntity;

@Repository
public interface ShipmentDelegateRepository extends JpaRepository<IssueEntity, Integer> {

	@Query(value = QueryConstant.GET_FILTER_BY_ISSUES)
	public List<Integer> getFilterByIssues();
	
	@Query(value = QueryConstant.GET_FILTER_BY_ISSUES_DETAILS, nativeQuery=true)
	public List getFilterByIssuesDetails(int dateValue, List<Integer> issueCodes);
	
}
