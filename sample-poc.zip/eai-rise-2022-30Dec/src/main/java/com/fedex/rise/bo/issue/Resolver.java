package com.fedex.rise.bo.issue;

import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public abstract class Resolver {

   public abstract boolean isResolved(EventVO anEventVO, IssueVO anIssueVO);
    
}
