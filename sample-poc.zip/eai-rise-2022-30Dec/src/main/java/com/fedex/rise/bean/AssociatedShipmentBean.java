package com.fedex.rise.bean;

import java.io.Serializable;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.AssociatedShipmentVO;

public class AssociatedShipmentBean implements Serializable {

    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;             
    private String _trkng_item_uniq_nbr;         
    private String _assoc_trkng_item_nbr;       
    private String _assoc_trkng_item_uniq_nbr;  
    private char   _assoc_track_type_cd;       
    
    public AssociatedShipmentBean () {}
    
    public AssociatedShipmentBean(AssociatedShipmentVO anAssociatedShipmentVO) {
        _trkng_item_nbr =  anAssociatedShipmentVO.get_trkng_item_nbr();   
        _trkng_item_uniq_nbr = anAssociatedShipmentVO.get_trkng_item_uniq_nbr();         
        _assoc_trkng_item_nbr = anAssociatedShipmentVO.get_assoc_trkng_item_nbr();       
        _assoc_trkng_item_uniq_nbr = anAssociatedShipmentVO.get_assoc_trkng_item_uniq_nbr();  
        _assoc_track_type_cd = anAssociatedShipmentVO.get_assoc_track_type_cd();         
    }
    
    public String getAssocTrackTypeDesc() {
        if (_assoc_track_type_cd == RiseConstants.PAPERWORK) {
            return "PWRK";
        } else {
            if (_assoc_track_type_cd == RiseConstants.RETURN) {
                return "RTRN";
            } else {
                if (_assoc_track_type_cd == RiseConstants.PARENT) {
                    return "PARNT";
                }
            }
        }
        return null;
    }
    
    /**
     * @return the _assoc_track_type_cd
     */
    public char get_assoc_track_type_cd() {
        return _assoc_track_type_cd;
    }
    /**
     * @param _assoc_track_type_cd the _assoc_track_type_cd to set
     */
    public void set_assoc_track_type_cd(char _assoc_track_type_cd) {
        this._assoc_track_type_cd = _assoc_track_type_cd;
    }
    /**
     * @return the _assoc_trkng_item_nbr
     */
    public String get_assoc_trkng_item_nbr() {
        return _assoc_trkng_item_nbr;
    }
    /**
     * @param _assoc_trkng_item_nbr the _assoc_trkng_item_nbr to set
     */
    public void set_assoc_trkng_item_nbr(String _assoc_trkng_item_nbr) {
        this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
    }
    /**
     * @return the _assoc_trkng_item_uniq_nbr
     */
    public String get_assoc_trkng_item_uniq_nbr() {
        return _assoc_trkng_item_uniq_nbr;
    }
    /**
     * @param _assoc_trkng_item_uniq_nbr the _assoc_trkng_item_uniq_nbr to set
     */
    public void set_assoc_trkng_item_uniq_nbr(String _assoc_trkng_item_uniq_nbr) {
        this._assoc_trkng_item_uniq_nbr = _assoc_trkng_item_uniq_nbr;
    }
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }
        
}
