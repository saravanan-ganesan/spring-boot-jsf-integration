package com.fedex.rise.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.repository.SearchDelegateRepository;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.ShipmentEmployeeVO;


@Service
public class SearchDelegateServiceImpl implements SearchDelegateService {

	@Autowired
	SearchDelegateRepository searchDelegateRepository;

	@Override
	public List<ShipmentEmployeeVO> searchByShprNm(String aShprNm) {
		List<ShipmentEmployeeVO> searchResults = new ArrayList<ShipmentEmployeeVO>();
		ShipmentEmployeeVO shipmentemployeeVO = null;
		List<Object> obj = searchDelegateRepository.searchByShipperName(aShprNm);
		if(null != obj && obj.size()!=0) {
			if(null != obj.get(0)) {
				Object[] resultSet = (Object[]) obj.get(0);
				shipmentemployeeVO = new ShipmentEmployeeVO();
				shipmentemployeeVO.set_grp_nm(null !=resultSet[0]?resultSet[0].toString():"");
				shipmentemployeeVO.set_acct_nm(null !=resultSet[1]?resultSet[1].toString():"");
				shipmentemployeeVO.set_acct_nbr(null !=resultSet[2]?resultSet[2].toString():"");
				shipmentemployeeVO.set_shpr_cntry_cd(null !=resultSet[3]?resultSet[3].toString():"");
				shipmentemployeeVO.set_recp_cntry_cd(null !=resultSet[4]?resultSet[4].toString():"");
		    	shipmentemployeeVO.set_svc_type_cd(null !=resultSet[5]?resultSet[5].toString():"");
		    	shipmentemployeeVO.set_emp_first_nm(null !=resultSet[6]?resultSet[6].toString():"");
		    	shipmentemployeeVO.set_emp_last_nm(null !=resultSet[7]?resultSet[7].toString():"");
		    	shipmentemployeeVO.set_emp_nbr(null !=resultSet[8]?resultSet[8].toString():"");
			}
			searchResults.add(shipmentemployeeVO);
		}
		return searchResults;
	}

	@Override
	public List<ShipmentEmployeeVO> searchByAcctNbr(String aAcctNbr) {
		StringBuffer accountNbr= new StringBuffer("%").append(aAcctNbr.toUpperCase()).append("%");
		List<ShipmentEmployeeVO> searchResults = new ArrayList<ShipmentEmployeeVO>();
		ShipmentEmployeeVO shipmentemployeeVO = null;
		List<Object> obj = searchDelegateRepository.searchByAcctNbr(accountNbr.toString());
		if(null != obj && obj.size()!=0) {
			if(null != obj.get(0)) {
				Object[] resultSet = (Object[]) obj.get(0);
				shipmentemployeeVO = new ShipmentEmployeeVO();
				shipmentemployeeVO.set_grp_nm(null !=resultSet[0]?resultSet[0].toString():"");
				shipmentemployeeVO.set_acct_nm(null !=resultSet[1]?resultSet[1].toString():"");
				shipmentemployeeVO.set_acct_nbr(null !=resultSet[2]?resultSet[2].toString():"");
				shipmentemployeeVO.set_shpr_cntry_cd(null !=resultSet[3]?resultSet[3].toString():"");
				shipmentemployeeVO.set_recp_cntry_cd(null !=resultSet[4]?resultSet[4].toString():"");
		    	shipmentemployeeVO.set_svc_type_cd(null !=resultSet[5]?resultSet[5].toString():"");
		    	shipmentemployeeVO.set_emp_first_nm(null !=resultSet[6]?resultSet[6].toString():"");
		    	shipmentemployeeVO.set_emp_last_nm(null !=resultSet[7]?resultSet[7].toString():"");
		    	shipmentemployeeVO.set_emp_nbr(null !=resultSet[8]?resultSet[8].toString():"");
			}
			searchResults.add(shipmentemployeeVO);
		}
		return searchResults;
	}

	@Override
	public List<ShipmentEmployeeVO> searchByTrkngNbr(String aTrkngNbr) {
		List<ShipmentEmployeeVO> searchResults = new ArrayList<ShipmentEmployeeVO>();
		ShipmentEmployeeVO shipmentemployeeVO = null;
		List<Object> obj = searchDelegateRepository.searchByTrkngNbr(aTrkngNbr.toString());
		if(null != obj && obj.size()!=0) {
			if(null != obj.get(0)) {
				Object[] resultSet = (Object[]) obj.get(0);
				shipmentemployeeVO = new ShipmentEmployeeVO();
				shipmentemployeeVO.set_trkng_item_nbr(null !=resultSet[0]?resultSet[0].toString():"");
				shipmentemployeeVO.set_trkng_item_uniq_nbr(null !=resultSet[1]?resultSet[1].toString():"");
				
				shipmentemployeeVO.set_grp_nm(null !=resultSet[0]?resultSet[0].toString():"");
				shipmentemployeeVO.set_acct_nm(null !=resultSet[1]?resultSet[1].toString():"");
				shipmentemployeeVO.set_acct_nbr(null !=resultSet[2]?resultSet[2].toString():"");
				shipmentemployeeVO.set_shpr_cntry_cd(null !=resultSet[3]?resultSet[3].toString():"");
				shipmentemployeeVO.set_recp_cntry_cd(null !=resultSet[4]?resultSet[4].toString():"");
		    	//shipmentemployeeVO.set_svc_type_cd(null !=resultSet[5]?resultSet[5].toString():"");
		    	shipmentemployeeVO.set_emp_first_nm(null !=resultSet[6]?resultSet[6].toString():"");
		    	shipmentemployeeVO.set_emp_last_nm(null !=resultSet[7]?resultSet[7].toString():"");
		    	shipmentemployeeVO.set_emp_nbr(null !=resultSet[8]?resultSet[8].toString():"");
			}
			searchResults.add(shipmentemployeeVO);
		}
		return searchResults;
	}

	@Override
	public List<Object> searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu,
			Date _limitOneWeekFromDate, Date _limitOneWeekToDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber,
			Date _limitOneWeekFromDateByMAWBTrackingNumber, String sortColumn, boolean isSortAscending, int startIndex,
			int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName,
			Date _limitOneWeekFromDateByMAWBShipperName, String sortColumn, boolean isSortAscending, int startIndex,
			int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN, String aAcctNbrCRN,
			Date _toDate4, Date _fromDate4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByReturnTrkngNbr(String aReturnTrkngNbr, String sortColumn, boolean isSortAscending,
			int startIndex, int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName,
			Date _limitOneWeekFromDateByCRNRecipientName, String sortColumn, boolean isSortAscending, int startIndex,
			int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2,
			String aSelectedLane2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode,
			Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, String sortColumn,
			boolean isSortAscending, int startIndex, int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> rampHubSearch(Date _shipDate, String _selectMenu, String aClearancePoint, String sortColumn,
			boolean isSortAscending, int startIndex, int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByFindMonitorAcctNbr(String aAcctNbr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByFindMonitorTrkngNbr(String aTrackingNbr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByWithODACRN(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA,
			Date _limitOneWeekToDateByCRNWithODA, String sortColumn, boolean isSortAscending, int startIndex,
			int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByFindMissingData(String aAcctNbr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByAddressCRN(String aAddressLineOne, String aAddressCityName,
			String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress,
			Date _limitOneWeekFromDateByCRNRecipientAddress, String sortColumn, boolean isSortAscending, int startIndex,
			int endIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> searchByShipDateRange(Date _limitOneWeekToDate3, Date _limitOneWeekFromDate3,
			String aServiceCode, String aAcctNbrMAWB3, String aSelectedLane, String sortColumn, boolean ascending) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getCRNShipmentsCountReturnTrackingNumber(String returnTrkngNbr) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCRNShipmentsCountRecipientName(String recipientName, Date limitOneWeekToDateByCRNRecipientName,
			Date limitOneWeekFromDateByCRNRecipientName) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCRNShipmentsCountWithODA(String acctNbr, Date limitOneWeekToDateByCRNWithODA,
			Date limitOneWeekFromDateByCRNWithODA) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCRNShipmentsCountRecipientPostalCode(String postalCode,
			Date limitOneWeekToDateByCRNRecipientPostalCode, Date limitOneWeekFromDateByCRNRecipientPostalCode) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCRNShipmentsCountRecipientAddress(String addressLineOne, String addressCityName,
			String addressStateProvince, String addressPostalCode, Date limitOneWeekToDateByCRNRecipientAddress,
			Date limitOneWeekFromDateByCRNRecipientAddress) {
		// TODO Auto-generated method stub
		return 0;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<EmployeeVO> getSearchByAll() {
		
		List list = searchDelegateRepository.getSearchByAll();
		
		if(!ObjectUtils.isEmpty(list)) {
			
			List<EmployeeVO> employeeVOList = new ArrayList<>();
			
			for(int i = 0; i < list.size(); i++) {
				
				Object object = list.get(i);
				if(object instanceof Object[]) {
					Object[] objArr = (Object[]) object;
					EmployeeVO employeeVO = new EmployeeVO();
					employeeVO.set_emp_nbr(objArr[0].toString());
					employeeVO.set_emp_first_nm(objArr[1].toString());
					employeeVO.set_emp_last_nm(objArr[2].toString());
					employeeVOList.add(employeeVO);
				}
				
			}
			
			return employeeVOList;
		}
		return null;
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<EmployeeVO> searchByGroupLaneNbr(int groupNbr, int laneNbr) {
		
		List list = searchDelegateRepository.searchByGroupLaneNbr(groupNbr, laneNbr);
		
		if(!ObjectUtils.isEmpty(list)) {
			
			List<EmployeeVO> employeeVOList = new ArrayList<>();
			
			list.forEach(x -> {
				if(x instanceof Object[]) {
					Object[] objArr = (Object[]) x;
					EmployeeVO employeeVO = new EmployeeVO();
					employeeVO.set_emp_nbr(objArr[0].toString());
					employeeVOList.add(employeeVO);
				}
			});
			return employeeVOList;
		}

		return null;
	}
}
