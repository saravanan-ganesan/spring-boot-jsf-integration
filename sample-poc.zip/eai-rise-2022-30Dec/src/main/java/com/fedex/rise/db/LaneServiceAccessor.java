package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.LaneServiceVO;

  public class LaneServiceAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(LaneServiceAccessor.class);
    
    public LaneServiceAccessor(Connection con) {
        super(con);
    }
            
    private final String selectLaneServiceSQL = "select " +
        "SVC_TYPE_CD, " +
        "LANE_NBR, " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "COMMIT_DAYS_QTY, " +
        "PRIM_CONT_NM, " +
        "PRIM_CONT_PH_NBR, " +
        "PRIM_CONT_FAX_NBR, " +
        "PRIM_CONT_EMAIL_DESC, " +
        "SCNDY_CONT_NM, " +
        "SCNDY_CONT_PH_NBR, " +
        "SCNDY_CONT_FAX_NBR, " +
        "SCNDY_CONT_EMAIL_DESC, " +
        "PICKUP_DAY_GRP, " +
        "LIFT_DAY_GRP " +
         "from Lane_Service where SVC_TYPE_CD = ? and LANE_NBR = ? and GROUP_NBR = ? and ACCT_NBR = ?";            
            
    public LaneServiceVO getLaneService(int groupNbr, String accountNbr, int laneNbr, 
            String serviceTypeCd) throws SQLException {
                
        LaneServiceVO laneServiceVO = null;
        try {
            setSqlSignature( selectLaneServiceSQL, false, logger.isDebugEnabled() );
            
            pstmt.setString( 1, serviceTypeCd);
            pstmt.setInt( 2, laneNbr);
            pstmt.setInt   ( 3, groupNbr);
            pstmt.setString( 4, accountNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                if (rs.next()) { // should only be one
                    laneServiceVO = new LaneServiceVO();
                        
                    laneServiceVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
                    laneServiceVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                    laneServiceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    laneServiceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    laneServiceVO.set_commit_days_qty(rs.getString("COMMIT_DAYS_QTY"));
                    laneServiceVO.set_prim_cont_nm(rs.getString("PRIM_CONT_NM"));
                    laneServiceVO.set_prim_cont_ph_nbr(rs.getString("PRIM_CONT_PH_NBR"));
                    laneServiceVO.set_prim_cont_fax_nbr(rs.getString("PRIM_CONT_FAX_NBR"));
                    laneServiceVO.set_prim_cont_email_desc(rs.getString("PRIM_CONT_EMAIL_DESC"));
                    laneServiceVO.set_scndy_cont_nm(rs.getString("SCNDY_CONT_NM"));
                    laneServiceVO.set_scndy_cont_ph_nbr(rs.getString("SCNDY_CONT_PH_NBR"));
                    laneServiceVO.set_scndy_cont_fax_nbr(rs.getString("SCNDY_CONT_FAX_NBR"));
                    laneServiceVO.set_scndy_cont_email_desc(rs.getString("SCNDY_CONT_EMAIL_DESC"));
                    laneServiceVO.set_pickup_day_grp(rs.getString("PICKUP_DAY_GRP").charAt(0));
                    laneServiceVO.set_lift_day_grp(rs.getString("LIFT_DAY_GRP").charAt(0));
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return laneServiceVO;
    }

    private final String selectLaneServicesSQL = "select " +
        "SVC_TYPE_CD, " +
        "LANE_NBR, " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "COMMIT_DAYS_QTY, " +
        "PRIM_CONT_NM, " +
        "PRIM_CONT_PH_NBR, " +
        "PRIM_CONT_FAX_NBR, " +
        "PRIM_CONT_EMAIL_DESC, " +
        "SCNDY_CONT_NM, " +
        "SCNDY_CONT_PH_NBR, " +
        "SCNDY_CONT_FAX_NBR, " +
        "SCNDY_CONT_EMAIL_DESC, " +
        "PICKUP_DAY_GRP, " +
        "LIFT_DAY_GRP " +
         "from Lane_Service where GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ?";
            
    public List getLaneServices(int groupNbr, String accountNbr, int laneNbr) throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectLaneServicesSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, groupNbr);
            pstmt.setString( 2, accountNbr);
            pstmt.setInt   ( 3, laneNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    LaneServiceVO laneServiceVO = new LaneServiceVO();
                        
                    laneServiceVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
                    laneServiceVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                    laneServiceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    laneServiceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    laneServiceVO.set_commit_days_qty(rs.getString("COMMIT_DAYS_QTY"));
                    laneServiceVO.set_prim_cont_nm(rs.getString("PRIM_CONT_NM"));
                    laneServiceVO.set_prim_cont_ph_nbr(rs.getString("PRIM_CONT_PH_NBR"));
                    laneServiceVO.set_prim_cont_fax_nbr(rs.getString("PRIM_CONT_FAX_NBR"));
                    laneServiceVO.set_prim_cont_email_desc(rs.getString("PRIM_CONT_EMAIL_DESC"));
                    laneServiceVO.set_scndy_cont_nm(rs.getString("SCNDY_CONT_NM"));
                    laneServiceVO.set_scndy_cont_ph_nbr(rs.getString("SCNDY_CONT_PH_NBR"));
                    laneServiceVO.set_scndy_cont_fax_nbr(rs.getString("SCNDY_CONT_FAX_NBR"));
                    laneServiceVO.set_scndy_cont_email_desc(rs.getString("SCNDY_CONT_EMAIL_DESC"));
                    laneServiceVO.set_pickup_day_grp(rs.getString("PICKUP_DAY_GRP").charAt(0));
                    laneServiceVO.set_lift_day_grp(rs.getString("LIFT_DAY_GRP").charAt(0));
                    
                    al.add(laneServiceVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    
    private final String selectLaneServiceTableSQL = "select " +
    	"SVC_TYPE_CD, " +
    	"LANE_NBR, " +
    	"GROUP_NBR, " +
    	"ACCT_NBR, " +
    	"COMMIT_DAYS_QTY, " +
    	"PRIM_CONT_NM, " +
    	"PRIM_CONT_PH_NBR, " +
    	"PRIM_CONT_FAX_NBR, " +
    	"PRIM_CONT_EMAIL_DESC, " +
    	"SCNDY_CONT_NM, " +
    	"SCNDY_CONT_PH_NBR, " +
    	"SCNDY_CONT_FAX_NBR, " +
    	"SCNDY_CONT_EMAIL_DESC, " +
    	"PICKUP_DAY_GRP, " +
    	"LIFT_DAY_GRP " +
    		"from Lane_Service";            
        
    public List getLaneServiceTable() throws SQLException {
    	ArrayList al = new ArrayList(); 
            
    	try {
    		setSqlSignature( selectLaneServiceTableSQL, false, logger.isDebugEnabled() );
        

        if (logger.isDebugEnabled()) {
            logger.debug(pstmt.toString());
        }
            
        execute();

        if ( hasResults ) {
                   
            while(rs.next()) {
                LaneServiceVO laneServiceVO = new LaneServiceVO();
                    
                laneServiceVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
                laneServiceVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                laneServiceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                laneServiceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                laneServiceVO.set_commit_days_qty(rs.getString("COMMIT_DAYS_QTY"));
                laneServiceVO.set_prim_cont_nm(rs.getString("PRIM_CONT_NM"));
                laneServiceVO.set_prim_cont_ph_nbr(rs.getString("PRIM_CONT_PH_NBR"));
                laneServiceVO.set_prim_cont_fax_nbr(rs.getString("PRIM_CONT_FAX_NBR"));
                laneServiceVO.set_prim_cont_email_desc(rs.getString("PRIM_CONT_EMAIL_DESC"));
                laneServiceVO.set_scndy_cont_nm(rs.getString("SCNDY_CONT_NM"));
                laneServiceVO.set_scndy_cont_ph_nbr(rs.getString("SCNDY_CONT_PH_NBR"));
                laneServiceVO.set_scndy_cont_fax_nbr(rs.getString("SCNDY_CONT_FAX_NBR"));
                laneServiceVO.set_scndy_cont_email_desc(rs.getString("SCNDY_CONT_EMAIL_DESC"));
                String pickupDayGrp = rs.getString("PICKUP_DAY_GRP");
                if (pickupDayGrp != null) {
                    laneServiceVO.set_pickup_day_grp(pickupDayGrp.charAt(0));
                }
                String liftDayGrp = rs.getString("LIFT_DAY_GRP");
                if (liftDayGrp != null) {
                    laneServiceVO.set_lift_day_grp(liftDayGrp.charAt(0));
                }
                
                al.add(laneServiceVO);
            }
        } else {
            return null;
        }
    	} catch (SQLException sqle) {
    		logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
    	} finally {
    		try {
    			cleanResultSet();
    		} catch (SQLException sqle2) {
    			logger.warn(sqle2.getMessage(), sqle2);
    		}
    	}
    	return al;
    }
}
