package com.fedex.rise.webejb;

/**
 * 
 * @ejb:bean name="SystemMessageBean" display-name="SystemMessageEJB" jndi-name="SystemMessageEJB"
 *           local-jndi-name="LocalSystemMessageEJB" type="Stateless"
 *           view-type="both"
 * 
 * @ejb:home extends="javax.ejb.EJBHome"
 *           local-extends="javax.ejb.EJBLocalHome"
 * 
 * @ejb:interface extends="javax.ejb.EJBObject"
 *                local-extends="javax.ejb.EJBLocalObject"
 * 
 * @weblogic.enable-call-by-reference True
 * 
 * @weblogic.pool max-beans-in-free-pool="10" 
 * initial-beans-in-free-pool="3"
 * 
 * @ejb.transaction type="Supports"
 */
/**
* SystemMessageEJB
* This class implements the EJB which is accessible via the JSPs. It is a
* stateless SessionBean. This class implements the facade for the Business
* Objects and or Data Access Objects. All EJB/J2EE related things should be
* implemented here leaving the BO's with no knowledge of the EJB/J2EE
* environment.
*/
//@JndiName(remote="webejb/SystemMessageEJBRemote")
//@Session(ejbName = "SystemMessageEJB",
//        maxBeansInFreePool="3",
//        initialBeansInFreePool="1",
//        type = Session.SessionType.STATELESS,
//        defaultTransaction=Constants.TransactionAttribute.SUPPORTS,
//        transactionType=Session.SessionTransactionType.BEAN,
//        enableCallByReference=Constants.Bool.TRUE)
public class SystemMessageEJB { //implements SessionBean {
//
//    private static final long serialVersionUID = 1L;
//
//    /** Logger */
//    private static Logger logger = LogManager.getLogger(SystemMessageEJB.class);
//    
//    private SessionContext mySessionContext = null;
//
//    public SessionContext getSessionContext() {
//        return mySessionContext;
//    }
//
//    public void setSessionContext(SessionContext aSessionContext)
//            throws RemoteException {
//        mySessionContext = aSessionContext;
//    }
//
//    public void ejbActivate() {
//        System.out.println("Activate SystemMessageEJB");
//    }
//
//    public void ejbPassivate() {
//        System.out.println("Passivate SystemMessageEJB");
//    }
//
//    /**
//     * @ejb:create-method
//     */
//    public void ejbCreate() {
//        System.out.println("EJB Create SystemMessageEJB");
//    }
//
//    /**
//     * @ejb:remove-method
//     */
//    public void ejbRemove() { 
//        System.out.println("EJB Remove SystemMessageEJB");
//    }
//
//    /**
//     * Persist a system message
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public void persistSystemMessage(SystemMessageVO aVO) throws SQLException, ServiceLocatorException {
//        SystemMessageBO systemMessageBO = new SystemMessageBO();
//        systemMessageBO.persistSystemMessage(aVO);
//    }
//
//    /**
//     * Get system messages
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getSystemMessages() throws SQLException, ServiceLocatorException {
//        SystemMessageBO systemMessageBO = new SystemMessageBO();
//        return systemMessageBO.getSystemMessages();        
//    }
// 
//    /**
//     * Update a system message
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public void updateSystemMessage(SystemMessageVO aVO) throws SQLException, ServiceLocatorException  {
//        SystemMessageBO systemMessageBO = new SystemMessageBO();
//        systemMessageBO.updateSystemMessage(aVO);
//    }
//    
//    /**
//     * Delete a system message
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public void deleteSystemMessage(int aMsgNbr) throws SQLException, ServiceLocatorException  {
//        SystemMessageBO systemMessageBO = new SystemMessageBO();
//        systemMessageBO.deleteSystemMessage(aMsgNbr);
//    }
// 
}
