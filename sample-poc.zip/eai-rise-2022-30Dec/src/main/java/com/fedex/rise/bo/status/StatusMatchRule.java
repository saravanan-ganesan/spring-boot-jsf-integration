package com.fedex.rise.bo.status;

public class StatusMatchRule {

    String trackTypeCd;
    String exceptionCd;
    StatusCriteria addtlMatchCriteria;
    
    public StatusMatchRule(String aTrackTypeCd, String anExceptionCd, StatusCriteria aStatusCriteria ) {
        trackTypeCd = aTrackTypeCd;
        exceptionCd = anExceptionCd;
        addtlMatchCriteria = aStatusCriteria;
    }
    
}
