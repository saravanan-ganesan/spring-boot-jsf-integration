package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public class STAT17Resolver extends Resolver {

    private static ArrayList _scans = new ArrayList();
    
    private static STAT17Resolver _instance = new STAT17Resolver();

    static {
        // Scans of interest
        _scans.add(RiseConstants.STAT);        
    };
  
    private STAT17Resolver() {};
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        if ((_scans.contains(anEventVO.get_track_type_cd())) && 
        		anEventVO.get_track_excp_cd().equalsIgnoreCase("17")||
            DeliveryResolver.getInstance().isResolved(anEventVO, anIssueVO)) {
            return true;
        }
        return false;
    }

    public static STAT17Resolver getInstance() {
        return _instance;
    }
    
}
