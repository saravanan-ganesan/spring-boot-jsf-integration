package com.fedex.rise.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.repository.ShipperDelegateRepository;
import com.fedex.rise.vo.AccountGroupVO;
import com.fedex.rise.vo.PerformanceVO;

@Service
@SuppressWarnings("rawtypes")
public class ShipperServiceImpl implements ShipperService {
	
	@Autowired
	ShipperDelegateRepository shipperDeligateRepository;
	

	@Override
	public List<AccountGroupVO> getAccountGroupNames() {
		
		List<?> allGroupNames = shipperDeligateRepository.getAccountGroups();
		
		List<AccountGroupVO> allGroupNamesVOList = new ArrayList<>();
		if (!ObjectUtils.isEmpty(allGroupNames)) {
			
			allGroupNames.forEach(grpNames -> {
				
				if (grpNames instanceof Object[]) {
					
					Object[] objArr = (Object[]) grpNames;

					AccountGroupVO accountGroupVO = new AccountGroupVO();
					if (objArr[0] != null)
						accountGroupVO.set_group_nbr(Integer.parseInt(objArr[0].toString()));
					if (objArr[1] != null)
						accountGroupVO.set_group_nm(objArr[1].toString());
					if (objArr[2] != null)
						accountGroupVO.set_group_desc(objArr[2].toString());

					allGroupNamesVOList.add(accountGroupVO);
				}
			});
		}
		return allGroupNamesVOList;
	}
	
	@Override
	public String getAccountGroupNamesByGrpNbr(String groupNbr) {
		
		String accountGroupName = null;
		List<AccountGroupVO> allGroupNames = getAccountGroupNames();
		
		if(!ObjectUtils.isEmpty(allGroupNames) && !ObjectUtils.isEmpty(groupNbr)) {
			
			allGroupNames.removeIf(groupName -> groupNbr.equalsIgnoreCase(String.valueOf(groupName.get_group_nbr())));
			if(!ObjectUtils.isEmpty(allGroupNames)) {
				accountGroupName = allGroupNames.get(0).get_group_nm();
			}
			
		}
		return accountGroupName;
	}


	@Override
	public List getAccountLanes(int aGroupNbr) {
		return shipperDeligateRepository.getAccountLanes(aGroupNbr);
	}


	@Override
	public List getLane(int LaneNbr) {
		return shipperDeligateRepository.getLane(LaneNbr);
	}


	@Override
	public List getLaneByGroupNbr(int groupNbr) {
		return shipperDeligateRepository.getLaneByGroupNbr(groupNbr);
	}

	@Override
	public String getLaneByLaneNbr(int laneNbr) {
		
		String groupName = null;
		List allLaneList = getAccountLanes(laneNbr);
		
		if (!ObjectUtils.isEmpty(allLaneList)) {
			
			for (Iterator itr = allLaneList.iterator(); itr.hasNext();) {
				
				Object object = (Object)itr.next();
				if(object instanceof Object[]) {
					Object[] objArr = (Object[])object;
					groupName = objArr[1].toString();
				}
			}
		}
		return groupName;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PerformanceVO> getPerformanceSum(String groupNbr, Date fromDate, 
    		Date toDate, String laneNbr, String empNbr) {
		
		List<PerformanceVO> performanceVOList = new ArrayList<>();
		if(!ObjectUtils.isEmpty(groupNbr) && groupNbr.equalsIgnoreCase("All")) {
			
			List selectPerformanceSumOfAllGroupLaneListByEmpList = shipperDeligateRepository.selectPerformanceSumOfAllGroupLaneListByEmp(fromDate, toDate, empNbr);
			if(!ObjectUtils.isEmpty(selectPerformanceSumOfAllGroupLaneListByEmpList)) {
				
				selectPerformanceSumOfAllGroupLaneListByEmpList.forEach(x -> {
					
					if(x instanceof Object[]) {
						Object[] objArr = (Object[]) x;
						PerformanceVO performanceVO = new PerformanceVO();
						performanceVO.set_total_mawb_qty(Long.valueOf(objArr[0].toString()));
						performanceVO.set_total_crn_qty(Long.valueOf(objArr[1].toString()));
						performanceVO.set_on_time_crn_qty(Long.valueOf(objArr[2].toString()));
						performanceVO.set_late_crn_qty(Long.valueOf(objArr[3].toString()));
						performanceVO.set_excus_crn_qty(Long.valueOf(objArr[4].toString()));
						performanceVO.set_oda_crn_qty(Long.valueOf(objArr[5].toString()));
						performanceVO.set_no_pod_crn_qty(Long.valueOf(objArr[6].toString()));
						performanceVO.set_total_wgt_amt(Long.valueOf(objArr[7].toString()));
						performanceVO.set_total_inv_value_amt(Long.valueOf(objArr[8].toString()));
						performanceVOList.add(performanceVO);
					}
				}); 
			}
			return performanceVOList;
		}
		return null;
	}

}
