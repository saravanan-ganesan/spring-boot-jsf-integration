package com.fedex.rise.bo.issue;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.bo.issue.DeliveryPreventer;
import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.xref.TrackDesc;
import com.fedex.rise.xref.TrackTypes;

/**
 * Issues are stored in the database in the Issue table.  Issue are created and resolved
 * base on arriving events.  To define an issue, you must assign it a value to be
 * stored in the database, then you must add it to the IssueList, and then define
 * how it will be resolved in the ResolveList.
 * Find the text ADDEVENT in the code below to find key areas of how to add issues
 *
 */
public class RiseIssues {
    private static Logger logger = LogManager.getLogger(RiseIssues.class);
    
    // Used in table below to describe if the rule applies to a shipment,
    // which is a MAWB, CRN or UNK
    public final static char MAWB = 'M';
    public final static char CRN = 'C';
    public final static char UNK = 'U';
    
    // A list of rules for resolving issues
    protected static HashMap resolveList = new HashMap();    
    
    // A list of rules for preventing issues from being created.
    protected static HashMap preventionList = new HashMap();
    
    // Maps issue codes to descriptions
    protected static HashMap issueDescList = new HashMap();
    
    // Maps short description to list of related issue codes
    protected static HashMap issueCdsByDescList = new HashMap();
    
    // Maps short issue type to list of related issue type codes
    protected static HashMap issueTypeCdsList = new HashMap();

    // Used in table below to define the time period in which an
    // issue becomes "real"
    protected final static int IMMEDIATE = -1;
    protected final static int ADD_HRS_TO_EVENT = 0;
    protected final static int MIDNIGHT = 1;
    protected final static int ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT = 2;
    
    // These codes define a issue and are stored in the Issue table in the
    // database.  Please follow naming convention:
    // Event, MAWB/CRN/UNK, description
    private final static int MIN_ISSUE_CD = 0;
    
    // ADDEVENT Add Issues which are driven by event here
    private final static int PUP_MAWB_MSSNG_MDE = MIN_ISSUE_CD;
    private final static int PUP_MAWB_NO_MVMNT = 1;
    private final static int PUP_CRN_NO_MVMNT = 2;
    private final static int PUP_UNK_NO_MVMNT = 3;
    
    private final static int STAT70_MAWB_MSSNG_MDE = 4;
    private final static int STAT70_MAWB_NO_MVMNT = 5;
    private final static int STAT70_CRN_NO_MVMNT = 6;
    private final static int STAT70_UNK_NO_MVMNT = 7;    
    
    private final static int PUX23_MAWB_PKG_RCVD_AFTR_ARCRFT = 8; 
    private final static int PUX23_MAWB_NO_MVMNT = 9;
    private final static int PUX23_CRN_PKG_RCVD_AFTR_ARCRFT = 10; 
    private final static int PUX23_CRN_NO_MVMNT = 11;    
    private final static int PUX23_UNK_NO_MVMNT = 12;
    
    private final static int PUX17_CRN_CSTMR_RQSTS_FTR_DLVRY = 13;
    
    private final static int PUX15_CRN_BSNSS_CLSD = 14;
    
    private final static int SOP_MAWB_NO_MVMNT = 15;
    private final static int SOP_CRN_NO_MVMNT = 16;
    private final static int SOP_UNK_NO_MVMNT = 17;
    
    private final static int RIP_MAWB_NO_MVMNT = 18;
    private final static int RIP_CRN_NO_MVMNT = 19;
    private final static int RIP_UNK_NO_MVMNT = 20;
    
    private final static int ROP_MAWB_NO_MVMNT = 21;
    private final static int ROP_CRN_NO_MVMNT = 22;
    private final static int ROP_UNK_NO_MVMNT = 23;

    private final static int HIP_CRN_NO_MVMNT = 24;
    private final static int HIP_UNK_NO_MVMNT = 25;
    
    private final static int HOP_CRN_NO_MVMNT = 26;
    private final static int HOP_UNK_NO_MVMNT = 27;
    
    private final static int ECCO_CC_CRN_NO_MVMNT = 28;
    private final static int ECCO_CC_UNK_NO_MVMNT = 29;
    
    private final static int ECCO_CC_CRN_MSSNG_SIP = 30;
    private final static int ECCO_CC_UNK_MSSNG_SIP = 31;   
    
    private final static int STAT65_CC_CRN_NO_MVMNT = 32;
    private final static int STAT65_CC_UNK_NO_MVMNT = 33;
    private final static int STAT66_CC_CRN_NO_MVMNT = 34;
    private final static int STAT66_CC_UNK_NO_MVMNT = 35;
    
    private final static int STAT65_CC_CRN_MSSNG_SIP = 36;
    private final static int STAT65_CC_UNK_MSSNG_SIP = 37;
    private final static int STAT66_CC_CRN_MSSNG_SIP = 38;
    private final static int STAT66_CC_UNK_MSSNG_SIP = 39;
    
    private final static int SIP_CRN_MSSNG_VAN = 40;
    private final static int SIP_UNK_MSSNG_VAN = 41;
    
    private final static int VAN_CRN_MSSNG_DLVRY = 42;
    private final static int VAN_UNK_MSSNG_DLVRY = 43;
        
    private final static int DEX03_CRN_INCRRCT_ADDRSS = 44;
    private final static int DEX03_UNK_INCRRCT_ADDRSS = 45;
    
    private final static int DEX07_CRN_SHPMT_RFSD = 46;
    private final static int DEX07_UNK_SHPMT_RFSD = 47;

    private final static int DEX08_CRN_RECP_NT_IN = 48;
    private final static int DEX08_UNK_RECP_NT_IN = 49;
    
    private final static int DEX10_CRN_DMGD_NT_DLVRD = 50;
    private final static int DEX10_UNK_DMGD_NT_DLVRD = 51;
    
    private final static int MISSORT_CRN_MISSRTD = 52;
    private final static int MISSORT_UNK_MISSRTD = 53;
    
    private final static int STAT84_MAWB_DLY_BYND_CNTRL = 54;
    private final static int STAT84_CRN_DLY_BYND_CNTRL = 55;
    private final static int STAT84_UNK_DLY_BYND_CNTRL = 56;
    
    private final static int STAT85_MAWB_MCHNCL_DLY = 57;
    private final static int STAT85_CRN_MCHNCL_DLY = 58;
    private final static int STAT85_UNK_MCHNCL_DLY = 59;
    
    private final static int STAT37_CRN_OBSRVD_PKG_DMGD = 60;
    private final static int STAT37_UNK_OBSRVD_PKG_DMGD = 61;
    
    private final static int STAT34_CRN_DACR = 62;
    private final static int STAT34_UNK_DACR = 63;
    
    private final static int HAL_CRN_HOLD_AT_LOC = 64;
    private final static int HAL_UNK_HOLD_AT_LOC = 65;
    
    private final static int HLD_CRN_HELD_AT_LOC = 66;
    private final static int HLD_UNK_HELD_AT_LOC = 67;
    
    private final static int PUP_MAWB_NO_CC = 68;
    private final static int PUP_CRN_NO_CC = 69;
    private final static int PUP_UNK_NO_CC = 70;
    
    private final static int STAT70_MAWB_NO_CC = 71;
    private final static int STAT70_CRN_NO_CC = 72;
    private final static int STAT70_UNK_NO_CC = 73;
    
    private final static int STAT60_MAWB_BOND_CAGE = 74;
    private final static int STAT55_MAWB_REG_AGENCY_CLEARNCE_DELAY = 75;
    private final static int STAT55_CRN_REG_AGENCY_CLEARNCE_DELAY = 76;
    private final static int STAT55_UNK_REG_AGENCY_CLEARNCE_DELAY = 77;
    
    private final static int PUX17_MAWB_CSTMR_RQSTS_FTR_DLVRY = 78;    
    private final static int HIP_MAWB_NO_MVMNT = 79;
    private final static int ECCO_CC_MAWB_NO_MVMNT = 80;
    private final static int ODA_MISSING_DELIVERY = 81;
    
    //Change for WR #135494 by Wipro Surge Uplift
    private final static int PUX79_FTR_DLVRY = 82;
    
    // ADDEVENT Add new event based issues here, update MAX_ISSUE_CD below
    /* Change for WR #135494 by Wipro
     * private final static int MAX_ISSUE_CD = ODA_MISSING_DELIVERY;*/
    private final static int MAX_ISSUE_CD = PUX79_FTR_DLVRY;
    
    // ADDEVENT Odd issues, not driven by events, but business logic
    // Should not be a return on a MAWB, we learn about returns in the associated group of the message
    // and is not associated with an event type
    public final static int RETURN_MAWB = 512;
    // Should not have multiple POD's on a MAWB
    public final static int MULTI_POD_MAWB = 513;
    // Identify shipments with missing data so monitors can fill it in
    public final static int MISSING_DATA_MAWB = 514;
    public final static int MISSING_DATA_CRN = 515;
    public final static int MISSING_DATA_UNK = 516;
    // An Issue created by the Monitor, so that they can mark something they want to monitor
    // regardless of system generated issues
    public final static int MONITOR_ISSUE = 517;  // Issue created by Monitor so that it keeps coming back
    
    
    
    // ADDEVENT These are used to define the short and long text on the GUI
    // Please follow naming convention
    // Event_DESC
    public final static IssueDesc MSSNG_MDE_DESC = IssueDesc.getInstance("NO MANIFEST", "No MDE event following PU");
    public final static IssueDesc MOVEMENT_DESC = IssueDesc.getInstance("NO MOVEMENT", "No movement on this shipment");
    public final static IssueDesc NOT_CLRD_CSTMS_DESC = IssueDesc.getInstance("CLEARANCE DELAY", "No cleared customs event");
    public final static IssueDesc PUX23_DESC = IssueDesc.getInstance("AFTR ARCRFT", "Package received after aircraft");
    public final static IssueDesc PUX17_DESC = IssueDesc.getInstance("FTR DLVRY", "Customer requests future delivery");
    public final static IssueDesc PUX15_DESC = IssueDesc.getInstance("BSNSS CLSD", "Business is closed");
    public final static IssueDesc ECCO_CC_DESC = IssueDesc.getInstance("NO SIP","No SIP event following cleared customs event");
    public final static IssueDesc STAT65_DESC = IssueDesc.getInstance("NO SIP", "No SIP event following cleared customs event");
    public final static IssueDesc SIP_MSSNG_VAN_DESC = IssueDesc.getInstance("NO VAN", "No VAN event following SIP");
    public final static IssueDesc VAN_MSSNG_DLVRY_DESC = IssueDesc.getInstance("NO DLVRY", "No delivery event following a VAN");
    public final static IssueDesc DEX03_DESC = IssueDesc.getInstance("INCRRCT ADDRSS", "Incorrect address");
    public final static IssueDesc DEX07_DESC = IssueDesc.getInstance("SHPMT RFSD", "Shipment was refused");
    public final static IssueDesc DEX08_DESC = IssueDesc.getInstance("RCPNT NT IN", "Recipient was not in");
    public final static IssueDesc DEX10_DESC = IssueDesc.getInstance("DMGD NT DLVRD", "Shipment damaged not delivered");
    public final static IssueDesc MISSRTD_DESC = IssueDesc.getInstance("MISSORT", "Shipment was missorted");
    public final static IssueDesc STAT84_DESC = IssueDesc.getInstance("DLY_BYND_CNTRL", "Shipment delayed beyond our control");
    public final static IssueDesc STAT85_DESC = IssueDesc.getInstance("MCHNCL_DLY", "Mechanical delay");
    public final static IssueDesc STAT37_DESC = IssueDesc.getInstance("OBSRVD_PKG_DMGD", "Observed the package is damaged");
    public final static IssueDesc STAT34_DESC = IssueDesc.getInstance("DACR", "Shipment destroyed at customer request");
    public final static IssueDesc HAL_DESC = IssueDesc.getInstance("HAL", "Shipment hold at location");
    public final static IssueDesc HLD_DESC = IssueDesc.getInstance("HLD", "Shipment held at location");
    public final static IssueDesc BOND_CAGE_DESC = IssueDesc.getInstance("IN BOND CAGE", "Shipment in bond cage");
    public final static IssueDesc REG_AGNCY_CLR_DLY_DESC = IssueDesc.getInstance("CLR DLY", "Regualatory Agency Clearance Delay");
    public final static IssueDesc ODA_MISSING_DELIVERY_DESC = IssueDesc.getInstance("MISSING POD", "ODA Missing POD");
    //Change for WR #135494 by Wipro
    public final static IssueDesc PUX79_DESC = IssueDesc.getInstance("FTR_DLVRY", "Future Delivery due to Surge shipment");
    
    
    // ADDEVENT issueDescListOdd issues
    public final static IssueDesc RETURN_MAWB_DESC = IssueDesc.getInstance("RTRN ON MAWB","A return has been done on a MAWB");
    public final static IssueDesc MULTI_POD_MAWB_DESC = IssueDesc.getInstance("MLTPL POD", "Multiple POD events");
    public final static IssueDesc MISSING_DATA_DESC = IssueDesc.getInstance("MSSNG DATA", "Important data is missing from the shipment");
    public final static IssueDesc MONITOR_ISSUE_DESC = IssueDesc.getInstance("MONITOR", "Issue created by Monitor");
    
    /**
     * Defines all of the issues, for an issue to be defined, we need to match the track type,
     *  optionally the exception cd, type shipment(MAWB,CRN,UNKNOWN).  If all that matches
     *  we just need to know the time in which the issue becomes real.  Additional, criteria can
     *  be defined for deciding if the issue should be or not.
     *  ADDEVENT
     */
    protected static Issue[] IssueList = {
        //         Scan Type       Exception Shipment Addtnl     Issue                            When Issue
        //                         Cd        Type     Criteria   Cd From Above                    becomes Issue
        //                         Optional  MAWB    
        //                                   CRN
        //                                   Unknown
        // PUP - Pickup
        new Issue(RiseConstants.PUP, null,   MAWB,     null,      PUP_MAWB_MSSNG_MDE,              ADD_HRS_TO_EVENT, 24, MSSNG_MDE_DESC),
        new Issue(RiseConstants.PUP, null,   MAWB,     null,      PUP_MAWB_NO_MVMNT,               ADD_HRS_TO_EVENT, 24, MOVEMENT_DESC),
        new Issue(RiseConstants.PUP, null,   CRN,      null,      PUP_CRN_NO_MVMNT,                ADD_HRS_TO_EVENT, 24, MOVEMENT_DESC),
        new Issue(RiseConstants.PUP, null,   UNK,      null,      PUP_UNK_NO_MVMNT,                ADD_HRS_TO_EVENT, 24, MOVEMENT_DESC),
        
        new Issue(RiseConstants.PUP, null,   MAWB,     null,      PUP_MAWB_NO_CC,                  ADD_HRS_TO_EVENT, 24, NOT_CLRD_CSTMS_DESC),
        new Issue(RiseConstants.PUP, null,   CRN,      null,      PUP_CRN_NO_CC,                   ADD_HRS_TO_EVENT, 24, NOT_CLRD_CSTMS_DESC),
        new Issue(RiseConstants.PUP, null,   UNK,      null,      PUP_UNK_NO_CC,                   ADD_HRS_TO_EVENT, 24, NOT_CLRD_CSTMS_DESC),
        
        // Stat 70, Transit in
        new Issue(RiseConstants.STAT, "70",  MAWB,     null,      STAT70_MAWB_MSSNG_MDE,           ADD_HRS_TO_EVENT, 15, MSSNG_MDE_DESC),
        new Issue(RiseConstants.STAT, "70",  MAWB,     null,      STAT70_MAWB_NO_MVMNT,            ADD_HRS_TO_EVENT, 15, MOVEMENT_DESC),
        new Issue(RiseConstants.STAT, "70",  CRN,      null,      STAT70_CRN_NO_MVMNT,             ADD_HRS_TO_EVENT, 15, MOVEMENT_DESC),
        new Issue(RiseConstants.STAT, "70",  UNK,      null,      STAT70_UNK_NO_MVMNT,             ADD_HRS_TO_EVENT, 15, MOVEMENT_DESC),
            
        new Issue(RiseConstants.STAT, "70",  MAWB,     null,      STAT70_MAWB_NO_CC,               ADD_HRS_TO_EVENT, 48, NOT_CLRD_CSTMS_DESC),
        new Issue(RiseConstants.STAT, "70",  CRN,      null,      STAT70_CRN_NO_CC,                ADD_HRS_TO_EVENT, 48, NOT_CLRD_CSTMS_DESC),
        new Issue(RiseConstants.STAT, "70",  UNK,      null,      STAT70_UNK_NO_CC,                ADD_HRS_TO_EVENT, 48, NOT_CLRD_CSTMS_DESC),
        
        
        // PUX 23 - Pickup exception
        new Issue(RiseConstants.PUX, "23",   MAWB,     null,      PUX23_MAWB_PKG_RCVD_AFTR_ARCRFT, ADD_HRS_TO_EVENT, 24, PUX23_DESC),
        new Issue(RiseConstants.PUX, "23",   MAWB,     null,      PUX23_MAWB_NO_MVMNT,             ADD_HRS_TO_EVENT, 15, MOVEMENT_DESC),
        new Issue(RiseConstants.PUX, "23",   CRN,      null,      PUX23_CRN_PKG_RCVD_AFTR_ARCRFT,  ADD_HRS_TO_EVENT, 24, PUX23_DESC),
        new Issue(RiseConstants.PUX, "23",   CRN,      null,      PUX23_CRN_NO_MVMNT,              ADD_HRS_TO_EVENT, 15, MOVEMENT_DESC),
        new Issue(RiseConstants.PUX, "23",   UNK,      null,      PUX23_UNK_NO_MVMNT,              ADD_HRS_TO_EVENT, 15, MOVEMENT_DESC),
        
        // PUX 17
        new Issue(RiseConstants.PUX, "17",   CRN,      null,      PUX17_CRN_CSTMR_RQSTS_FTR_DLVRY, IMMEDIATE,         0, PUX17_DESC),
        new Issue(RiseConstants.PUX, "17",   CRN,      null,      PUX17_MAWB_CSTMR_RQSTS_FTR_DLVRY, IMMEDIATE,         0, PUX17_DESC),
            
        // PUX 15
        new Issue(RiseConstants.PUX, "15",   CRN,      null,      PUX15_CRN_BSNSS_CLSD,            IMMEDIATE,         0, PUX15_DESC),
            
        // Station Outbound
        // SOP, Can't depend on this scan to say that the shipment left the
        // origin station, but can use it if it occurs to show movement
        // SOPS can happen at the beginning or end of a shipment life cycle
        new Issue(RiseConstants.SOP, null,   MAWB,     null,      SOP_MAWB_NO_MVMNT,               ADD_HRS_TO_EVENT,12, MOVEMENT_DESC),
        new Issue(RiseConstants.SOP, null,   CRN,      null,      SOP_CRN_NO_MVMNT,                ADD_HRS_TO_EVENT,12, MOVEMENT_DESC),
        new Issue(RiseConstants.SOP, null,   UNK,      null,      SOP_UNK_NO_MVMNT,                ADD_HRS_TO_EVENT,12, MOVEMENT_DESC),
               
        new Issue(RiseConstants.RIP, null,   MAWB,     null,      RIP_MAWB_NO_MVMNT,               ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        new Issue(RiseConstants.RIP, null,   CRN,      null,      RIP_CRN_NO_MVMNT,                ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        new Issue(RiseConstants.RIP, null,   UNK,      null,      RIP_UNK_NO_MVMNT,                ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        
        // Ramp outbound
        // ROP, cannot depend on this being the event to say that the shipment
        // has left the origin location, can use it to show movement
        // ROPS can happened at the beginning or end of a shipment life cycle
        new Issue(RiseConstants.ROP, null,   MAWB,     null,      ROP_MAWB_NO_MVMNT,               ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        new Issue(RiseConstants.ROP, null,   CRN,      null,      ROP_CRN_NO_MVMNT,                ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        new Issue(RiseConstants.ROP, null,   UNK,      null,      ROP_UNK_NO_MVMNT,                ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        
        // Hub inbound
        // HIP, not dependable as an event that will happen when an shipment 
        // arrives at a HUB.  Not sure that it is the HUB at which it will
        // get a customs cleared.  
        new Issue(RiseConstants.HIP, null,   MAWB,     null,      HIP_MAWB_NO_MVMNT,               ADD_HRS_TO_EVENT, 5, MOVEMENT_DESC),
        new Issue(RiseConstants.HIP, null,   CRN,      null,      HIP_CRN_NO_MVMNT,                ADD_HRS_TO_EVENT, 5, MOVEMENT_DESC),
        new Issue(RiseConstants.HIP, null,   UNK,      null,      HIP_UNK_NO_MVMNT,                ADD_HRS_TO_EVENT, 5, MOVEMENT_DESC),

        // HOP Hub Outbound
        new Issue(RiseConstants.HOP, null,   CRN,      null,      HOP_CRN_NO_MVMNT,                ADD_HRS_TO_EVENT, 8, MOVEMENT_DESC),
        new Issue(RiseConstants.HOP, null,   UNK,      null,      HOP_UNK_NO_MVMNT,                ADD_HRS_TO_EVENT, 8, MOVEMENT_DESC),
        
        // ECCO Customs Cleared
        new Issue(RiseConstants.ECCO, null,  MAWB,     ClearedCustomsCriteria.getInstance(),       ECCO_CC_MAWB_NO_MVMNT,  ADD_HRS_TO_EVENT, 8, MOVEMENT_DESC),
        new Issue(RiseConstants.ECCO, null,  CRN,      ClearedCustomsCriteria.getInstance(),       ECCO_CC_CRN_NO_MVMNT,   ADD_HRS_TO_EVENT, 12, MOVEMENT_DESC),
        new Issue(RiseConstants.ECCO, null,  UNK,      ClearedCustomsCriteria.getInstance(),       ECCO_CC_UNK_NO_MVMNT,   ADD_HRS_TO_EVENT, 4, MOVEMENT_DESC),
        new Issue(RiseConstants.ECCO, null,  CRN,      ClearedCustomsCriteria.getInstance(),       ECCO_CC_CRN_MSSNG_SIP,  ADD_HRS_TO_EVENT, 8, ECCO_CC_DESC),
        new Issue(RiseConstants.ECCO, null,  UNK,      ClearedCustomsCriteria.getInstance(),       ECCO_CC_UNK_MSSNG_SIP,  ADD_HRS_TO_EVENT, 8, ECCO_CC_DESC),
        
        // STAT Customs Cleared
        new Issue(RiseConstants.STAT, "65",  CRN,      null,      STAT65_CC_CRN_NO_MVMNT,          ADD_HRS_TO_EVENT, 8, MOVEMENT_DESC),
        new Issue(RiseConstants.STAT, "65",  UNK,      null,      STAT65_CC_UNK_NO_MVMNT,          ADD_HRS_TO_EVENT, 4, MOVEMENT_DESC),
        new Issue(RiseConstants.STAT, "66",  CRN,      null,      STAT66_CC_CRN_NO_MVMNT,          ADD_HRS_TO_EVENT, 4, MOVEMENT_DESC),
        new Issue(RiseConstants.STAT, "66",  UNK,      null,      STAT66_CC_UNK_NO_MVMNT,          ADD_HRS_TO_EVENT, 4, MOVEMENT_DESC),
        
        new Issue(RiseConstants.STAT, "65",  CRN,      null,      STAT65_CC_CRN_MSSNG_SIP,         ADD_HRS_TO_EVENT, 8, STAT65_DESC),
        new Issue(RiseConstants.STAT, "65",  UNK,      null,      STAT65_CC_UNK_MSSNG_SIP,         ADD_HRS_TO_EVENT, 8, STAT65_DESC),
        new Issue(RiseConstants.STAT, "66",  CRN,      null,      STAT66_CC_CRN_MSSNG_SIP,         ADD_HRS_TO_EVENT, 8, STAT65_DESC),
        new Issue(RiseConstants.STAT, "66",  UNK,      null,      STAT66_CC_UNK_MSSNG_SIP,         ADD_HRS_TO_EVENT, 8, STAT65_DESC),
            
        // SIP can come earlier than being at the location where the VAN is going to occur
        new Issue(RiseConstants.SIP, null,   CRN,      null,      SIP_CRN_MSSNG_VAN,               ADD_HRS_TO_EVENT, 2, SIP_MSSNG_VAN_DESC),
        new Issue(RiseConstants.SIP, null,   UNK,      null,      SIP_UNK_MSSNG_VAN,               ADD_HRS_TO_EVENT, 2, SIP_MSSNG_VAN_DESC),
        
        // VAN, delivery can be POD/DDEX/ODA
        new Issue(RiseConstants.VAN, null,   CRN,      null,      VAN_CRN_MSSNG_DLVRY,             ADD_HRS_TO_EVENT, 6, VAN_MSSNG_DLVRY_DESC),
        new Issue(RiseConstants.VAN, null,   UNK,      null,      VAN_UNK_MSSNG_DLVRY,             ADD_HRS_TO_EVENT, 6, VAN_MSSNG_DLVRY_DESC),
            
        // DEX 03 Incorrect Address
        new Issue(RiseConstants.DEX, "03",   CRN,      null,      DEX03_CRN_INCRRCT_ADDRSS,        IMMEDIATE,        0, DEX03_DESC),
        new Issue(RiseConstants.DEX, "03",   UNK,      null,      DEX03_UNK_INCRRCT_ADDRSS,        IMMEDIATE,        0, DEX03_DESC),
        
        // DEX 07 Shipment Refused by Recipient
        new Issue(RiseConstants.DEX, "07",   CRN,      null,      DEX07_CRN_SHPMT_RFSD,            IMMEDIATE,        0, DEX07_DESC),
        new Issue(RiseConstants.DEX, "07",   UNK,      null,      DEX07_UNK_SHPMT_RFSD,            IMMEDIATE,        0, DEX07_DESC),
            
        // DEX 08 Recipient Not In/Business Closed
        new Issue(RiseConstants.DEX, "08",   CRN,      null,      DEX08_CRN_RECP_NT_IN,            ADD_HRS_TO_EVENT, 48, DEX08_DESC),
        new Issue(RiseConstants.DEX, "08",   UNK,      null,      DEX08_UNK_RECP_NT_IN,            ADD_HRS_TO_EVENT, 48, DEX08_DESC),
            
        // DEX 10 Damaged, delivery not attempted
        new Issue(RiseConstants.DEX, "10",   CRN,      null,      DEX10_CRN_DMGD_NT_DLVRD,         IMMEDIATE,        0, DEX10_DESC),
        new Issue(RiseConstants.DEX, "10",   UNK,      null,      DEX10_UNK_DMGD_NT_DLVRD,         IMMEDIATE,        0, DEX10_DESC),    
            
        // Missort
        new Issue(RiseConstants.MIS, null,   CRN,      null,      MISSORT_CRN_MISSRTD,             IMMEDIATE,        0, MISSRTD_DESC),
        new Issue(RiseConstants.MIS, null,   UNK,      null,      MISSORT_UNK_MISSRTD,             IMMEDIATE,        0, MISSRTD_DESC),
            
        // Stat 84, Delay beyond our control
        new Issue(RiseConstants.STAT, "84",  MAWB,     null,      STAT84_MAWB_DLY_BYND_CNTRL,      IMMEDIATE,        0, STAT84_DESC),
        new Issue(RiseConstants.STAT, "84",  CRN,      null,      STAT84_CRN_DLY_BYND_CNTRL,       IMMEDIATE,        0, STAT84_DESC),
        new Issue(RiseConstants.STAT, "84",  UNK,      null,      STAT84_UNK_DLY_BYND_CNTRL,       IMMEDIATE,        0, STAT84_DESC),
        
        // Stat 85, Mechanical Delay
        new Issue(RiseConstants.STAT, "85",  MAWB,     null,      STAT85_MAWB_MCHNCL_DLY,          IMMEDIATE,        0, STAT85_DESC),
        new Issue(RiseConstants.STAT, "85",  CRN,      null,      STAT85_CRN_MCHNCL_DLY,           IMMEDIATE,        0, STAT85_DESC),
        new Issue(RiseConstants.STAT, "85",  UNK,      null,      STAT85_UNK_MCHNCL_DLY,           IMMEDIATE,        0, STAT85_DESC),
            
        // Stat 37, Observed package damaged
        new Issue(RiseConstants.STAT, "37",  CRN,      null,      STAT37_CRN_OBSRVD_PKG_DMGD,      IMMEDIATE,        0, STAT37_DESC),
        new Issue(RiseConstants.STAT, "37",  UNK,      null,      STAT37_UNK_OBSRVD_PKG_DMGD,      IMMEDIATE,        0, STAT37_DESC),
            
        // Stat 34, Destroyed at customers request
        new Issue(RiseConstants.STAT, "34",  CRN,      null,      STAT34_CRN_DACR,                 IMMEDIATE,        0, STAT34_DESC),
        new Issue(RiseConstants.STAT, "34",  UNK,      null,      STAT34_UNK_DACR,                 IMMEDIATE,        0, STAT34_DESC),
        
        // HAL, Hold at location
        new Issue(RiseConstants.HAL, null,   CRN,      null,      HAL_CRN_HOLD_AT_LOC,             ADD_HRS_TO_EVENT, 24, HAL_DESC),
        new Issue(RiseConstants.HAL, null,   UNK,      null,      HAL_UNK_HOLD_AT_LOC,             ADD_HRS_TO_EVENT, 24, HAL_DESC),
        
        // HLD, Held at location
        new Issue(RiseConstants.HLD, null,   CRN,      null,      HLD_CRN_HELD_AT_LOC,             ADD_HRS_TO_EVENT,  24, HLD_DESC),
        new Issue(RiseConstants.HLD, null,   UNK,      null,      HLD_UNK_HELD_AT_LOC,             ADD_HRS_TO_EVENT,  24, HLD_DESC),
        
        // Bond Cage
        new Issue(RiseConstants.STAT, "60",  MAWB,     null,      STAT60_MAWB_BOND_CAGE,           IMMEDIATE,         0, BOND_CAGE_DESC),
        
        // Regulatory Agency Clearance Delay
        new Issue(RiseConstants.STAT, "55", MAWB,       null,     STAT55_MAWB_REG_AGENCY_CLEARNCE_DELAY, IMMEDIATE,   0, REG_AGNCY_CLR_DLY_DESC),
        new Issue(RiseConstants.STAT, "55", CRN,       null,      STAT55_CRN_REG_AGENCY_CLEARNCE_DELAY, IMMEDIATE,    0, REG_AGNCY_CLR_DLY_DESC),
        new Issue(RiseConstants.STAT, "55", UNK,       null,      STAT55_UNK_REG_AGENCY_CLEARNCE_DELAY, IMMEDIATE,    0, REG_AGNCY_CLR_DLY_DESC),
        
        // ODA Missing delivery
        new Issue(RiseConstants.ODA, null,  CRN,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.ODA, null,  UNK,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.STAT, "19", CRN,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.STAT, "19", UNK,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.STAT, "67", CRN,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.STAT, "67", UNK,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.STAT, "33", CRN,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        new Issue(RiseConstants.STAT, "33", UNK,       null,      ODA_MISSING_DELIVERY, 			ADD_HRS_TO_EVENT_OR_HOUR_AFTER_COMMIT, 48, ODA_MISSING_DELIVERY_DESC),
        
        //Change for WR #135494 by Wipro
        //PUX 79 (Surge shipment as uplift not available)
        new Issue(RiseConstants.PUX, "79", CRN,       null,      PUX79_FTR_DLVRY, 					ADD_HRS_TO_EVENT,    240, PUX79_DESC)
    };
    
    /**
     * Defines the resolving rules.  For each of the rows above, there must be a row here which defines how
     * the issue is resolved.
     * ADDEVENT
     */
    static {
        resolveList.put(new Integer(PUP_MAWB_MSSNG_MDE),                SpecificEventResolver.getInstance(RiseConstants.MDE1_70));

        resolveList.put(new Integer(PUP_MAWB_NO_MVMNT),                 MovementResolver.getInstance());
        resolveList.put(new Integer(PUP_CRN_NO_MVMNT),                  MovementResolver.getInstance());
        resolveList.put(new Integer(PUP_UNK_NO_MVMNT),                  MovementResolver.getInstance());

        resolveList.put(new Integer(PUP_MAWB_NO_CC),                    ClearedCustomsResolver.getInstance());
        resolveList.put(new Integer(PUP_CRN_NO_CC),                     ClearedCustomsResolver.getInstance());
        resolveList.put(new Integer(PUP_UNK_NO_CC),                     ClearedCustomsResolver.getInstance());
        
        resolveList.put(new Integer(STAT70_MAWB_MSSNG_MDE),             MDE1Resolver.getInstance());
        resolveList.put(new Integer(STAT70_MAWB_NO_MVMNT),              MovementResolver.getInstance());
        resolveList.put(new Integer(STAT70_CRN_NO_MVMNT),               MovementResolver.getInstance());
        resolveList.put(new Integer(STAT70_UNK_NO_MVMNT),               MovementResolver.getInstance());

        resolveList.put(new Integer(STAT70_MAWB_NO_CC),                 ClearedCustomsResolver.getInstance());
        resolveList.put(new Integer(STAT70_CRN_NO_CC),                  ClearedCustomsResolver.getInstance());
        resolveList.put(new Integer(STAT70_UNK_NO_CC),                  ClearedCustomsResolver.getInstance());
        
        resolveList.put(new Integer(PUX23_MAWB_PKG_RCVD_AFTR_ARCRFT),   MovementResolver.getInstance());
        resolveList.put(new Integer(PUX23_MAWB_NO_MVMNT),               MovementResolver.getInstance());
        resolveList.put(new Integer(PUX23_CRN_PKG_RCVD_AFTR_ARCRFT),    MovementResolver.getInstance());
        resolveList.put(new Integer(PUX23_CRN_NO_MVMNT),                MovementResolver.getInstance());
        resolveList.put(new Integer(PUX23_UNK_NO_MVMNT),                MovementResolver.getInstance());

        resolveList.put(new Integer(PUX17_CRN_CSTMR_RQSTS_FTR_DLVRY),   SpecificEventResolver.getInstance(RiseConstants.POD));
        resolveList.put(new Integer(PUX17_MAWB_CSTMR_RQSTS_FTR_DLVRY),   SpecificEventResolver.getInstance(RiseConstants.POD));

        resolveList.put(new Integer(PUX15_CRN_BSNSS_CLSD),              MovementResolver.getInstance());

        resolveList.put(new Integer(SOP_MAWB_NO_MVMNT),                 MovementResolver.getInstance());
        resolveList.put(new Integer(SOP_CRN_NO_MVMNT),                  MovementResolver.getInstance());
        resolveList.put(new Integer(SOP_UNK_NO_MVMNT),                  MovementResolver.getInstance());

        resolveList.put(new Integer(RIP_MAWB_NO_MVMNT),                 MovementResolver.getInstance());
        resolveList.put(new Integer(RIP_CRN_NO_MVMNT),                  MovementResolver.getInstance());
        resolveList.put(new Integer(RIP_UNK_NO_MVMNT),                  MovementResolver.getInstance());
        
        resolveList.put(new Integer(ROP_MAWB_NO_MVMNT),                 MovementResolver.getInstance());
        resolveList.put(new Integer(ROP_CRN_NO_MVMNT),                  MovementResolver.getInstance());
        resolveList.put(new Integer(ROP_UNK_NO_MVMNT),                  MovementResolver.getInstance());

        resolveList.put(new Integer(HIP_MAWB_NO_MVMNT),                 MovementResolver.getInstance());
        resolveList.put(new Integer(HIP_CRN_NO_MVMNT),                  MovementResolver.getInstance());
        resolveList.put(new Integer(HIP_UNK_NO_MVMNT),                  MovementResolver.getInstance());

        resolveList.put(new Integer(HOP_CRN_NO_MVMNT),                  MovementResolver.getInstance());
        resolveList.put(new Integer(HOP_UNK_NO_MVMNT),                  MovementResolver.getInstance());

        resolveList.put(new Integer(ECCO_CC_MAWB_NO_MVMNT),             MovementResolver.getInstance());
        resolveList.put(new Integer(ECCO_CC_CRN_NO_MVMNT),              MovementResolver.getInstance());
        resolveList.put(new Integer(ECCO_CC_UNK_NO_MVMNT),              MovementResolver.getInstance());

        resolveList.put(new Integer(ECCO_CC_CRN_MSSNG_SIP),             MovementResolver.getInstance());
        resolveList.put(new Integer(ECCO_CC_UNK_MSSNG_SIP),             MovementResolver.getInstance());
        
        resolveList.put(new Integer(STAT65_CC_CRN_NO_MVMNT),            MovementResolver.getInstance());
        resolveList.put(new Integer(STAT65_CC_UNK_NO_MVMNT),            MovementResolver.getInstance());
        resolveList.put(new Integer(STAT66_CC_CRN_NO_MVMNT),            MovementResolver.getInstance());
        resolveList.put(new Integer(STAT66_CC_UNK_NO_MVMNT),            MovementResolver.getInstance());
        
        resolveList.put(new Integer(STAT65_CC_CRN_MSSNG_SIP),           MovementResolver.getInstance());
        resolveList.put(new Integer(STAT65_CC_UNK_MSSNG_SIP),           MovementResolver.getInstance());
        resolveList.put(new Integer(STAT66_CC_CRN_MSSNG_SIP),           MovementResolver.getInstance());
        resolveList.put(new Integer(STAT66_CC_UNK_MSSNG_SIP),           MovementResolver.getInstance());

        resolveList.put(new Integer(SIP_CRN_MSSNG_VAN),                 MovementResolver.getInstance());
        resolveList.put(new Integer(SIP_UNK_MSSNG_VAN),                 MovementResolver.getInstance());

        resolveList.put(new Integer(VAN_CRN_MSSNG_DLVRY),               DeliveryResolver.getInstance());
        resolveList.put(new Integer(VAN_UNK_MSSNG_DLVRY),               DeliveryResolver.getInstance());

        resolveList.put(new Integer(DEX03_CRN_INCRRCT_ADDRSS),          MovementResolver.getInstance());
        resolveList.put(new Integer(DEX03_UNK_INCRRCT_ADDRSS),          MovementResolver.getInstance());

        resolveList.put(new Integer(DEX07_CRN_SHPMT_RFSD),              MovementResolver.getInstance());
        resolveList.put(new Integer(DEX07_UNK_SHPMT_RFSD),              MovementResolver.getInstance());

        resolveList.put(new Integer(DEX08_CRN_RECP_NT_IN),              MovementResolver.getInstance());
        resolveList.put(new Integer(DEX08_UNK_RECP_NT_IN),              MovementResolver.getInstance());

        resolveList.put(new Integer(DEX10_CRN_DMGD_NT_DLVRD),           MovementResolver.getInstance());
        resolveList.put(new Integer(DEX10_UNK_DMGD_NT_DLVRD),           MovementResolver.getInstance());

        resolveList.put(new Integer(MISSORT_CRN_MISSRTD),               MovementResolver.getInstance());
        resolveList.put(new Integer(MISSORT_UNK_MISSRTD),               MovementResolver.getInstance());

        resolveList.put(new Integer(STAT84_MAWB_DLY_BYND_CNTRL),        MovementResolver.getInstance());
        resolveList.put(new Integer(STAT84_CRN_DLY_BYND_CNTRL),         MovementResolver.getInstance());
        resolveList.put(new Integer(STAT84_UNK_DLY_BYND_CNTRL),         MovementResolver.getInstance());

        resolveList.put(new Integer(STAT85_MAWB_MCHNCL_DLY),            MovementResolver.getInstance());
        resolveList.put(new Integer(STAT85_CRN_MCHNCL_DLY),             MovementResolver.getInstance());
        resolveList.put(new Integer(STAT85_UNK_MCHNCL_DLY),             MovementResolver.getInstance());
        
        resolveList.put(new Integer(STAT37_CRN_OBSRVD_PKG_DMGD),        STAT17Resolver.getInstance());
        resolveList.put(new Integer(STAT37_UNK_OBSRVD_PKG_DMGD),        STAT17Resolver.getInstance());
        
        resolveList.put(new Integer(STAT34_CRN_DACR),                   STAT17Resolver.getInstance());
        resolveList.put(new Integer(STAT34_UNK_DACR),                   STAT17Resolver.getInstance());
        
        resolveList.put(new Integer(HAL_CRN_HOLD_AT_LOC),               MovementResolver.getInstance());
        resolveList.put(new Integer(HAL_UNK_HOLD_AT_LOC),               MovementResolver.getInstance());
        
        resolveList.put(new Integer(HLD_CRN_HELD_AT_LOC),               MovementResolver.getInstance());
        resolveList.put(new Integer(HLD_UNK_HELD_AT_LOC),               MovementResolver.getInstance());
        
        resolveList.put(new Integer(STAT60_MAWB_BOND_CAGE),             BondCageResolver.getInstance());
        
        resolveList.put(new Integer(STAT55_MAWB_REG_AGENCY_CLEARNCE_DELAY), BondCageResolver.getInstance());
        resolveList.put(new Integer(STAT55_CRN_REG_AGENCY_CLEARNCE_DELAY), BondCageResolver.getInstance());
        resolveList.put(new Integer(STAT55_UNK_REG_AGENCY_CLEARNCE_DELAY), BondCageResolver.getInstance());
        
        resolveList.put(new Integer(ODA_MISSING_DELIVERY), DeliveryResolver.getInstance());
        //Change for WR #135494 by Wipro
        resolveList.put(new Integer(PUX79_FTR_DLVRY), STAT79Resolver.getInstance());
        
        // Build up a list of issue codes, and their descriptions
        // for faster lookups, used by the GUI
        // Some Issues can derive the IssueDesc, by iterating over
        // the IssueList data structure, others must be added by hand
        // HashMap looks like: IssueCd => IssueDesc
        // ADDEVENT
        for (int i = MIN_ISSUE_CD; i <= MAX_ISSUE_CD; i++ ) {
            for (int j = 0; j < IssueList.length; j++) {
                if (IssueList[j].issueTypeCd == i) {
                   issueDescList.put(new Integer(i), IssueList[j].issueDesc);
                }
            }                                      
        }
        issueDescList.put(new Integer(MULTI_POD_MAWB), MULTI_POD_MAWB_DESC);
        issueDescList.put(new Integer(RETURN_MAWB), RETURN_MAWB_DESC);
        issueDescList.put(new Integer(MONITOR_ISSUE), MONITOR_ISSUE_DESC);
        issueDescList.put(new Integer(MISSING_DATA_MAWB), MISSING_DATA_DESC);
        issueDescList.put(new Integer(MISSING_DATA_CRN), MISSING_DATA_DESC);
        issueDescList.put(new Integer(MISSING_DATA_UNK), MISSING_DATA_DESC); 
        
        // Build up a list of issue codes, and their track type code and exception code
        // for faster lookups, used by the GUI
        issueTypeCdsList.put(PUP_MAWB_MSSNG_MDE, new String("PUP"));
        issueTypeCdsList.put(PUP_MAWB_NO_MVMNT, new String("PUP"));
        issueTypeCdsList.put(PUP_CRN_NO_MVMNT, new String("PUP"));
        issueTypeCdsList.put(PUP_UNK_NO_MVMNT, new String("PUP"));
        issueTypeCdsList.put(STAT70_MAWB_NO_MVMNT, new String("STAT 70"));
        issueTypeCdsList.put(STAT70_CRN_NO_MVMNT, new String("STAT 70"));
        issueTypeCdsList.put(STAT70_UNK_NO_MVMNT, new String("STAT 70"));
        issueTypeCdsList.put(PUX23_MAWB_PKG_RCVD_AFTR_ARCRFT, new String("PUX 23"));
        issueTypeCdsList.put(PUX23_MAWB_NO_MVMNT, new String("PUX 23"));
        issueTypeCdsList.put(PUX23_CRN_PKG_RCVD_AFTR_ARCRFT, new String("PUX 23"));
        issueTypeCdsList.put(PUX23_CRN_NO_MVMNT, new String("PUX 23"));
        issueTypeCdsList.put(PUX23_UNK_NO_MVMNT, new String("PUX 23"));
        issueTypeCdsList.put(PUX17_CRN_CSTMR_RQSTS_FTR_DLVRY, new String("PUX 17"));
        issueTypeCdsList.put(PUX15_CRN_BSNSS_CLSD, new String("PUX 15"));
        issueTypeCdsList.put(SOP_MAWB_NO_MVMNT, new String("SOP"));
        issueTypeCdsList.put(SOP_CRN_NO_MVMNT, new String("SOP"));
        issueTypeCdsList.put(SOP_UNK_NO_MVMNT, new String("SOP"));
        issueTypeCdsList.put(RIP_MAWB_NO_MVMNT, new String("RIP"));
        issueTypeCdsList.put(RIP_CRN_NO_MVMNT, new String("RIP"));
        issueTypeCdsList.put(RIP_UNK_NO_MVMNT, new String("RIP"));
        issueTypeCdsList.put(ROP_MAWB_NO_MVMNT, new String("ROP"));
        issueTypeCdsList.put(ROP_CRN_NO_MVMNT, new String("ROP"));
        issueTypeCdsList.put(ROP_UNK_NO_MVMNT, new String("ROP"));
        issueTypeCdsList.put(HIP_CRN_NO_MVMNT, new String("HIP"));
        issueTypeCdsList.put(HIP_UNK_NO_MVMNT, new String("HIP"));
        issueTypeCdsList.put(HOP_CRN_NO_MVMNT, new String("HOP"));
        issueTypeCdsList.put(HOP_UNK_NO_MVMNT, new String("HOP"));
        issueTypeCdsList.put(ECCO_CC_CRN_NO_MVMNT, new String("ECCO"));
        issueTypeCdsList.put(ECCO_CC_UNK_NO_MVMNT, new String("ECCO"));
        issueTypeCdsList.put(ECCO_CC_CRN_MSSNG_SIP, new String("ECCO"));
        issueTypeCdsList.put(ECCO_CC_UNK_MSSNG_SIP, new String("ECCO"));
        issueTypeCdsList.put(STAT65_CC_CRN_NO_MVMNT, new String("STAT 65"));
        issueTypeCdsList.put(STAT65_CC_UNK_NO_MVMNT, new String("STAT 65"));
        issueTypeCdsList.put(STAT66_CC_CRN_NO_MVMNT, new String("STAT 66"));
        issueTypeCdsList.put(STAT66_CC_UNK_NO_MVMNT, new String("STAT 66"));
        issueTypeCdsList.put(STAT65_CC_CRN_MSSNG_SIP, new String("STAT 65"));
        issueTypeCdsList.put(STAT65_CC_UNK_MSSNG_SIP, new String("STAT 65"));
        issueTypeCdsList.put(STAT66_CC_CRN_MSSNG_SIP, new String("STAT 66"));
        issueTypeCdsList.put(STAT66_CC_UNK_MSSNG_SIP, new String("STAT 66"));
        issueTypeCdsList.put(SIP_CRN_MSSNG_VAN, new String("SIP"));
        issueTypeCdsList.put(SIP_UNK_MSSNG_VAN, new String("SIP"));
        issueTypeCdsList.put(VAN_CRN_MSSNG_DLVRY, new String("VAN"));
        issueTypeCdsList.put(VAN_UNK_MSSNG_DLVRY, new String("VAN"));
        issueTypeCdsList.put(DEX03_CRN_INCRRCT_ADDRSS, new String("DEX 03"));
        issueTypeCdsList.put(DEX03_UNK_INCRRCT_ADDRSS, new String("DEX 03"));
        issueTypeCdsList.put(DEX07_CRN_SHPMT_RFSD, new String("DEX 07"));
        issueTypeCdsList.put(DEX07_UNK_SHPMT_RFSD, new String("DEX 07"));
        issueTypeCdsList.put(DEX08_CRN_RECP_NT_IN, new String("DEX 08"));
        issueTypeCdsList.put(DEX08_UNK_RECP_NT_IN, new String("DEX 08"));
        issueTypeCdsList.put(DEX10_CRN_DMGD_NT_DLVRD, new String("DEX 10"));
        issueTypeCdsList.put(DEX10_UNK_DMGD_NT_DLVRD, new String("DEX 10"));
        issueTypeCdsList.put(MISSORT_CRN_MISSRTD, new String("MISSORT"));
        issueTypeCdsList.put(MISSORT_UNK_MISSRTD, new String("MISSORT"));
        issueTypeCdsList.put(STAT84_MAWB_DLY_BYND_CNTRL, new String("STAT 84"));
        issueTypeCdsList.put(STAT84_CRN_DLY_BYND_CNTRL, new String("STAT 84"));
        issueTypeCdsList.put(STAT84_UNK_DLY_BYND_CNTRL, new String("STAT 84"));
        issueTypeCdsList.put(STAT85_MAWB_MCHNCL_DLY, new String("STAT 85"));
        issueTypeCdsList.put(STAT85_CRN_MCHNCL_DLY, new String("STAT 85"));
        issueTypeCdsList.put(STAT85_UNK_MCHNCL_DLY, new String("STAT 85"));
        issueTypeCdsList.put(STAT37_CRN_OBSRVD_PKG_DMGD, new String("STAT 37"));
        issueTypeCdsList.put(STAT37_UNK_OBSRVD_PKG_DMGD, new String("STAT 37"));
        issueTypeCdsList.put(STAT34_CRN_DACR, new String("STAT 34"));
        issueTypeCdsList.put(STAT34_UNK_DACR, new String("STAT 34"));
        issueTypeCdsList.put(HAL_CRN_HOLD_AT_LOC, new String("HAL"));
        issueTypeCdsList.put(HAL_UNK_HOLD_AT_LOC, new String("HAL"));
        issueTypeCdsList.put(HLD_CRN_HELD_AT_LOC, new String("HOLD"));
        issueTypeCdsList.put(HLD_UNK_HELD_AT_LOC, new String("HOLD"));
        issueTypeCdsList.put(PUP_MAWB_NO_CC, new String("PUP"));
        issueTypeCdsList.put(PUP_CRN_NO_CC, new String("PUP"));
        issueTypeCdsList.put(PUP_UNK_NO_CC, new String("PUP"));
        issueTypeCdsList.put(STAT70_MAWB_NO_CC, new String("STAT 70"));
        issueTypeCdsList.put(STAT70_CRN_NO_CC, new String("STAT 70"));
        issueTypeCdsList.put(STAT70_UNK_NO_CC, new String("STAT 70"));
        issueTypeCdsList.put(STAT60_MAWB_BOND_CAGE, new String("STAT 60"));
        issueTypeCdsList.put(STAT55_MAWB_REG_AGENCY_CLEARNCE_DELAY, new String("STAT 55"));
        issueTypeCdsList.put(STAT55_CRN_REG_AGENCY_CLEARNCE_DELAY, new String("STAT 55"));
        issueTypeCdsList.put(STAT55_UNK_REG_AGENCY_CLEARNCE_DELAY, new String("STAT 55"));
        issueTypeCdsList.put(PUX17_MAWB_CSTMR_RQSTS_FTR_DLVRY, new String("PUX 17"));
        issueTypeCdsList.put(HIP_MAWB_NO_MVMNT, new String("HIP"));
        issueTypeCdsList.put(ECCO_CC_MAWB_NO_MVMNT, new String("ECCO"));
        issueTypeCdsList.put(ODA_MISSING_DELIVERY, new String("ODA"));
        issueTypeCdsList.put(new Integer(MULTI_POD_MAWB), new String("POD"));
        issueTypeCdsList.put(new Integer(RETURN_MAWB), new String(" "));
        issueTypeCdsList.put(new Integer(MONITOR_ISSUE), new String(" "));
        issueTypeCdsList.put(new Integer(MISSING_DATA_MAWB), new String(" "));
        issueTypeCdsList.put(new Integer(MISSING_DATA_CRN), new String(" "));
        issueTypeCdsList.put(new Integer(MISSING_DATA_UNK), new String(" "));
        //Change for WR #135494 by Wipro
        issueTypeCdsList.put(PUX79_FTR_DLVRY, new String("PUX 79"));
        
        // Build up a list of "short descriptions" and their associated issue codes
        // for use on the GUI to search by issues
        // Some Issues can derive the IssueDesc, by iterating over
        // the IssueList data structure, others must be added by hand
        // Hashmap looks like this: "Short Text Desc" => [x, y, z]
        // ADDEVENT
        for (int i = MIN_ISSUE_CD; i <= MAX_ISSUE_CD; i++ ) {
            IssueDesc issueDesc = IssueList[i].issueDesc;
            String shortDesc = issueDesc.shortTextDesc;
            if (!issueCdsByDescList.containsKey(shortDesc)) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(new Integer(i));
                issueCdsByDescList.put(shortDesc, arrayList);
            } else {
                ArrayList arrayList = (ArrayList)issueCdsByDescList.get(shortDesc);
                arrayList.add(new Integer(i));
            }   
        }
        
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Integer(MULTI_POD_MAWB));
        issueCdsByDescList.put(MULTI_POD_MAWB_DESC.getShortTextDesc(), arrayList);
        
        arrayList = new ArrayList();
        arrayList.add(new Integer(RETURN_MAWB));
        issueCdsByDescList.put(RETURN_MAWB_DESC.getShortTextDesc(), arrayList);        

        arrayList = new ArrayList();
        arrayList.add(new Integer(MONITOR_ISSUE));
        issueCdsByDescList.put(MONITOR_ISSUE_DESC.getShortTextDesc(), arrayList);     
        
        arrayList = new ArrayList();
        arrayList.add(new Integer(MISSING_DATA_MAWB));
        arrayList.add(new Integer(MISSING_DATA_CRN));
        arrayList.add(new Integer(MISSING_DATA_UNK));
        issueCdsByDescList.put(MISSING_DATA_DESC.getShortTextDesc(), arrayList);

    }
    
    /**
     * Defines the prevention rules.  For each of the rows above, there must be a row here which defines how
     * the issue is resolved.
     * ADDEVENT
     */
    static {

        preventionList.put(new Integer(PUP_MAWB_MSSNG_MDE),                DeliveryPreventer.getInstance());

        preventionList.put(new Integer(PUP_MAWB_NO_MVMNT),                 PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(PUP_CRN_NO_MVMNT),                  PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(PUP_UNK_NO_MVMNT),                  PostPUPScansPreventer.getInstance());

        preventionList.put(new Integer(PUP_MAWB_NO_CC),                    ClearanceDelayPreventer.getInstance());
        preventionList.put(new Integer(PUP_CRN_NO_CC),                     ClearanceDelayPreventer.getInstance());
        preventionList.put(new Integer(PUP_UNK_NO_CC),                     ClearanceDelayPreventer.getInstance());
        
        preventionList.put(new Integer(STAT70_MAWB_MSSNG_MDE),             DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT70_MAWB_NO_MVMNT),              DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT70_CRN_NO_MVMNT),               DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT70_UNK_NO_MVMNT),               DeliveryPreventer.getInstance());

        preventionList.put(new Integer(STAT70_MAWB_NO_CC),                 DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT70_CRN_NO_CC),                  DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT70_UNK_NO_CC),                  DeliveryPreventer.getInstance());
        
        preventionList.put(new Integer(PUX23_MAWB_PKG_RCVD_AFTR_ARCRFT),   ECCOPreventer.getInstance());
        preventionList.put(new Integer(PUX23_MAWB_NO_MVMNT),               ECCOPreventer.getInstance());
        preventionList.put(new Integer(PUX23_CRN_PKG_RCVD_AFTR_ARCRFT),    PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(PUX23_CRN_NO_MVMNT),                PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(PUX23_UNK_NO_MVMNT),                PostPUPScansPreventer.getInstance());

        preventionList.put(new Integer(PUX17_CRN_CSTMR_RQSTS_FTR_DLVRY),   PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(PUX17_MAWB_CSTMR_RQSTS_FTR_DLVRY),  NonPreventer.getInstance());

        preventionList.put(new Integer(PUX15_CRN_BSNSS_CLSD),              PostPUPScansPreventer.getInstance());

        preventionList.put(new Integer(SOP_MAWB_NO_MVMNT),                 VANorDexPreventer.getInstance());
        preventionList.put(new Integer(SOP_CRN_NO_MVMNT),                  VANorDexPreventer.getInstance());
        preventionList.put(new Integer(SOP_UNK_NO_MVMNT),                  VANorDexPreventer.getInstance());

        preventionList.put(new Integer(RIP_MAWB_NO_MVMNT),                 RIPPreventer.getInstance());
        preventionList.put(new Integer(RIP_CRN_NO_MVMNT),                  RIPPreventer.getInstance());
        preventionList.put(new Integer(RIP_UNK_NO_MVMNT),                  RIPPreventer.getInstance());
        
        preventionList.put(new Integer(ROP_MAWB_NO_MVMNT),                 ROPPreventer.getInstance());
        preventionList.put(new Integer(ROP_CRN_NO_MVMNT),                  ROPPreventer.getInstance());
        preventionList.put(new Integer(ROP_UNK_NO_MVMNT),                  ROPPreventer.getInstance());

        preventionList.put(new Integer(HIP_MAWB_NO_MVMNT),                 HIPPreventer.getInstance());
        preventionList.put(new Integer(HIP_CRN_NO_MVMNT),                  HIPPreventer.getInstance());
        preventionList.put(new Integer(HIP_UNK_NO_MVMNT),                  HIPPreventer.getInstance());

        preventionList.put(new Integer(HOP_CRN_NO_MVMNT),                  HOPPreventer.getInstance());
        preventionList.put(new Integer(HOP_UNK_NO_MVMNT),                  HOPPreventer.getInstance());

        preventionList.put(new Integer(ECCO_CC_MAWB_NO_MVMNT),             PostPUPScansPreventer.getInstance());        
        preventionList.put(new Integer(ECCO_CC_CRN_NO_MVMNT),              PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(ECCO_CC_UNK_NO_MVMNT),              PostPUPScansPreventer.getInstance());

        preventionList.put(new Integer(ECCO_CC_CRN_MSSNG_SIP),             PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(ECCO_CC_UNK_MSSNG_SIP),             PostPUPScansPreventer.getInstance());
        
        preventionList.put(new Integer(STAT65_CC_CRN_NO_MVMNT),            PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(STAT65_CC_UNK_NO_MVMNT),            PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(STAT66_CC_CRN_NO_MVMNT),            PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(STAT66_CC_UNK_NO_MVMNT),            PostPUPScansPreventer.getInstance());
        
        preventionList.put(new Integer(STAT65_CC_CRN_MSSNG_SIP),           PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(STAT65_CC_UNK_MSSNG_SIP),           PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(STAT66_CC_CRN_MSSNG_SIP),           PostPUPScansPreventer.getInstance());
        preventionList.put(new Integer(STAT66_CC_UNK_MSSNG_SIP),           PostPUPScansPreventer.getInstance());

        preventionList.put(new Integer(SIP_CRN_MSSNG_VAN),                 SIPPreventer.getInstance());
        preventionList.put(new Integer(SIP_UNK_MSSNG_VAN),                 SIPPreventer.getInstance());

        preventionList.put(new Integer(VAN_CRN_MSSNG_DLVRY),               DEXorODAPreventer.getInstance());
        preventionList.put(new Integer(VAN_UNK_MSSNG_DLVRY),               DEXorODAPreventer.getInstance());

        preventionList.put(new Integer(DEX03_CRN_INCRRCT_ADDRSS),          DeliveryPreventer.getInstance());
        preventionList.put(new Integer(DEX03_UNK_INCRRCT_ADDRSS),          DeliveryPreventer.getInstance());

        preventionList.put(new Integer(DEX07_CRN_SHPMT_RFSD),              NonPreventer.getInstance());
        preventionList.put(new Integer(DEX07_UNK_SHPMT_RFSD),              NonPreventer.getInstance());

        preventionList.put(new Integer(DEX08_CRN_RECP_NT_IN),              REXorODAPreventer.getInstance());
        preventionList.put(new Integer(DEX08_UNK_RECP_NT_IN),              REXorODAPreventer.getInstance());

        preventionList.put(new Integer(DEX10_CRN_DMGD_NT_DLVRD),           NonPreventer.getInstance());
        preventionList.put(new Integer(DEX10_UNK_DMGD_NT_DLVRD),           NonPreventer.getInstance());

        preventionList.put(new Integer(MISSORT_CRN_MISSRTD),               NonPreventer.getInstance());
        preventionList.put(new Integer(MISSORT_UNK_MISSRTD),               NonPreventer.getInstance());

        preventionList.put(new Integer(STAT84_MAWB_DLY_BYND_CNTRL),        DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT84_CRN_DLY_BYND_CNTRL),         DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT84_UNK_DLY_BYND_CNTRL),         DeliveryPreventer.getInstance());

        preventionList.put(new Integer(STAT85_MAWB_MCHNCL_DLY),            STAT85Preventer.getInstance());
        preventionList.put(new Integer(STAT85_CRN_MCHNCL_DLY),             STAT85Preventer.getInstance());
        preventionList.put(new Integer(STAT85_UNK_MCHNCL_DLY),             STAT85Preventer.getInstance());
        
        preventionList.put(new Integer(STAT37_CRN_OBSRVD_PKG_DMGD),        NonPreventer.getInstance());
        preventionList.put(new Integer(STAT37_UNK_OBSRVD_PKG_DMGD),        NonPreventer.getInstance());
        
        preventionList.put(new Integer(STAT34_CRN_DACR),                   NonPreventer.getInstance());
        preventionList.put(new Integer(STAT34_UNK_DACR),                   NonPreventer.getInstance());
        
        preventionList.put(new Integer(HAL_CRN_HOLD_AT_LOC),               DeliveryPreventer.getInstance());
        preventionList.put(new Integer(HAL_UNK_HOLD_AT_LOC),               DeliveryPreventer.getInstance());
        
        preventionList.put(new Integer(HLD_CRN_HELD_AT_LOC),               DeliveryPreventer.getInstance());
        preventionList.put(new Integer(HLD_UNK_HELD_AT_LOC),               DeliveryPreventer.getInstance());
        
        preventionList.put(new Integer(STAT60_MAWB_BOND_CAGE),             DeliveryPreventer.getInstance());
        
        preventionList.put(new Integer(STAT55_MAWB_REG_AGENCY_CLEARNCE_DELAY), DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT55_CRN_REG_AGENCY_CLEARNCE_DELAY), DeliveryPreventer.getInstance());
        preventionList.put(new Integer(STAT55_UNK_REG_AGENCY_CLEARNCE_DELAY), DeliveryPreventer.getInstance());    
        
        preventionList.put(new Integer(ODA_MISSING_DELIVERY), 			   DeliveryPreventer.getInstance());
       //Change for WR #135494 by Wipro
        preventionList.put(new Integer(PUX79_FTR_DLVRY), 			   PostPUPScansPreventer.getInstance());
    }
    
    /**
     * Get an IssueDesc from the table above.
     * @param aTrackTypeCd
     * @param aExceptionCd
     * @param aShpmntTypeCd
     * @return an IssueDesc
     */
    public final static IssueDesc getIssueDesc(String aTrackTypeCd, String aExceptionCd, char aShpmntTypeCd) {
        for (int i = 0; i < IssueList.length; i++) {
            if (IssueList[i].trackTypeCd.equals(aTrackTypeCd)) {
                if (IssueList[i].trackExcpCd.equals(aExceptionCd)) {
                    if (IssueList[i].shpmtTypeCd == aShpmntTypeCd) {
                        return IssueList[i].issueDesc;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Same as above, but this time use only the value that
     * would be in the database.  Used by GUI.
     * @param anIssueCd
     * @return
     */
    public final static IssueDesc getIssueDesc(int anIssueCd) {
        return (IssueDesc)issueDescList.get(new Integer(anIssueCd));
    }
    
    /**
     * Same as above, but this time use only the value that
     * would be in the database.  Used by GUI.
     * @param anIssueCd
     * @return
     */
    public final static String getIssueTypeCode(int anIssueCd) {
        return (String)issueTypeCdsList.get(new Integer(anIssueCd));
    }
    
    /*
     * Create a CSV file of the tables above.
     */
    public static String listIssues() {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < IssueList.length; i++) {
            //if ((IssueList[i].shpmtTypeCd == 'M') ||
            //   (IssueList[i].shpmtTypeCd == 'C')) {
                sb.append(IssueList[i].issueTypeCd);
                sb.append(',');
                TrackDesc trackDesc = TrackTypes.getTrackTypeDesc(IssueList[i].trackTypeCd);
                sb.append(trackDesc.get_shortName());
                sb.append(',');
                if (IssueList[i].trackExcpCd != null) {
                    sb.append(IssueList[i].trackExcpCd);
                }
                sb.append(',');
                sb.append(IssueList[i].shpmtTypeCd);
                sb.append(',');
                int timeCalcMethod = IssueList[i].timeCalcMethod; 
                if (timeCalcMethod == IMMEDIATE) { 
                    sb.append("Immediate");
                } else {
                    if (timeCalcMethod == ADD_HRS_TO_EVENT) {
                        sb.append("Add Hours:");
                        sb.append(IssueList[i].timeHourOffset);
                    } else {
                        sb.append("Midnight");
                    }
                }
                sb.append(',');
                sb.append(IssueList[i].issueDesc);
                sb.append(',');
                
                Integer issueCd = new Integer(IssueList[i].issueTypeCd);
                if (resolveList.containsKey(issueCd)) {
                    Resolver resolver = (Resolver)resolveList.get(issueCd);
                    String resolverName = resolver.getClass().getName();
                    String resolverShortName = resolverName.substring(resolverName.lastIndexOf('.')+1);
                    if (resolverShortName.equals("SpecificEventResolver")) {
                        sb.append(resolverShortName);
                        sb.append(':');
                        sb.append(resolver);
                    } else {
                        sb.append(resolverShortName);
                    }
                }            
                sb.append("\n");
            //}
        }
        return sb.toString();
    }
    
//    public static void main(String[] args) {
//        System.out.println(listIssues());
//    }
    
    
}
