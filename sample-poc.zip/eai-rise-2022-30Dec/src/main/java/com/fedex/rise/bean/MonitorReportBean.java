package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.event.ActionEvent;
import javax.faces.component.UIComponent;

/**
 * Backing Bean class for the Monitor Report screen.
 * @author be379961
 *
 */
public class MonitorReportBean implements Serializable {
	/** serializing version */
    private static final long serialVersionUID = 1L;
    /** logger */
    private static final Log log = LogFactory.getLog(MonitorReportBean.class);
    
    /** delegate to get shipper data */
	private Date _fromDate = null;
	private Date _toDate = null;
	private String _selectRadio =  "one";
	private Calendar _calendar = Calendar.getInstance();
	private String _thisYear = String.valueOf(_calendar.get(Calendar.YEAR));
	private String _lastYear = String.valueOf(_calendar.get(Calendar.YEAR)-1);
	private String _selectYear =  new String(_thisYear);
	private String _selectMonth =  new String("Jan");
    private Map  _attribute = new HashMap(); 
	
    private static SelectItem[] selectRadioItems = {
    	new SelectItem("one","Date Range"),
    	new SelectItem("two", "Month and Year"),
    	new SelectItem("three", "Year")
    };
    
    private static SelectItem[] selectMonthItems = {
    	new SelectItem("0","January"),
    	new SelectItem("1", "February"),
    	new SelectItem("2","March"),
    	new SelectItem("3", "April"),
    	new SelectItem("4","May"),
    	new SelectItem("5", "June"),
    	new SelectItem("6","July"),
    	new SelectItem("7", "August"),
    	new SelectItem("8","September"),
    	new SelectItem("9", "October"),
    	new SelectItem("10","November"),
    	new SelectItem("11","December")
    };
     
    private SelectItem[] selectYearItems = {
    	new SelectItem(_lastYear, _lastYear),
    	new SelectItem(_thisYear, _thisYear)
    };
    
   
    // =========================================================================
    // Public Methods
    // =========================================================================
    /**
     * Get the selected tracking unique number attribute.
     * @return String of the tracking unique number attribute.
     */
    public String getSelectedTrackingUniqueNbr(){
    	return (String)_attribute.get("tracking_unique_nbr");
    }
    /**
     * Get the selected tracking number attribute.
     * @return String of the tracking number attribute.
     */
    public String getSelectedTrackingNbr(){
    	return (String)_attribute.get("tracking_nbr");
    }
    
    /**
     * Get the selected monitor type attribute.
     * @return String of the monitor type attribute.
     */
    public String getSelectedMonitorType(){
    	return (String)_attribute.get("monitor_type");
    }
    
    /**
     * Get the selected monitor name attribute.
     * @return String of the monitor name attribute.
     */
    public String getSelectedMonitorName(){
    	return (String)_attribute.get("monitor_name");
    }
    
    /**
     * Sets the monitor name and type put in the 
     * hash attribute hash table.
     * @param component the UIComponent from the action listener.
     */ 
    public void selectedMonitor(ActionEvent event){
    	UIComponent component = event.getComponent();
    	setSelectedMonitor(component);
    }
    /**
     * Sets the monitor name type through the 
     * action listener for the monitorReportList.jsp
     * @param event the ActionEvent from the action listener.
     */
    private void setSelectedMonitor(UIComponent component){ 
    	// Store the monitor type in the hash table.
    	String monitorType = 
    		(String)component.getAttributes().get("monitor_type");
    	_attribute.put("monitor_type", monitorType);
    	
    	// Store the monitor name in the hash table.
    	String monitorName = 
    		(String)component.getAttributes().get("monitor_name");
    	
    	_attribute.put("monitor_name", monitorName);
    }
    
    /**
     * Sets the tracking number and type put in the 
     * hash attribute hash table.
     * @param component the UIComponent from the action listener.
     */ 
    public void selectedTrackingNbr(ActionEvent event){
    	UIComponent component = event.getComponent();
    	setSelectedTrackingNbr(component);
    }
    /**
     * Sets the tracking number type through the 
     * action listener for the monitorReportDetailList.jsp
     * @param event the ActionEvent from the action listener.
     */
    private void setSelectedTrackingNbr(UIComponent component){ 
    	// Store the tracking number in the hash table.
    	String trackingNbr = 
    		(String)component.getAttributes().get("tracking_nbr");
    	_attribute.put("tracking_nbr", trackingNbr);
    	
    	// Store the tracking unique number in the hash table.
    	String trackingUniqueNbr = 
    		(String)component.getAttributes().get("tracking_unique_nbr");
    	_attribute.put("tracking_unique_nbr", trackingUniqueNbr);
    }

    /**
     * Sets the selected month in the hash attribute hash table.
     * @param component the UIComponent from the action listener.
     */
    private void setSelectedMonth(UIComponent component){ 
    	Object value = (Object)component.getAttributes().get("selected_month");
    	String string = value.toString();
    	String stringInt = new String();
    	if (string.equals("January")){
    		stringInt = "0";
    	}else if (string.equals("February")){
    		stringInt = "1";
    	}else if (string.equals("March")){
    		stringInt = "2";
    	}else if (string.equals("April")){
    		stringInt = "3";
    	}else if (string.equals("May")){
    		stringInt = "4";
    	}else if (string.equals("June")){
    		stringInt = "5";
    	}else if (string.equals("July")){
    		stringInt = "6";
    	}else if (string.equals("August")){
    		stringInt = "7";
    	}else if (string.equals("September")){
    		stringInt = "8";
    	}else if (string.equals("October")){
    		stringInt = "9";
    	}else if (string.equals("November")){
    		stringInt = "10";
    	}else if (string.equals("December")){
    		stringInt = "11";
    	}
    	_attribute.put("selected_month", stringInt);
    	
    	value = (Object)component.getAttributes().get("selected_month_number");
    	string = value.toString();
    	_attribute.put("selected_month_number", string);
    }
    
    /**
     * @return selectRadioItems
     */
    public SelectItem[] getSelectRadioItems() {
    	return selectRadioItems;
    }
    /**
     * 
     * @return selectMonthItems
     */
    public SelectItem[] getSelectMonthItems() {
    	return selectMonthItems;
    }
    /**
     * 
     * @return selectYearItems
     */
    public SelectItem[] getSelectYearItems() {
    	return selectYearItems;
    }
    
    /**
     * @return the _fromDate
     */
    public Date getFromDate() {
    	// Set the default date.
    	if (_fromDate == null){
    		_fromDate = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, - 1); // subtract 1 day.
    		_fromDate = startDate.getTime();
    	}
        return _fromDate;
    }


    /**
     * @param fromDate the _fromDate to set
     */
    public void setFromDate(Date fromDate) {	
        _fromDate = fromDate;
    }
    
    /**
     * @param edit the _fromDate
     */
    private void editFromDate() {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	if (_fromDate != null){
    		Calendar oldestStartDate = Calendar.getInstance();
    		
    		// If fromDate is more than a year less than _toDate, restrict 
    		// fromDate to a year.
    		oldestStartDate.setTime(_toDate);
    		oldestStartDate.add(Calendar.MONTH, -6);
    		if (_fromDate.before(oldestStartDate.getTime())){
    			_fromDate = oldestStartDate.getTime();
    			
    			log.info("From date is more than 6 months before this date, and has been reset to the To date minus 6 months.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"From date is more than 6 months before this date, and has been reset to the To date minus 6 months.", 
                		null);
                facesContext.addMessage(null, facesMessage);
    		}
    	}
    	// If fromDate is greater than _toDate shall set them equal.
    	if (_fromDate.after(_toDate)){
    		_fromDate = _toDate;
    		
    		log.info("From date is greater than To date, and has been reset equal to the To date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"From date is greater than To date, and has been reset equal to the To date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    }
    
    /**
     * @return the _toDate
     */
    public Date getToDate() {
    	if (_toDate == null){
    		Calendar toDate = Calendar.getInstance();
    		toDate.add(Calendar.DAY_OF_YEAR, - 1); // subtract 1 day.
    		_toDate = new Date(toDate.getTimeInMillis());
    	}
        return _toDate;
    }

    /**
     * @param toDate the _toDate to set
     */
    public void setToDate(Date toDate) {
        _toDate = toDate;
    }
    
    /**
     * @param edit the _toDate
     */
    private void editToDate() {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	if (_toDate != null){
    		// If toDate is before the _fromDate shall set them equal.
    		if (_toDate.before(_fromDate)){
    			_toDate.setTime(_fromDate.getTime());
    			
    			log.info("To date is less than the From date, and has been reset equal to the From date.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"To date is less than the From date, and has been reset equal to the From date.", 
                		null);
                facesContext.addMessage(null, facesMessage);
    		}
    		
    		// Max To date is todays date after 5:10 PM MTN (17:10 MTN)
    		Calendar maxToDate = Calendar.getInstance();   		
    		maxToDate.set(Calendar.HOUR_OF_DAY, 17); // 17:00 MTN.
    		maxToDate.set(Calendar.MINUTE, 10); // 17:10 MTN.
    		
    		Calendar toCalendar = Calendar.getInstance();
    		int currentHour = toCalendar.get(Calendar.HOUR_OF_DAY);
    		int currentMinute = toCalendar.get(Calendar.MINUTE);
    		
    		toCalendar.setTime(_toDate);
    		toCalendar.set(Calendar.HOUR_OF_DAY, currentHour);
    		toCalendar.set(Calendar.MINUTE, currentMinute);
    		Date toDate = toCalendar.getTime();
    		
    		Calendar yesterday = Calendar.getInstance();
			yesterday.add(Calendar.DAY_OF_YEAR, -1);
    			
    		if (toDate.before(maxToDate.getTime()) && _toDate.after(yesterday.getTime())){
    			// If the request is made before 17:10 before today, set to date to yesterday.
    			_toDate.setTime(yesterday.getTimeInMillis());
    			
    			log.info("If the request is made before 6:10 PM CT before today, set To Date to yesterday.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"If the request is made before 6:10 PM CT before today, set To Date to yesterday.", 
                		null);
                facesContext.addMessage(null, facesMessage);
    		}
    		
    		//Check if to date is a future day. Set max date and time, todays date at 23:59.
    		maxToDate.set(Calendar.HOUR_OF_DAY, 23); // 23:00 MTN.
    		maxToDate.set(Calendar.MINUTE, 59); // 23:59 MTN.
    		
    		if (_toDate.after(maxToDate.getTime())){
    			// If the _toDate is greater than todays date at 23:59, set _toDate to yesterday.
    			_toDate.setTime(yesterday.getTimeInMillis());
    			
    			log.info("The To Date is greater than today, set To Date to yesterday.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"The To Date is greater than today, set To Date to yesterday.", 
                		null);
                facesContext.addMessage(null, facesMessage);
    		}
    	}
    }
    
    /**
     * @return the _selectRadio
     */
    public String getSelectRadio() {
    	if (_selectRadio == null){
    		_selectRadio =  "one";
    	}
        return _selectRadio;
    }
    
    /**
     * @param selectRadio the _selectRadio to set
     */
    public void setSelectRadio(String selectRadio) {
    	_selectRadio = selectRadio;
    }
    
    /**
     * @return the _selectRadio
     */
    public boolean getSelectRadioOne() {
    	return _selectRadio.equalsIgnoreCase("one");
    }
    
    /**
     * @return the _selectRadio
     */
    public boolean getSelectRadioTwo() {
    	return _selectRadio.equalsIgnoreCase("two");
    }
    
    /**
     * @return the _selectRadio
     */
    public boolean getSelectRadioThree() {
    	return _selectRadio.equalsIgnoreCase("three");
    }
    
    /**
     * @return the _selectYear
     */
    public String getYear() {
        return _selectYear;
    }
    
    /**
     * @param selectYear the selectYear to set
     */
    public void setYear(String selectYear) {
    	_selectYear = selectYear;
    	
    	// Set the from date.
		int year = Integer.parseInt(selectYear);
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, Calendar.JANUARY, 1);
		_fromDate.setTime(fromDate.getTimeInMillis());
		
		// Set the to date.
		Calendar toDate = Calendar.getInstance();
		if (year == toDate.get(Calendar.YEAR)){
			toDate.set(Calendar.HOUR, - 24); // subtract 1 day.
			setToDate(toDate.getTime());
		}else{
			toDate.set(year, Calendar.DECEMBER, 31);
			setToDate(toDate.getTime());
		}
    }
    
    /**
     * @return the _selectYear
     */
    public String getSelectYear() {
        return _selectYear;
    }
    
    /**
     * @param selectYear the selectYear to set
     */
    public void setSelectYear(String selectYear) {
    	_selectYear = selectYear;
    	
    	// Set the from date.
    	int month = Integer.parseInt(getSelectMonth());
		int year = Integer.parseInt(selectYear);
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, month, 1);
		_fromDate.setTime(fromDate.getTimeInMillis());
		
		// Set the to date.
		int lastDayMonth = fromDate.getActualMaximum(Calendar.DAY_OF_MONTH); 
		Calendar toDate = Calendar.getInstance();
		toDate.set(year, month, lastDayMonth);
		setToDate(toDate.getTime());
    }
    
    /**
     * @return the selectMonth
     */
    public String getSelectMonth() {
    	if (_selectMonth == null){
    		_selectMonth =  "0";
    	}
        return _selectMonth;
    }
    
    /**
     * @param selectMonth the _selectMonth to set
     */
    public void setSelectMonth(String selectMonth) {
    	_selectMonth = selectMonth;
    	
    	// Set the from date.
    	int month = Integer.parseInt(selectMonth);
		int year = Integer.parseInt(getSelectYear());
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(year, month, 1);
		_fromDate.setTime(fromDate.getTimeInMillis());
		
		// Set the to date.
		int lastDayMonth = fromDate.getActualMaximum(Calendar.DAY_OF_MONTH); 
		Calendar toDate = Calendar.getInstance();
		toDate.set(year, month, lastDayMonth);
		setToDate(toDate.getTime());
    }
    
    
    /**
     * Action method to go to the Monitor Report List screen.
     * @return "monitorReportList"
     */
    public String viewReportAction(){
    	editFromDate();
    	editToDate();
    	return "monitorReportList";
    }
    
    /**
     * Action method to reset the Monitor Report screen.
     *
     */
    public void resetAction(){
    	_fromDate = null;
    	_toDate = null;
    	_selectRadio =  "one";
    	_calendar = Calendar.getInstance();
    	_thisYear = String.valueOf(_calendar.get(Calendar.YEAR));
    	_lastYear = String.valueOf(_calendar.get(Calendar.YEAR)-1);
    	_selectYear =  new String(_thisYear);
    	_selectMonth =  new String("Jan");
        _attribute = new HashMap(); 
    }
}
