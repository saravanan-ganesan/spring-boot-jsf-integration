package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * Shipment Value Object (or Transfer Object) used to encapsulate the shipment
 * data for transport.
 */
public class ShipmentVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;              // VARCHAR2(12);
    private String _trkng_item_uniq_nbr;         // VARCHAR2(10);
    private int    _grp_nbr;                     // NUMBER(6);
    private String _acct_nbr;                    // VARCHAR2(9);
    private int    _lane_nbr;                    // NUMBER(6);
    private String _svc_type_cd;                 // VARCHAR2(10);
    private String _shpmt_type_cd;               // VARCHAR2(3);
    private int    _trkng_item_form_cd;          // NUMBER(4);
    private int    _pack_type_cd;                // NUMBER(2);
    private String _orig_loc_cd;                 // VARCHAR2(5);
    private String _dest_loc_cd;                 // VARCHAR2(5);
    private int    _shpmt_wgt;                   // NUMBER(10,6);
    private char   _shpmt_uom_cd = ' ';          // CHAR(1);
    private Date   _ship_dt;                     // DATE;
    private String _shpr_co_nm;                  // VARCHAR2(35);
    private String _shpr_ph_nbr;                 // VARCHAR2(15);
    private String _shpr_addr_line_one_desc;     // VARCHAR2(35);
    private String _shpr_addr_line_two_desc;     // VARCHAR2(35);
    private String _shpr_addr_line_three_desc;   // VARCHAR2(35);
    private String _shpr_city_nm;                // VARCHAR2(30);
    private String _shpr_pstl_cd;                // VARCHAR2(9);
    private String _shpr_cntry_cd;               // VARCHAR2(2);
    private String _shpr_st_prov_cd;             // VARCHAR2(2);
    private String _recp_co_nm;                  // VARCHAR2(35);
    private String _recp_ph_nbr;                 // VARCHAR2(15);
    private String _recp_addr_line_one_desc;     // VARCHAR2(35);
    private String _recp_addr_line_two_desc;     // VARCHAR2(35);
    private String _recp_addr_line_three_desc;   // VARCHAR2(35);
    private String _recp_city_nm;                // VARCHAR2(30);
    private String _recp_st_prov_cd;             // VARCHAR2(2);
    private String _recp_cntry_cd;               // VARCHAR2(2);
    private String _recp_pstl_cd;                // VARCHAR2(9);
    private String _actl_del_nm;                 // VARCHAR2(35);
    private String _actl_addr_line_one_desc;     // VARCHAR2(35);
    private Calendar   _del_dt;                  // DATE;
    private String _spcl_hndlg_grp;              // VARCHAR2(8);
    private String _crtg_agent_co_nm;            // VARCHAR2(35);
    private String _cstms_curr_cd;               // VARCHAR2(3);
    private int    _cstms_value_amt;             // NUMBER(10,2);
    private int    _dimnl_wgt;                   // NUMBER(10,6);
    private int    _inv_amt;                     // NUMBER(10,2);
    private int    _shpmt_pkg_qt;                // NUMBER(4);
    private Calendar _last_event_tmstp;          // TIMESTAMP(6);
    private String _last_event_track_type_cd;    // VARCHAR2(2);
    private String _last_event_track_loc_cd;
    private Calendar _commit_dt;                 // DATE(7);
    private Calendar _adj_commit_dt;             // DATE(7);
    private int    _adj_commit_dt_offst_nbr;     // NUMBER(6);
    private String _perf_rsult_cd;               // VARCHAR2(11);
    private int   _package_piece_qty;            // NUMBER(4);
    private int   _delivery_qty;                 // NUMBER(6);
    private char _skid_intact_flag = ' ';        // CHAR(1);
    private char _quantity_observed_flag = ' ';  // CHAR(1);
    private Calendar _est_avail_for_delv_dt;
    private String _last_stat_desc;
    private String _last_stat_track_loc_cd;
    private Date _last_stat_tmstp;
    private Calendar _cleared_cstms_tmstp;
    private String _wrk_stat_cd;
    
    /**
     * @return the _last_stat_desc
     */
    public String get_last_stat_desc() {
        return _last_stat_desc;
    }

    /**
     * @param _last_stat_desc the _last_stat_desc to set
     */
    public void set_last_stat_desc(String _last_stat_desc) {
        this._last_stat_desc = _last_stat_desc;
    }

    /**
     * Default Constructor
     */
    public ShipmentVO() {
    }
    
    /**
     * Think of this as a deep copy constructor
     * @param aShipmentVO
     */
    public ShipmentVO(ShipmentVO aShipmentVO) {
        super();
        this._trkng_item_nbr = aShipmentVO._trkng_item_nbr;
        this._trkng_item_uniq_nbr = aShipmentVO._trkng_item_uniq_nbr;
        this._grp_nbr = aShipmentVO._grp_nbr;
        this._acct_nbr = aShipmentVO._acct_nbr;
        this._lane_nbr = aShipmentVO._lane_nbr;
        this._svc_type_cd = aShipmentVO._svc_type_cd;
        this._shpmt_type_cd = aShipmentVO._shpmt_type_cd;
        this._trkng_item_form_cd = aShipmentVO._trkng_item_form_cd;
        this._pack_type_cd = aShipmentVO._pack_type_cd;
        this._orig_loc_cd = aShipmentVO._orig_loc_cd;
        this._dest_loc_cd = aShipmentVO._dest_loc_cd;
        this._shpmt_wgt = aShipmentVO._shpmt_wgt;
        this._shpmt_uom_cd = aShipmentVO._shpmt_uom_cd;
        if (aShipmentVO._ship_dt != null) {
            this._ship_dt = (Date) aShipmentVO._ship_dt.clone();
        } else {
            this._ship_dt = null;
        }
        this._shpr_co_nm = aShipmentVO._shpr_co_nm;
        this._shpr_ph_nbr = aShipmentVO._shpr_ph_nbr;
        this._shpr_addr_line_one_desc = aShipmentVO._shpr_addr_line_one_desc;
        this._shpr_addr_line_two_desc = aShipmentVO._shpr_addr_line_two_desc;
        this._shpr_addr_line_three_desc = aShipmentVO._shpr_addr_line_three_desc;
        this._shpr_city_nm = aShipmentVO._shpr_city_nm;
        this._shpr_pstl_cd = aShipmentVO._shpr_pstl_cd;
        this._shpr_cntry_cd = aShipmentVO._shpr_cntry_cd;
        this._shpr_st_prov_cd = aShipmentVO._shpr_st_prov_cd;
        this._recp_co_nm = aShipmentVO._recp_co_nm;
        this._recp_ph_nbr = aShipmentVO._recp_ph_nbr;
        this._recp_addr_line_one_desc = aShipmentVO._recp_addr_line_one_desc;
        this._recp_addr_line_two_desc = aShipmentVO._recp_addr_line_two_desc;
        this._recp_addr_line_three_desc = aShipmentVO._recp_addr_line_three_desc;
        this._recp_city_nm = aShipmentVO._recp_city_nm;
        this._recp_st_prov_cd = aShipmentVO._recp_st_prov_cd;
        this._recp_cntry_cd = aShipmentVO._recp_cntry_cd;
        this._recp_pstl_cd = aShipmentVO._recp_pstl_cd;
        this._actl_del_nm = aShipmentVO._actl_del_nm;
        this._actl_addr_line_one_desc = aShipmentVO._actl_addr_line_one_desc;
        if (aShipmentVO._del_dt != null) {
            this._del_dt = (Calendar) aShipmentVO._del_dt.clone();
        } else {
            this._del_dt = null;
        }
        this._spcl_hndlg_grp = aShipmentVO._spcl_hndlg_grp;
        this._crtg_agent_co_nm = aShipmentVO._crtg_agent_co_nm;
        this._cstms_curr_cd = aShipmentVO._cstms_curr_cd;
        this._cstms_value_amt = aShipmentVO._cstms_value_amt;
        this._dimnl_wgt = aShipmentVO._dimnl_wgt;
        this._inv_amt = aShipmentVO._inv_amt;
        this._shpmt_pkg_qt = aShipmentVO._shpmt_pkg_qt;
        if (aShipmentVO._last_event_tmstp != null) {
            this._last_event_tmstp = (Calendar) aShipmentVO._last_event_tmstp.clone();
        } else {
            this._last_event_tmstp = null;
        }
        this._last_event_track_type_cd = aShipmentVO._last_event_track_type_cd;
        this._last_event_track_loc_cd = aShipmentVO._last_event_track_loc_cd;
        if (aShipmentVO._commit_dt != null) {
            this._commit_dt = (Calendar) aShipmentVO._commit_dt.clone();
        } else {
            this._commit_dt = null;
        }
        
        if (aShipmentVO._adj_commit_dt != null) {
            this._adj_commit_dt = (Calendar) aShipmentVO._adj_commit_dt.clone();
        } else {
            this._adj_commit_dt = null;
        }
        this._adj_commit_dt_offst_nbr = aShipmentVO._adj_commit_dt_offst_nbr;
        this._perf_rsult_cd = aShipmentVO._perf_rsult_cd;
        
        this._package_piece_qty = aShipmentVO.get_package_piece_qty();
        this._delivery_qty = aShipmentVO.get_delivery_qty();
        this._skid_intact_flag = aShipmentVO.get_skid_intact_flag();
        this._quantity_observed_flag = aShipmentVO.get_quantity_observed_flag();
        this._est_avail_for_delv_dt = aShipmentVO.get_est_avail_for_delv_dt();
        this._last_stat_desc = aShipmentVO.get_last_stat_desc();
        
        this._last_stat_track_loc_cd = aShipmentVO.get_last_stat_track_loc_cd();
        if (aShipmentVO._last_stat_tmstp != null) {
            this._last_stat_tmstp = (Date)aShipmentVO.get_last_stat_tmstp().clone();
        } else {
            this._last_stat_tmstp = null;
        }
        
        if (aShipmentVO._cleared_cstms_tmstp != null) {
            this._cleared_cstms_tmstp = (Calendar)aShipmentVO.get_cleared_cstms_tmstp().clone();
        } else {
            this._cleared_cstms_tmstp = null;
        }
        
        this._wrk_stat_cd = aShipmentVO.get_wrk_stat_cd();
    }
    
    /**
     * @return the _est_avail_for_delv_dt
     */
    public Calendar get_est_avail_for_delv_dt() {
        return _est_avail_for_delv_dt;
    }

    /**
     * @param _est_avail_for_delv_dt the _est_avail_for_delv_dt to set
     */
    public void set_est_avail_for_delv_dt(Calendar _est_avail_for_delv_dt) {
        this._est_avail_for_delv_dt = _est_avail_for_delv_dt;
    }
    
    /**
     * @return the _delivery_qty
     */
    public int get_delivery_qty() {
        return _delivery_qty;
    }

    /**
     * @param _delivery_qty the _delivery_qty to set
     */
    public void set_delivery_qty(int _delivery_qty) {
        this._delivery_qty = _delivery_qty;
    }

    /**
     * @return the _package_piece_qty
     */
    public int get_package_piece_qty() {
        return _package_piece_qty;
    }

    /**
     * @param _package_piece_qty the _package_piece_qty to set
     */
    public void set_package_piece_qty(int _package_piece_qty) {
        this._package_piece_qty = _package_piece_qty;
    }

    /**
     * @return the _quantity_observed_flag
     */
    public char get_quantity_observed_flag() {
        return _quantity_observed_flag;
    }

    /**
     * @param _quantity_observed_flag the _quantity_observed_flag to set
     */
    public void set_quantity_observed_flag(char _quantity_observed_flag) {
        this._quantity_observed_flag = _quantity_observed_flag;
    }

    /**
     * @return the _skid_intact_flag
     */
    public char get_skid_intact_flag() {
        return _skid_intact_flag;
    }

    /**
     * @param _skid_intact_flag the _skid_intact_flag to set
     */
    public void set_skid_intact_flag(char _skid_intact_flag) {
        this._skid_intact_flag = _skid_intact_flag;
    }

    /**
     * @return the _adj_commit_dt
     */
    public Calendar get_adj_commit_dt() {
        return _adj_commit_dt;
    }

    /**
     * @param _adj_commit_dt the _adj_commit_dt to set
     */
    public void set_adj_commit_dt(Calendar _adj_commit_dt) {
        this._adj_commit_dt = _adj_commit_dt;
    }

    /**
     * @return the _commit_dt
     */
    public Calendar get_commit_dt() {
        return _commit_dt;
    }

    /**
     * @param _commit_dt the _commit_dt to set
     */
    public void set_commit_dt(Calendar _commit_dt) {
        this._commit_dt = _commit_dt;
    }

    /**
     * @return the _adj_commit_dt_offst_nbr
     */
    public int get_adj_commit_dt_offst_nbr() {
        return _adj_commit_dt_offst_nbr;
    }

    /**
     * @param _adj_commit_dt_offst_nbr the _adj_commit_dt_offst_nbr to set
     */
    public void set_adj_commit_dt_offst_nbr(int _adj_commit_dt_offst_nbr) {
        this._adj_commit_dt_offst_nbr = _adj_commit_dt_offst_nbr;
    }
    
    /**
     * @return the _latest_event_tmstp
     */
    public Calendar get_last_event_tmstp() {
        return _last_event_tmstp;
    }

    /**
     * @param _latest_event_tmstp the _latest_event_tmstp to set
     */
    public void set_last_event_tmstp(Calendar _latest_event_tmstp) {
        this._last_event_tmstp = _latest_event_tmstp;
    }
    /**
     * @return the _ship_dt
     */
    public Date get_ship_dt() {
        return _ship_dt;
    }
    /**
     * @param _ship_dt the _ship_dt to set
     */
    public void set_ship_dt(Date _ship_dt) {
        this._ship_dt = _ship_dt;
    }
    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }
    /**
     * @param _acct_nbr the _acct_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr;
    }
    /**
     * @return the _actl_del_nm
     */
    public String get_actl_del_nm() {
        return _actl_del_nm;
    }
    /**
     * @param _actl_del_nm the _actl_del_nm to set
     */
    public void set_actl_del_nm(String _actl_del_nm) {
        this._actl_del_nm = _actl_del_nm;
    }
    /**
     * @return the _crtg_agent_co_nm
     */
    public String get_crtg_agent_co_nm() {
        return _crtg_agent_co_nm;
    }
    /**
     * @param _crtg_agent_co_nm the _crtg_agent_co_nm to set
     */
    public void set_crtg_agent_co_nm(String _crtg_agent_co_nm) {
        this._crtg_agent_co_nm = _crtg_agent_co_nm;
    }
    /**
     * @return the _cstms_curr_cd
     */
    public String get_cstms_curr_cd() {
        return _cstms_curr_cd;
    }
    /**
     * @param _cstms_curr_cd the _cstms_curr_cd to set
     */
    public void set_cstms_curr_cd(String _cstms_curr_cd) {
        this._cstms_curr_cd = _cstms_curr_cd;
    }
    /**
     * @return the _cstms_value_amt
     */
    public int get_cstms_value_amt() {
        return _cstms_value_amt;
    }
    /**
     * @param _cstms_value_amt the _cstms_value_amt to set
     */
    public void set_cstms_value_amt(int _cstms_value_amt) {
        this._cstms_value_amt = _cstms_value_amt;
    }
    /**
     * @return the _del_dt
     */
    public Calendar get_del_dt() {
        return _del_dt;
    }
    /**
     * @param _del_dt the _del_dt to set
     */
    public void set_del_dt(Calendar _del_dt) {
        this._del_dt = _del_dt;
    }
    /**
     * @return the _dest_loc_cd
     */
    public String get_dest_loc_cd() {
        return _dest_loc_cd;
    }
    /**
     * @param _dest_loc_cd the _dest_loc_cd to set
     */
    public void set_dest_loc_cd(String _dest_loc_cd) {
        this._dest_loc_cd = _dest_loc_cd;
    }
    /**
     * @return the _dimnl_wgt
     */
    public int get_dimnl_wgt() {
        return _dimnl_wgt;
    }
    /**
     * @param _dimnl_wgt the _dimnl_wgt to set
     */
    public void set_dimnl_wgt(int _dimnl_wgt) {
        this._dimnl_wgt = _dimnl_wgt;
    }
    /**
     * @return the _grp_nbr
     */
    public int get_grp_nbr() {
        return _grp_nbr;
    }
    /**
     * @param _grp_nm the _grp_nm to set
     */
    public void set_grp_nbr(int _grp_nbr) {
        this._grp_nbr = _grp_nbr;
    }
    /**
     * @return the _inv_amt
     */
    public int get_inv_amt() {
        return _inv_amt;
    }
    /**
     * @param _inv_amt the _inv_amt to set
     */
    public void set_inv_amt(int _inv_amt) {
        this._inv_amt = _inv_amt;
    }
    /**
     * @return the _lane_nbr
     */
    public int get_lane_nbr() {
        return _lane_nbr;
    }
    /**
     * @param _lane_nbr the _lane_nbr to set
     */
    public void set_lane_nbr(int _lane_nbr) {
        this._lane_nbr = _lane_nbr;
    }
    /**
     * @return the _orig_loc_cd
     */
    public String get_orig_loc_cd() {
        return _orig_loc_cd;
    }
    /**
     * @param _orig_loc_cd the _orig_loc_cd to set
     */
    public void set_orig_loc_cd(String _orig_loc_cd) {
        this._orig_loc_cd = _orig_loc_cd;
    }
    /**
     * @return the _pack_type_cd
     */
    public int get_pack_type_cd() {
        return _pack_type_cd;
    }
    /**
     * @param _pack_type_cd the _pack_type_cd to set
     */
    public void set_pack_type_cd(int _pack_type_cd) {
        this._pack_type_cd = _pack_type_cd;
    }

    /**
     * @return the _recp_city_nm
     */
    public String get_recp_city_nm() {
        return _recp_city_nm;
    }
    /**
     * @param _recp_city_nm the _recp_city_nm to set
     */
    public void set_recp_city_nm(String _recp_city_nm) {
        this._recp_city_nm = _recp_city_nm;
    }
    /**
     * @return the _recp_cntry_cd
     */
    public String get_recp_cntry_cd() {
        return _recp_cntry_cd;
    }
    /**
     * @param _recp_cntry_cd the _recp_cntry_cd to set
     */
    public void set_recp_cntry_cd(String _recp_cntry_cd) {
        this._recp_cntry_cd = _recp_cntry_cd;
    }
    /**
     * @return the _recp_co_nm
     */
    public String get_recp_co_nm() {
        return _recp_co_nm;
    }
    /**
     * @param _recp_co_nm the _recp_co_nm to set
     */
    public void set_recp_co_nm(String _recp_co_nm) {
        this._recp_co_nm = _recp_co_nm;
    }
    /**
     * @return the _recp_ph_nbr
     */
    public String get_recp_ph_nbr() {
        return _recp_ph_nbr;
    }
    /**
     * @param _recp_ph_nbr the _recp_ph_nbr to set
     */
    public void set_recp_ph_nbr(String _recp_ph_nbr) {
        this._recp_ph_nbr = _recp_ph_nbr;
    }
    /**
     * @return the _recp_pstl_cd
     */
    public String get_recp_pstl_cd() {
        return _recp_pstl_cd;
    }
    /**
     * @param _recp_pstl_cd the _recp_pstl_cd to set
     */
    public void set_recp_pstl_cd(String _recp_pstl_cd) {
        this._recp_pstl_cd = _recp_pstl_cd;
    }
    /**
     * @return the _recp_st_prov_cd
     */
    public String get_recp_st_prov_cd() {
        return _recp_st_prov_cd;
    }
    /**
     * @param _recp_st_prov_cd the _recp_st_prov_cd to set
     */
    public void set_recp_st_prov_cd(String _recp_st_prov_cd) {
        this._recp_st_prov_cd = _recp_st_prov_cd;
    }
    /**
     * @return the _shpmt_pkg_qt
     */
    public int get_shpmt_pkg_qt() {
        return _shpmt_pkg_qt;
    }
    /**
     * @param _shpmt_pkg_qt the _shpmt_pkg_qt to set
     */
    public void set_shpmt_pkg_qt(int _shpmt_pkg_qt) {
        this._shpmt_pkg_qt = _shpmt_pkg_qt;
    }
    /**
     * @return the _shpmt_type_cd
     */
    public String get_shpmt_type_cd() {
        return _shpmt_type_cd;
    }
    /**
     * @param _shpmt_type_cd the _shpmt_type_cd to set
     */
    public void set_shpmt_type_cd(String _shpmt_type_cd) {
        this._shpmt_type_cd = _shpmt_type_cd;
    }
    /**
     * @return the _shpmt_uom_cd
     */
    public char get_shpmt_uom_cd() {
        return _shpmt_uom_cd;
    }
    /**
     * @param _shpmt_uom_cd the _shpmt_uom_cd to set
     */
    public void set_shpmt_uom_cd(char _shpmt_uom_cd) {
        this._shpmt_uom_cd = _shpmt_uom_cd;
    }
    /**
     * @return the _shpmt_wgt
     */
    public int get_shpmt_wgt() {
        return _shpmt_wgt;
    }
    /**
     * @param _shpmt_wgt the _shpmt_wgt to set
     */
    public void set_shpmt_wgt(int _shpmt_wgt) {
        this._shpmt_wgt = _shpmt_wgt;
    }
    /**
     * @return the _shpr_city_nm
     */
    public String get_shpr_city_nm() {
        return _shpr_city_nm;
    }
    /**
     * @param _shpr_city_nm the _shpr_city_nm to set
     */
    public void set_shpr_city_nm(String _shpr_city_nm) {
        this._shpr_city_nm = _shpr_city_nm;
    }
    /**
     * @return the _shpr_cntry_cd
     */
    public String get_shpr_cntry_cd() {
        return _shpr_cntry_cd;
    }
    /**
     * @param _shpr_cntry_cd the _shpr_cntry_cd to set
     */
    public void set_shpr_cntry_cd(String _shpr_cntry_cd) {
        this._shpr_cntry_cd = _shpr_cntry_cd;
    }
    /**
     * @return the _shpr_co_nm
     */
    public String get_shpr_co_nm() {
        return _shpr_co_nm;
    }
    /**
     * @param _shpr_co_nm the _shpr_co_nm to set
     */
    public void set_shpr_co_nm(String _shpr_co_nm) {
        this._shpr_co_nm = _shpr_co_nm;
    }
    /**
     * @return the _shpr_ph_nbr
     */
    public String get_shpr_ph_nbr() {
        return _shpr_ph_nbr;
    }
    /**
     * @param _shpr_ph_nbr the _shpr_ph_nbr to set
     */
    public void set_shpr_ph_nbr(String _shpr_ph_nbr) {
        this._shpr_ph_nbr = _shpr_ph_nbr;
    }
    /**
     * @return the _shpr_pstl_cd
     */
    public String get_shpr_pstl_cd() {
        return _shpr_pstl_cd;
    }
    /**
     * @param _shpr_pstl_cd the _shpr_pstl_cd to set
     */
    public void set_shpr_pstl_cd(String _shpr_pstl_cd) {
        this._shpr_pstl_cd = _shpr_pstl_cd;
    }
    /**
     * @return the _actl_addr_line_one_desc
     */
    public String get_actl_addr_line_one_desc() {
        return _actl_addr_line_one_desc;
    }

    /**
     * @param _actl_addr_line_one_desc the _actl_addr_line_one_desc to set
     */
    public void set_actl_addr_line_one_desc(String _actl_addr_line_one_desc) {
        this._actl_addr_line_one_desc = _actl_addr_line_one_desc;
    }

    /**
     * @return the _recp_addr_line_one_desc
     */
    public String get_recp_addr_line_one_desc() {
        return _recp_addr_line_one_desc;
    }

    /**
     * @param _recp_addr_line_one_desc the _recp_addr_line_one_desc to set
     */
    public void set_recp_addr_line_one_desc(String _recp_addr_line_one_desc) {
        this._recp_addr_line_one_desc = truncate(_recp_addr_line_one_desc,35);
    }

    /**
     * @return the _recp_addr_line_three_desc
     */
    public String get_recp_addr_line_three_desc() {
        return _recp_addr_line_three_desc;
    }

    /**
     * @param _recp_addr_line_three_desc the _recp_addr_line_three_desc to set
     */
    public void set_recp_addr_line_three_desc(String _recp_addr_line_three_desc) {
        this._recp_addr_line_three_desc = truncate(_recp_addr_line_three_desc,35);
    }

    /**
     * @return the _recp_addr_line_two_desc
     */
    public String get_recp_addr_line_two_desc() {
        return _recp_addr_line_two_desc;
    }

    /**
     * @param _recp_addr_line_two_desc the _recp_addr_line_two_desc to set
     */
    public void set_recp_addr_line_two_desc(String _recp_addr_line_two_desc) {
        this._recp_addr_line_two_desc = truncate(_recp_addr_line_two_desc,35);
    }

    /**
     * @return the _shpr_addr_line_one_desc
     */
    public String get_shpr_addr_line_one_desc() {
        return _shpr_addr_line_one_desc;
    }

    /**
     * @param _shpr_addr_line_one_desc the _shpr_addr_line_one_desc to set
     */
    public void set_shpr_addr_line_one_desc(String _shpr_addr_line_one_desc) {
        this._shpr_addr_line_one_desc = _shpr_addr_line_one_desc;
    }

    /**
     * @return the _shpr_addr_line_three_desc
     */
    public String get_shpr_addr_line_three_desc() {
        return _shpr_addr_line_three_desc;
    }

    /**
     * @param _shpr_addr_line_three_desc the _shpr_addr_line_three_desc to set
     */
    public void set_shpr_addr_line_three_desc(String _shpr_addr_line_three_desc) {
        this._shpr_addr_line_three_desc = _shpr_addr_line_three_desc;
    }

    /**
     * @return the _shpr_addr_line_two_desc
     */
    public String get_shpr_addr_line_two_desc() {
        return _shpr_addr_line_two_desc;
    }

    /**
     * @param _shpr_addr_line_two_desc the _shpr_addr_line_two_desc to set
     */
    public void set_shpr_addr_line_two_desc(String _shpr_addr_line_two_desc) {
        this._shpr_addr_line_two_desc = _shpr_addr_line_two_desc;
    }

    /**
     * @return the _shpr_st_prov_cd
     */
    public String get_shpr_st_prov_cd() {
        return _shpr_st_prov_cd;
    }
    /**
     * @param _shpr_st_prov_cd the _shpr_st_prov_cd to set
     */
    public void set_shpr_st_prov_cd(String _shpr_st_prov_cd) {
        this._shpr_st_prov_cd = _shpr_st_prov_cd;
    }
    /**
     * @return the _spcl_hndlg_grp
     */
    public String get_spcl_hndlg_grp() {
        return _spcl_hndlg_grp;
    }
    /**
     * @param _spcl_hndlg_grp the _spcl_hndlg_grp to set
     */
    public void set_spcl_hndlg_grp(String _spcl_hndlg_grp) {
        this._spcl_hndlg_grp = _spcl_hndlg_grp;
    }
    /**
     * @return the _svc_type_cd
     */
    public String get_svc_type_cd() {
        return _svc_type_cd;
    }
    /**
     * @param _svc_type_cd the _svc_type_cd to set
     */
    public void set_svc_type_cd(String _svc_type_cd) {
        this._svc_type_cd = _svc_type_cd;
    }
    /**
     * @return the _trkng_item_form_cd
     */
    public int get_trkng_item_form_cd() {
        return _trkng_item_form_cd;
    }
    /**
     * @param _trkng_item_form_cd the _trkng_item_form_cd to set
     */
    public void set_trkng_item_form_cd(int _trkng_item_form_cd) {
        this._trkng_item_form_cd = _trkng_item_form_cd;
    }
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }



    /**
     * @return the _perf_rsult_cd
     */
    public String get_perf_rsult_cd() {
        return _perf_rsult_cd;
    }

    /**
     * @param _perf_rsult_cd the _perf_rsult_cd to set
     */
    public void set_perf_rsult_cd(String _perf_rsult_cd) {
        this._perf_rsult_cd = _perf_rsult_cd;
    }

    /**
     * @return the _last_event_track_type_cd
     */
    public String get_last_event_track_type_cd() {
        return _last_event_track_type_cd;
    }

    /**
     * @param _last_event_track_type_cd the _last_event_track_type_cd to set
     */
    public void set_last_event_track_type_cd(String _last_event_track_type_cd) {
        this._last_event_track_type_cd = _last_event_track_type_cd;
    }

    /**
     * @return the _last_event_track_loc_cd
     */
    public String get_last_event_track_loc_cd() {
        return _last_event_track_loc_cd;
    }

    /**
     * @param _last_event_track_loc_cd the _last_event_track_loc_cd to set
     */
    public void set_last_event_track_loc_cd(String _last_event_track_loc_cd) {
        this._last_event_track_loc_cd = _last_event_track_loc_cd;
    }

    /**
     * @return the _last_stat_track_loc_cd
     */
    public String get_last_stat_track_loc_cd() {
        return _last_stat_track_loc_cd;
    }

    /**
     * @param _last_stat_track_loc_cd the _last_stat_track_loc_cd to set
     */
    public void set_last_stat_track_loc_cd(String _last_stat_track_loc_cd) {
        this._last_stat_track_loc_cd = _last_stat_track_loc_cd;
    }

    /**
     * @return the _last_stat_tmstp
     */
    public Date get_last_stat_tmstp() {
        return _last_stat_tmstp;
    }

    /**
     * @param _last_stat_tmstp the _last_stat_tmstp to set
     */
    public void set_last_stat_tmstp(Date _last_stat_tmstp) {
        this._last_stat_tmstp = _last_stat_tmstp;
    }

    /**
     * @return the _cleared_cstms_tmstp
     */
    public Calendar get_cleared_cstms_tmstp() {
        return _cleared_cstms_tmstp;
    }

    /**
     * @param _cleared_cstms_tmstp the _cleared_cstms_tmstp to set
     */
    public void set_cleared_cstms_tmstp(Calendar _cleared_cstms_tmstp) {
        this._cleared_cstms_tmstp = _cleared_cstms_tmstp;
    }

    /**
     * @return the _wrk_stat_cd
     */
    public String get_wrk_stat_cd() {
        return _wrk_stat_cd;
    }

    /**
     * @param _wrk_stat_cd the _wrk_stat_cd to set
     */
    public void set_wrk_stat_cd(String _wrk_stat_cd) {
        this._wrk_stat_cd = _wrk_stat_cd;
    }
    
    /**
     * Truncate the String to the given length with no warnings
     * or error raised if it is bigger.
     *
     * @param  value String to be truncated
     * @param  length  Maximum length of string
     *
     * @return Returns value if value is null or value.length() is less 
     * or equal to than length, otherwise a String representing
     * value truncated to length.
     */
    private String truncate(String value, int length)
    {
      if (value != null && value.length() > length)
        value = value.substring(0, length);
      return value;
    }
}
