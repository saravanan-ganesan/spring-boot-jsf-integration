package com.fedex.rise.bean;

import java.io.Serializable;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.PerformanceVO;
import java.text.NumberFormat;

/**
 * Performance Detail List Backing bean
 */
public class PerformanceDetailListBean extends SortableList implements Serializable {
	/** serializing version */
    private static final long serialVersionUID = 1L;
    
	private static final Log log 
		= LogFactory.getLog(PerformanceDetailListBean.class);
	private static final int MAX_ROWS = 1000;
	
	private static final int SORT_ASCENDING = 1;
    private static final int SORT_DESCENDING = -1;
    
    private DataModel _data;
    private DataModel _columnHeaders;
    
    /** selected account */
    private PerformanceBean _selectedPerformanceBean =  null;
    
    private List _performanceList = null;
    private String _performanceDesc = null;
    private String _performanceSelect = null;
    
    /**
     * Constructor
     */
    public PerformanceDetailListBean() {
    	super("Shipper");
    	
        // create header row
        List headerList = new ArrayList();
        headerList.add(new ColumnHeader("Shipper", "10", false));
        headerList.add(new ColumnHeader("MAWB", "6", false));
        headerList.add(new ColumnHeader("CRN", "10", false));
        headerList.add(new ColumnHeader("On-Time", "10", false));
        headerList.add(new ColumnHeader("Late", "10", false));
        headerList.add(new ColumnHeader("Excused", "10", false));
        headerList.add(new ColumnHeader("No POD", "10", false));
        headerList.add(new ColumnHeader("ODA", "10", false));
        headerList.add(new ColumnHeader("Weight (Kgs)", "10", false));
        headerList.add(new ColumnHeader("Transportation Invoice ($)", "10", 
        		false));
        headerList.add(new ColumnHeader("Performance (%)", "11", false));       
        _columnHeaders = new ListDataModel(headerList);
        
        // Get data from the back end performance data.
        if (getPerformanceBean() != null){
        	_performanceList = getPerformanceAcctSumList(getPerformanceBean());
        }
        
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
        
        String selectedMonth = getSelectedMonth();
        int selectedMonthInt = Integer.parseInt(selectedMonth);
        String selectedMonthName = null;
        
        if (selectedMonthInt >= 0 && selectedMonthInt <= 11 ) {
	    	DateFormatSymbols dfs = new DateFormatSymbols();
	    	String[] months = dfs.getMonths();
	    	selectedMonthName = months[selectedMonthInt];
	    }
        
        _performanceSelect = new String(
        		" > From Date: " 
        		+ outputFormat.format(getPerformanceBean().getFromDate()) +
        		" | To Date: " 
        		+ outputFormat.format(getPerformanceBean().getToDate()) );
        //WR#:179441 Changes
        _performanceDesc = new String(
        		" > Month Selected: " + selectedMonthName +
        		" | " + getPerformanceBean().getGroupName() +
        		" | Origin: " + getPerformanceBean().getOrigCntryCd() +
        		" | Dest: " + getPerformanceBean().getDestCntryCd() +
        		" | Monitor: "+ getPerformanceBean().getMonitorName());
        
        isFromDateBeforeSixMonths();
    }
    
    // ==========================================================================
    // Getters and Setters
    // ==========================================================================
    /**
     * Get the _performanceDesc.
     * @return the _performanceDesc
     */
    public String getPerformanceDesc(){
    	return _performanceDesc;
    }
    /**
     * @param performanceDesc the _performanceDesc to set
     */
    public String getPerformanceSelect(){
    	return _performanceSelect;
    }
    /**
     * Get the column value for the table.
     * @return column value
     */
    public Object getColumnValue() {
        Object columnValue = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnValue = ((List) _data.getRowData()).get(_columnHeaders.getRowIndex());
        }
        return columnValue;
    }
    
    public String getAcctNbr() {
        Object acctNbr = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
        	acctNbr = ((List) _data.getRowData()).get(0);
        }
        return acctNbr.toString(); 
    }
    /**
     * Get the performance type, Late, Excused, No POD, and ODA
     * @return performance type.
     */
    public String getPerformanceType(){
    	String performanceType = null;
    	if (_columnHeaders.getRowIndex() == 4){
    		performanceType = new String("LATE");
    	}else if (_columnHeaders.getRowIndex() == 5){
    		performanceType = new String("EXCUSED");
    	}else if (_columnHeaders.getRowIndex() == 6){
    		performanceType = new String("NOPOD");
    	}else if (_columnHeaders.getRowIndex() == 7){
    		performanceType = new String("ODA");
    	}
    	return performanceType;
    }
    /**
     * Get the column width for the table.
     * @return column width
     */
    public String getColumnWidth() {
        String columnWidth = null;
        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable()) {
            columnWidth = ((ColumnHeader) _columnHeaders.getRowData()).getWidth();
        }
        return columnWidth;
    }
    
    /**
     * First column (account) is a link to get to details
     * @return true if it is first column
     */
    public boolean isLink() {
        boolean valueLink = false;

        if (_data.isRowAvailable() && _columnHeaders.isRowAvailable() &&
        	(_data.getRowIndex() != _data.getRowCount()- 1)) {
            valueLink = ((_columnHeaders.getRowIndex() == 4 ||
            		_columnHeaders.getRowIndex() == 5 ||
            		_columnHeaders.getRowIndex() == 6 ||
            		_columnHeaders.getRowIndex() == 7) && 
            		!getColumnValue().equals("0") &&
            		!isToDateBeforeSixMonths());
        }
        return valueLink;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getRowsPerPage() {
        // if no data then no rows 
        if (_data == null) return 0;
       
        // if less than a page, then return actual number of rows
        int rows = _data.getRowCount();
        if (rows > MAX_ROWS)
            return MAX_ROWS;
        else
            return rows;
    }
    
    public DataModel getColumnHeaders() {
        return _columnHeaders;
    }
    
    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getCount() {
        // if no data then no rows 
        if (_data == null) return 0;
       
        return _data.getRowCount();
    }
    
    /**
     * Get the Performance that is selected in the list
     * @return
     */
    public PerformanceBean getSelectedPerformance() {
        return _selectedPerformanceBean;
    }
    
    /**
     * Get the Performance data model list
     * @return DataModel
     */
    public DataModel getData() {
        populatePerformanceList();
        sort(getSort(), isAscending());   
        return _data;
    }
    
    public String performanceDetail(){
    	return "crnListPage";
    }

    /**
     * Determine if the FromDate is less than 6 months from today.
     * @return true if the FromDate is less than 6 months from today.
     */
    public boolean isFromDateLessThanSixMonths(){
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.MONTH, -6);
    	boolean fromDateLessThanSixMonths 
    		= getPerformanceBean().getFromDate().before(today.getTime());
    	if (fromDateLessThanSixMonths){
    		log.info("All tracking numbers may not be displayed, because the detail shipment data is purged after six months.");
        	FacesMessage facesMessage = new FacesMessage(
        		FacesMessage.SEVERITY_WARN, 
        		"All tracking numbers may not be displayed, because the detail shipment data is purged after six months.", 
        		null);
        	facesContext.addMessage(null, facesMessage);
    	}
        
    	return fromDateLessThanSixMonths;
    	
    }
    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        return true;
    }

    protected void sort(final String column, final boolean ascending) {
        if (column != null) {
            int columnIndex = getColumnIndex(column);
            int direction = (ascending) ? SORT_ASCENDING : SORT_DESCENDING;
            sort(columnIndex, direction);
        }
    }

    protected void sort(final int columnIndex, final int direction) {
        if (columnIndex == 0){
        	sortString(columnIndex, direction);
        }else if (columnIndex > 0 && columnIndex < 9){
        	sortInteger(columnIndex, direction);
        }else if (columnIndex == 9){
        	sortDouble(columnIndex, direction);
        }else {
        	sortFloat(columnIndex, direction);
        }
    }
     
    protected void sortDouble(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Double column1 = Double.valueOf(((List) o1).get(columnIndex).toString().replace(",", ""));
                Double column2 = Double.valueOf(((List) o2).get(columnIndex).toString().replace(",", ""));
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) _data.getWrappedData(), comparator);
    }
    
    protected void sortFloat(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Float column1 = Float.valueOf(((List) o1).get(columnIndex).toString());
                Float column2 = Float.valueOf(((List) o2).get(columnIndex).toString());
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) _data.getWrappedData(), comparator);
    }
    
    protected void sortInteger(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Integer column1 = Integer.parseInt(((List) o1).get(columnIndex).toString());
                Integer column2 = Integer.parseInt(((List) o2).get(columnIndex).toString());
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) _data.getWrappedData(), comparator);
    }
    
    protected void sortString(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Object column1 = ((List) o1).get(columnIndex);
                Object column2 = ((List) o2).get(columnIndex);
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) _data.getWrappedData(), comparator);
    }
    // =========================================================================
    // Private Methods
    // =========================================================================
    
    private int getColumnIndex(final String columnName) {
        int columnIndex = -1;
        List headers = (List) _columnHeaders.getWrappedData();
        for (int i = 0; i < headers.size() && columnIndex == -1; i++) {
            ColumnHeader header = (ColumnHeader) headers.get(i);
            if (header.getLabel().equals(columnName)) {
                columnIndex = i;
            }
        }
        return columnIndex;
    }
    
    /**
     * Return a list of performance data.
     * @return
     */
    private List getPerformanceAcctSumList(PerformanceBean performanceBean) {
    	log.debug("Entering getPerformanceAcctSumList()");
    	ShipperDelegate shipperDelegate = new ShipperDelegate();
        
        String selectedMonth = getSelectedMonth();
        //WR#:179441 Changes
        if (performanceBean.getGroupNbr().equals("All") && performanceBean.getEmpName().equals("All")){
        	return shipperDelegate.getPerformanceGroupSumList(
            		performanceBean.getFromDate(), 
            		performanceBean.getToDate(),
            		Integer.parseInt(selectedMonth),
            		Integer.parseInt(performanceBean.getSelectedMonthNumber()));
        }else{
        //WR#:179441 Changes
        	return shipperDelegate.getPerformanceAcctSumList(performanceBean.
        		getGroupNbr(),
        		performanceBean.getFromDate(), 
        		performanceBean.getToDate(),
        		performanceBean.getLaneOrgDest(),
        		Integer.parseInt(selectedMonth),
        		Integer.parseInt(performanceBean.getSelectedMonthNumber()),
        		performanceBean.getEmpName()); 
        }
    }
    
    /**
     * Get the selected month from the performance bean, which stores it into 
     * the session.
     */
    private String getSelectedMonth(){
        return getPerformanceBean().getSelectedMonth();
    }
    
    /**
     * Get the selected tree node (account, lane, service, etc.)
     * @return String
     */
    private PerformanceBean getPerformanceBean() {
        Map params = FacesContext.getCurrentInstance().getExternalContext().
        	getSessionMap();
        PerformanceBean performanceBean = 
        	(PerformanceBean)params.get("PerformanceBean");
        return performanceBean;
    }
    
    /**
     * Get the list of Performance (data rows) for the account level
     */
    private void populatePerformanceList() {
       
        if (_performanceList == null) {
           // no selection, so no data
           _data = null;
        } else {
           // node selected so get data for this account, lane, service, etc.
           List rowList = new ArrayList();
           
           // Format display of performance % and Inv amt.
           NumberFormat formatPercentage = NumberFormat.getInstance();
           formatPercentage.setMaximumFractionDigits(1);
           NumberFormat formatInvAmt = NumberFormat.getInstance();
           formatInvAmt.setMaximumFractionDigits(2);
               
           // create data rows (list of lists)
           Iterator itr=_performanceList.iterator();
           
           // initialize the roll up totals for this page.
           int totalMawbQty = 0;
           int totalCrnQty = 0;
           int totalOnTimeCrnQty = 0;
           int totalLateCrnQty = 0;
           int totalExcusCrnQty = 0;
           int totalNoPodCrnQty = 0;
           int totalOdaCrnQty = 0;
           int totalWgtAmt = 0;
           float totalInvValueAmt = 0;
           
           while (itr.hasNext()) {
        	   PerformanceVO performanceVO = (PerformanceVO) itr.next();
               List colList = new ArrayList();
               
               // Insert Performance results into a display list.
               colList.add(String.valueOf(performanceVO.get_acct_nbr()));
               colList.add(String.valueOf(performanceVO.get_total_mawb_qty()));      
               colList.add(String.valueOf(performanceVO.get_total_crn_qty()));  
               colList.add(String.valueOf(performanceVO.get_on_time_crn_qty())); 
               colList.add(String.valueOf(performanceVO.get_late_crn_qty()));       
               colList.add(String.valueOf(performanceVO.get_excus_crn_qty())); 
               colList.add(String.valueOf(performanceVO.get_no_pod_crn_qty()));
               colList.add(String.valueOf(performanceVO.get_oda_crn_qty()));
               colList.add(String.valueOf(performanceVO.get_total_wgt_amt()));
               colList.add(formatInvAmt.format(
            		   (float)performanceVO.get_total_inv_value_amt()/100.0));
               
               // Roll up the totals for this page;
               totalMawbQty += performanceVO.get_total_mawb_qty();
               totalCrnQty += performanceVO.get_total_crn_qty();
               totalOnTimeCrnQty += performanceVO.get_on_time_crn_qty();
               totalLateCrnQty += performanceVO.get_late_crn_qty();
               totalExcusCrnQty += performanceVO.get_excus_crn_qty();
               totalNoPodCrnQty += performanceVO.get_no_pod_crn_qty();
               totalOdaCrnQty += performanceVO.get_oda_crn_qty();
               totalWgtAmt += performanceVO.get_total_wgt_amt();
               totalInvValueAmt += performanceVO.get_total_inv_value_amt();
               
               // Calulate performance
               float perfPercent = 0;
               if (performanceVO.get_total_crn_qty() > 0){
               perfPercent = (float)(performanceVO.get_on_time_crn_qty()
            		   + performanceVO.get_excus_crn_qty() 
            		   + performanceVO.get_oda_crn_qty())/
            		   (float)(performanceVO.get_total_crn_qty()) * 100;
               } 
               
               colList.add(formatPercentage.format(perfPercent));  
               
               rowList.add(colList);
               
           }
           
           // Insert Total Performance results into a display list.
           List totalColList = new ArrayList();
           totalColList.add("Total");
           totalColList.add(String.valueOf(totalMawbQty));      
           totalColList.add(String.valueOf(totalCrnQty));  
           totalColList.add(String.valueOf(totalOnTimeCrnQty)); 
           totalColList.add(String.valueOf(totalLateCrnQty));       
           totalColList.add(String.valueOf(totalExcusCrnQty)); 
           totalColList.add(String.valueOf(totalNoPodCrnQty));
           totalColList.add(String.valueOf(totalOdaCrnQty));
           totalColList.add(String.valueOf(totalWgtAmt));
           totalColList.add(formatInvAmt.format(totalInvValueAmt/100.0));
           // Calulate Total Performance
           float totalPerfPercent = 0;
           if (totalCrnQty > 0){
        	   totalPerfPercent = (float)(totalOnTimeCrnQty
        		   + totalExcusCrnQty 
        		   + totalOdaCrnQty)/
        		   (float)(totalCrnQty) * 100;
           } 
           totalColList.add(formatPercentage.format(totalPerfPercent));
           rowList.add(totalColList);
           
           _data = new ListDataModel(rowList);
        }
    }
    /**
     * Determine if the ToDate is before 6 months from today.
     * @return true if the ToDate is before 6 months from today.
     */
    private boolean isToDateBeforeSixMonths(){
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.MONTH, -6);
    	boolean toDateBeforeSixMonths 
    		= getPerformanceBean().getToDate().before(today.getTime());
    	return toDateBeforeSixMonths;
    	
    }
    
    /**
     * Determine if the FromDate is before 6 months from today.
     * @return true if the FromDate is before 6 months from today.
     */
    private void isFromDateBeforeSixMonths(){
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	Calendar today = Calendar.getInstance();
    	today.add(Calendar.MONTH, -6);
    	boolean fromDateLessThanSixMonths 
    		= getPerformanceBean().getFromDate().before(today.getTime());
    	if (fromDateLessThanSixMonths){
    		log.info("All tracking numbers may not be displayed, because the detail shipment data is purged after six months.");
        	FacesMessage facesMessage = new FacesMessage(
        		FacesMessage.SEVERITY_WARN, 
        		"All tracking numbers may not be displayed, because the detail shipment data is purged after six months.", 
        		null);
        	facesContext.addMessage(null, facesMessage);
    	}
    }
}
