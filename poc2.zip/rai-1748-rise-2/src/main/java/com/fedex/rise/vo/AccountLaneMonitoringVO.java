package com.fedex.rise.vo;

import java.io.Serializable;

public class AccountLaneMonitoringVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String _emp_nbr;
    private int _group_nbr;
    private String _acct_nbr;
    private int    _lane_nbr;
    
    public AccountLaneMonitoringVO(String _emp_nbr, int _group_nbr, String _acct_nbr, int _lane_nbr) {
        super();
        this._emp_nbr = _emp_nbr;
        this._group_nbr = _group_nbr;
        this._acct_nbr = _acct_nbr;
        this._lane_nbr = _lane_nbr;
    }
    
    public AccountLaneMonitoringVO() {
    }

    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }
    /**
     * @param _acct_nbr the _acct_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr;
    }
    /**
     * @return the _emp_nbr
     */
    public String get_emp_nbr() {
        return _emp_nbr;
    }
    /**
     * @param _emp_nbr the _emp_nbr to set
     */
    public void set_emp_nbr(String _emp_nbr) {
        this._emp_nbr = _emp_nbr;
    }

    /**
     * @return the _group_nbr
     */
    public int get_group_nbr() {
        return _group_nbr;
    }
    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_group_nbr(int _group_nbr) {
        this._group_nbr = _group_nbr;
    }
    /**
     * @return the _lane_nbr
     */
    public int get_lane_nbr() {
        return _lane_nbr;
    }
    /**
     * @param _lane_nbr the _lane_nbr to set
     */
    public void set_lane_nbr(int _lane_nbr) {
        this._lane_nbr = _lane_nbr;
    }
}
