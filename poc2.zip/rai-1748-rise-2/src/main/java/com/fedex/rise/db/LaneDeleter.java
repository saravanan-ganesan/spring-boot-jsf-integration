package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class LaneDeleter extends OracleBase {

    private static Logger logger = LogManager.getLogger(LaneDeleter.class);

    public LaneDeleter(Connection con) {
        super(con);
    }

    private static final String deleteLaneSQL = "Delete from Lane where LANE_NBR = ?";

    public void deleteLane(int aLaneNbr) throws SQLException {

        try {
            // constraint violations will keep us from deleting lanes that are in use, meaning
            // a row exists in the Lane_Service table for this lane_nbr.  
            setSqlSignature(deleteLaneSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, aLaneNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
