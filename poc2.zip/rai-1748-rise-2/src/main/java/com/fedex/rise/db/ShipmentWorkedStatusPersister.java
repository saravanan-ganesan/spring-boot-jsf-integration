package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ShipmentEmployeeVO;

public class ShipmentWorkedStatusPersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(MonitoredAccountsAccessor.class);

    public ShipmentWorkedStatusPersister(Connection con) {
        super(con);
    }

    private static final String updateWorkedStatusSQL= 
    	"update SHIPMENT set WRK_STAT_CD = ? " +
    	"where TRKNG_ITEM_NBR = ? and TRKNG_ITEM_UNIQ_NBR = ?";

    public void saveWorkedStatus(String aStatusCd, String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        
        try {
            setSqlSignature(updateWorkedStatusSQL, false, logger.isDebugEnabled());
            
            pstmt.setString(1, aStatusCd);
            pstmt.setString(2, aTrkngItemNbr);
            pstmt.setString(3, aTrkngItemUniqNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();
            
        } catch (SQLException e) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
    
}
