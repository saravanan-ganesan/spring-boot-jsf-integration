package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

public class ScheduledEventVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;
    private String _trkng_item_uniq_nbr;
    private String _track_type_cd;
    private Date   _sched_event_tmstp;
    private String _event_trkng_item_nbr;
    private String _event_trkng_item_uniq_nbr;
    private String _event_track_type_cd;
    private Date   _event_crtn_tmstp;
    
    /**
     * @return the _event_crtn_tmstp
     */
    public Date get_event_crtn_tmstp() {
        return _event_crtn_tmstp;
    }
    /**
     * @param _event_crtn_tmstp the _event_crtn_tmstp to set
     */
    public void set_event_crtn_tmstp(Date _event_crtn_tmstp) {
        this._event_crtn_tmstp = _event_crtn_tmstp;
    }
    /**
     * @return the _event_track_type_cd
     */
    public String get_event_track_type_cd() {
        return _event_track_type_cd;
    }
    /**
     * @param _event_track_type_cd the _event_track_type_cd to set
     */
    public void set_event_track_type_cd(String _event_track_type_cd) {
        this._event_track_type_cd = _event_track_type_cd;
    }
    /**
     * @return the _event_trkng_item_nbr
     */
    public String get_event_trkng_item_nbr() {
        return _event_trkng_item_nbr;
    }
    /**
     * @param _event_trkng_item_nbr the _event_trkng_item_nbr to set
     */
    public void set_event_trkng_item_nbr(String _event_trkng_item_nbr) {
        this._event_trkng_item_nbr = _event_trkng_item_nbr;
    }
    /**
     * @return the _event_trkng_item_uniq_nbr
     */
    public String get_event_trkng_item_uniq_nbr() {
        return _event_trkng_item_uniq_nbr;
    }
    /**
     * @param _event_trkng_item_uniq_nbr the _event_trkng_item_uniq_nbr to set
     */
    public void set_event_trkng_item_uniq_nbr(String _event_trkng_item_uniq_nbr) {
        this._event_trkng_item_uniq_nbr = _event_trkng_item_uniq_nbr;
    }
    /**
     * @return the _sched_event_tmstp
     */
    public Date get_sched_event_tmstp() {
        return _sched_event_tmstp;
    }
    /**
     * @param _sched_event_tmstp the _sched_event_tmstp to set
     */
    public void set_sched_event_tmstp(Date _sched_event_tmstp) {
        this._sched_event_tmstp = _sched_event_tmstp;
    }
    /**
     * @return the _track_type_cd
     */
    public String get_track_type_cd() {
        return _track_type_cd;
    }
    /**
     * @param _track_type_cd the _track_type_cd to set
     */
    public void set_track_type_cd(String _track_type_cd) {
        this._track_type_cd = _track_type_cd;
    }
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }

}
