package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public class DeliveryResolver extends Resolver {

    private static ArrayList _deliveryScans = new ArrayList();
    
    private static DeliveryResolver _instance = new DeliveryResolver();
    
    static {
        // These scans are determined by me to mean a delivery has occurred
        _deliveryScans.add(RiseConstants.POD);
        _deliveryScans.add(RiseConstants.DDEX);        
    };
    
    private DeliveryResolver () {}
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        if (_deliveryScans.contains(anEventVO.get_track_type_cd())) {
            return true;
        }
        return false;
    }
    
    public static DeliveryResolver getInstance() {
        return _instance;
    }

}
