package com.fedex.rise.bo;

import java.util.Calendar;
import java.lang.Math;

import com.fedex.rise.cache.LaneServiceCacheDAO;
import com.fedex.rise.vo.IPDShipmentVO;
import com.fedex.rise.vo.ShipmentVO;
/**
 * Class that has all of the adjusted commit date calculations.
 * 
 * @author be379961
 *
 */
public class AdjustedCommitDt {
	
    /**
     * The business rules for setting the adjusted commit days are as follows.
     * 
     * 1.) If the field COMMIT_DAYS_QTY is set in the LANE_SERVICE table for 
     * the service type code, lane number, and account number. The adjusted 
     * commit date is equal to the ship date plus the COMMIT_DAYS_QTY.  If the 
     * adjusted commit date falls on a weekend it will be moved to the coming 
     * Monday.
     * 
     * OR if COMMIT_DAYS_QTY is null or the ship date is null, the next set of 
     * logic will be attempted.
     *
     * 2.) If SEP commit date is not null.
     * 	2a.) If the existing adjusted commit date is null, set the adjusted 
     * 	commit equal to the commit date.
     * 	OR
     * 	2b.) If the delivery date is not null, and the commit date and delivery
     * 	date are not equal in UTC time, set the adjusted commit equal to the 
     * 	commit date.
     * 
     * OR if SEP commit date is null and adjusted commit date is null
     * 
     * 3.) If the estimate available for delivery date is not null.
     * 	3a.) Set the adjusted commit equal to the estimate available for 
     * delivery date.
     * 		3a1.) If the delivery date is not null, then set the time zone 
     * 		offset of the adjusted commit date to that of the delivery date.
     * 
     * @param anIpdShipmentVO
     */
    public Calendar processAdjustedCommitDate(IPDShipmentVO anIpdShipmentVO,
    		ShipmentVO existingShipmentVO){
    	Calendar adjCommitDt = null;
    	// Determine if adjusted commit date has been processed yet. If the 
    	// adjusted commit date in the DB is null, it needs to be calculated.
    	boolean existingAdjCommitDtNull = false;
    	if (existingShipmentVO == null){
    		existingAdjCommitDtNull = true;
    	}else if (existingShipmentVO.get_adj_commit_dt() == null){
    		existingAdjCommitDtNull = true;
    	}
    	
    	// Determine if the commit date is equal to the delivery date in UTC 
    	// milliseconds.  If this is the case, the commit date has been set 
    	// equal to the delivery date by upstream processes, and is so the NEW 
    	// commit date is not valid.  If this has happened, DO NOT update the 
    	// existing adjusted commit date to be equal to the commit date.
    	boolean commitDateEqualsDelDt = equalUTCTime(
    			anIpdShipmentVO.get_shipment().get_commit_dt(),
    			anIpdShipmentVO.get_shipment().get_del_dt());
    
    	// If the field COMMIT_DAYS_QTY is set in the LANE_SERVICE table for 
        // the service type code, lane number, and account number. The adjusted 
        // commit date is equal to the ship date plus the COMMIT_DAYS_QTY.  If  
        // the adjusted commit date falls on a weekend it will be moved to the  
        // coming Monday.
    	if (anIpdShipmentVO.get_shipment().get_ship_dt() != null){
    		adjCommitDt = calculateAdjustedCommitDate(anIpdShipmentVO);
    	}
    	
    	if (adjCommitDt == null){
    		// If SEP commit date is not null.
    	    // If the existing adjusted commit date is null, set the adjusted 
    	    // commit equal to the commit date. If the delivery date is not 
    		// null, and the commit date and delivery date are not equal in 
    		// UTC time, set the adjusted commit equal to the commit date.
    		if (anIpdShipmentVO.get_shipment().get_commit_dt() != null){
    			if (existingAdjCommitDtNull || !commitDateEqualsDelDt){
    				adjCommitDt = (Calendar)anIpdShipmentVO.get_shipment().
    				get_commit_dt().clone();
    			}
    		// If the estimate available for delivery date is not null, and 
    		// the existing adjusted commit date is null. Set the adjusted 
    		// commit equal to the estimate available for delivery date.
    		} else if (anIpdShipmentVO.get_shipment().get_est_avail_for_delv_dt() 
    				!= null && existingAdjCommitDtNull){
    			//  If the delivery date is not null, then set the time zone 
    		    // offset of the adjusted commit date to that of the delivery 
    			// date.
    			if (anIpdShipmentVO.get_shipment().get_del_dt() != null){
    				adjCommitDt = setTimeZone(
    					anIpdShipmentVO.get_shipment().get_est_avail_for_delv_dt(), 
    					anIpdShipmentVO.get_shipment().get_del_dt());
    			}else{
    				adjCommitDt = (Calendar)anIpdShipmentVO.get_shipment().
						get_est_avail_for_delv_dt().clone();
    			}
    		}
    	}
    	return adjCommitDt;
    }
    
	/**
	 * First determine whether to use the most recent calculated adjusted commit 
	 * date, if not null.  Otherwise use the existing one stored in the database 
	 * if not null.
	 * 
	 * Recalculate the adjusted commit date due to the monitor modifying the 
	 * commit date. The modification of the commit date is stored in the 
	 * SHIPMENT table, and stored in the field ADJ_COMMIT_DT_OFFST_NBR. This 
	 * field has the number of days offset from the current value of adjusted 
	 * commit date.
	 * 
	 * @param anIpdShipmentVO
	 * @param existingShipmentVO
	 * @return the adjusted commit date to account for weekends.
	 */
	public Calendar monitorAdjustedCommitDt(IPDShipmentVO anIpdShipmentVO, 
			ShipmentVO existingShipmentVO){
		Calendar commit_dt;
		Calendar adj_commit_dt;
		adj_commit_dt = anIpdShipmentVO.get_shipment().get_adj_commit_dt();
		commit_dt = anIpdShipmentVO.get_shipment().get_commit_dt();
		
		if (existingShipmentVO != null && adj_commit_dt == null){
			adj_commit_dt = existingShipmentVO.get_adj_commit_dt();
		}
		if (existingShipmentVO != null && commit_dt == null){
			commit_dt = existingShipmentVO.get_commit_dt();
		}
		
		if (existingShipmentVO != null && adj_commit_dt != null){
			if (existingShipmentVO.get_adj_commit_dt_offst_nbr() != 0){
				// Convert the number of days offset to hours.
				int hoursoffset = 
				existingShipmentVO.get_adj_commit_dt_offst_nbr() * 24;
					
				//	Add the offset to the ship date.
				adj_commit_dt.add(Calendar.HOUR, hoursoffset);
					
				// Determine if the adjusted commit date is a Saturday,
    			// if it is add 2 days onto the commit date.
    			if (adj_commit_dt.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY){
    				hoursoffset = 48;
    				adj_commit_dt.add(Calendar.HOUR, hoursoffset);
    			} else {
    				// Determine if the adjusted commit date is a Sunday,
    				// if it is add 1 days onto the commit date.
    				if (adj_commit_dt.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
    					hoursoffset = 24;
    					adj_commit_dt.add(Calendar.HOUR, hoursoffset);
    				}
    			}
			}
			if (commit_dt != null && adj_commit_dt != null){
				if (commit_dt.after(adj_commit_dt)){
					return commit_dt;
				}
			}
		}else if (commit_dt != null){
			return commit_dt;
		}
		return adj_commit_dt;
	}
    
    /**
     * Determine if the two Calandar dates have equal epoch time.
     *
     * @param a Calendar argument
     * @param b Calendar argument
     * @return true if a and b have the same epoch time.
     */
    private boolean equalUTCTime(Calendar a, Calendar b){
    	if (a != null && b != null){
    		if (a.getTimeInMillis() == b.getTimeInMillis()){
    			return true;
    		}
    	}
    	return false;
    }
    
    /** 
     * Set the commit date time zone to the delivery date time zone if it 
     * exists.
     * @param commitDt
     * @param delDt
     * @return
     */
    private Calendar setTimeZone(Calendar commitDt, Calendar delDt){
    	if (delDt != null) {
    		if (delDt.getTimeZone() != null){
    			commitDt.setTimeZone(delDt.getTimeZone());
    		}
    	}
    	return commitDt;
    }
    
    /**
     * Set the adjusted commit date based on service type code, lane number, 
     * account number using the Service Lane cached data. This method will 
     * adjust for 
     * @param anIpdShipmentVO the IPDShipmentVO object.
     * @return Calendar.  A null value if can not calculate the adjusted ship 
     * date, or the adjusted ship date if the key is valid.
     */
    private Calendar calculateAdjustedCommitDate(IPDShipmentVO anIpdShipmentVO){
    	// Unless the service code, lane number and account number exist, there 
    	// is no point in being in this method.
    	if (anIpdShipmentVO.get_shipment().get_svc_type_cd() != null && 
    			anIpdShipmentVO.get_shipment().get_lane_nbr() > 0 &&
    			anIpdShipmentVO.get_shipment().get_acct_nbr() != null){
    		// Build the key to the LaneServiceCacheDAO map, which is concatenating
        	// the sevice type code to the lane number and account number.
        	String key = anIpdShipmentVO.get_shipment().get_svc_type_cd()
    			+ String.valueOf(anIpdShipmentVO.get_shipment().get_lane_nbr())
    			+ anIpdShipmentVO.get_shipment().get_acct_nbr();
        	
        	// If data exists calculate the adjusted commit date.
    		if (LaneServiceCacheDAO.containsKey(key)){
    			// Get the number of days offset.
    			String commit_days_qty = 
    				LaneServiceCacheDAO.get(key).get_commit_days_qty();
    			// If not null add the offset to the ship date.
    			if (commit_days_qty != null){
    				// Convert ship date to a Calendar.
    				Calendar adjCommitDt = Calendar.getInstance();
    				adjCommitDt.setTime(anIpdShipmentVO.get_shipment()
    						.get_ship_dt());
    				// Need to set the time zone in the adjusted commit date.  
    				// Have it be the same as the delivery date time zone or the 
    				//commit date time zone.
    				if (anIpdShipmentVO.get_shipment().get_del_dt() != null){
    					adjCommitDt.setTimeZone(anIpdShipmentVO.get_shipment().
    							get_del_dt().getTimeZone());
    				}else if(anIpdShipmentVO.get_shipment().get_commit_dt() != null){
    					adjCommitDt.setTimeZone(anIpdShipmentVO.get_shipment().
    							get_commit_dt().getTimeZone());
    				}
    				// Convert the number of days offset to hours.
    				int hoursoffset = Integer.parseInt(commit_days_qty) * 24;
    				// Add the offset to the ship date.
    				adjCommitDt.add(Calendar.HOUR, hoursoffset);
    				// Determine if the adjusted commit date is a Saturday,
    				// if it is add 2 days onto the commit date.
    				if (adjCommitDt.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY){
    					hoursoffset = 48;
    					adjCommitDt.add(Calendar.HOUR, hoursoffset);
    				}
    				// Determine if the adjusted commit date is a Sunday,
    				// if it is add 1 days onto the commit date.
    				if (adjCommitDt.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
    					hoursoffset = 24;
    					adjCommitDt.add(Calendar.HOUR, hoursoffset);
    				}
    				return adjCommitDt;
    			}
    		} 
    	}
    	return null;
    }
}
