package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class ConfigurationAccessor extends OracleBase {
	private static Logger logger = LogManager.getLogger(ConfigurationAccessor.class);
	/**
     * Constructor
     * @param con
     */
    public ConfigurationAccessor(Connection con) {
        super(con);
    }

    private final String selectConfigurationValueSQL = "select " +
    "CONFG_VALUE_DESC from Configuration " +
    "where CONFG_VALUE_NM = ?";
    
    /**
     * Get the value for a name from the configuration table.
     * @param confgValueNm Name of the configuration table.
     * @return The String of the value, otherwise return a null.
     * @throws SQLException
     */
    public String getValue(String  confgValueNm) throws SQLException{
    	
    	String value = null;
    	try {
            setSqlSignature( selectConfigurationValueSQL, false, 
            		logger.isDebugEnabled() );
             
            pstmt.setString( 1, confgValueNm);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	value = rs.getString("CONFG_VALUE_DESC");
    
            } else {
                return value;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
    	
    	return value;
    }
}
