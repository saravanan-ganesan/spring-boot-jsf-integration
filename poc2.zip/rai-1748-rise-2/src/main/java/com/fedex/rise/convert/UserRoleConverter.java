package com.fedex.rise.convert;

import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class UserRoleConverter implements Converter {
    /** logger */
    private static final Log log = LogFactory.getLog(UserRoleConverter.class);
    
    /** user roles, use LinkedHashMap so order is preserved */
    private static HashMap userRoles = new LinkedHashMap();
    
    static {
        userRoles.put("FA", "FedEx Administrator");
        userRoles.put("A",  "Administrator");
        userRoles.put("M",  "Monitor");
        userRoles.put("RM", "Restricted Monitor");
        userRoles.put("R",  "Restricted");
    }
    
    /**
     * Default constructor
     */
    public UserRoleConverter() {
        super();
        //if (log.isDebugEnabled()) log.debug("Constructed");
    }
    
    public Object getAsObject(FacesContext context, UIComponent component, String userRole)
            throws ConverterException {
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + userRole);
        return getAsString(context, component, userRole);
    }

    public String getAsString(FacesContext context, UIComponent component, Object userRole)
            throws ConverterException {
        
        return (String)userRoles.get((String)userRole);
    }
    
    public static String lookupUserRoleDesc(String aUserRoleCd) {
        return (String)userRoles.get(aUserRoleCd);
    }
    
    public static HashMap getUserRoles() {
        return userRoles;
    }

}
