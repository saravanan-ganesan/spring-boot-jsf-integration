package com.fedex.rise.ese;

import java.io.InputStream;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.asn.UTF8String.Utf8string;
import com.fedex.asn.UTF8String.enhancedevent_.EnhancedEvent;
import com.oss.asn1.DecodeFailedException;
import com.oss.asn1.DecodeNotSupportedException;
import com.oss.asn1.XERCoder;

/**
 * This class is used to derialize the Enhanced Event which comes
 * from the JMS queue in XML(XER) format.
 *
 */
public class EnhancedEventXMLDeserializer {

    // Class logger
    static Logger logger = LogManager.getLogger(EnhancedEventXMLDeserializer.class);

    // XER decoder
    private XERCoder coder = null;

    static {
        try {
            Utf8string.initialize();
        } catch (Exception e) {
            logger.error("Initialization of XML dersializer failed:", e);
        }
    }    
    
    /**
     * Decodes the event
     * @param input source of message to deserialize
     * @return an EnhancedEvent
     * @throws DecodeNotSupportedException 
     * @throws DecodeFailedException 
     */
    public EnhancedEvent deserialize(InputStream input)
        throws DecodeFailedException, DecodeNotSupportedException {

        coder = Utf8string.getXERCoder();
        EnhancedEvent event = (EnhancedEvent) coder.decode(input, new EnhancedEvent());
            
        return event;
    }
    
    public void finalize() {
        Utf8string.deinitialize();
    }

}
