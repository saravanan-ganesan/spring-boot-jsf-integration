package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class SystemMessageDeleter extends OracleBase {
    private static Logger logger = LogManager.getLogger(SystemMessageDeleter.class);
    
    public SystemMessageDeleter(Connection con) {
        super(con);
    }   
    
    private static final String deleteSystemMessagesSQL = "delete from " +
        "SYSTEM_MESSAGE where MESSAGE_NBR = ?";
    
    public void deleteSystemMessage(int aMsgNbr) throws SQLException {
        
        try {
            setSqlSignature( deleteSystemMessagesSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, aMsgNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();          

        } catch ( SQLException e ) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
}
