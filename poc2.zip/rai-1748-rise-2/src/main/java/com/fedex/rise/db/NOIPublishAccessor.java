package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;
import com.fedex.rise.vo.NOIPublishVO;

/**
 * NOI Accessor.
 * 
 * @author be379961
 *
 */
public class NOIPublishAccessor extends OracleBase {

    private static Logger logger = LogManager.getLogger(NOIPublishAccessor.class);
    
	/**
	 * Constructor.
	 *
	 */
    public NOIPublishAccessor(Connection con) {
        super(con);
    }
    
    /** SQL to get label image for a piece in a shipment */
    private static final String selectNOIPublish
         = "SELECT RTRN_TRKNG_ITEM_NBR, SHIP_DT, NOI_RQST_TMSTP, PBLSH_DT, NOI_INPUT_TMSTP "
        	 + "FROM NOTIFICATION_OF_INTEREST WHERE rownum=1 and PBLSH_DT is null for update";

    /**
     * This method is used to retrieve a row from the NOI_PUBLISH table.
     * 
     * @return NOIPublishVO row of data from the NOIPublishVO
     * @throws SQLException 
     */
    public NOIPublishVO getNOIPublishRow() throws SQLException {
    	NOIPublishVO result = null;
        try {
            setSqlSignature( selectNOIPublish );
            execute();

            if ( hasResults && rs.next() ) {    // need first and only result row
                result = new NOIPublishVO();
            	result.set_trk_item_nbr( rs.getString("RTRN_TRKNG_ITEM_NBR"));
            	result.set_ship_date((rs.getDate("SHIP_DT")));
            	result.set_trk_date_time((rs.getTimestamp("NOI_RQST_TMSTP")));
            	result.set_publish_date((rs.getTimestamp("PBLSH_DT")));
            	result.set_input_timestamp((rs.getTimestamp("NOI_INPUT_TMSTP")));
            	
            	if (logger.isDebugEnabled()) {
                    logger.debug(result.toString());
                }
            }
        }
        catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                logger.error(sqle2.getMessage(), sqle2);
            }
        }
        return result;
    } 
}
