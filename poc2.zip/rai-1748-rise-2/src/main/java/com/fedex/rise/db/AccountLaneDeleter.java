package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountLaneVO;

public class AccountLaneDeleter extends OracleBase {

    private static Logger logger = LogManager.getLogger(AccountLaneDeleter.class);

    public AccountLaneDeleter(Connection con) {
        super(con);
    }

    private static final String deleteAccountLaneSQL = "Delete from Account_Lane where " +
                "GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ?";
    private static final String deleteAccountLaneSQL2 = "Delete from Account_Lane where " +
                "GROUP_NBR = ? and ACCT_NBR = ?";

    /**
     * Delete the specified lane
     * @param anAccountLaneVO
     * @throws SQLException
     */
    public void deleteAccountLane(AccountLaneVO anAccountLaneVO) throws SQLException {

        try {
            setSqlSignature(deleteAccountLaneSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, anAccountLaneVO.get_group_nbr());
            pstmt.setString(2, anAccountLaneVO.get_acct_nbr());
            pstmt.setInt(   3, anAccountLaneVO.get_lane_nbr());
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
    
    /**
     * Delete all lanes for the specified groupNbr and accountNbr
     * @param groupNbr
     * @param accountNbr
     * @throws SQLException
     */
    public void deleteAccountLanes(int groupNbr, String accountNbr) throws SQLException {

        try {
            setSqlSignature(deleteAccountLaneSQL2, false, logger.isDebugEnabled());

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
