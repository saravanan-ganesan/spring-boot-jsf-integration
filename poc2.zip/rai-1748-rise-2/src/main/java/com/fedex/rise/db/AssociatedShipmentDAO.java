package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AssociatedShipmentVO;

public class AssociatedShipmentDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AssociatedShipmentDAO.class);
    
    /**
     * This method is used to persist a record into the Associated Shipment table.
     *
     * @param anAssociatedShipmentList the associated shipment data to persist
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void doPersist(List anAssociatedShipmentList) throws SQLException, ServiceLocatorException {
        Connection connection = null;
        
        try {
            connection = initializeConnection(true);
            AssociatedShipmentPersister persister = new AssociatedShipmentPersister(connection);
            Iterator iter = anAssociatedShipmentList.iterator();
            while(iter.hasNext()) {
                AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                if (assocShipmentVO.get_trkng_item_nbr() != null 
                		&& assocShipmentVO.get_trkng_item_uniq_nbr() != null 
                		&& assocShipmentVO.get_assoc_trkng_item_nbr() != null){
                	persister.persist(assocShipmentVO);
                }
            }
        } finally {
            closeConnection(connection);
        }
    }
    
    public List getAssociatedShipments(String trkng_item_nbr, 
                                       String trkng_item_uniq_nbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AssociatedShipmentAccessor accessor = new AssociatedShipmentAccessor(connection);
            List list = accessor.getAssociatedShipments(trkng_item_nbr, trkng_item_uniq_nbr);
            return list;
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * This method is used to get the associations by using the assoc trkng item number and
     * the association type.  Kind of a reverse look up.
     * @param anAssocTrkngItemNbr
     * @param anAssocTypeCd
     * @return
     * @throws ServiceLocatorException 
     * @throws SQLException 
     */
    public List getReverseAssociationByType(String anAssocTrkngItemNbr, char anAssocTypeCd) throws
        ServiceLocatorException, SQLException {
         
        Connection connection = null;

        try {
            connection = initializeConnection();
            AssociatedShipmentAccessor accessor = new AssociatedShipmentAccessor(connection);
            List list = accessor.getReverseAssociatedShipmentsByType(anAssocTrkngItemNbr, anAssocTypeCd);
            return list;
        } finally {
            closeConnection(connection);
        } 
    }
    
    public void updateAssociatedShipments(List anUpdateAssociation) throws ServiceLocatorException, SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            AssociatedShipmentUpdater updater = new AssociatedShipmentUpdater(connection);
            Iterator iter = anUpdateAssociation.iterator();
            while(iter.hasNext()) {
                AssociatedShipmentVO assocShipmentVO = (AssociatedShipmentVO)iter.next();
                updater.updateAssocShipment(assocShipmentVO);
            }
        } finally {
            closeConnection(connection);
        }  
    }

    public void updateAssociatedShipment(AssociatedShipmentVO anUpdateAssociation) throws ServiceLocatorException, SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection(true);
            AssociatedShipmentUpdater updater = new AssociatedShipmentUpdater(connection);
            updater.updateAssocShipment(anUpdateAssociation);
        } finally {
            closeConnection(connection);
        }  
    }
    
}
