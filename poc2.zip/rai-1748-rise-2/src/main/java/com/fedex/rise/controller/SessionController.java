package com.fedex.rise.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SessionController {

	@Autowired
	@Qualifier("sessionRegistry")
	private SessionRegistry sessionRegistry;
	
	@RequestMapping("/session/invalidate")
	public ResponseEntity<String> clearAllSession(@RequestParam(required = false) String email, HttpSession session) {
		
		SecurityContextImpl sci = (SecurityContextImpl)session.getAttribute("SPRING_SECURITY_CONTEXT");
		
		if(sci != null) {
			
			DefaultOidcUser user = (DefaultOidcUser) sci.getAuthentication().getPrincipal();
			
			if(!ObjectUtils.isEmpty(email)) {
				
				if(user.getEmail().equalsIgnoreCase(email)) {
					
					session.invalidate();
					return new ResponseEntity<>("Successfully invalidated the session for for the user associated with email " + email + "!!!", HttpStatus.OK);
					
				} else {
					
					return new ResponseEntity<>("Email mismatch to clear session!!!", HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				
				return new ResponseEntity<>("Email is required to clear in the form email=emailId to clear session!!!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}

		return new ResponseEntity<>("No session availble!!!", HttpStatus.INTERNAL_SERVER_ERROR);
 	}
	
	@RequestMapping("/session")
	public ResponseEntity<String> getAllSession() {
		
		String html = "";
		
		if(!ObjectUtils.isEmpty(sessionRegistry) && !ObjectUtils.isEmpty(sessionRegistry.getAllPrincipals())) {
			
			List<DefaultOidcUser> userList = new ArrayList<>();
			
			if(sessionRegistry.getAllPrincipals().size() != 0) {
				
				final List<Object> allPrincipals = sessionRegistry.getAllPrincipals();

		        for (final Object principal : allPrincipals) {
		            if (principal instanceof DefaultOidcUser) {
		                final DefaultOidcUser user = (DefaultOidcUser) principal;

		                List<SessionInformation> activeUserSessions =
		                        sessionRegistry.getAllSessions(principal,
		                                /* includeExpiredSessions */ false); // Should not return null;

		                if (!activeUserSessions.isEmpty()) {
		                    // Do something with user
		                	userList.add(user);
		                }
		            }
		        }
			}
			
			html = "<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\n"
			+ "	<tbody>\n"
			+ "		<tr>\n"
			+ "			<td style=\"width:225px\"><strong>Name</strong></td>\n"
			+ "			<td style=\"width:261px\"><strong>Email</strong></td>\n"
			+ "		</tr>\n";
//			+ "		<tr>\n";
			for(DefaultOidcUser user:userList) {
				
				html = html + "<tr>\n<td style=\"width:225px\">" +  user.getFullName() +  "</td>\n";
				html = html + "<td style=\"width:225px\">" +  user.getEmail() +  "</td>\n</tr>\n";
			}
			html = html 
//			+ "		</tr>\n"
			+ "		<tr>\n"
			+ "			<td style=\"width:225px\">&nbsp;</td>\n"
			+ "			<td style=\"width:261px\">&nbsp;</td>\n"
			+ "		</tr>\n"
			+ "	</tbody>\n"
			+ "</table>";
			
			
		}
		if(html == "") html = "There is no active session available in this application!!!";
		return new ResponseEntity<>(html, HttpStatus.OK);
	}
}
