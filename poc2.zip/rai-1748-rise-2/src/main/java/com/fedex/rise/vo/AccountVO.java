package com.fedex.rise.vo;

import java.io.Serializable;

public class AccountVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int _group_nbr;
    private String _acct_nbr;
    private String _acct_nm;
    private String _company_nm;
    private String _dtytax_acct_nbr;
    private String _cmdty_desc;
    private String _spcl_instr_desc;
    private String _comment_desc;
    private char   _rerte_flg;
    private char   _hold_at_loc_flg;
    
    public AccountVO() { } 
    
    public AccountVO(int _group_nbr, String _acct_nbr, String _acct_nm, String _company_nm, String _dtytax_acct_nbr, String _cmdty_desc, String _spcl_instr_desc, String _comment_desc, char _rerte_flg, char _hold_at_loc_flg) {
        super();
        this._group_nbr = _group_nbr;
        this._acct_nbr = _acct_nbr;
        this._acct_nm = _acct_nm;
        this._company_nm = _company_nm;
        this._dtytax_acct_nbr = _dtytax_acct_nbr;
        this._cmdty_desc = _cmdty_desc;
        this._spcl_instr_desc = _spcl_instr_desc;
        this._comment_desc = _comment_desc;
        this._rerte_flg = _rerte_flg;
        this._hold_at_loc_flg = _hold_at_loc_flg;
    }
    
    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }
    /**
     * @param _acct_nbr the _acct_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr;
    }
    /**
     * @return the _acct_nm
     */
    public String get_acct_nm() {
        return _acct_nm;
    }
    /**
     * @param _acct_nm the _acct_nm to set
     */
    public void set_acct_nm(String _acct_nm) {
        this._acct_nm = _acct_nm;
    }
    /**
     * @return the _cmdty_desc
     */
    public String get_cmdty_desc() {
        return _cmdty_desc;
    }
    /**
     * @param _cmdty_desc the _cmdty_desc to set
     */
    public void set_cmdty_desc(String _cmdty_desc) {
        this._cmdty_desc = _cmdty_desc;
    }
    /**
     * @return the _comment_desc
     */
    public String get_comment_desc() {
        return _comment_desc;
    }
    /**
     * @param _comment_desc the _comment_desc to set
     */
    public void set_comment_desc(String _comment_desc) {
        this._comment_desc = _comment_desc;
    }
    /**
     * @return the _company_nm
     */
    public String get_company_nm() {
        return _company_nm;
    }
    /**
     * @param _company_nm the _company_nm to set
     */
    public void set_company_nm(String _company_nm) {
        this._company_nm = _company_nm;
    }
    /**
     * @return the _dtytax_acct_nbr
     */
    public String get_dtytax_acct_nbr() {
        return _dtytax_acct_nbr;
    }
    /**
     * @param _dtytax_acct_nbr the _dtytax_acct_nbr to set
     */
    public void set_dtytax_acct_nbr(String _dtytax_acct_nbr) {
        this._dtytax_acct_nbr = _dtytax_acct_nbr;
    }
    /**
     * @return the _group_nbr
     */
    public int get_group_nbr() {
        return _group_nbr;
    }
    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_group_nbr(int _group_nbr) {
        this._group_nbr = _group_nbr;
    }
    /**
     * @return the _hold_at_loc_flg
     */
    public char get_hold_at_loc_flg() {
        return _hold_at_loc_flg;
    }
    /**
     * @param _hold_at_loc_flg the _hold_at_loc_flg to set
     */
    public void set_hold_at_loc_flg(char _hold_at_loc_flg) {
        this._hold_at_loc_flg = _hold_at_loc_flg;
    }
    /**
     * @return the _rerte_flg
     */
    public char get_rerte_flg() {
        return _rerte_flg;
    }
    /**
     * @param _rerte_flg the _rerte_flg to set
     */
    public void set_rerte_flg(char _rerte_flg) {
        this._rerte_flg = _rerte_flg;
    }
    /**
     * @return the _spcl_instr_desc
     */
    public String get_spcl_instr_desc() {
        return _spcl_instr_desc;
    }
    /**
     * @param _spcl_instr_desc the _spcl_instr_desc to set
     */
    public void set_spcl_instr_desc(String _spcl_instr_desc) {
        this._spcl_instr_desc = _spcl_instr_desc;
    }


}
