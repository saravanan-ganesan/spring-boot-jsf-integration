package com.fedex.rise.bean;

import java.io.IOException;

import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.config.SpringContext;
import com.fedex.rise.constant.AppConstant;

import lombok.extern.slf4j.Slf4j;

/**
 * This is the base controller class contains the common functionality for all
 * other sub-controller
 * 
 * @author saravanan g
 *
 */
@Slf4j
@ViewScoped
public class BaseBean {

	public void redirect(String url) {

		try {

			if (!ObjectUtils.isEmpty(url)) {

				if (!url.startsWith("/")) {
					url = AppConstant.FOLDER_SEPARATOR + url;
				}
				FacesContext.getCurrentInstance().getExternalContext().redirect(url);

			} else {

				FacesContext.getCurrentInstance().getExternalContext().redirect("/error");
			}

		} catch (IOException e) {
			printStackTrace(e);
		}
	}

	public void printStackTrace(Throwable e) {

		log.info(ExceptionUtils.getStackTrace(e));
	}

	@SuppressWarnings("unchecked")
	public <T> T getBean(String beanName, Class<T> beanclazz) {

		if (SpringContext.getApplicationContext() != null) {
			Object beanObject = SpringContext.getBean(beanName);
			if(null != beanObject) {
				return (T) beanObject;
			} else {
				return null;
			}
		} else {
			return null;
		}
		
	}

}
