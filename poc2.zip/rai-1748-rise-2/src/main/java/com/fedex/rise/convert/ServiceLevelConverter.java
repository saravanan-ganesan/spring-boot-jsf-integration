package com.fedex.rise.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.format.ServiceTypeFormatter;
import com.fedex.rise.xref.SvcLvlDescCodes;

public class ServiceLevelConverter implements Converter {
    /** logger */
    private static final Log log = LogFactory.getLog(ServiceLevelConverter.class);
    
    /**
     * Default constructor
     */
    public ServiceLevelConverter() {
        super();
        //if (log.isDebugEnabled()) log.debug("Constructed");
    }
    
    
    public Object getAsObject(FacesContext context, UIComponent component, String aSvcLvl)
        throws ConverterException {
        
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + aSvcLvl);
        return getAsString(context, component, aSvcLvl);
    }   

    public String getAsString(FacesContext context, UIComponent component, Object aSvcLvl)
        throws ConverterException {
        
        if (aSvcLvl == null) {
            return null;
        }
        String svcLvl = (String)aSvcLvl;
        String svcDesc = SvcLvlDescCodes.lookupCd(svcLvl);
        return ServiceTypeFormatter.format(svcLvl, svcDesc);
    }
}
