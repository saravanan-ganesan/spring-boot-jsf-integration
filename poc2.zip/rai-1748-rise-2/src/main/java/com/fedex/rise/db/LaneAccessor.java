package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.LaneVO;

public class LaneAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(LaneAccessor.class);
    
    public LaneAccessor(Connection con) {
        super(con);
    }
            
    private final String selectLaneSQL = "select " +
        "LANE_NBR, " +
        "ORIG_CNTRY_CD, " +
        "DEST_CNTRY_CD " + 
        "from Lane where LANE_NBR = ?";  
    
    private final String selectLanesSQL = "select " +
        "LANE_NBR, " +
        "ORIG_CNTRY_CD, " +
        "DEST_CNTRY_CD " + 
        "from Lane order by ORIG_CNTRY_CD, DEST_CNTRY_CD"; 
            
    public LaneVO getLane(int laneNbr) throws SQLException {
    	LaneVO laneVO = new LaneVO(); 
                
        try {
            setSqlSignature( selectLaneSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, laneNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                        
                    laneVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                    laneVO.set_orig_cntry_cd(rs.getString("ORIG_CNTRY_CD"));
                    laneVO.set_dest_cntry_cd(rs.getString("DEST_CNTRY_CD"));
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return laneVO;
    }

    public List getLaneTable() throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectLanesSQL, false, logger.isDebugEnabled() );

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    LaneVO laneVO = new LaneVO();
                        
                    laneVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                    laneVO.set_orig_cntry_cd(rs.getString("ORIG_CNTRY_CD"));
                    laneVO.set_dest_cntry_cd(rs.getString("DEST_CNTRY_CD"));
                    
                    al.add(laneVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
}
