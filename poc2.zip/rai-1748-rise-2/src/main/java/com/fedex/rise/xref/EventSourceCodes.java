package com.fedex.rise.xref;

import java.util.HashMap;

public class EventSourceCodes {

    static HashMap sourceCds = new HashMap();
    private final static String doubleQuote = "\"";
    
    static {
        // Key = Source Cd.  Key maps to the Description of the source cd.
        // What is seen on COSMOS screens is in parens ().  
        sourceCds.put("1", "MSDS");  
        sourceCds.put("2", "Tracker");
        sourceCds.put("3", "DADS (D)");
        sourceCds.put("4", "PF7 (7)");
        sourceCds.put("5", "CERPS (C)");
        sourceCds.put("6", "International Manifest (I)");
        sourceCds.put("7", "Application");
        sourceCds.put("9", "Reject Queue COSIIB (R)");
        sourceCds.put("A", "NPQ (NP)");
        sourceCds.put("B", "Supply (S)");
        sourceCds.put("C", "CASH (B)");
        sourceCds.put("D", "CADES (K)");
        sourceCds.put("E", "File Maintenance - COSIIA");
        sourceCds.put("F", "FICHE");
        sourceCds.put("G", "COSIIB Screens (G)");
        sourceCds.put("I", "Intl MailService POD - MPOD (ME)");
        sourceCds.put("J", "Meter Uplink System (M)");
        sourceCds.put("K", "ECCO (E)");
        sourceCds.put("L", "Tracker Backup (TB)");
        sourceCds.put("M", "RED (RD)");
        sourceCds.put("N", "System Generated (AU)");
        sourceCds.put("O", "RJQ - RED (RD)");
        sourceCds.put("P", "Cargo Scanner (H)");
        sourceCds.put("Q", "OPAR Override Program (OV)");
        sourceCds.put("R", "COD System (CD)");
        sourceCds.put("S", "PC Pickup System (PK)");
        sourceCds.put("T", "RADAR (RA)");
        sourceCds.put("U", "Automated Expedite System (EX)");
        sourceCds.put("V", "Customer Automated System (CU)");
        sourceCds.put("W", "PC Post (PC)");
        sourceCds.put("X", "AS/400 (GP)");
        sourceCds.put("Y", "Hub Overhead Scan Device - Orig");
        sourceCds.put("Z", "FedEx Online Device (FE)");
        sourceCds.put("#", "Purple Lights");
        sourceCds.put("$", "Small Package Sort System - SPSS");
        sourceCds.put("%", "XSCAN");
        sourceCds.put("(", "Ring Scanner - PPU");
        sourceCds.put("+", "Overhead Scanner - OHS");
        sourceCds.put(":", "Purple Lights Packages");
        sourceCds.put(doubleQuote, "Police");
        sourceCds.put(",", "LDC");
        sourceCds.put("!", "PowerPad (PP)");
        sourceCds.put("@", "GSP Tracker");
        sourceCds.put("<", "Ship & Get");
     }
    
    public static String get(String aSourceCd) {
        return (String)sourceCds.get(aSourceCd);
    }
}
