package com.fedex.rise.bo.issue;

import java.util.ArrayList;
import java.util.Date;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public class MovementResolver extends Resolver {

    private static ArrayList _movementScans = new ArrayList();
    
    private static MovementResolver _instance = new MovementResolver();

    static {
        // These scans are determined by me to mean a movement has occurred
        _movementScans.add(RiseConstants.SOP);
        _movementScans.add(RiseConstants.ROP); 
        _movementScans.add(RiseConstants.HIP); 
        _movementScans.add(RiseConstants.ECCO); 
        _movementScans.add(RiseConstants.HOP); 
        _movementScans.add(RiseConstants.RIP); 
        _movementScans.add(RiseConstants.SIP); 
        _movementScans.add(RiseConstants.VAN);        
    };
  
    private MovementResolver() {};
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        if ((_movementScans.contains(anEventVO.get_track_type_cd())) ||
            DeliveryResolver.getInstance().isResolved(anEventVO, anIssueVO)) {
            return true;
        }
        return false;
    }

    public static MovementResolver getInstance() {
        return _instance;
    }
    
}
