package com.fedex.rise.timer;

import javax.management.NotificationListener;

import com.fedex.rise.db.DatabaseDAO;

/**
 * WebLogic Server includes a timer service that you can configure to emit 
 * notifications at specific dates and times or at a constant interval. To 
 * listen and respond to these timer notifications, you create a JMX 
 * notification listener and register it with the timer service. This class
 * shall be used to publish NOIs at periodic intervals.
 * 
 * @author be379961
 *
 */
public class DBCleanUpScheduler { //extends DatabaseDAO implements NotificationListener {
//
//	private static Logger logger = LogManager.getLogger(DBCleanUpScheduler.class);
//	
//	/**
//	 * Constants, one day, hour, minute and second in milliseconds.
//	 */ 
//	private static final long PERIOD_DAY_MSEC = Timer.ONE_DAY;  
//	private static final long PERIOD_HOUR_MSEC = Timer.ONE_HOUR;  
//	private static final long PERIOD_MINUTE_MSEC = Timer.ONE_MINUTE;  
//	private static final long PERIOD_SECOND_MSEC = Timer.ONE_SECOND;  
//	
//	private Timer _timer;    
//	private Integer _notificationId;      
//	private DBCleanup _dBCleanup = null;
//	
//	/**
//	 * Constructor which instantiates Timer MBean, register a listener, and 
//	 * adding the notification to the Timer. Converts period of scheduling from 
//	 * hours to milliseconds.  Also calculates when to start the first scheduled
//	 * event.
//	 *
//	 */
//	public DBCleanUpScheduler() {        
//		logger.info("TimerScheduler: class instantiated");      
//		/**
//		 * Instantiating the Timer MBean
//		 */   
//		_timer = null;
//		_timer = new Timer(); 
//		
//		/**
//		 * Set the database clean up period from the property file.  If it is not
//		 * set, use a default value of 24 hours.
//		 */
//		long numberHours = 24;
//			
//		
//		long periodLong = PERIOD_HOUR_MSEC * numberHours;	
//		
//		logger.debug("periodLong = " + String.valueOf(periodLong));
//		/**
//		 * Set the database cleanup time of day to start running from the property 
//		 * file.  If it is not set, use a default value of 0.5 which represents 
//		 * the local time 0030. Minutes can be included by setting the 
//		 * DBCLEANUP_START_LOCAL_TIME_HOURS to fraction of hours, for example 
//		 * 13.5 is equivalent to 1330.
//		 */
//		String timeToStartAfterMidnightHours = 
//			ConfigurationManager.get("DBCLEANUP_START_LOCAL_TIME_HOURS");
//		if (timeToStartAfterMidnightHours == null){
//			timeToStartAfterMidnightHours = "0.5";
//			logger.error("DBCLEANUP_START_LOCAL_TIME_HOURS property is null");
//		}
//		logger.info("property DBCLEANUP_START_LOCAL_TIME_HOURS = " 
//				+ timeToStartAfterMidnightHours);
//		/**
//		 * Get the current local date in milliseconds, currentDateMilliSecs.
//		 * Get the current local time in milliseconds, timeOfDayToStartMilliSecs.
//		 */
//		Calendar localTime = Calendar.getInstance();
//		long currentDateMilliSecs = localTime.getTimeInMillis();
//		SimpleDateFormat sdflocalTimeHour = new SimpleDateFormat("HH");
//		SimpleDateFormat sdflocalTimeMinute = new SimpleDateFormat("mm");
//		SimpleDateFormat sdflocalTimeSecond = new SimpleDateFormat("ss");
//		long timeOfDayHour = 
//			Long.parseLong(sdflocalTimeHour.format(localTime.getTime()));
//		long timeOfDayMinute = 
//			Long.parseLong(sdflocalTimeMinute.format(localTime.getTime()));
//		long timeOfDaySecond = 
//			Long.parseLong(sdflocalTimeSecond.format(localTime.getTime()));
//		
//		long timeOfDayMilliSecs = timeOfDayHour * PERIOD_HOUR_MSEC
//			+ timeOfDayMinute * PERIOD_MINUTE_MSEC
//			+ timeOfDaySecond * PERIOD_SECOND_MSEC;
//		
//		long timeOfDayToStartMilliSecs = 
//			(long)(Double.parseDouble(timeToStartAfterMidnightHours) 
//			* PERIOD_HOUR_MSEC);
//		
//		/**
//		 * Calculate the first time for the database clean up scheduled 
//		 * handleNotification shall be called.  The timeToStartMilliSecs is a
//		 * function of timeOfDayMilliSecs, timeOfDayToStartMilliSecs, and 
//		 * currentDateMilliSecs.
//		 */
//		long timeToStartMilliSecs;
//		if (timeOfDayMilliSecs <= timeOfDayToStartMilliSecs){
//			timeToStartMilliSecs = currentDateMilliSecs 
//				+ timeOfDayToStartMilliSecs - timeOfDayMilliSecs;
//			
//		}else {
//			timeToStartMilliSecs = currentDateMilliSecs 
//				+ timeOfDayToStartMilliSecs + PERIOD_DAY_MSEC 
//				- timeOfDayMilliSecs;
//		}
//		
//		logger.debug("timeToStartMilliSecs = " + String.valueOf(timeToStartMilliSecs));
//		/**
//		 * Registering this class as a listener
//		 */        
//		_timer.addNotificationListener(this, null, "some handback object");
//		
//		/**
//		 * Adding the notification to the Timer and assigning the
//		 * ID that the Timer returns to a variable
//		 */        
//		Date timerTriggerAt = new Date(timeToStartMilliSecs); 
//		_notificationId = null;
//		_notificationId = _timer.addNotification("tenMinuteTimer", 
//				"a recurring call", this, timerTriggerAt, periodLong);        
//		_timer.start();    
//		
//		logger.info("TimerScheduler:timer started. notificationId = " 
//				+ _notificationId.toString());   
//		
//		_dBCleanup = new DBCleanup();
//	}
//	
//	/**
//	 * Stop the timer and remove the notification while shutting down.
//	 *
//	 */
//	public synchronized void cleanUp()
//	{
//		logger.info("cleanUp");
//		
//	    try
//	    {     
//	    	if (_timer != null) {
//	    		_timer.stop();
//	    		if (_notificationId != null) {
//	    			_timer.removeNotification(_notificationId);
//	    			_notificationId = null;
//	    			logger.info("cleanUp: stopped");
//	    		}
//	    	}
//	    }
//	    catch (InstanceNotFoundException e)
//	    {
//	    	logger.error("Instance Not Found Exception", e);
//	       e.printStackTrace();
//	    }
//	}
//	
//	/**
//	 * finalize method used while shutting down.
//	 */
//	protected void finalize() throws Throwable
//	{
//		logger.info("finalize");
//	    	   cleanUp();
//	    	   super.finalize();
//	}
//    
//	/**
//	 * Callback method.
//	 */
//	public void handleNotification(Notification notif, Object handback) {  
//			logger.info("handleNotification "+(new Date()));
//		Connection connection = null;
//		String dBCleanUpServerName = 
//			ConfigurationManager.get("DBCLEANUP_SERVER_NAME");
//		if (dBCleanUpServerName == null){
//			logger.error("DBCLEANUP_SERVER_NAME property is null");
//		}
//		try {
//			if (getHostName().equalsIgnoreCase(dBCleanUpServerName)){
//				if (_dBCleanup != null){
//					connection = initializeConnection();
//					_dBCleanup.start(connection);
//					closeConnection(connection);
//				}
//			}
//		} catch (UnknownHostException e){
//			logger.error("Database Clean Up Unknown host exception", e);
//		} catch (Exception e){
//			logger.error("Error encountered during Database Clen Up", e);
//		}
//	}
//	
//	private String getHostName() throws UnknownHostException {
//		String localHostname = null;
//		localHostname = System.getenv("CNAME");
//		if (localHostname == null || localHostname.equalsIgnoreCase("")) {
//			InetAddress address = InetAddress.getLocalHost();
//			localHostname = address.getCanonicalHostName();
//		}
//		return localHostname;
//	}
}
