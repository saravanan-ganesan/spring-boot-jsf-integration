package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.LaneServiceVO;

public class LaneServiceDeleter extends OracleBase {

    private static Logger logger = LogManager.getLogger(LaneServiceDeleter.class);

    public LaneServiceDeleter(Connection con) {
        super(con);
    }

    private static final String deleteLaneServiceSQL = "Delete from Lane_Service where " +
                "GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ? and SVC_TYPE_CD = ?";
    private static final String deleteLaneServiceSQL2 = "Delete from Lane_Service where " +
                "GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ?";
    private static final String deleteLaneServiceSQL3 = "Delete from Lane_Service where " +
                "GROUP_NBR = ? and ACCT_NBR = ?";

    /**
     * Delete the specified service
     * @param anLaneServiceVO
     * @throws SQLException
     */
    public void deleteLaneService(LaneServiceVO anLaneServiceVO) throws SQLException {

        try {
            setSqlSignature(deleteLaneServiceSQL, false, logger.isDebugEnabled());

            pstmt.setInt(   1, anLaneServiceVO.get_group_nbr());
            pstmt.setString(2, anLaneServiceVO.get_acct_nbr());
            pstmt.setInt(   3, anLaneServiceVO.get_lane_nbr());
            pstmt.setString(4, anLaneServiceVO.get_svc_type_cd());

            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
   
    /**
     * Delete all services for the specified groupNbr, accountNbr, laneNbr
     * @param groupNbr
     * @param accountNbr
     * @param laneNbr
     * @throws SQLException
     */
    public void deleteLaneServices(int groupNbr, String accountNbr, int laneNbr) throws SQLException {

        try {
            setSqlSignature(deleteLaneServiceSQL2, false, logger.isDebugEnabled());

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);
            pstmt.setInt(3, laneNbr);

            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
    
    /**
     * Delete all services for the specified groupNbr, accountNbr
     * @param groupNbr
     * @param accountNbr
     * @param laneNbr
     * @throws SQLException
     */
    public void deleteLaneServices(int groupNbr, String accountNbr) throws SQLException {

        try {
            setSqlSignature(deleteLaneServiceSQL3, false, logger.isDebugEnabled());

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);

            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
