package com.fedex.rise.bean;

import java.io.Serializable;

/**
 * Tabbed Pane Bean to maintain tab state for the CRN Details dialog.
 * Tab: Details, Events
 * 
 * TODO: rename tab1 to details, etc.
 */
public class CrnTabbedPaneBean implements Serializable {
    //private static final Log log = LogFactory.getLog(CrnTabbedPaneBean.class);

    /** serialize id */
    private static final long serialVersionUID = 1L;

    private boolean _tab1Visible = true;
    private boolean _tab2Visible = true;
    private boolean _tab3Visible = true;

    public boolean isTab1Visible() {
        return _tab1Visible;
    }

    public void setTab1Visible(boolean tab1Visible) {
        _tab1Visible = tab1Visible;
    }

    public boolean isTab2Visible() {
        return _tab2Visible;
    }

    public void setTab2Visible(boolean tab2Visible) {
        _tab2Visible = tab2Visible;
    }

    public boolean isTab3Visible() {
        return _tab3Visible;
    }

    public void setTab3Visible(boolean tab3Visible) {
        _tab3Visible = tab3Visible;
    }

}
