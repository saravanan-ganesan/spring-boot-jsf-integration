package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.PerformanceVO;

public class PerformancePersister extends OracleBase {
	private static Logger logger = LogManager.getLogger(PerformancePersister.class);
	
	public PerformancePersister(Connection con) {
        super(con);
    }
	
	private static final String addPerformanceRowSQL =
	    "Insert into Performance(" +
	    "SHIP_DT, " +
	    "ACCT_NBR, " +
	    "LANE_NBR, " +       
	    "GROUP_NBR, " +
	    "ORIG_CNTRY_CD, " +
	    "DEST_CNTRY_CD, " +
	    "TOTAL_MAWB_QTY, " +
	    "TOTAL_CRN_QTY, " +
	    "ON_TIME_CRN_QTY, " +
	    "LATE_CRN_QTY, " +
	    "EXCUS_CRN_QTY, " +
	    "ODA_CRN_QTY, " +
	    "NO_POD_CRN_QTY, " +
	    "TOTAL_WGT_AMT, " +
	    "TOTAL_INV_VALUE_AMT, " +
	    "INPUT_TMSTP) " +
	    "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,SYSDATE)";        

	public void doPersist(PerformanceVO aPerformanceVO) throws SQLException {
	    
	    try {
	        setSqlSignature( addPerformanceRowSQL, false, logger.isDebugEnabled() );    
	            
	        if (aPerformanceVO.get_ship_dt() != null) {
	            java.sql.Date sqlDate = 
	                new java.sql.Date(aPerformanceVO.get_ship_dt()
	                			.getTimeInMillis());
	            pstmt.setDate(  1, sqlDate);
	        } else {
	            pstmt.setNull(  1, java.sql.Types.DATE);
	        }
	        pstmt.setString( 2, aPerformanceVO.get_acct_nbr());
	        pstmt.setInt(3, aPerformanceVO.get_lane_nbr());
	        pstmt.setInt(4, aPerformanceVO.get_group_nbr());  
	        pstmt.setString( 5, aPerformanceVO.get_orig_cntry_cd());
	        pstmt.setString( 6, aPerformanceVO.get_dest_cntry_cd());
	        pstmt.setLong( 7, aPerformanceVO.get_total_mawb_qty());
	        pstmt.setLong( 8, aPerformanceVO.get_total_crn_qty());
	        pstmt.setLong( 9, aPerformanceVO.get_on_time_crn_qty());
	        pstmt.setLong( 10, aPerformanceVO.get_late_crn_qty());
	        pstmt.setLong( 11, aPerformanceVO.get_excus_crn_qty());
	        pstmt.setLong( 12, aPerformanceVO.get_oda_crn_qty());
	        pstmt.setLong(13, aPerformanceVO.get_no_pod_crn_qty());
	        pstmt.setLong(14, aPerformanceVO.get_total_wgt_amt());
	        pstmt.setLong(15, aPerformanceVO.get_total_inv_value_amt());
	            
	        
	        if (logger.isDebugEnabled()) {
	            logger.debug(pstmt.toString());
	        }
	        
	        execute();

	    } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
	        throw sqle;
	    } finally {
	        try {
	            cleanResultSet();
	        } catch (SQLException sqle2) {
	            sqle2.printStackTrace();
	            throw sqle2;
	        }
	    }
	}
}
