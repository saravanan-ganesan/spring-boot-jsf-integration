package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.format.EmployeeNameFormatter;
import com.fedex.rise.format.LaneFormatter;
import com.fedex.rise.format.ServiceTypeFormatter;
import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.LaneServiceVO;
import com.fedex.rise.vo.LaneVO;
import com.fedex.rise.xref.SvcLvlDescCodes;
import com.fedex.rise.bo.UserDelegate;
/**
 * Backer bean for AccountLane, lanes associated with an account
 * 
 */
public class LaneServiceBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(LaneServiceBean.class);

    /** delegate to get shipper data */
    private ShipperDelegate shipperDelegate = new ShipperDelegate();
    private UserDelegate userDelegate = new UserDelegate();
    
    /** parent shipper for this account */
    private ShipperTreeBean _shipperTreeBean = null;
   
    /** other key values, to identify an LaneService */
    private String _shipperNbr = null;
    private String _accountNbr =  null;
    private String _laneNbr =  null;
    private String _serviceTypeCd =  null;
    
    /** editable attributes */
    private int _commitDaysQty = 0;
    private String _selectedMonitor = null;
    // to handle the empty values for monitors it is defined as new instead of null
    private String[] _manyMonitor = new String[0];
     
    /** displayable name for the service */
    private String _svcName = null;
    
    /** list of valid services */
    static private List _allServices = new ArrayList();
    static {
        HashMap services = SvcLvlDescCodes.getAll();
        Iterator itr = services.entrySet().iterator();
        while (itr.hasNext()) {
           Map.Entry entry = (Map.Entry)itr.next();
           String svcTypeCd = (String)entry.getKey();
           String svcTypeDesc = (String)entry.getValue();
           
           // create SelectItem with the key (svcTypeCd) and a formatted display value
           _allServices.add(new SelectItem(svcTypeCd, ServiceTypeFormatter.format(svcTypeCd, svcTypeDesc)));
        }
    }
    
    
    /** 
     * Default Constructor
     */
    public LaneServiceBean() {
        shipperDelegate = new ShipperDelegate();
        
        // get the ShipperTreeBean from the session, so we can get access to 
        // (1) the selected lane node (we'll need the shipperNbr, laneNbr) or 
        // (2) the selected service node (we'll need the shipperNbr & accountNbr, laneNbr, serviceTypeCd)
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        _shipperTreeBean = (ShipperTreeBean)params.get("shipperTreeBean");
        init();
    }
    
    private void init() {
        // Get the selected node key values (shipperNbr, accountNbr)
        String[] keys = _shipperTreeBean.getSelectedKeys();
        _shipperNbr = keys[0];
        _accountNbr = keys[1];
        _laneNbr = keys[2];
 
        // determine if we are adding a new lane from the account (2 nodes, shipper, account)
        // or if we are showing the lane info (should be 3 nodes, shipper, account, lane);
        if (keys.length > 3) {
            _serviceTypeCd = keys[3];
      
            // Get the selected service
            LaneServiceVO service= shipperDelegate.getLaneService(_shipperNbr, 
                       _accountNbr, _laneNbr, _serviceTypeCd);
            if (service.get_commit_days_qty() != null)
                _commitDaysQty = Integer.parseInt(service.get_commit_days_qty());
            else
                _commitDaysQty = 0;
            
            _svcName = ServiceTypeFormatter.format(_serviceTypeCd, SvcLvlDescCodes.lookupCd(_serviceTypeCd));
         
        }
    }
    
    
    /*---------------------------------------------------------------------
     * Getter/Setter methods
     *--------------------------------------------------------------------- 
     */
   

    public String getSvcName() {
        return _svcName;
    }
    
    /**
     * @return the _commitDaysQty
     */
    public String getCommitDaysQty() {
        return String.valueOf(_commitDaysQty);
    }


    /**
     * @param daysQty the _commitDaysQty to set
     */
    public void setCommitDaysQty(String daysQty) {
        _commitDaysQty = Integer.parseInt(daysQty);
    }
    
    /**
     * Get the list of valid services
     * @return
     */
    public List getAllServices() {
        return _allServices;
    }
   
    /**
     * set selected Monitor 
     */
    public void setSelectedMonitor(String monitor) {
        log.debug("Entering setSelectedMonitor()");
        _selectedMonitor = monitor;
    }
    
    /**
     * get selected Monitor
     */
    public String getSelectedMonitor() {
        log.debug("Entering getSelectedMonitor()");
        
        _selectedMonitor = null;
        
        List monitorEmployeeNbrs = shipperDelegate.getMonitors(_shipperNbr, 
                _accountNbr, _laneNbr, _serviceTypeCd);
       
        // TODO: handle multiple monitors ??
        if (monitorEmployeeNbrs != null && monitorEmployeeNbrs.size() > 0) {
            _selectedMonitor = (String)monitorEmployeeNbrs.get(0);
        } else {
            _selectedMonitor = null;
        }
        
        return _selectedMonitor;
    }
    /**
     * set many Monitor 
     */
  
    public void setManyMonitor(String[] list) {
        log.debug("Entering setManyMonitor()");
        _manyMonitor = list;
    }
    
    /**
     * get many Monitor
     */
        public String[] getManyMonitor() {
        log.debug("Entering getManyMonitor()");
        
        List monitorEmployeeNbrs = shipperDelegate.getMonitors(_shipperNbr,_accountNbr, _laneNbr, _serviceTypeCd);
        _manyMonitor = new String[monitorEmployeeNbrs==null?0:monitorEmployeeNbrs.size()];
                int i=0;
        for (Iterator itr=monitorEmployeeNbrs.iterator(); itr.hasNext(); i++) {
        	AcctLaneServiceMonitoringVO acctLnMonitoring = (AcctLaneServiceMonitoringVO) itr.next();
            _manyMonitor[i] = String.valueOf(acctLnMonitoring.get_emp_nbr());
        }
        
               
        return _manyMonitor;
    }
        
    /*---------------------------------------------------------------------
     * Actions
     *--------------------------------------------------------------------- 
     */
    
    /**
     * Delete Service from a lane
     */
    public String deleteServiceAction() {
        log.debug("Entering deleteServiceAction()");
        
        shipperDelegate.deleteServiceFromShipper(_shipperNbr, _accountNbr, 
               _laneNbr, _serviceTypeCd);
        
        // tell shipper so this new node will not be selected 
        _shipperTreeBean.notifyDelete();
       
        // TODO: handle errors
        return "success";
    }

    /**
    * Save Service 
     */
    public String saveServiceAction() {
        log.debug("Entering saveServiceAction()");
        
        // update the service for this lane
        shipperDelegate.updateLaneService(_shipperNbr, _accountNbr, _laneNbr, 
                _serviceTypeCd, _commitDaysQty);
        
        // update the monitor for the service
                    shipperDelegate.addAcctLaneServiceManyMonitor(_shipperNbr, _accountNbr, 
                _laneNbr, _serviceTypeCd, _manyMonitor);
        
        //Update the GROUP_NBR in the SHIPMENT table of past shipments, if needed.
        shipperDelegate.updateGroupNbrPastShipments(_shipperNbr, 
        		_accountNbr, _laneNbr, _serviceTypeCd);
        
        // TODO: handle errors
        return "success";
    }
    
}
