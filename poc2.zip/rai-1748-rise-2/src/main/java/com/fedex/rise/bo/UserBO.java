package com.fedex.rise.bo;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import com.fedex.rise.db.EmployeeDAO;
import com.fedex.rise.db.MonitorDAO;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EmployeeVO;

public class UserBO {
    
    /**
     * Fetch the monitored account information via the Employee Number.
     * @param emplyNbr
     * @return a List used to populate the monitoring pane on the GUI
     * @throws SQLException 
     */
    public List getMonitoredAccounts(String anEmplyNbr) throws SQLException {
        MonitorDAO monitorDAO = new MonitorDAO();
        return monitorDAO.getMonitoredAccounts(anEmplyNbr);
    }
    
    /**
     * Fetch the users/employees
     * @return a List of users
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public List getUsers() throws SQLException, ServiceLocatorException {
        EmployeeDAO userDAO = new EmployeeDAO();
        return userDAO.getEmployees();
    }
    
    /**
     * Fetch the users/employees
     * @return EmployeeVO
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public EmployeeVO getUser(String emplyNbr) throws SQLException, ServiceLocatorException {
        EmployeeDAO userDAO = new EmployeeDAO();
        return userDAO.getEmployee(emplyNbr);
    }
    
    /**
     * Save the user/employee
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void saveUser(EmployeeVO anEmployeeVO) throws SQLException, ServiceLocatorException {
        EmployeeDAO userDAO = new EmployeeDAO();
        
        // determine if this is an update of an existing employee 
        // or insert of new employee
        List users = userDAO.getEmployees();
        boolean found = false;
        for (Iterator itr=users.iterator(); itr.hasNext(); ) {
            EmployeeVO tempEmply = (EmployeeVO)itr.next(); 
            if (tempEmply.get_emp_nbr().equals(anEmployeeVO.get_emp_nbr())) {
                found = true;
                break;
            }
        }
        
        if (found) {
            userDAO.updateEmployee(anEmployeeVO);
        } else {
            userDAO.addEmployee(anEmployeeVO);
        }
         
    }
    
    /**
     * Delete the user/employee
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void deleteUser(String anEmployeeNbr) throws SQLException, ServiceLocatorException {
        EmployeeDAO userDAO = new EmployeeDAO();
        
        userDAO.deleteEmployee(anEmployeeNbr);
    }
}
