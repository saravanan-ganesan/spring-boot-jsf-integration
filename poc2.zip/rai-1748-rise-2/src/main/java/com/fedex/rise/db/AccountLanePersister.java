package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountLaneVO;

public class AccountLanePersister extends OracleBase {
   private static Logger logger = LogManager.getLogger(AccountLanePersister.class);
    
    public AccountLanePersister(Connection con) {
        super(con);
    }
    
    private static final String addAccountLaneSQL =
            "Insert into Account_Lane(" +
            "GROUP_NBR, " +
            "ACCT_NBR, " +
            "LANE_NBR, " +
            "RTRN_ACCT_NBR, " +
            "RTRN_ADDR_LINE_ONE_DESC, " +
            "RTRN_ADDR_LINE_TWO_DESC, " +
            "RTRN_ADDR_LINE_THREE_DESC, " +
            "RTRN_CITY_NM, " +
            "RTRN_ST_PROV_CD, " +
            "RTRN_CONT_NM, " +
            "RTRN_CONT_PH_NBR, " +
            "IM_OF_REC_NM, " +
            "IM_OF_REC_ADDR_LINE_ONE_DESC, " +
            "IM_OF_REC_ADDR_LINE_TWO_DESC, " +
            "IM_OF_REC_CITY_NM, " +
            "IM_OF_REC_ST_PROV_CD, " +
            "IM_OF_REC_PSTL_CD, " +
            "IM_OF_REC_CONT_NM, " +
            "IM_OF_REC_PH_NBR, " +
            "IM_OF_REC_FAX_NBR, " +
            "IM_OF_REC_EMAIL_DESC, " +
            "ORIG_ACCT_EXEC_NM, " +
            "ORIG_ACCT_EXEC_PH_NBR, " +
            "ORIG_ACCT_EXEC_FAX_NBR, " +
            "ORIG_ACCT_EXEC_EMAIL_DESC, " +
            "DEST_ACCT_EXEC_NM, " +
            "DEST_ACCT_EXEC_PH_NBR, " +
            "DEST_ACCT_EXEC_FAX_NBR, " +
            "DEST_ACCT_EXEC_EMAIL_DESC, " +
            "BRKR_NM, " +
            "BRKR_PH_NBR, " +
            "BRKR_FAX_NBR, " +
            "PRIM_ENGNR_NM, " +
            "PRIM_ENGNR_PH_NBR, " +
            "PRIM_ENGNR_FAX_NBR, " +
            "PRIM_ENGNR_EMAIL_DESC, " +
            "SCNDY_ENGNR_NM, " +
            "SCNDY_ENGNR_PH_NBR, " +
            "SCNDY_ENGNR_FAX_NBR, " +
            "SCNDY_ENGNR_EMAIL_DESC, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP)" +
             "values(?,?,?,?,?,?,?,?," +
                    "?,?,?,?,?,?,?,?," +
                    "?,?,?,?,?,?,?,?," +
                    "?,?,?,?,?,?,?,?," +
                    "?,?,?,?,?,?,?,?," +                    
                    "SYSDATE, SYSDATE)";        
    
    public void addAccountLane(AccountLaneVO anAccountLaneVO) throws SQLException {
        
        try {
            setSqlSignature( addAccountLaneSQL, false, logger.isDebugEnabled() );

            pstmt.setInt( 1, anAccountLaneVO.get_group_nbr());
            pstmt.setString( 2, anAccountLaneVO.get_acct_nbr());
            pstmt.setInt(    3, anAccountLaneVO.get_lane_nbr());
            pstmt.setString( 4, anAccountLaneVO.get_rtrn_acct_nbr());
            pstmt.setString( 5, anAccountLaneVO.get_rtrn_addr_line_one_desc());
            pstmt.setString( 6, anAccountLaneVO.get_rtrn_addr_line_two_desc());
            pstmt.setString( 7, anAccountLaneVO.get_rtrn_addr_line_three_desc());
            pstmt.setString( 8, anAccountLaneVO.get_rtrn_city_nm());
            pstmt.setString( 9, anAccountLaneVO.get_rtrn_st_prov_cd());
            pstmt.setString(10, anAccountLaneVO.get_rtrn_cont_nm());
            pstmt.setString(11, anAccountLaneVO.get_rtrn_cont_ph_nbr());
            pstmt.setString(12, anAccountLaneVO.get_im_of_rec_nm());
            pstmt.setString(13, anAccountLaneVO.get_im_of_rec_addr_line_one_desc());
            pstmt.setString(14, anAccountLaneVO.get_im_of_rec_addr_line_two_desc());
            pstmt.setString(15, anAccountLaneVO.get_im_of_rec_city_nm());
            pstmt.setString(16, anAccountLaneVO.get_im_of_rec_st_prov_cd());
            pstmt.setString(17, anAccountLaneVO.get_im_of_rec_pstl_cd());
            pstmt.setString(18, anAccountLaneVO.get_im_of_rec_cont_nm());
            pstmt.setString(19, anAccountLaneVO.get_im_of_rec_ph_nbr());
            pstmt.setString(20, anAccountLaneVO.get_im_of_rec_fax_nbr());
            pstmt.setString(21, anAccountLaneVO.get_im_of_rec_email_desc());
            pstmt.setString(22, anAccountLaneVO.get_orig_acct_exec_nm());
            pstmt.setString(23, anAccountLaneVO.get_orig_acct_exec_ph_nbr());
            pstmt.setString(24, anAccountLaneVO.get_orig_acct_exec_fax_nbr());
            pstmt.setString(25, anAccountLaneVO.get_orig_acct_exec_email_desc());
            pstmt.setString(26, anAccountLaneVO.get_dest_acct_exec_nm());
            pstmt.setString(27, anAccountLaneVO.get_dest_acct_exec_ph_nbr());
            pstmt.setString(28, anAccountLaneVO.get_dest_acct_exec_fax_nbr());
            pstmt.setString(29, anAccountLaneVO.get_dest_acct_exec_email_desc());
            pstmt.setString(30, anAccountLaneVO.get_brkr_nm());
            pstmt.setString(31, anAccountLaneVO.get_brkr_ph_nbr());
            pstmt.setString(32, anAccountLaneVO.get_brkr_fax_nbr());
            pstmt.setString(33, anAccountLaneVO.get_prim_engnr_nm());
            pstmt.setString(34, anAccountLaneVO.get_prim_engnr_ph_nbr());
            pstmt.setString(35, anAccountLaneVO.get_prim_engnr_fax_nbr());
            pstmt.setString(36, anAccountLaneVO.get_prim_engnr_email_desc());
            pstmt.setString(37, anAccountLaneVO.get_scndy_engnr_nm());
            pstmt.setString(38, anAccountLaneVO.get_scndy_engnr_ph_nbr());
            pstmt.setString(39, anAccountLaneVO.get_scndy_engnr_fax_nbr());
            pstmt.setString(40, anAccountLaneVO.get_scndy_engnr_email_desc());            
           
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }       
}
