package com.fedex.rise.bo.issue;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

/**
 * Used old RISE and POF documentation from Barb and also talked to 
 * Gary Rockwood who gave me a snippet of cobol code which vaguely defines
 * what the values mean.
 *
 */
public class ClearedCustomsResolver extends Resolver {

    private static ClearedCustomsResolver _instance = new ClearedCustomsResolver();
    
    private ClearedCustomsResolver() {}
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        // Check for Stat 65 or ECCO event
        String trackTypeCd = anEventVO.get_track_type_cd();
        if (trackTypeCd.equals(RiseConstants.STAT)) {
            String trackExcpCd = anEventVO.get_track_excp_cd();
            if ((trackExcpCd != null) && (trackExcpCd.equals("65"))) {
                return true;
            }
        }
        
        if (DeliveryResolver.getInstance().isResolved(anEventVO, anIssueVO)){
        	return true;
        }
        
        if (trackTypeCd.equals(RiseConstants.ECCO)) {
            char eccoTypeCd = anEventVO.get_ecco_type_cd();
            char eccoCommCd = anEventVO.get_ecco_comm_cd();
        
            if ((eccoTypeCd == 'C') && ((eccoCommCd == 'E') || (eccoCommCd == '5'))) {
                return true;
            }

            if ((eccoTypeCd == 'P') && ((eccoCommCd == 'C') || (eccoCommCd == '3'))) {
                return true;
            }
        }
        return false;
    }
    
    public static ClearedCustomsResolver getInstance() {
        return _instance;
    }

}
