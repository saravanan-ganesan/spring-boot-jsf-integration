package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;

public class MDE1Resolver extends Resolver {

    private static ArrayList _scans = new ArrayList();
    
    private static MDE1Resolver _instance = new MDE1Resolver();

    static {
        // Scans of interest
        _scans.add(RiseConstants.MDE1_70);        
    };
  
    private MDE1Resolver() {};
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        if ((_scans.contains(anEventVO.get_track_type_cd())) ||
            DeliveryResolver.getInstance().isResolved(anEventVO, anIssueVO)) {
            return true;
        }
        return false;
    }

    public static MDE1Resolver getInstance() {
        return _instance;
    }
    
}
