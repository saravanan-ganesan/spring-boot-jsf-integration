package com.fedex.rise.bean;

import javax.faces.view.ViewScoped;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.util.ObjectUtils;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.service.UserService;
import com.fedex.rise.vo.EmployeeVO;

@ViewScoped
@JsfController(path = "/", page = "/pages/jsp/home.jsp", value = "homeBean")
public class HomeBean extends BaseBean {

	@Autowired
	UserService userService;
	
	UserBean userBean;
	
	public HomeBean() {}


	public UserBean getUserBean() {
		
		if(userBean == null) {
			userBean = new UserBean();
		}
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(null != authentication && !(authentication instanceof AnonymousAuthenticationToken)) {
			
			DefaultOidcUser oktaUser = (DefaultOidcUser) authentication.getPrincipal();
			if(null != oktaUser) {
				
				EmployeeVO employeeVO = userService.getUser("5412859");
				if(!ObjectUtils.isEmpty(employeeVO)) {
					
					userBean.setFirstName( employeeVO.get_emp_first_nm() );
					userBean.setLastName(employeeVO.get_emp_last_nm());
					userBean.setUserId(employeeVO.get_emp_nbr());
					userBean.setRole(employeeVO.get_emp_role_cd());
				}
				
			}
			
//			FacesContext facesContext = FacesContext.getCurrentInstance();
//			NavigationMenu navigationMenu = (NavigationMenu) facesContext.getApplication()
//					.getVariableResolver()
//					.resolveVariable(facesContext, "navigationMenu");
//			
//			System.out.println("###$$$$$"+navigationMenu);
			
//			NavigationMenu nMenu = getBean("navigationMenu", NavigationMenu.class);
//			if(nMenu != null) {
//				System.out.println("inside nMenu not null to set tab selection from home bean");
//				if(nMenu.getSelectedItem() != null && !nMenu.getSelectedItem().equalsIgnoreCase("Home")) {
//					nMenu.setItem("Home");
//				}
//			}
		}
		
		return userBean;
	}


	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}



}
