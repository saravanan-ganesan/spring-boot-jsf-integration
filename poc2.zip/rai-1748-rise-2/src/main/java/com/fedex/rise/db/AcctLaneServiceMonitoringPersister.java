package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;

public class AcctLaneServiceMonitoringPersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(AcctLaneServiceMonitoringPersister.class);
    
    public AcctLaneServiceMonitoringPersister(Connection con) {
        super(con);
    }
       
    private static final String addAccountLaneServiceMonitoringSQL =
            "Insert into Acct_Lane_Service_Monitoring(" +
            "EMP_NBR, " +
            "GROUP_NBR, " +
            "ACCT_NBR, " +
            "LANE_NBR, " +
            "SVC_TYPE_CD, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP)" +
             "values(?, ?, ?, ?, ?, SYSDATE, SYSDATE)";        
    
    public void addAccountLaneServiceMonitoring(AcctLaneServiceMonitoringVO anAcctLaneServiceMonitoringVO) throws SQLException {
        
        try {
            setSqlSignature( addAccountLaneServiceMonitoringSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anAcctLaneServiceMonitoringVO.get_emp_nbr());
            pstmt.setInt( 2, anAcctLaneServiceMonitoringVO.get_group_nbr());
            pstmt.setString( 3, anAcctLaneServiceMonitoringVO.get_acct_nbr());
            pstmt.setInt(    4, anAcctLaneServiceMonitoringVO.get_lane_nbr());
            pstmt.setString( 5, anAcctLaneServiceMonitoringVO.get_svc_type_cd());
           
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }       

}
