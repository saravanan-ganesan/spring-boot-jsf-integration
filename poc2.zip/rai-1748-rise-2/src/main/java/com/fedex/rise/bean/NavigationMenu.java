
package com.fedex.rise.bean;

import java.util.Arrays;

import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.view.ViewScoped;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.navmenu.htmlnavmenu.HtmlCommandNavigationItem;

import com.fedex.rise.annotation.JsfController;

/**
 * Main Navigation menu
 */
@ViewScoped
@JsfController(path = "/filterByIssue", page = "/pages/jsp/filterByIssue.jsp", value = "navigationMenu")
public class NavigationMenu extends BaseBean {
    
    
    private static final Log log = LogFactory.getLog(NavigationMenu.class);
    
    //Start WR#:179441 Changes
    private transient SearchBean searchBean = new SearchBean();
    //End WR#:179441 Changes

    public String selectedItem = "Home"; /* initially select the Home item */
    
    public NavigationMenu() {
    	System.out.println("NavigationMenu constructor called");
    }
   
    /*---------*/
    /* Getters */
    /*---------*/
    
    public String getSelectedItem() {
    	System.out.println("****"+selectedItem+"*****");
        return selectedItem;
    }
    
    public void setSelectedItem(String selectedItem) {
    	this.selectedItem = selectedItem;
    }
   
    /*---------*/
    /* Actions */
    /*---------*/
    
    public void homeAction() {
        log.info("HomeAction called");
        SearchBean.searchFailed = null;
        //return "home";
        redirect("/");
    }

    public void monitorAction() {
        log.info("MonitorAction called");
        SearchBean.searchFailed = null;
//        return "monitor";
        redirect("monitor");
    }

    public void FindShipperAccountAction() {
        log.info("FindShipperAccountAction called");
        SearchBean.searchFailed = null;
        //return "findShipperAccountNumber";
        redirect("findShipper");
    }
    
    public String FindShipmentAction() {
        log.info("FindShipmentAction called");
        SearchBean.searchFailed = null;
      //Start WR#:179441 Changes
        searchBean.reset();
      //End WR#:179441 Changes
        return "findShipment";
    }
    
    public String FindShipmentsMAWBSAction() {
        log.info("FindShipmentsMAWBSAction called");
        SearchBean.searchFailed = null;
      //Start WR#:179441 Changes
        searchBean.reset();
      //End WR#:179441 Changes
        return "findShipmentsMAWBS";
    }
    
    public String FindPackagesCRNSAction() {
        log.info("FindPackagesCRNSAction called");
        SearchBean.searchFailed = null;
        return "findPackagesCRNS";
    }
    
    public String FindMissingDataAction() {
        log.info("FindMissingDataAction called");
        SearchBean.searchFailed = null;
        return "findMissingData";
    }
    
    public String FindMonitorAction() {
        log.info("FindMonitorAction called");
        SearchBean.searchFailed = null;
        return "findMonitor";
    }
    
    public String performanceAction() {
        log.info("PerformanceAction called");
        SearchBean.searchFailed = null;
        return "performance";
    }

    public String adminAction() {
        log.info("AdminAction called");
        SearchBean.searchFailed = null;
        return "admin";
    }
    
    public String monitorReportAction() {
        log.info("monitorReportAction called");
        SearchBean.searchFailed = null;
        return "monitorReport";
    }

    public String userAdminAction() {
    	SearchBean.searchFailed = null;
        return "userAdmin";
    }
    public String roleChangeAction() {
    	SearchBean.searchFailed = null;
        return "roleChange";
    }

    public String laneAdminAction() {
    	SearchBean.searchFailed = null;
        return "laneAdmin";
    }

    public String shipperAdminAction() {
    	SearchBean.searchFailed = null;
        return "shipperAdmin";
    }
    
    public String RampHubAction() {
    	SearchBean.searchFailed = null;
        return "rampHub";
    }   
    
    
    /*-------Export Data WR--------*/
    public void filterByIssueAction() {
		log.info("filterAction called");
		SearchBean.searchFailed = null;
		redirect("filterByIssue");
		//return "filterByIssue";
		
	}
    
    

    /*-----------------*/
    /* Action Listener */
    /*-----------------*/
    
    public void actionListener(ActionEvent event) {
    	System.out.println(event);
    	selectedItem = ((HtmlCommandNavigationItem) event.getComponent()).getValue().toString();
    	System.out.println("inside actionlistener selectedItem="+selectedItem);
        FilterByIssueBean filterByIssueBean = (FilterByIssueBean) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("filterByIssueBean");
        

		if (filterByIssueBean != null) {
			String[] noIssuesFiltering = { "-1" };
			filterByIssueBean.setFilter(Arrays.asList(noIssuesFiltering));
			filterByIssueBean.setShipDateOffsetStr(null);
			filterByIssueBean.setCheckTotalCount(false);
			filterByIssueBean.setTotalCount(0);
		}
        log.info("ActionListener: menu item selected = " + selectedItem);
        
    }
    
    public void setActive() {
    	
    	selectedItem = "Home";
        FilterByIssueBean filterByIssueBean = (FilterByIssueBean) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("filterByIssueBean");
        

		if (filterByIssueBean != null) {
			String[] noIssuesFiltering = { "-1" };
			filterByIssueBean.setFilter(Arrays.asList(noIssuesFiltering));
			filterByIssueBean.setShipDateOffsetStr(null);
			filterByIssueBean.setCheckTotalCount(false);
			filterByIssueBean.setTotalCount(0);
		}
        log.info("ActionListener: menu item selected = " + selectedItem);
        
    }

}
