package com.fedex.rise.entity;

import java.time.Instant;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;


@Data
@Entity
@Table(name = "ISSUE")
public class IssueEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "TRKNG_ITEM_NBR")
	private Integer trkngItemNbr;
	
	@Column(name = "TRKNG_ITEM_UNIQ_NBR")
	private Integer trkngItemUniqNbr;
	
	@Column(name = "ISSUE_TYPE_CD")
	private int issueTypeCd;    // identifies the exception
	
	@Column(name = "TRACK_TYPE_CD")
	private String trackTypeCd; // Track type
	
	@Column(name = "TRACK_EXCP_CD")
	private String trackExcpCd; // Exception cd

	@Column(name = "RES_DT")
	private Instant resDt;
	
	@Column(name = "RES_DESC")
	private String resDesc; 
	
	@Column(name = "ISSUE_TMSTP")
	private Instant issueTmstp;
    
    @OneToOne(mappedBy = "issue", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = false)
    private  IssueDescEntity issueDesc; // Text description of issue
    
	
}
