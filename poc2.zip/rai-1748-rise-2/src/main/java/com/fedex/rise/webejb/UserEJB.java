package com.fedex.rise.webejb;

/**
 * 
 * @ejb:bean name="UserBean" display-name="UserEJB" jndi-name="UserEJB"
 *           local-jndi-name="LocalUserEJB" type="Stateless"
 *           view-type="both"
 * 
 * @ejb:home extends="javax.ejb.EJBHome"
 *           local-extends="javax.ejb.EJBLocalHome"
 * 
 * @ejb:interface extends="javax.ejb.EJBObject"
 *                local-extends="javax.ejb.EJBLocalObject"
 * 
 * @weblogic.enable-call-by-reference True
 * 
 * @weblogic.pool max-beans-in-free-pool="10" 
 * initial-beans-in-free-pool="3"
 * 
 * @ejb.transaction type="Supports"
 */
/**
* UserEJB
* This class implements the EJB which is accessible via the JSPs. It is a
* stateless SessionBean. This class implements the facade for the Business
* Objects and or Data Access Objects. All EJB/J2EE related things should be
* implemented here leaving the BO's with no knowledge of the EJB/J2EE
* environment.
*/
//@JndiName(remote="webejb/UserEJBRemote")
//@Session(ejbName = "UserEJB",
//        maxBeansInFreePool="3",
//        initialBeansInFreePool="1",
//        type = Session.SessionType.STATELESS,
//        defaultTransaction=Constants.TransactionAttribute.SUPPORTS,
//        transactionType=Session.SessionTransactionType.BEAN,
//        enableCallByReference=Constants.Bool.TRUE)
public class UserEJB {//implements SessionBean {
//
//    private static final long serialVersionUID = 1L;
//
//    /** Logger */
//    private static Logger logger = LogManager.getLogger(UserEJB.class);
//    
//    private SessionContext mySessionContext = null;
//
//    public SessionContext getSessionContext() {
//        return mySessionContext;
//    }
//
//    public void setSessionContext(SessionContext aSessionContext)
//            throws RemoteException {
//        mySessionContext = aSessionContext;
//    }
//
//    public void ejbActivate() {
//        System.out.println("Activate UserEJB");
//    }
//
//    public void ejbPassivate() {
//        System.out.println("Passivate UserEJB");
//    }
//
//    /**
//     * @ejb:create-method
//     */
//    public void ejbCreate() {
//        System.out.println("EJB Create UserEJB");
//    }
//
//    /**
//     * @ejb:remove-method
//     */
//    public void ejbRemove() { 
//        System.out.println("EJB Remove UserEJB");
//    }
//
//    /**
//     * Get monitored accounts via employee number
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     */
//    @RemoteMethod()
//    public List getMonitoredAccounts(String anEmplyNbr) throws SQLException {
//        UserBO userBO = new UserBO();
//        return userBO.getMonitoredAccounts(anEmplyNbr);        
//    }
//    
//    /**
//     * Get user
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public EmployeeVO getUser(String emplyNbr) throws SQLException, ServiceLocatorException {
//        UserBO userBO = new UserBO();
//        return userBO.getUser(emplyNbr);        
//    }
//    
//    /**
//     * Get users
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getUsers() throws SQLException, ServiceLocatorException {
//        UserBO userBO = new UserBO();
//        return userBO.getUsers();        
//    }
//    
//    /**
//     * Save a user
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public void saveUser(EmployeeVO anEmployeeVO) throws SQLException, ServiceLocatorException {
//        UserBO userBO = new UserBO();
//        userBO.saveUser(anEmployeeVO);
//    }
//    
//    /**
//     * Delete a user
//     * @ejb:interface-method view-type="remote"
//     * @throws SQLException 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public void deleteUser(String anEmployeeNbr) throws SQLException, ServiceLocatorException {
//        UserBO userBO = new UserBO();
//        userBO.deleteUser(anEmployeeNbr);
//    }
}
