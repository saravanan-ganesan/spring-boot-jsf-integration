package com.fedex.rise.bo;

public class SearchDelegate {
//    private static final Log log = LogFactory.getLog(SearchDelegate.class);
//
//    public SearchRemote getSearchBean() {
//        ServiceLocator sl = null;
//        SearchHome sh = null;
//        SearchRemote sb = null;
//
//        try {
//            sl = ServiceLocator.getInstance();
//            sh = (SearchHome)sl.getRemoteHome(ServiceLocatorConstants.SearchRemoteJNDIName, SearchHome.class);
//            sb = sh.create();  
//            
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        
//        return sb;
//    }
//
//// Search By Shipper Name or Account Number ------------------------------------    
//    
//    public List searchByShprNm(String aShprNm) {    	
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByShprNm(aShprNm);            
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }       
// 
//    public List searchByAcctNbr(String aAcctNbr) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByAcctNbr(aAcctNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }      
//    
//    public List searchByTrkngNbr(String aTrkngNbr) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByTrkngNbr(aTrkngNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }
//    
////Start WR#:179441 Changes    
//    public List searchByAll() {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByAll();
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    } 
//    
//    public List searchByGroupLaneNbr(int groupNbr,int laneNbr) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByGroupLaneNbr(groupNbr,laneNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    } 
////End WR#:179441 Changes    
//
//    
//    public List searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu, Date _limitOneWeekFromDate, Date _limitOneWeekToDate) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByReferenceNbr(aReferenceNbr, aReferenceNumberMenu, _limitOneWeekFromDate, _limitOneWeekToDate);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }     
//
//    public int getCRNShipmentsCountTrackingNumber(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountTrackingNumber(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }     
//    
//    public List searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByTrkngNbrMAWB(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber, sortColumn, isSortAscending, 
//            		startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }    
//          
//    
//    public int getCRNShipmentsCountShipperName(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountShipperName(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }       
//    
//    public List searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByAcctNmMAWB(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName, sortColumn, isSortAscending, 
//            		startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }     
//    
//    public List searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN, String aAcctNbrCRN, Date _toDate4, Date _fromDate4) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByIssueCodeCRN(aTrackingNbrCRN, aIssueCodeCRN, aAcctNbrCRN, _toDate4, _fromDate4);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }      
//  
//    public int getCRNShipmentsCountReturnTrackingNumber(String aReturnTrkngNbr) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountReturnTrackingNumber(aReturnTrkngNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }         
//    
//    public List searchByReturnTrkngNbr(String aReturnTrkngNbr, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByReturnTrkngNbr(aReturnTrkngNbr, sortColumn, isSortAscending, startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }     
//    
//    
//    
//    public int getCRNShipmentsCountRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, _limitOneWeekFromDateByCRNRecipientName);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }       
//    
//    public List searchByRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, 
//    		Date _limitOneWeekFromDateByCRNRecipientName, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, 
//            		_limitOneWeekFromDateByCRNRecipientName,	sortColumn, isSortAscending, startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    } 
//    
//    public List searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2, String aSelectedLane2) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByShipDate(_shipDate, aServiceCode2, aAcctNbrMAWB2, aSelectedLane2);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }     
//    
//    //WR#:179441 Changes
//   	public List searchByShipDateRange(Date _limitOneWeekToDate3,
//   			Date _limitOneWeekFromDate3, String aServiceCode,
//   			String aAcctNbrMAWB3, String aSelectedLane, String sortColumn,
//   			boolean ascending) {
//   		SearchRemote sb = getSearchBean();
//
//   		List results = null;
//   		try {
//   			results = sb.searchByShipDateRange(_limitOneWeekToDate3,
//   					_limitOneWeekFromDate3, aServiceCode, aAcctNbrMAWB3,
//   					aSelectedLane, sortColumn, ascending);
//
//   		} catch (RemoteException e) {
//   			// TODO Auto-generated catch block
//   			e.printStackTrace();
//   		} catch (SQLException e) {
//   			// TODO Auto-generated catch block
//   			e.printStackTrace();
//   		}
//   		return results;
//   	}     
//
//    public int getCRNShipmentsCountRecipientPostalCode(String aPostalCode, Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountRecipientPostalCode(aPostalCode, _limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }     
//    
//    public List searchByPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) { 	
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByPostalCode(_limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode, aPostalCode, sortColumn, isSortAscending, 
//            		startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }        
//    
//    public int getMAWBShipmentsCount(Date _shipDate, String _selectMenu, 
//    		String aClearancePoint) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getMAWBShipmentsCount(_shipDate, _selectMenu, aClearancePoint);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }       
//    
//    public List rampHubSearch(Date _shipDate, String _selectMenu, 
//    		String aClearancePoint, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) { 	
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.rampHubSearch(_shipDate, _selectMenu, aClearancePoint,
//            		sortColumn, isSortAscending, startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }       
//    
//    public List searchByFindMonitorAcctNbr(String aAcctNbr) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByFindMonitorAcctNbr(aAcctNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }     
//    
//    public List searchByFindMonitorTrkngNbr(String aTrackingNbr) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByFindMonitorTrkngNbr(aTrackingNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }    
//
//    public int getCRNShipmentsCountWithODA(String aPostalCode, Date _limitOneWeekToDateByCRNWithODA, Date _limitOneWeekFromDateByCRNWithODA) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountWithODA(aPostalCode, _limitOneWeekToDateByCRNWithODA, _limitOneWeekFromDateByCRNWithODA);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }    
//    
//    public List searchByWithODACRN(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA, Date _limitOneWeekToDateByCRNWithODA, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByWithODACRN(aAcctNbr, _limitOneWeekFromDateByCRNWithODA, _limitOneWeekToDateByCRNWithODA, sortColumn, isSortAscending, 
//            		startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }    
//    
//    public List searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByWithoutPODCRN(aAcctNbr2, aTrackingNbrMAWB2);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }      
//    
//    public List searchByFindMissingData(String aAcctNbr) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByFindMissingData(aAcctNbr);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }      
//
//    public int getCRNShipmentsCountRecipientAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress) { 	
//        SearchRemote sb = getSearchBean();
//
//        int size = 0;
//        try {
//            size = sb.getCRNShipmentsCountRecipientAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return size;
//    }    
//    
//    public List searchByAddressCRN(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress, String sortColumn, boolean isSortAscending, 
//    		int startIndex, int endIndex) {
//        SearchRemote sb = getSearchBean();
//
//        List results = null;
//        try {
//            results = sb.searchByAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress, sortColumn, isSortAscending, 
//            		startIndex, endIndex);
//            
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return results;
//    }       
//        
//   
//    
}
