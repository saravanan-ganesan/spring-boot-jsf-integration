package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * Event Value Object (or Transfer Object) used to encapsulate the event
 * data for transport.
 */
public class EventVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;
    private String _trkng_item_uniq_nbr;
    private String _track_type_cd;
    private Calendar _event_crtn_tmstp;
    private String _trkng_item_entry_type_cd;
    private char   _ecco_type_cd = ' ';
    private char   _ecco_comm_cd = ' ';
    private String _track_excp_cd;
    private String _track_loc_cd;
    private String _admin_loc_cd;
    private String _scan_emp_nbr;
    private String _track_src_cd;
    private String _event_sqnc_nbr;
    private Date   _input_tmstp;
    private Date   _last_updt_tmstp;
    private String _event_note_desc;
    
    /**
     * @return the _eventNoteDesc
     */
    public String get_event_note_desc() {
        return _event_note_desc;
    }

    /**
     * @param notes the _eventNotes to set
     */
    public void set_event_note_desc(String notes) {
        if (_event_note_desc == null) {
            _event_note_desc = notes;
        } else {
            _event_note_desc = _event_note_desc + "|" + notes;
        }
    }

    /**
     * Default Constructor
     */
    public EventVO() {
    }
    
    /**
     * Create an Event for a shipment 
     * @param _trkng_item_nbr
     * @param _trkng_item_uniq_nbr
     * @param _track_type_cd
     * @param _event_crtn_tmstp
     * @param _trkng_item_entry_type_cd
     * @param _ecco_type_cd
     * @param _ecco_comm_cd
     * @param _track_excp_cd
     * @param _track_loc_cd
     * @param _admin_loc_cd
     * @param _scan_emp_nbr
     * @param _track_src_cd
     * @param _event_sqnc_nbr
     * @param _eventNotes
     */
    public EventVO(String _trkng_item_nbr, String _trkng_item_uniq_nbr, String _track_type_cd, 
            Calendar _event_crtn_tmstp, String _trkng_item_entry_type_cd, 
            char _ecco_type_cd, char _ecco_comm_cd, String _track_excp_cd, 
            String _track_loc_cd, String _admin_loc_cd, 
            String _scan_emp_nbr, String _track_src_cd, String _event_sqnc_nbr,
            String _event_note_desc) {
        super();
        this._trkng_item_nbr = _trkng_item_nbr;
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
        this._track_type_cd = _track_type_cd;
        this._event_crtn_tmstp = _event_crtn_tmstp;
        this._trkng_item_entry_type_cd = _trkng_item_entry_type_cd;
        this._ecco_type_cd = _ecco_type_cd;
        this._ecco_comm_cd = _ecco_comm_cd;
        this._track_excp_cd = _track_excp_cd;
        this._track_loc_cd = _track_loc_cd;
        this._admin_loc_cd = _admin_loc_cd;
        this._scan_emp_nbr = _scan_emp_nbr;
        this._track_src_cd = _track_src_cd;
        this._event_sqnc_nbr = _event_sqnc_nbr;
        this._event_note_desc = _event_note_desc;
    }
    
    /**
     * @return the _admin_loc_cd
     */
    public String get_admin_loc_cd() {
        return _admin_loc_cd;
    }
    /**
     * @param _admin_loc_cd the _admin_loc_cd to set
     */
    public void set_admin_loc_cd(String _admin_loc_cd) {
        this._admin_loc_cd = _admin_loc_cd;
    }
    /**
     * @return the _ecco_comm_cd
     */
    public char get_ecco_comm_cd() {
        return _ecco_comm_cd;
    }
    /**
     * @param _ecco_comm_cd the _ecco_comm_cd to set
     */
    public void set_ecco_comm_cd(char _ecco_comm_cd) {
        this._ecco_comm_cd = _ecco_comm_cd;
    }
    /**
     * @return the _ecco_type_cd
     */
    public char get_ecco_type_cd() {
        return _ecco_type_cd;
    }
    /**
     * @param _ecco_type_cd the _ecco_type_cd to set
     */
    public void set_ecco_type_cd(char _ecco_type_cd) {
        this._ecco_type_cd = _ecco_type_cd;
    }
    /**
     * @return the _event_crtn_tmstp
     */
    public Calendar get_event_crtn_tmstp() {
        return _event_crtn_tmstp;
    }
    /**
     * @param _event_crtn_tmstp the _event_crtn_tmstp to set
     */
    public void set_event_crtn_tmstp(Calendar _event_crtn_tmstp) {
        this._event_crtn_tmstp = _event_crtn_tmstp;
    }
    /**
     * @return the _event_sqnc_nbr
     */
    public String get_event_sqnc_nbr() {
        return _event_sqnc_nbr;
    }
    /**
     * @param _event_sqnc_nbr the _event_sqnc_nbr to set
     */
    public void set_event_sqnc_nbr(String _event_sqnc_nbr) {
        this._event_sqnc_nbr = _event_sqnc_nbr;
    }
    /**
     * @return the _scan_emp_nbr
     */
    public String get_scan_emp_nbr() {
        return _scan_emp_nbr;
    }
    /**
     * @return the _scan_emp_nbr stripped of leading zeros
     */
    public String get_scan_emp_nbr_stripped() {
        // strip off leading zeros
        String temp = _scan_emp_nbr;
        while (temp != null && temp.length() > 0 && temp.charAt(0) == '0')
            temp = temp.substring(1);
        return temp;
    }

    /**
     * @param _scan_emp_nbr the _scan_emp_nbr to set
     */
    public void set_scan_emp_nbr(String _scan_emp_nbr) {
        this._scan_emp_nbr = _scan_emp_nbr;
    }
    /**
     * @return the _track_excp_cd
     */
    public String get_track_excp_cd() {
        return _track_excp_cd;
    }
    /**
     * @param _track_excp_cd the _track_excp_cd to set
     */
    public void set_track_excp_cd(String _track_excp_cd) {
        this._track_excp_cd = _track_excp_cd;
    }
    /**
     * @return the _track_loc_cd
     */
    public String get_track_loc_cd() {
        return _track_loc_cd;
    }
    /**
     * @param _track_loc_cd the _track_loc_cd to set
     */
    public void set_track_loc_cd(String _track_loc_cd) {
        this._track_loc_cd = _track_loc_cd;
    }
    /**
     * @return the _track_src_cd
     */
    public String get_track_src_cd() {
        return _track_src_cd;
    }
    /**
     * @param _track_src_cd the _track_src_cd to set
     */
    public void set_track_src_cd(String _track_src_cd) {
        this._track_src_cd = _track_src_cd;
    }
    /**
     * @return the _track_type_cd
     */
    public String get_track_type_cd() {
        return _track_type_cd;
    }
    /**
     * @param _track_type_cd the _track_type_cd to set
     */
    public void set_track_type_cd(String _track_type_cd) {
        this._track_type_cd = _track_type_cd;
    }
    /**
     * @return the _trkng_item_entry_type_cd
     */
    public String get_trkng_item_entry_type_cd() {
        return _trkng_item_entry_type_cd;
    }
    /**
     * @param _trkng_item_entry_type_cd the _trkng_item_entry_type_cd to set
     */
    public void set_trkng_item_entry_type_cd(String _trkng_item_entry_type_cd) {
        this._trkng_item_entry_type_cd = _trkng_item_entry_type_cd;
    }
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }
    
    public String toString() {
        return _trkng_item_nbr + ":" + _trkng_item_uniq_nbr + ":" + _track_type_cd;        
    }

    /**
     * @return the _input_tmstp
     */
    public Date get_input_tmstp() {
        return _input_tmstp;
    }

    /**
     * @param _input_tmstp the _input_tmstp to set
     */
    public void set_input_tmstp(Date _input_tmstp) {
        this._input_tmstp = _input_tmstp;
    }

    /**
     * @return the _last_updt_tmstp
     */
    public Date get_last_updt_tmstp() {
        return _last_updt_tmstp;
    }

    /**
     * @param _last_updt_tmstp the _last_updt_tmstp to set
     */
    public void set_last_updt_tmstp(Date _last_updt_tmstp) {
        this._last_updt_tmstp = _last_updt_tmstp;
    }
}
