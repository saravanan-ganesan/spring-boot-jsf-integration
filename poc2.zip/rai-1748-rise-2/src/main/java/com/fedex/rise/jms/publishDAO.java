package com.fedex.rise.jms;

import java.io.ByteArrayOutputStream;
import java.util.Hashtable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.BytesMessage;
import javax.jms.JMSException;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.jms.JMSPublishConfig;

/**
 * DAO to publish to the JMS queue.
 * 
 * @author be379961
 *
 */
public class publishDAO {
    private static Logger logger = LogManager.getLogger(publishDAO.class);
    
    private static long RECONNECTWAITMSEC = 10000;
    private static int  RECONNECTATTEMPTS = 3;
	private Hashtable _env = null;
	private ConnectionFactory _connFactory = null;
	private Connection _connection  = null;
	private Destination _destination = null;
	private Session _session = null;
	private MessageProducer _msgProducer = null;
	private JMSPublishConfig _JMSPublishConfig = null;
    
	/**
	 * Connect to the publish JMS queue.
	 * 
	 * @param anJMSPublishVO VO that has JMS queue connection parameters.
	 */
	protected boolean doConnectJMS(JMSPublishConfig anJMSPublishConfig){
        InitialContext jndiCtx = null;
        String jmsUsername = null;
        String jmsPassword = null;
        _JMSPublishConfig = anJMSPublishConfig;
        
        _env = new Hashtable();
    	_env.put(InitialContext.INITIAL_CONTEXT_FACTORY, 
    			anJMSPublishConfig.get_tibjmsInitalContextFactoryStr());
    	_env.put(InitialContext.PROVIDER_URL, 
    			anJMSPublishConfig.get_providerURLStr());
        
        try {
        	jndiCtx = new InitialContext(_env);
        	_connFactory = (ConnectionFactory)jndiCtx.lookup(
        			anJMSPublishConfig.get_connFactoryStr());
        	_connection = _connFactory.createConnection(jmsUsername, 
        			jmsPassword);
        	_session = _connection.createSession(true, 
        			Session.DUPS_OK_ACKNOWLEDGE);
        	_destination = (Destination)jndiCtx.lookup(
        			anJMSPublishConfig.get_queueStr());
        	_msgProducer = _session.createProducer(_destination);
        	_connection.start();
        	
        	if(jndiCtx !=  null)
            {
               jndiCtx.close();
            }
        	return true;
        }catch (JMSException jmse){
        	logger.error("JMS Exception", jmse);
        	this.close();
        	return false;
        }catch (NamingException jne){
        	logger.error("Naming Exception", jne);
            this.close();
        	return false;
        }  
	}
	
	/**
	 * Loop the number attempts requested
	 * 	If reconnect fails Then
	 * 		sleep requested wait time
	 * 	Endif
	 * Endloop
	 * @param anJMSPublishConfig
	 * @return
	 */
	protected boolean doReconnectJMS(JMSPublishConfig anJMSPublishConfig){
		int attempts = 0;
		while(attempts < RECONNECTATTEMPTS)
	    {
			attempts++;
	        close();
	         
	        if (doConnectJMS(anJMSPublishConfig)) {
	        	return true;
	        }else {
	        	logger.warn("Connection attempt " + attempts + 
	        		" failed (Will try again).");
	        	try
	   	        {
	        		Thread.sleep(RECONNECTWAITMSEC);
	   	        }
	   	        catch( InterruptedException sleepE ){
	   	         		logger.warn("Sleep failed, processing will continue.");
	   	        }
	        }
	    }
	    logger.error("Connection attempt " + attempts + " failed (Giving up).");
	    return false;
	}
	   
	/**
	 * Creates a BytesMessage, writes  byteArrayOutputStream to an array in the
	 * message.  Sets the properties of the NOI-Request message. Sends and
	 *  commits the message. 
	 * 
	 * @param byteArrayOutputStream XER encoded NOI message.
	 */
	protected boolean sendAndCommit(ByteArrayOutputStream byteArrayOutputStream,
			JMSPublishConfig anJMSPublishConfig){
		BytesMessage message;
		
		try {
			message = _session.createBytesMessage();
			message.writeBytes(byteArrayOutputStream.toByteArray());
		
			message.setStringProperty("NOISystem", 
					anJMSPublishConfig.get_noiSystem());
			message.setStringProperty("NOIUser", 
					anJMSPublishConfig.get_noiUser());
			message.setStringProperty("MessageType", "NR");
			message.setStringProperty("SourceType", "RISE");
			
			/**
			 * Send and commit the message.
			 */
			_msgProducer.send(message);
			_session.commit();
			
			if (logger.isDebugEnabled()) {
                logger.debug("Publishing NOI message. " + message.toString());
            }
			return true;
		}catch (JMSException jmse){
			logger.error("JMS Exception", jmse);
			return doReconnectJMS(_JMSPublishConfig);
        }		
	}
	/**
	 * Closes and nulls out the MessageProducer, Session, Connection, and 
	 * Destination instances.
	 */
	public void close() 
	{
		logger.debug("Closing publishDAO");
	      try
	      {
	         if(null != _msgProducer)
	        	 _msgProducer.close();
	      }
	      catch(Exception e)
	      {
	         logger.error("Caught exception during _msgProducer.close()", e);
	      }

	      try
	      {
	         if(null!=_session)
	        	 _session.close();
	      }
	      catch(Exception e)
	      {
	         logger.error("Caught exception during session.close()", e);
	      }

	      try
	      {
	         if(null!=_connection)
	        	 _connection.close();
	      }
	      catch(Exception e)
	      {
	         logger.error("Caught exception during connection.stop()", e);
	      }

	      _msgProducer = null;
	      _destination = null;
	      _session     = null;
	      _connection  = null;
	   }
}
