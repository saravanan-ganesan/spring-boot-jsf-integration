package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

public class SystemMessageVO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    int _msgNbr;
    Date _startDt;
    Date _endDt;
    String _empRoleCd;
    String _empNbr;
    String _msgDesc;
    
    /**
     * @return the _empNbr
     */
    public String get_empNbr() {
        return _empNbr;
    }
    /**
     * @param nbr the _empNbr to set
     */
    public void set_empNbr(String nbr) {
        _empNbr = nbr;
    }
    /**
     * @return the _empRoleCd
     */
    public String get_empRoleCd() {
        return _empRoleCd;
    }
    /**
     * @param roleCd the _empRoleCd to set
     */
    public void set_empRoleCd(String roleCd) {
        _empRoleCd = roleCd;
    }
    /**
     * @return the _endDt
     */
    public Date get_endDt() {
        return _endDt;
    }
    /**
     * @param dt the _endDt to set
     */
    public void set_endDt(Date dt) {
        _endDt = dt;
    }
    /**
     * @return the _msgDesc
     */
    public String get_msgDesc() {
        return _msgDesc;
    }
    /**
     * @param desc the _msgDesc to set
     */
    public void set_msgDesc(String desc) {
        _msgDesc = desc;
    }
    /**
     * @return the _startDt
     */
    public Date get_startDt() {
        return _startDt;
    }
    /**
     * @param dt the _startDt to set
     */
    public void set_startDt(Date dt) {
        _startDt = dt;
    }
    /**
     * @return the _msgNbr
     */
    public int get_msgNbr() {
        return _msgNbr;
    }
    /**
     * @param nbr the _msgNbr to set
     */
    public void set_msgNbr(int nbr) {
        _msgNbr = nbr;
    }
    
    
}
