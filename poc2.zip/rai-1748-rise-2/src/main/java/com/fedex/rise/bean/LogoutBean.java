package com.fedex.rise.bean;

import java.io.IOException;

import com.fedex.rise.annotation.JsfController;

@JsfController(path = "/logout", page = "/logout.jsp", value = "logoutBean")
public class LogoutBean extends BaseBean {

	public void logoutAction() throws IOException {

		redirect("logout");
		
	}

}
