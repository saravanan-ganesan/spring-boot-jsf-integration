$(function() {

	$("#performancefromdate, #performancetodate").datepicker({
		showOn: "button",
		buttonImage: "images/calendar.gif",
		buttonImageOnly: true,
		buttonText: "Select date",
		dateFormat: "mm/dd/yy",
		changeMonth: true,
		changeYear: true,
		showWeek: true,
		firstDay: 0,
		dayNamesMin: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
		monthNamesShort: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", 													"November", "December"],
	    showButtonPanel: true,
	    currentText: "Today is : " +  $.datepicker.formatDate('mm/dd/yy', new Date()) 
	});


});