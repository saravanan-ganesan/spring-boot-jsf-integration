package com.jsf.samples.bootfaces.controller;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.stereotype.Component;

@Component(value = "homeController")
@ELBeanName(value = "homeController")
@Join(path = "/", to = "/WEB-INF/pages/home/home.jsf")
public class HomeController {


}
