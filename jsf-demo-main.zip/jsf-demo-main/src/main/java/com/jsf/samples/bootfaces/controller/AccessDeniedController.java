package com.jsf.samples.bootfaces.controller;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.stereotype.Component;

@Component(value = "accessDeniedController")
@ELBeanName(value = "accessDeniedController")
@Join(path = "/accessDenied", to = "/accessDenied.html")
public class AccessDeniedController {


}
