//package com.jsf.samples.bootfaces.config;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class ViewRegistryConfig implements WebMvcConfigurer {
//
//	@Override
//	public void addViewControllers(ViewControllerRegistry registry) {
//		registry.addViewController("/403");
//	}
//
////	@Override
////	public void addCorsMappings(CorsRegistry registry) {
////
////		registry.addMapping("/**").allowedOriginPatterns("*").allowedMethods("*").allowCredentials(true);
////	}
////
////	@Bean
////	public CorsWebFilter corsWebFilter() {
////
////		CorsConfiguration corsConfiguration = new CorsConfiguration();
////		corsConfiguration.addAllowedOriginPattern("*");
////		corsConfiguration.addAllowedHeader("*");
////		corsConfiguration.addAllowedMethod("*");
////		corsConfiguration.setAllowCredentials(true);
////
////		UrlBasedCorsConfigurationSource corsConfigurationSource = new UrlBasedCorsConfigurationSource();
////		corsConfigurationSource.registerCorsConfiguration("/**", corsConfiguration);
////		return new CorsWebFilter(corsConfigurationSource);
////
////	}
//}