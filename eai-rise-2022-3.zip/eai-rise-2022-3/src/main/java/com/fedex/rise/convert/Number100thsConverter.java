package com.fedex.rise.convert;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class is used to convert the numeric values in the database which
 * are stored in 100th's without the decimal to be displayed with the decimal
 * in the correct position.
 *
 */
public class Number100thsConverter implements Converter {
    /** logger */
    private static final Log log = LogFactory.getLog(Number100thsConverter.class);
    
    /**
     * Default constructor
     */
    public Number100thsConverter() {
        super();
        //if (log.isDebugEnabled()) log.debug("Constructed");
    }

    public Object getAsObject(FacesContext context, UIComponent component, String aNumber)
            throws ConverterException {
        //if (log.isDebugEnabled()) log.debug("GetAsObject(): " + aNumber);
        StringBuffer sb = new StringBuffer(aNumber);
        int decimalPos = sb.indexOf(".");
        if (decimalPos != -1) {
            sb.append("00");
        } else {
            sb.append(".00");
            decimalPos = sb.indexOf(".");
        }
        sb.deleteCharAt(decimalPos);
        String newStr =  sb.substring(0, decimalPos + 2);
        try {
            Integer converted = new Integer(newStr);
            return converted;
        } catch (NumberFormatException nfe) {
            FacesMessage message = new FacesMessage("Errors encountered", "Invalid number");
            message.setSeverity(FacesMessage.SEVERITY_ERROR);
            throw new ConverterException(message);
        }
    }

    public String getAsString(FacesContext context,  UIComponent component, Object aNumber)
            throws ConverterException {
        String numStr = ((Integer)aNumber).toString();
        StringBuffer sb = new StringBuffer(numStr);
        while (sb.length() < 2) { sb.append('0'); }
        sb.insert(sb.length() - 2, '.');
        return sb.toString();
    }

}
