package com.fedex.rise.bo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fedex.rise.vo.AssociatedShipmentVO;

public class MergeAssociatedShipments {
    /**
     * Merging for the associated shipments is a little different.  In the database we have
     * records made up of trkng_nbr_item, trkng_item_uniq_nbr, assoc_trkng_nbr_item and
     * assoc trkng_item_uniq_nbr.  The last field is not part of the key and can be null.
     * Should the assoc_trkng_item_uniq_nbr field arrive in an event and be null in the
     * database, we want to update it.  The list returned from this method will be updated 
     * in the database.
     * 
     * @param aSource associated shipments present in event
     * @param aTarget associated shipments in database
     * @return only the new, not in database notes
     */
    public List merge(List aSource, List aTarget) {
        ArrayList hs = new ArrayList();
        Iterator iter = aSource.iterator();
        while (iter.hasNext()) {
            AssociatedShipmentVO associatedShipmentVO = (AssociatedShipmentVO)iter.next();
            // The contains method is a match on trkng_nbr_item, trkng_item_uniq_nbr and
            //  assoc_trkng_nbr_item, does not consider assoc_trkng_item_uniq_nbr
            if (aTarget.contains(associatedShipmentVO)) {
                // If the new event, has the assoc_trkng_item_uniq_nbr and the record
                // in the database is null, we want to update it.
                if (associatedShipmentVO.get_assoc_trkng_item_uniq_nbr() != null) {
                    int index = aTarget.indexOf(associatedShipmentVO);
                    AssociatedShipmentVO dbMatch = (AssociatedShipmentVO)aTarget.get(index);
                    if (dbMatch.get_assoc_trkng_item_uniq_nbr() == null) {
                        hs.add(associatedShipmentVO);
                    }
                }
            }
        }
        return hs;
    }
    
    public List findNewAssociations(List aSource, List aTarget) {
        ArrayList hs = new ArrayList();
        Iterator iter = aSource.iterator();
        while (iter.hasNext()) {
            AssociatedShipmentVO associatedShipmentVO = (AssociatedShipmentVO)iter.next();
            if (!aTarget.contains(associatedShipmentVO)) {
                hs.add(associatedShipmentVO);    
            }
        }
        return hs;
    }
}
