package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AcctLaneServiceMonitoringVO;

public class AcctLaneServiceMonitoringDeleter extends OracleBase {


    private static Logger logger = LogManager.getLogger(AcctLaneServiceMonitoringDeleter.class);

    public AcctLaneServiceMonitoringDeleter(Connection con) {
        super(con);
    }

    private static final String deleteAccountLaneServiceMonitoringSQL = "Delete from Acct_Lane_Service_Monitoring where " +
                "EMP_NBR = ? and GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ? and SVC_TYPE_CD = ?";
    private static final String deleteAccountLaneServiceMonitoringSQL2 = "Delete from Acct_Lane_Service_Monitoring where " +
                "GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ? and SVC_TYPE_CD = ?";
    private static final String deleteAccountLaneServiceMonitoringSQL3 = "Delete from Acct_Lane_Service_Monitoring where " +
                "GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ?";
    private static final String deleteAccountLaneServiceMonitoringSQL4 = "Delete from Acct_Lane_Service_Monitoring where " +
                "GROUP_NBR = ? and ACCT_NBR = ?";
        /**
     * Delete specified monitor from the service
     * @param anAccountLaneServiceMonitoringVO
     * @throws SQLException
     */
    public void deleteAcctLaneServiceMonitoring(AcctLaneServiceMonitoringVO anAccountLaneServiceMonitoringVO) throws SQLException {

        try {
            setSqlSignature(deleteAccountLaneServiceMonitoringSQL, false, logger.isDebugEnabled());

            pstmt.setString(1, anAccountLaneServiceMonitoringVO.get_emp_nbr());
            pstmt.setInt(2, anAccountLaneServiceMonitoringVO.get_group_nbr());
            pstmt.setString(3, anAccountLaneServiceMonitoringVO.get_acct_nbr());
            pstmt.setInt(   4, anAccountLaneServiceMonitoringVO.get_lane_nbr());
            pstmt.setString(5, anAccountLaneServiceMonitoringVO.get_svc_type_cd());
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
        
    
    /**
     * Delete all monitor from the specified group, account, lane, service
     * @throws SQLException
     */
    public void deleteAcctLaneServiceMonitoring(int groupNbr, String accountNbr,
            int laneNbr, String serviceTypeCd) throws SQLException {

        try {
            setSqlSignature(deleteAccountLaneServiceMonitoringSQL2, false, logger.isDebugEnabled());

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);
            pstmt.setInt(3, laneNbr);
            pstmt.setString(4, serviceTypeCd);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
    
    /**
     * Delete all monitor from the specified group, account, lane
     * @throws SQLException
     */
    public void deleteAcctLaneServiceMonitoring(int groupNbr, String accountNbr,
            int laneNbr) throws SQLException {

        try {
            setSqlSignature(deleteAccountLaneServiceMonitoringSQL3, false, logger.isDebugEnabled());

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);
            pstmt.setInt(3, laneNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException e) {
           logger.error(e);
           throw e;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
    
    /**
     * Delete all monitor from the specified group, account
     * @throws SQLException
     */
    public void deleteAcctLaneServiceMonitoring(int groupNbr, String accountNbr)
            throws SQLException {

        try {
            setSqlSignature(deleteAccountLaneServiceMonitoringSQL4, false, logger.isDebugEnabled());

            pstmt.setInt(1, groupNbr);
            pstmt.setString(2, accountNbr);
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException e) {
           logger.error(e);
           throw e;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
