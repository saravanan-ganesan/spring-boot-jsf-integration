package com.fedex.rise.ese;

import java.io.ByteArrayInputStream;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.ThreadContext;

import com.fedex.asn.UTF8String.enhancedevent_.EnhancedEvent;
import com.fedex.rise.bo.EnhancedEventBO;
import com.fedex.rise.bo.issue.TransactionException;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IPDShipmentVO;
import com.fedex.rise.vo.ShipmentVO;
import com.oss.asn1.DecodeFailedException;
import com.oss.asn1.DecodeNotSupportedException;

/**
 * This class is used to deserialize the ESE event and extract the 
 * relevant data.  This is the only place that we should deal with
 * the native event structure.
 */

public class EnhancedEventMessageHandler {
    /** Logger */
    private static Logger logger = LogManager.getLogger(EnhancedEventMessageHandler.class);

    /**
     * This method will deserialize the ESE event, extract the necessary data, and then
     * call the method to apply the business logic and persist/update the database.
     * All exception handling is taken care of in this method.  If an exception occurs
     * and it seems reasonable to re-attempt, throw the exception.  Otherwise, catch
     * and log the exception.
     *  
     * @param aByteMessage
     * @throws SQLException
     * @throws ServiceLocatorException
     * @throws TransactionException
     */
    public void processMessage(byte [] aByteMessage) 
        throws SQLException, ServiceLocatorException, TransactionException {
        
        EnhancedEventXMLDeserializer eexd = new EnhancedEventXMLDeserializer();
        ByteArrayInputStream input = new ByteArrayInputStream(aByteMessage);
        EnhancedEventBO enhancedEventBO = new EnhancedEventBO();
        
        if (logger.isDebugEnabled()) {
            String s = new String(aByteMessage);
            logger.debug(s);
        }    
        
        EnhancedEvent ee = null;
        try {
            ee = eexd.deserialize(input);
        
            logger.debug("Message decoded successfully.");

            // Drop message, it is from the reject SEP queue.
            if (!rejectMessage(ee)){
            	// Extract the data from the event
            	IPDShipmentVO ipdShipmentVO = extractEventData(ee);
            
            	// Apply the Business Logic
            	ThreadContext.push(ipdShipmentVO.get_shipment().get_shpmt_type_cd());
            	enhancedEventBO.processEvent(ipdShipmentVO);
            }
            
        // Catch an exception here if you don't want to have it
        // redelivered, throw the exception if you want it
        // redelivered
        } catch (DecodeFailedException dfe) {
            // This will just drop it and log it
           logger.error("Failure to decode ESE event:", dfe);
           logger.error(new String(aByteMessage));
        } catch (DecodeNotSupportedException dnse) {
            // This will just drop it and log it
           logger.error("Failure to decode ESE event:", dnse); 
           logger.error(new String(aByteMessage));
        } catch (ESEParseException pe) {
            // Parts of the ESE event that we need are not
            // present, no need to try again, log it and move on
            logger.error("Failure to parse ESE Event:", pe);
            logger.error(new String(aByteMessage));
        } catch (TransactionException te) {
            logger.error("Transaction Error:", te);
            logger.error(new String(aByteMessage));
            throw te;
        } catch (SQLException sqle) {
            logger.error("SQL Exception", sqle);
            throw sqle;
        } catch (Exception e) {
            logger.error("Unexpected Exception:", e);
            logger.error(new String(aByteMessage));
        } finally {
        	ThreadContext.pop();
        }       
    }
    
    /**
     * Extracts all the data in the Event into VO's.  The BaseEventExtractor
     * encapsulates the enhanced event and the logic to parse base data
     * that will be used multiple times.  It also validates that key portions
     * of the event is present.  Each specific Extractor represents the business
     * logic to extract the data fields need for each db table.  So far we have
     * an Event, Associated Shipments, Shipment and Reference Note table.
     * 
     * @param anEe the enhance event to extract data from
     * @return a VO representing all of the Event's data of interest
     * @throws ESEParseException when event is not useable
     */
    private IPDShipmentVO extractEventData(EnhancedEvent anEe) throws ESEParseException {
        // Extract Event table data, from the message
        EventExtractor eventExtractor = new EventExtractor(anEe);
        EventVO eventVO = eventExtractor.extract();
        
        // Extract associated airbills, returns, paperwork, parents
        AssociatedShipmentExtractor associatedShipmentExtractor = 
            new AssociatedShipmentExtractor(eventExtractor.getBaseEventExtractor());
        List associatedShipmentVOs = associatedShipmentExtractor.extract();
        
        AssociatedShipmentsHelper assocShipHelper = 
            new AssociatedShipmentsHelper(associatedShipmentVOs);
        assocShipHelper.log();
        
        // Extract Shipment table data from the message, use the BaseEventExtractor from a
        // previous extractor to avoid parsing the same base fields again
        ShipmentExtractor shipmentExtractor = new ShipmentExtractor(eventExtractor.getBaseEventExtractor());
        ShipmentVO shipmentVO = shipmentExtractor.extract(assocShipHelper);
        
        // Extract Reference Notes table data from the message, use the BaseEventExtractor from
        // a previous extractor to avoid parsing the same base fields again
        ReferenceNotesExtractor referenceNotesExtractor = new ReferenceNotesExtractor(eventExtractor.getBaseEventExtractor());
        List referenceNotes = referenceNotesExtractor.extract();
        
        // Combine the data into a single aggregating VO
        IPDShipmentVO ipdShipmentVO = new IPDShipmentVO();
        ipdShipmentVO.set_event(eventVO);
        ipdShipmentVO.set_shipment(shipmentVO);
        ipdShipmentVO.set_associatedShipments(associatedShipmentVOs);
        ipdShipmentVO.set_referenceNotes(referenceNotes);
        
        // This object represents all the data we extracted from the event
        return ipdShipmentVO;        
    }
    
    /**
     * Determine if this is a rejected scan.  The reject-queue-error-reason 
     * is not null, or the reject-queue-error-code-md  is not null.
     * @param anEe the enhance event to extract data from
     * @return false message is ok, true it comes from the reject queue.
     */
    private boolean rejectMessage(EnhancedEvent anEe){
    	
    	if (anEe.getMaster_list() != null){
    		if ((anEe.getMaster_list().getReject_queue_error_reason() != null ||
    			anEe.getMaster_list().getReject_queue_error_code_md() != null)  
    			&& !anEe.getMaster_list().getTrack_source_cd().equals("9")){
    			logger.debug("Drop message, it is from the reject SEP queue.");
    			return true;
    		}
    	}
        
    	return false;
    }
    
}