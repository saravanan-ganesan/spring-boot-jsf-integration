package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * Shipment Comment Value Object (or Transfer Object) used to encapsulate 
 * comment data for transport.
 */
public class ShipmentCommentVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;
    private String _trkng_item_uniq_nbr;
    private Date   _com_tmstp;
    private String _emp_nbr;
    private String _com_desc;
    
    /**
     * Default Constructor
     */
    public ShipmentCommentVO() {
    }
    
    /**
     * Construct a Shipment Comment
     * @param _trkng_item_nbr
     * @param _trkng_item_uniq_nbr
     * @param _com_tmstp
     * @param _emp_nbr
     * @param _com_desc
     */
    public ShipmentCommentVO(String _trkng_item_nbr, String _trkng_item_uniq_nbr, 
            Date _com_tmstp, String _emp_nbr, String _com_desc) {
        super();
        this._trkng_item_nbr = _trkng_item_nbr;
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
        this._com_tmstp = _com_tmstp;
        this._emp_nbr = _emp_nbr;
        this._com_desc = _com_desc;
    }
    
    /**
     * @return the _com_desc
     */
    public String get_com_desc() {
        return _com_desc;
    }
    /**
     * @param _com_desc the _com_desc to set
     */
    public void set_com_desc(String _com_desc) {
        this._com_desc = _com_desc;
    }
    /**
     * @return the _com_tmstp
     */
    public Date get_com_tmstp() {
        return _com_tmstp;
    }
    /**
     * @param _com_tmstp the _com_tmstp to set
     */
    public void set_com_tmstp(Date _com_tmstp) {
        this._com_tmstp = _com_tmstp;
    }
    /**
     * @return the _emp_nbr
     */
    public String get_emp_nbr() {
        return _emp_nbr;
    }
    /**
     * @param _emp_nbr the _emp_nbr to set
     */
    public void set_emp_nbr(String _emp_nbr) {
        this._emp_nbr = _emp_nbr;
    }
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }
    
}
