package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.AccountGroupVO;
import com.fedex.rise.vo.AccountVO;


public class AccountDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AccountDAO.class);
    
    public void addAccount(AccountVO anAccountVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountPersister persister = new AccountPersister(connection);
            persister.addAccount(anAccountVO);
        } finally {
            closeConnection(connection);
        }
    }

    public void updateAccount(AccountVO anAccountVO) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountUpdater updater = new AccountUpdater(connection);
            updater.updateAccount(anAccountVO);
        } finally {
            closeConnection(connection);
        }
    }    
    
    
    public void deleteAccount(int aGroupNbr, String anAccountNbr) 
    	throws SQLException, ServiceLocatorException {
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            AccountDeleter deleter = new AccountDeleter(connection);
            deleter.deleteAccount(aGroupNbr, anAccountNbr);
        } finally {
            closeConnection(connection);
        }
    }
    
    public List getAccounts(int aGroupNbr) 
		throws SQLException, ServiceLocatorException {
        
    	Connection connection = null;
    	List list = null;

    	try {
    		connection = initializeConnection();
    		AccountAccessor acctAccessor 
        	= new AccountAccessor(connection);
    		AccountVO anAccountVO = new AccountVO();
    		anAccountVO.set_group_nbr(aGroupNbr);
    		list = acctAccessor.getAccounts(anAccountVO);
    	} finally {
    		closeConnection(connection);
    	}
    	return list;
    }
    
    public List getAccountTable() throws SQLException, ServiceLocatorException {
    	ArrayList al = new ArrayList();
    	AccountGroupDAO agdao = new AccountGroupDAO();
    	List acctGrouplist = agdao.getAccountGroupTable();
    	Iterator acctGroupIterator = acctGrouplist.iterator();
    	
        while (acctGroupIterator.hasNext()) {
            AccountGroupVO accountGroupVO = 
            		(AccountGroupVO)acctGroupIterator.next();
            List acctList = getAccounts(accountGroupVO.get_group_nbr());
            Iterator acctIterator = acctList.iterator();
            
            while (acctIterator.hasNext()){
            	AccountVO accountVO = 
            		(AccountVO)acctIterator.next();
            	al.add(accountVO);
            } 
        }
    	return al;
    }
    
    public AccountVO getAccount(int aGroupNbr, String accountNbr) 
		throws SQLException, ServiceLocatorException {
        
 		AccountVO accountVO =  null;
    	Connection connection = null;

    	try {
    		connection = initializeConnection();
    		AccountAccessor acctAccessor  = new AccountAccessor(connection);
    		accountVO =  acctAccessor.getAccount(aGroupNbr, accountNbr);
    	} finally {
    		closeConnection(connection);
    	}
    	return accountVO;
    }
}
