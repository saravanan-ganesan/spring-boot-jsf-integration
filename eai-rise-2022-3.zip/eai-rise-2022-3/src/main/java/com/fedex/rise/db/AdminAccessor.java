package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.MonitoredAccountsVO;

public class AdminAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(AdminAccessor.class);
    
    public AdminAccessor(Connection con) {
        super(con);
    }    
    
    private static final String getShippersSQL =
        "select ACCOUNT_GROUP.GROUP_NBR, ACCOUNT_GROUP.GROUP_NM, ACCOUNT_GROUP.GROUP_DESC, " +
        " ACCOUNT.ACCT_NBR, ACCOUNT.ACCT_NM, " +
        " LANE.LANE_NBR, LANE.ORIG_CNTRY_CD, LANE.DEST_CNTRY_CD, " +
        " LANE_SERVICE.SVC_TYPE_CD, " +
        " ACCT_LANE_SERVICE_MONITORING.EMP_NBR, " +
        " EMPLOYEE.EMP_FIRST_NM, EMPLOYEE.EMP_LAST_NM " +
        "from ACCOUNT_GROUP, ACCOUNT, ACCOUNT_LANE, LANE, LANE_SERVICE, " +
        " ACCT_LANE_SERVICE_MONITORING, EMPLOYEE " +
        "where ACCOUNT_GROUP.GROUP_NBR = ACCOUNT.GROUP_NBR (+) " +
        "and ACCOUNT.GROUP_NBR = ACCOUNT_LANE.GROUP_NBR (+) " +
        "and ACCOUNT.ACCT_NBR = ACCOUNT_LANE.ACCT_NBR (+) " +
        "and ACCOUNT_LANE.GROUP_NBR = LANE_SERVICE.GROUP_NBR (+) " +
        "and ACCOUNT_LANE.ACCT_NBR = LANE_SERVICE.ACCT_NBR (+) " +
        "and ACCOUNT_LANE.LANE_NBR = LANE_SERVICE.LANE_NBR (+) " +
        "and ACCOUNT_LANE.LANE_NBR = LANE.LANE_NBR (+) " +
        "and LANE_SERVICE.GROUP_NBR = ACCT_LANE_SERVICE_MONITORING.GROUP_NBR (+) " +
        "and LANE_SERVICE.ACCT_NBR = ACCT_LANE_SERVICE_MONITORING.ACCT_NBR (+) " +
        "and LANE_SERVICE.LANE_NBR = ACCT_LANE_SERVICE_MONITORING.LANE_NBR (+) " +
        "and LANE_SERVICE.SVC_TYPE_CD = ACCT_LANE_SERVICE_MONITORING.SVC_TYPE_CD (+) " +
        "and ACCT_LANE_SERVICE_MONITORING.EMP_NBR = EMPLOYEE.EMP_NBR (+) " +
        "order by ACCOUNT_GROUP.GROUP_NM, ACCOUNT.ACCT_NBR, ACCOUNT.ACCT_NM, " +
        " LANE.ORIG_CNTRY_CD, LANE.DEST_CNTRY_CD, LANE_SERVICE.SVC_TYPE_CD";

    public List getAllShippers() throws SQLException {
        ArrayList al = new ArrayList();
        
        try {
            setSqlSignature( getShippersSQL, false, logger.isDebugEnabled() );

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    // rows found
                    MonitoredAccountsVO monitoredAccountsVO = new MonitoredAccountsVO();
                    monitoredAccountsVO.set_groupNbr(rs.getInt("GROUP_NBR"));
                    monitoredAccountsVO.set_groupNm(rs.getString("GROUP_NM"));
                    monitoredAccountsVO.set_acctNbr(rs.getString("ACCT_NBR"));
                    monitoredAccountsVO.set_acctName(rs.getString("ACCT_NM"));
                    monitoredAccountsVO.set_laneNbr(rs.getInt("LANE_NBR"));
                    monitoredAccountsVO.set_origCntryCd(rs.getString("ORIG_CNTRY_CD"));
                    monitoredAccountsVO.set_destCntryCd(rs.getString("DEST_CNTRY_CD"));
                    monitoredAccountsVO.set_svcTypeCd(rs.getString("SVC_TYPE_CD")); 
                    monitoredAccountsVO.set_monitorEmpNbr(rs.getString("EMP_NBR"));
                    monitoredAccountsVO.set_monitorFirstName(rs.getString("EMP_FIRST_NM"));
                    monitoredAccountsVO.set_monitorLastName(rs.getString("EMP_LAST_NM"));
                    
                    al.add(monitoredAccountsVO);
                }
            } else {
                return null;
            }            

        } catch ( SQLException e ) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return al;
    } 
}
