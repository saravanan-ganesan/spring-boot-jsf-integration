package com.fedex.rise.bo;

/**
 * Shipper Business Delegate which is resposible for getting data from or 
 * setting data in the persistent storage, e.g. the backend database. 
 * 
 */
public class ShipperDelegate {
//    private static final Log log = LogFactory.getLog(UserDelegate.class);
//   
//    /**
//     * Get the Shipper EBJ
//     * @return ShipperRemote 
//     */
//    public ShipperRemote getShipperBean() {
//        ServiceLocator sl = null;
//        ShipperHome shipperHome = null;
//        ShipperRemote shipperBean = null;
//
//        try {
//            sl = ServiceLocator.getInstance();
//            shipperHome = (ShipperHome)sl.getRemoteHome(ServiceLocatorConstants.ShipperRemoteJNDIName, ShipperHome.class);
//            shipperBean = shipperHome.create();
//        } catch (ServiceLocatorException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (CreateException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        
//        return shipperBean;
//    }
//    
//    /**
//     * Get the shippers, accounts, lanes, services 
//     * @return List containing shippers, accounts, lanes, services
//     */
//    public List getAllShippers() {
//        // retrieve shippers, accounts, lanes, services from DB via EJB
//        List shippers = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shippers = shipperBean.getAllShippers();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return shippers;
//        
//        // TODO: need a flag on if it shipper, account, lane is assigned to a user to monitor
//    }
// 
//    /**
//     * Get the shipper (a.k.a AccountGroup or Group)
//     * @return AccountGroupVO 
//     */
//    public AccountGroupVO getShipperFromName(String shipperName) {
//        AccountGroupVO accountGroupVO = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            accountGroupVO = shipperBean.getShipper(shipperName);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();            
//        }      
//        return accountGroupVO;
//    }
//    
//    /**
//     * Get the shipper (a.k.a AccountGroup or Group)
//     * @return AccountGroupVO 
//     */
//    public AccountGroupVO getShipper(String shipperNbr) {
//        AccountGroupVO accountGroupVO = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            accountGroupVO = shipperBean.getShipper(Integer.parseInt(shipperNbr));
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();            
//        }      
//        return accountGroupVO;
//    }
//    
//    /**
//     * Get the AccountGroup table
//     * @return List of AccountGroupVO 
//     */
//    public List getAccountGroupTable() {
//        List accountGroupTable = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//        	accountGroupTable = shipperBean.getAccountGroupTable();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();            
//        }      
//        return accountGroupTable;
//    }
//    
//    /**
//     * Get a List of LaneVOs for a groupNbr.
//     * @param groupNbr of interest
//     * @return List of LaneVOs 
//     */
//    public List getAllLanes(int groupNbr) {
//        List alllanes = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//        	alllanes = shipperBean.getAllLanes(groupNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();            
//        }      
//        return alllanes;
//    }
//    
//    /** create a new shipper */
//    public void addShipper(String shipperName) {
//        log.debug("create new shipper: " + shipperName);
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.addShipper(shipperName);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** update a shipper */
//    public void updateShipper(String shipperNbr, String shipperName) {
//        log.debug("update shipper: " + shipperName);
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            AccountGroupVO shipperVO = new AccountGroupVO(Integer.parseInt(shipperNbr), shipperName, "");
//            shipperBean.updateShipper(shipperVO);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** 
//     * delete a shipper 
//     * will fail if the accounts haven't been delete first
//     * @return 0 for failure or 1 for success
//     */
//    public int deleteShipper(String shipperNbr) {
//        log.debug("delete shipper: " + shipperNbr);
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.deleteShipper(shipperNbr);
//        } catch (RemoteException e) {
//            log.error("Error deleting shipper: " + shipperNbr, e);
//            return 0;
//        } catch (SQLException e) {
//            log.error("Error deleting shipper:" + shipperNbr, e);
//            return 0;
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//            return 0;
//        }      
//        
//        return 1;
//    }
//
//    /**
//     * Get the account
//     * @return AccountVO
//     */
//    public AccountVO getAccount(String shipperNbr, String accountNbr) {
//        AccountVO accountVO = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            accountVO = shipperBean.getAccount(shipperNbr, accountNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();      
//        } catch (ServiceLocatorException sle) {
//           // TODO Auto-generated catch block
//            sle.printStackTrace();
//        }
//        return accountVO;
//        
//        // TODO: need a flag on if it shipper, account, lane is assigned to a user to monitor
//    }
//    
//    /** add an account to a shipper */
//    public void addAccountToShipper(String shipperNbr, String accountNbr, String accountName) {
//        if (log.isDebugEnabled()) {
//            log.debug("add account '" + accountName + "' to shipper '" + shipperNbr + "'");
//        }
//        
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            // TODO: populate account attrs
//            String _company_nm = null;
//            String _dtytax_acct_nbr = null;
//            String _cmdty_desc = null;
//            String _spcl_instr_desc = null;
//            String _comment_desc = null;
//            char _rerte_flg = ' ';
//            char _hold_at_loc_flg = ' ';
//            AccountVO accountVO = new AccountVO(Integer.parseInt(shipperNbr), accountNbr, accountName, 
//                    _company_nm, _dtytax_acct_nbr, _cmdty_desc, _spcl_instr_desc, _comment_desc, _rerte_flg, _hold_at_loc_flg);
//            shipperBean.addAccount(accountVO);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** remove an account from a shipper */
//    public void deleteAccountFromShipper(String shipperNbr, String accountNbr) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.deleteAccount(shipperNbr, accountNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** 
//     * update account for a shipper 
//     * accountNbr can't change because it's key value
//     */
//    public void updateAccount(String shipperNbr, String accountNbr, String accountName) {
//        if (log.isDebugEnabled()) {
//            log.debug("update account '" + accountName + "' to shipper '" + shipperNbr + "'");
//        }
//        
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            // TODO: populate account attrs
//            String _company_nm = null;
//            String _dtytax_acct_nbr = null;
//            String _cmdty_desc = null;
//            String _spcl_instr_desc = null;
//            String _comment_desc = null;
//            char _rerte_flg = ' ';
//            char _hold_at_loc_flg = ' ';
//            AccountVO accountVO = new AccountVO(Integer.parseInt(shipperNbr), accountNbr, accountName, 
//                    _company_nm, _dtytax_acct_nbr, _cmdty_desc, _spcl_instr_desc, _comment_desc, _rerte_flg, _hold_at_loc_flg);
//            shipperBean.updateAccount(accountVO);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** 
//     * get all lanes 
//     * @return List of LaneVOs 
//     */
//    public List getLanes() {
//        List lanes = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            lanes = shipperBean.getLanes();
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//        return lanes; 
//    }
//    
//    /** 
//     * get a lane 
//     * @return lane LaneVO 
//     */
//    public LaneVO getLane(String laneNbr) {
//        LaneVO lane = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            lane = shipperBean.getLane(laneNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();
//        }
//        return lane; 
//    }
//    
//    /** create a new lane */
//    public boolean addLane(String originCountryCd, String destCountryCd) {
//        boolean isSuccess = true;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           shipperBean.addLane(originCountryCd, destCountryCd);
//        } catch (RemoteException e) {
//            log.error("Add Lane failed, lane: " + originCountryCd + "-" + destCountryCd, e);
//            isSuccess = false; 
//        } catch (SQLException e) {
//            log.error("Add Lane failed, lane: " + originCountryCd + "-" + destCountryCd, e);
//            isSuccess = false; 
//        } catch (ServiceLocatorException sle) {
//            log.error("Add Lane failed, lane: " + originCountryCd + "-" + destCountryCd, sle);
//            isSuccess = false; 
//        }      
//        return isSuccess;
//    }
//    
//    /** delete a lane */
//    public boolean deleteLane(String laneNbr) {
//        boolean isSuccess = true;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           shipperBean.deleteLane(laneNbr);
//        } catch (RemoteException e) {
//            log.error("Delete Lane failed, laneNbr: " + laneNbr, e);
//            isSuccess = false; 
//        } catch (SQLException e) {
//            log.error("Delete Lane failed, laneNbr: " + laneNbr, e);
//            isSuccess = false; 
//        } catch (ServiceLocatorException sle) {
//            log.error("Delete Lane failed, laneNbr: " + laneNbr, sle);
//            isSuccess = false; 
//        }      
//        return isSuccess;
//    }
//   
//    /** get lanes for an account */
//    public AccountLaneVO getAccountLane(String shipperNbr, String accountNbr, String laneNbr) {
//        AccountLaneVO lane = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           lane = shipperBean.getAccountLane(shipperNbr, accountNbr, laneNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }
//        return lane;
//    }
//    
//    /** get lanes for an account */
//    public List getAccountLanes(String shipperNbr, String accountNbr) {
//        List lanes = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           lanes = shipperBean.getAccountLanes(shipperNbr, accountNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//        return lanes;
//    }
//    
//    /** add lanes to a shipper, will determine which to add, update, delete */
//    public void addLanesToShipper(String shipperNbr, String accountNbr, String[] lanes) {
//        if (log.isDebugEnabled()) {
//            log.debug("add lanes '" + lanes + "' to account '" + accountNbr + "' to shipper '" + shipperNbr + "'");
//        }
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           shipperBean.addLanesToShipper(shipperNbr, accountNbr, lanes);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** get services for a shipper, account, lane */
//    public List getLaneServices(String shipperNbr, String accountNbr, String laneNbr) {
//        List services = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           services = shipperBean.getLaneServices(shipperNbr, accountNbr, laneNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//        return services;
//    }
//    
//    /** get service details for a shipper, account, lane, servicetypecd */
//    public LaneServiceVO getLaneService(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd) {
//        LaneServiceVO service = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           service = shipperBean.getLaneService(shipperNbr, accountNbr, laneNbr,
//                   serviceTypeCd);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return service;
//    }
//    
//    /** remove a lane from account, shipper */
//    public void deleteLaneFromShipper(String shipperNbr, String accountNbr, String laneNbr) {
//        if (log.isDebugEnabled()) {
//            log.debug("delete lane '" + laneNbr + "' on account '" + accountNbr + "' on shipper '" + shipperNbr + "'");
//        }
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.deleteLane(shipperNbr, accountNbr, laneNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** add a service to lane, account, shipper.  will determine which to add, update, delete */
//    public void addServiceToShipper(String shipperNbr, String accountNbr, 
//            String laneNbr, String[] serviceTypeCds) {
//        if (log.isDebugEnabled()) {
//            log.debug("add service '" + serviceTypeCds + "to lane '" + laneNbr 
//                + "' to accountNbr '" + accountNbr + "' to shipper '" + shipperNbr + "'");
//        }
//        
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           shipperBean.addServicesToShipper(shipperNbr, accountNbr, laneNbr, serviceTypeCds);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** update a service for a lane, account, shipper */
//    public void updateLaneService(String shipperNbr, String accountNbr, String laneNbr, 
//            String serviceTypeCd, int commitDaysQty) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            LaneServiceVO laneServiceVO = new LaneServiceVO(serviceTypeCd,
//                   Integer.parseInt(laneNbr), Integer.parseInt(shipperNbr), accountNbr);
//            laneServiceVO.set_commit_days_qty(String.valueOf(commitDaysQty));
//            shipperBean.updateLaneService(laneServiceVO);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace(); 
//        }
//    }
//    
//    /** remove a service from lane, account, shipper */
//    public void deleteServiceFromShipper(String shipperNbr, String accountNbr, String laneNbr, String serviceTypeCd) {
//        if (log.isDebugEnabled()) {
//            log.debug("delete service '" + serviceTypeCd + " on lane '" + laneNbr 
//                + "' on account '" + accountNbr + "' on shipper '" + shipperNbr + "'");
//        }
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.deleteService(shipperNbr, accountNbr, laneNbr, serviceTypeCd);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    /** get monitors for a shipper, account, lane, service */
//    public List getMonitors(String shipperNbr, String accountNbr, String laneNbr, String serviceTypeCd) {
//        List monitors = null;
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//           monitors = shipperBean.getMonitors(shipperNbr, accountNbr, laneNbr, serviceTypeCd);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//        return monitors;
//    }
//    
//    /** Get a list of performance results for a group number, date range, and lane */
//    public List getPerformanceList(String GroupNbr, Date fromDate, Date toDate,
//    		String laneNbrStr){
//    	   List performance = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   performance = shipperBean.getPerformanceList(GroupNbr, fromDate, 
//        			   toDate, laneNbrStr);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return performance;
//    }
//	//WR#:179441 Changes
//    /** Get a list of the sum of performance results for a group number, date range, lane and empnbr */
//    public List getPerformanceSumList(String GroupNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, String empNbr){
//    	   List performance = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   performance = shipperBean.getPerformanceSumList(GroupNbr, fromDate, 
//        			   toDate, laneNbrStr, empNbr);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return performance;
//    }
//   
//    /** Get a list of the sum of performance results for a group number, date range, lane, month number */
//    public List getPerformanceGroupSumList(Date fromDate, Date toDate,
//    		int monthNbr, int monthSelectedNumber){
//    	   List performance = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   performance = shipperBean.getPerformanceGroupSumList( 
//        			   fromDate, toDate, monthNbr, monthSelectedNumber);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return performance;
//    }
//    
//    /** Get a list of moitor reports */
//    public List getMonitorReportList(Date fromDate, Date toDate){
//    	   List monitorReport = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   monitorReport = shipperBean.getMonitorReportList(fromDate, toDate);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return monitorReport;
//    }
//
//    /** Get a list of moitor reports */
//    public List getMonitorReportList(String monitorName, String monitorType, Date fromDate, Date toDate){
//    	   List monitorReport = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   monitorReport = shipperBean.getMonitorReportList(monitorName, monitorType, fromDate, toDate);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return monitorReport;
//    }
//    
//    /** Get a count of moitor reports */
//    public int getMonitorReportCount(String monitorName, String monitorType, Date fromDate, Date toDate){
//    	   int size = 0;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   size = shipperBean.getMonitorReportCount(monitorName, monitorType, fromDate, toDate);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return size;
//    }
//    
//    /** Get a list of moitor reports */
//    public List getMonitorReportDetailList(String monitorName, String monitorType, Date fromDate, Date toDate, 
//    		int startIndex, int endIndex, String sortColumn, boolean isSortAscending){
//    	   List monitorReport = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   monitorReport = shipperBean.getMonitorReportDetailList(monitorName, monitorType, fromDate, toDate, 
//        			   startIndex, endIndex, sortColumn, isSortAscending);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return monitorReport;
//    }
//	//WR#:179441 Changes    
//    /** Get a list of the sum of performance results for a group number, date range, lane, month number */
//    public List getPerformanceAcctSumList(String GroupNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, int monthNbr, int monthSelectedNumber, String empNbr){
//    	   List performance = null;
//    	   
//    	   ShipperRemote shipperBean = getShipperBean();
//           try {
//        	   performance = shipperBean.getPerformanceAcctSumList(GroupNbr, 
//        			   fromDate, toDate, laneNbrStr, monthNbr, monthSelectedNumber, empNbr);
//           } catch (RemoteException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (SQLException e) {
//               // TODO Auto-generated catch block
//               e.printStackTrace();
//           } catch (ServiceLocatorException sle) {
//               // TODO Auto-generated catch block
//               sle.printStackTrace();  
//           }      
//           return performance;
//    }
//    /** add monitor to an account 
//    public void addAccountMonitor(String shipperNbr, String accountNbr, String emplyNbr) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.addAccountMonitor(shipperNbr, accountNbr, emplyNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//    }
//*/
//    
//    /** add monitor to a lane
//    public void addAccountLaneMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String emplyNbr) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.addAccountLaneMonitor(shipperNbr, accountNbr, laneNbr, emplyNbr);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }      
//    }
//*/
//    /** add monitor to a service */
//   
//    /** add many monitor to a service */
//    public void addAcctLaneServiceManyMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd, String[] manyMonitor) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.addAcctLaneServiceManyMonitor(shipperNbr, accountNbr, laneNbr, 
//                    serviceTypeCd, manyMonitor);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//        
//    /** add monitor to a service */
//    public void addAcctLaneServiceMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd, String selectedMonitor) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.addAcctLaneServiceMonitor(shipperNbr, accountNbr, laneNbr, 
//                    serviceTypeCd, selectedMonitor);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//    
//    public void updateSelectedAcctLaneServiceMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd, String selectedMonitor, String oldMonitor) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//        	shipperBean.updateSelectedAcctLaneServiceMonitor(shipperNbr, accountNbr, laneNbr, 
//                    serviceTypeCd, selectedMonitor, oldMonitor);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
//   
//    /** Update the group number in the shipment table of past shipments. **/
//    public void updateGroupNbrPastShipments(String groupNbr, String accountNbr, 
//    		String laneNbr, String svcTypeCd) {
//        ShipperRemote shipperBean = getShipperBean();
//        try {
//            shipperBean.updateGroupNbrPastShipments(groupNbr, accountNbr, 
//            		laneNbr, svcTypeCd);
//        } catch (RemoteException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (SQLException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (ServiceLocatorException sle) {
//            // TODO Auto-generated catch block
//            sle.printStackTrace();  
//        }      
//    }
}    
