package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.MonitoredAccountsVO;

public class MonitoredAccountsAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(MonitoredAccountsAccessor.class);
    
    public MonitoredAccountsAccessor(Connection con) {
        super(con);
    }    
    
    // get all accounts being monitored for specified user
    private static final String getMonitoredAccountsSQL =
        "select ACCT_LANE_SERVICE_MONITORING.GROUP_NBR, ACCOUNT_GROUP.GROUP_NM, ACCOUNT_GROUP.GROUP_DESC, " +
        " ACCT_LANE_SERVICE_MONITORING.ACCT_NBR, ACCT_NM, " +
        " ACCT_LANE_SERVICE_MONITORING.LANE_NBR, LANE.ORIG_CNTRY_CD, LANE.DEST_CNTRY_CD, " +
        " ACCT_LANE_SERVICE_MONITORING.SVC_TYPE_CD " +
        "from ACCT_LANE_SERVICE_MONITORING, ACCOUNT_GROUP, ACCOUNT, LANE " + 
        "where ACCT_LANE_SERVICE_MONITORING.EMP_NBR = ? " + 
        "and ACCOUNT_GROUP.GROUP_NBR = ACCT_LANE_SERVICE_MONITORING.GROUP_NBR " +
        "and ACCOUNT.GROUP_NBR = ACCT_LANE_SERVICE_MONITORING.GROUP_NBR " +
        "and ACCOUNT.ACCT_NBR = ACCT_LANE_SERVICE_MONITORING.ACCT_NBR " +
        "and LANE.LANE_NBR = ACCT_LANE_SERVICE_MONITORING.LANE_NBR " +
        "order by ACCOUNT_GROUP.GROUP_NM, ACCT_NM";

    public List getMonitoredAccounts(String anEmplyNbr) throws SQLException {
        ArrayList al = new ArrayList();
        
        try {
            setSqlSignature( getMonitoredAccountsSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anEmplyNbr);
           
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    // rows found
                    MonitoredAccountsVO monitoredAccountsVO = new MonitoredAccountsVO();
                    monitoredAccountsVO.set_groupNbr(rs.getInt("GROUP_NBR"));
                    monitoredAccountsVO.set_groupNm(rs.getString("GROUP_NM"));
                    monitoredAccountsVO.set_acctNbr(rs.getString("ACCT_NBR"));
                    monitoredAccountsVO.set_acctName(rs.getString("ACCT_NM"));
                    monitoredAccountsVO.set_laneNbr(rs.getInt("LANE_NBR"));
                    monitoredAccountsVO.set_origCntryCd(rs.getString("ORIG_CNTRY_CD"));
                    monitoredAccountsVO.set_destCntryCd(rs.getString("DEST_CNTRY_CD"));
                    monitoredAccountsVO.set_svcTypeCd(rs.getString("SVC_TYPE_CD")); 
                    
                    al.add(monitoredAccountsVO);
                }
            } else {
                return null;
            }            

        } catch ( SQLException e ) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return al;
    } 
    
    // get all accounts being monitored by RISE
    private static final String getAllMonitoredAccountsSQL =
        "select ACCT_LANE_SERVICE_MONITORING.GROUP_NBR, ACCOUNT_GROUP.GROUP_NM, ACCOUNT_GROUP.GROUP_DESC, " +
        " ACCT_LANE_SERVICE_MONITORING.ACCT_NBR, ACCT_NM, " +
        " ACCT_LANE_SERVICE_MONITORING.LANE_NBR, LANE.ORIG_CNTRY_CD, LANE.DEST_CNTRY_CD, " +
        " ACCT_LANE_SERVICE_MONITORING.SVC_TYPE_CD " +
        "from ACCT_LANE_SERVICE_MONITORING, ACCOUNT_GROUP, ACCOUNT, LANE " +  
        "where ACCOUNT_GROUP.GROUP_NBR = ACCT_LANE_SERVICE_MONITORING.GROUP_NBR " +
        "and ACCOUNT.GROUP_NBR = ACCT_LANE_SERVICE_MONITORING.GROUP_NBR " +
        "and ACCOUNT.ACCT_NBR = ACCT_LANE_SERVICE_MONITORING.ACCT_NBR " +
        "and LANE.LANE_NBR = ACCT_LANE_SERVICE_MONITORING.LANE_NBR " +
        "order by ACCOUNT_GROUP.GROUP_NM, ACCT_NM";

    public List getAllMonitoredAccounts() throws SQLException {
        ArrayList al = new ArrayList();
        
        try {
            setSqlSignature( getAllMonitoredAccountsSQL, false, logger.isDebugEnabled() );
           
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    // rows found
                    MonitoredAccountsVO monitoredAccountsVO = new MonitoredAccountsVO();
                    monitoredAccountsVO.set_groupNbr(rs.getInt("GROUP_NBR"));
                    monitoredAccountsVO.set_groupNm(rs.getString("GROUP_NM"));
                    monitoredAccountsVO.set_acctNbr(rs.getString("ACCT_NBR"));
                    monitoredAccountsVO.set_acctName(rs.getString("ACCT_NM"));
                    monitoredAccountsVO.set_laneNbr(rs.getInt("LANE_NBR"));
                    monitoredAccountsVO.set_origCntryCd(rs.getString("ORIG_CNTRY_CD"));
                    monitoredAccountsVO.set_destCntryCd(rs.getString("DEST_CNTRY_CD"));
                    monitoredAccountsVO.set_svcTypeCd(rs.getString("SVC_TYPE_CD")); 
                    
                    al.add(monitoredAccountsVO);
                }
            } else {
                return null;
            }            

        } catch ( SQLException e ) {
            logger.error(e);
            throw e;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return al;
    } 
    
    private static final String selectEmployeeRoleCodeSQL = 
        "select " + "EMP_ROLE_CD " 
        + "from Employee where EMP_NBR = ?";
    
    /**
     * Determine if the employee role code is a Restricted Monitor ("RM").
     * @param emplyNbr
     * @return boolean true if employee is a Restricted Monitor
     * @throws SQLException 
     */
    public boolean isEmployeeRestrictedMonitor(String emplyNbr) throws SQLException {
        String employeeRoleCd = new String(" ");
                
        try {
            setSqlSignature( selectEmployeeRoleCodeSQL, false, logger.isDebugEnabled() );
            
            pstmt.setString( 1, emplyNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    employeeRoleCd = rs.getString("EMP_ROLE_CD");
                }
            } else {
                return false;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return employeeRoleCd.equalsIgnoreCase("RM");
    }    
}
