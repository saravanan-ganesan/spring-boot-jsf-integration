package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.Calendar;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.vo.EventVO;
import com.fedex.rise.xref.EventNotesDescCodes;
import com.fedex.rise.xref.EventSourceCodes;
import com.fedex.rise.xref.ExceptionTypes;
import com.fedex.rise.xref.TrackDesc;
import com.fedex.rise.xref.TrackTypes;

/**
 * Encapsulates the display logic for displaying an event
 */
public class EventBean implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private static Log log = LogFactory.getLog(EventBean.class);
    
    private String _track_type_cd;
    private Calendar _event_crtn_tmstp;
    private String _trkng_item_entry_type_cd;
    private char   _ecco_type_cd = ' ';
    private char   _ecco_comm_cd = ' ';
    private String _track_excp_cd;
    private String _track_loc_cd;
    private String _admin_loc_cd;
    private String _scan_emp_nbr;
    private String _track_src_cd;
    private String _event_note_desc;
    
    private static final HashMap riseAcronyms = new HashMap();
    
    static {
        riseAcronyms.put("60", "TDR");
        riseAcronyms.put("70", "TDR");
        riseAcronyms.put("72", "TDR");
        riseAcronyms.put("73", "TDR");
        riseAcronyms.put("74", "TDR");
        riseAcronyms.put("76", "CC");
    }
    
    /**
     * Default Constructor
     */
    public EventBean() {
    }
    
    /**
     * Fill in the attributes of this object from the EventVO
     */
    public EventBean(EventVO anEventVO) {
        super();
        this._track_type_cd = anEventVO.get_track_type_cd();
        this._event_crtn_tmstp = anEventVO.get_event_crtn_tmstp();
        this._trkng_item_entry_type_cd = anEventVO.get_trkng_item_entry_type_cd();
        this._ecco_type_cd = anEventVO.get_ecco_type_cd();
        this._ecco_comm_cd = anEventVO.get_ecco_comm_cd();
        this._track_excp_cd = anEventVO.get_track_excp_cd();
        this._track_loc_cd = anEventVO.get_track_loc_cd();
        this._admin_loc_cd = anEventVO.get_admin_loc_cd();
        this._scan_emp_nbr = anEventVO.get_scan_emp_nbr();
        this._track_src_cd = anEventVO.get_track_src_cd();
        this._event_note_desc = anEventVO.get_event_note_desc();
    }
       
    /**
     * @return the exception code translated into text
     */
    public String get_track_excp_cd() {
        String exceptionDesc = null;
        if (_track_excp_cd != null) {
            exceptionDesc =  ExceptionTypes.lookupExceptionType(_track_excp_cd);
            if (exceptionDesc == null) {
            	log.info("exceptionDesc"+_track_excp_cd); //Change for WR #135494 by Wipro Surge Uplift
            	return _track_excp_cd;      
            }
            else if(_track_excp_cd.equals("79")){
            	return exceptionDesc.concat(_track_excp_cd);
            }
            log.info("exceptionDesc"+exceptionDesc); //Change for WR #135494 by Wipro
        }
        return exceptionDesc;
    }

    /**
     * @return the source track code tranlsated into text
     */
    public String get_track_src_cd() {
        String srcCd = null;
        if (_track_src_cd != null) {
            srcCd =  EventSourceCodes.get(_track_src_cd);
            if (_track_src_cd.equals("2")) {
                if (_trkng_item_entry_type_cd != null) {
                    if (_trkng_item_entry_type_cd.equals("3")) {
                        srcCd += " (TS)";
                    } else {
                        if (_trkng_item_entry_type_cd.equals("2")) {
                            srcCd += " (TM)";                    
                        } else {    
                            srcCd += " (T)";                    
                        }
                    }
                } else {
                    srcCd += " (T)";                    
                }
            }
            if (srcCd == null) {
                return _track_src_cd;
            }
        }
        return srcCd;
    }
    
    /**
     * @return the _track_type_cd
     */
    public String get_track_type_cd() {
        TrackDesc trackDesc = TrackTypes.getTrackTypeDesc(_track_type_cd);
        String eventDesc;
        // handle if not found
        if (trackDesc != null){
            eventDesc =  trackDesc.get_shortName();
        }
        else {
            log.error("Unkown Event TrackType: " + _track_type_cd);
            eventDesc = "unknown";
        }
            
        String riseAcronym = (String)riseAcronyms.get(_track_type_cd);
        if (riseAcronym == null) {
            // Arrived Customs
            if (_track_type_cd.equals("79") && // ECCO
                ((_ecco_type_cd == 'P') && 
                ((_ecco_comm_cd == '2') || (_ecco_comm_cd == 'B')))) {
                riseAcronym = "ARRC";
            } else {
               if (_track_type_cd.equals("07") && // STAT
                  ((_track_excp_cd.equals("71") || _track_excp_cd.equals("72")))) {
                   riseAcronym = "ARRC";
               } else { // Cleared Customs
                   if (_track_type_cd.equals("79") && // ECCO
                           ((_ecco_type_cd == 'C') && 
                           ((_ecco_comm_cd == 'E') || (_ecco_comm_cd == '5')))) {
                           riseAcronym = "CC";
                   } else {
                       if (_track_type_cd.equals("79") && // ECCO
                               ((_ecco_type_cd == 'P') && 
                               ((_ecco_comm_cd == 'C') || (_ecco_comm_cd == '3')))) {
                               riseAcronym = "CC";
                       } else {
                           if (_track_type_cd.equals("07") && // STAT
                              ((_track_excp_cd.equals("65") || _track_excp_cd.equals("66")))) {
                               riseAcronym = "CC";
                           } else {
                               if (_track_type_cd.equals("07") && // STAT
                                   _track_excp_cd.equals("34")) {
                                   riseAcronym = "DACR";
                               }
                           }
                       }
                   }
               }
            }
        }
        if (riseAcronym != null) {
            riseAcronym += "/" + eventDesc;
        } else {
            riseAcronym = eventDesc;
        }
        if (_track_excp_cd != null) {
            riseAcronym += "(" + _track_excp_cd + ")";
        }
        return riseAcronym;
    }

    /**
     * @return the _eventNoteDesc
     */
    public String get_event_note_desc() {
        StringBuffer userText = new StringBuffer();
        if (_event_note_desc == null) {
            return null;
        }
        String[] notes = _event_note_desc.split("\\|");
        for (int i = 0 ; i < notes.length ; i++) {
            String[] note = notes[i].split(":");
            String label = EventNotesDescCodes.lookupCd(note[0]);
            userText.append(label);
            if (note.length > 1){
            	userText.append(": ");
                userText.append(note[1]);
                if (i != notes.length - 1) {
                    userText.append(", ");
                }
            }
        }
        return userText.toString();
    }

    /**
     * *********************************************************************** 
     */
    
    /**
     * @return the _track_loc_cd
     */
    public String get_track_loc_cd() {
        return _track_loc_cd;
    }
    
    /**
     * @return the _admin_loc_cd
     */
    public String get_admin_loc_cd() {
        return _admin_loc_cd;
    }

    /**
     * @return the _event_crtn_tmstp
     */
    public Calendar get_event_crtn_tmstp() {
        return _event_crtn_tmstp;
    } 
    
    /**
     * @return the _scan_emp_nbr
     */
    public String get_scan_emp_nbr() {
        return _scan_emp_nbr;
    }
    
    /**
     * @return the _scan_emp_nbr stripped of leading zeros
     */
    public String get_scan_emp_nbr_stripped() {
        // strip off leading zeros
        String temp = _scan_emp_nbr;
        while (temp != null && temp.length() > 0 && temp.charAt(0) == '0')
            temp = temp.substring(1);
        return temp;
    }
    
    /**
     * @return the _trkng_item_entry_type_cd
     */
    public String get_trkng_item_entry_type_cd() {
        return _trkng_item_entry_type_cd;
    }
    
}
