package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.xref.TrackDesc;
import com.fedex.rise.xref.TrackTypes;

/**
 * Used to see if an issue can be resolved by the current
 * event by examing the event's track type cd and optionally,
 * if present the exception code.  If there is a match it
 * will indicate that the issue can be resolved.
 */
public class SpecificEventResolver extends Resolver {

    private String _trackTypeCd = null;
    private String _exceptionCd = null;
    
    private static ArrayList _instances = new ArrayList();
    
    private SpecificEventResolver(String aTrackTypeCd, String anExceptionCd) {
        _trackTypeCd = aTrackTypeCd;
        _exceptionCd = anExceptionCd;
    }
    
    private SpecificEventResolver(String aTrackTypeCd) {
        _trackTypeCd = aTrackTypeCd;
        _exceptionCd = null;
    }
    
    public boolean isResolved(EventVO anEventVO, IssueVO anIssueVO) {
        boolean resolved = false;
        if (_trackTypeCd.equals(anEventVO.get_track_type_cd())) {
            String exceptionCd = anEventVO.get_track_excp_cd();
            if ((_exceptionCd != null) && (exceptionCd != null)) {
                if (_exceptionCd.equals(exceptionCd)) {
                    resolved = true;
                }
            } else {
                resolved = true;
            }
        }
        return resolved;
    }
    
    public static SpecificEventResolver getInstance(String aTrackTypeCd, String anExceptionCd) {
        SpecificEventResolver resolver = new SpecificEventResolver(aTrackTypeCd, anExceptionCd);
        if (_instances.contains(resolver)) {
            int index = _instances.indexOf(resolver);
            return (SpecificEventResolver)_instances.get(index);
        } else {
            _instances.add(resolver);
            return resolver;
        }
    }

    public static SpecificEventResolver getInstance(String aTrackTypeCd) {
        SpecificEventResolver resolver = new SpecificEventResolver(aTrackTypeCd, null);
        if (_instances.contains(resolver)) {
            int index = _instances.indexOf(resolver);
            return (SpecificEventResolver)_instances.get(index);
        } else {
            _instances.add(resolver);
            return resolver;
        }
    }
    
    /**
     * @return the _exceptionCd
     */
    public String get_exceptionCd() {
        return _exceptionCd;
    }

    /**
     * @param cd the _exceptionCd to set
     */
    public void set_exceptionCd(String cd) {
        _exceptionCd = cd;
    }

    /**
     * @return the _trackTypeCd
     */
    public String get_trackTypeCd() {
        return _trackTypeCd;
    }

    /**
     * @param typeCd the _trackTypeCd to set
     */
    public void set_trackTypeCd(String typeCd) {
        _trackTypeCd = typeCd;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((_exceptionCd == null) ? 0 : _exceptionCd.hashCode());
        result = PRIME * result + ((_trackTypeCd == null) ? 0 : _trackTypeCd.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final SpecificEventResolver other = (SpecificEventResolver) obj;
        if (_exceptionCd == null) {
            if (other._exceptionCd != null)
                return false;
        } else if (!_exceptionCd.equals(other._exceptionCd))
            return false;
        if (_trackTypeCd == null) {
            if (other._trackTypeCd != null)
                return false;
        } else if (!_trackTypeCd.equals(other._trackTypeCd))
            return false;
        return true;
    }
    
    public String toString() {
        StringBuffer sb = new StringBuffer();
        TrackDesc trackDesc = TrackTypes.getTrackTypeDesc(_trackTypeCd);
        sb.append(trackDesc.get_shortName());
        if (_exceptionCd != null) {
            sb.append(':');
            sb.append(_exceptionCd);
        }
        return sb.toString();
    }

}
