package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.issue.RiseIssues;
import com.fedex.rise.bo.status.StatusCalculator;
import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.util.SpecialHandlingXlator;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentCommentVO;
import com.fedex.rise.vo.FilterByIssueVO;

/**
 * Shipment data bean, aggregates all the shipment data (shipmentVO, events,
 * issues, reference notes, etc.
 */
public class FilterDataBean implements Serializable {
	/** serializing version */
	private static final long serialVersionUID = 1L;
	/** logger */
	private static final Log log = LogFactory.getLog(FilterDataBean.class);

	/** encapsulated shipment data */
	private String _assoc_trkng_item_nbr;
	private String _trkng_item_nbr;
	private FilterByIssueVO FilterByIssueVO;

	private String _dest_loc_cd;

	private String _group_nm;
	private String _acct_nm;
	private String _acct_nbr;

	private String _shpr_cntry_cd;
	private String _recp_cntry_cd;
	private String _SVC_TYPE_CD;

	private String _emp_nbr;
	private String _emp_first_nm;
	private String _emp_last_nm;

	private Date _ship_dt;
	private Calendar _commit_dt;

	/*
	 * private List shipmentReferences = new ArrayList(); private List comments
	 * = new ArrayList(); private List events = new ArrayList();
	 */
	private List issues = new ArrayList();

	/** list of AssociatedShipmentVO, for paperwork and return airbills */
	/* private List associatedShipments = new ArrayList(); */

	/** new comment to add */

	private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();

	private String rootCause = "-";

	/**
	 * Construct new Filter Data Bean.
	 * 
	 */

	public FilterDataBean(String _assoc_trkng_item_nbr, String _trkng_item_nbr, Date _ship_dt, String _group_nm,
			String _acct_nm, String _acct_nbr, String _SHPR_CNTRY_CD, String _RECP_CNTRY_CD, String _SVC_TYPE_CD,
			Calendar _commit_dt, String _dest_loc_cd, FilterByIssueVO FilterByIssueVO, List issues, String _emp_nbr,
			String _emp_first_nm, String _emp_last_nm) {
		super();

		this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
		this._trkng_item_nbr = _trkng_item_nbr;
		this._ship_dt = _ship_dt;
		this._group_nm = _group_nm;
		this._acct_nm = _acct_nm;
		this._acct_nbr = _acct_nbr;
		this._shpr_cntry_cd = _SHPR_CNTRY_CD;
		this._recp_cntry_cd = _RECP_CNTRY_CD;
		this._SVC_TYPE_CD = _SVC_TYPE_CD;
		this._commit_dt = _commit_dt;
		this._dest_loc_cd = _dest_loc_cd;
		this.FilterByIssueVO = FilterByIssueVO;
		this.issues = issues;
		this._emp_nbr = _emp_nbr;
		this._emp_first_nm = _emp_first_nm;
		this._emp_last_nm = _emp_last_nm;
	}

	public String get_assoc_trkng_item_nbr() {
		return _assoc_trkng_item_nbr;
	}

	public void set_assoc_trkng_item_nbr(String _assoc_trkng_item_nbr) {
		this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
	}

	public String get_emp_nbr() {
		return _emp_nbr;
	}

	public void set_emp_nbr(String _emp_nbr) {
		this._emp_nbr = _emp_nbr;
	}

	public String get_emp_first_nm() {
		return _emp_first_nm;
	}

	public void set_emp_first_nm(String _emp_first_nm) {
		this._emp_first_nm = _emp_first_nm;
	}

	public String get_emp_last_nm() {
		return _emp_last_nm;
	}

	public void set_emp_last_nm(String _emp_last_nm) {
		this._emp_last_nm = _emp_last_nm;
	}

	public String get_dest_loc_cd() {
		return _dest_loc_cd;
	}

	public void set_dest_loc_cd(String _dest_loc_cd) {
		this._dest_loc_cd = _dest_loc_cd;
	}

	public Calendar get_commit_dt() {
		return _commit_dt;
	}

	public void set_commit_dt(Calendar _commit_dt) {
		this._commit_dt = _commit_dt;
	}

	public String get_group_nm() {
		return _group_nm;
	}

	public void set_group_nm(String _group_nm) {
		this._group_nm = _group_nm;
	}

	public String get_acct_nm() {
		return _acct_nm;
	}

	public void set_acct_nm(String _acct_nm) {
		this._acct_nm = _acct_nm;
	}

	public String get_shpr_cntry_cd() {
		return _shpr_cntry_cd;
	}

	public void set_shpr_cntry_cd(String _SHPR_CNTRY_CD) {
		this._shpr_cntry_cd = _SHPR_CNTRY_CD;
	}

	public String get_recp_cntry_cd() {
		return _recp_cntry_cd;
	}

	public void set_recp_cntry_cd(String _RECP_CNTRY_CD) {
		this._recp_cntry_cd = _RECP_CNTRY_CD;
	}

	public String get_SVC_TYPE_CD() {
		if (_SVC_TYPE_CD.equals("17")) {
			_SVC_TYPE_CD = "ED" + "(" + _SVC_TYPE_CD + ")";
		} else if (_SVC_TYPE_CD.equals("18")) {
			_SVC_TYPE_CD = "ID" + "(" + _SVC_TYPE_CD + ")";
		} else if (_SVC_TYPE_CD.equals("84")) {
			_SVC_TYPE_CD = "DF" + "(" + _SVC_TYPE_CD + ")";
		}

		return _SVC_TYPE_CD;

	}

	public void set_SVC_TYPE_CD(String _SVC_TYPE_CD) {
		this._SVC_TYPE_CD = _SVC_TYPE_CD;
	}

	public String get_acct_nbr() {
		return _acct_nbr;
	}

	public void set_acct_nbr(String _acct_nbr) {
		this._acct_nbr = _acct_nbr;
	}

	

	/**
	 * @return the issues
	 */
	public List getIssues() {
		return issues;
	}

	/**
	 * @param issues
	 *            the issues to set
	 */
	public void setIssues(List issues) {
		this.issues = issues;
	}

	/**
	 * @return the shipment
	 */
	public FilterByIssueVO getShipment() {
		return FilterByIssueVO;
	}

	/**
	 * @param shipment
	 *            the shipment to set
	 */
	public void setShipment(FilterByIssueVO FilterByIssueVO) {
		this.FilterByIssueVO = FilterByIssueVO;
	}

	/**
	 * @return the shipmentReferences
	 */
	/*
	 * public List getShipmentReferences() { return shipmentReferences; }
	 */
	public Date get_ship_dt() {

		return _ship_dt;
	}

	/**
	 * @param _ship_dt
	 *            the _ship_dt to set
	 */
	public void set_ship_dt(Date _ship_dt) {
		this._ship_dt = _ship_dt;

	}

	public String getTrkng_item_nbr() {

		return _trkng_item_nbr;
	}

	public void setTrkng_item_nbr(String trkng_item_nbr) {
		this._trkng_item_nbr = trkng_item_nbr;
	}

	public Date getCommitDate() {
		Date commitDate = null;
		if (_commit_dt != null) {
			commitDate = _commit_dt.getTime();
		}
		return commitDate;
	}

	public String getLane() {
		String Lane = get_shpr_cntry_cd() + "-" + get_recp_cntry_cd();
		return Lane;
	}

	/**
	 * Return the most recent scan event (track type).
	 * 
	 * @return the status
	 */
	public String getStatus() {
		StringBuffer status = new StringBuffer();
		if (FilterByIssueVO.get_last_stat_desc() != null) {
			status.append(StatusCalculator.getStatusDesc(FilterByIssueVO.get_last_stat_desc()));
		}
		if (FilterByIssueVO.get_last_event_track_loc_cd() != null) {
			status.append(" @ ");
			// append last status location, since this field is new, if it is
			// null, use old last event location
			if (FilterByIssueVO.get_last_stat_track_loc_cd() == null)
				status.append(FilterByIssueVO.get_last_event_track_loc_cd());
			else
				status.append(FilterByIssueVO.get_last_stat_track_loc_cd());
		}
		if (FilterByIssueVO.get_last_stat_tmstp() != null) {
			status.append(" @ ");
			TimeZone tz = UserBean.getLoggedInUser().getTimeZone();
			Calendar cal = Calendar.getInstance(tz);
			cal.setTime(FilterByIssueVO.get_last_stat_tmstp());
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			sdf.setTimeZone(tz);
			String lastScanTime = sdf.format(cal.getTime());
			status.append(lastScanTime);
		}
		return status.toString();
	}

	

	/**
	 * Return the Ship Date as a Month String (MM)
	 * 
	 * @return Ship Date Month
	 */
	public String getShipDateMonthStr() {
		if (FilterByIssueVO.get_ship_dt() == null)
			return "";
		Calendar shipdt = Calendar.getInstance();
		shipdt.setTimeInMillis(FilterByIssueVO.get_ship_dt().getTime());

		SimpleDateFormat formatter = new SimpleDateFormat("MM");
		return formatter.format(shipdt.getTime());
	}

	/**
	 * Return the Ship Date as a Day String (dd)
	 * 
	 * @return Ship Date Month
	 */
	public String getShipDateDayStr() {
		if (FilterByIssueVO.get_ship_dt() == null)
			return "";
		Calendar shipdt = Calendar.getInstance();
		shipdt.setTimeInMillis(FilterByIssueVO.get_ship_dt().getTime());

		SimpleDateFormat formatter = new SimpleDateFormat("dd");
		return formatter.format(shipdt.getTime());
	}

	/**
	 * Return the Ship Date as a Year String (yyyy)
	 * 
	 * @return Ship Date Month
	 */
	public String getShipDateYearStr() {
		if (FilterByIssueVO.get_ship_dt() == null)
			return "";
		Calendar shipdt = Calendar.getInstance();
		shipdt.setTimeInMillis(FilterByIssueVO.get_ship_dt().getTime());

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
		return formatter.format(shipdt.getTime());
	}

	/**
	 * Get IssuesStr
	 * 
	 * @return Issues, concat all issues comma delimited
	 */
	public String getIssuesStr() {
		if (issues.size() > 0) {
			// Issues, show all OPEN issues, not closed ones
			StringBuffer issueStr = new StringBuffer();
			for (Iterator itr = issues.iterator(); itr.hasNext();) {
				IssueBean issue = (IssueBean) itr.next();
				if (issue.getIssue().getRes_dt() == null) {
					if (issueStr.length() > 0)
						issueStr.append(", ");
					issueStr.append(issue.getDesc());
				}
			}
			return issueStr.toString();
		} else {
			// NO Issues
			return "";
		}
	}

	/*-----------------------------------------------------------------------
	 * Action methods 
	 *-----------------------------------------------------------------------
	 */

	/**
	 * Is the monitor allowed to edit. Set boolean to indicate whether the
	 * request came from performance or not.
	 * 
	 * @return if came from performance, the flag is false, otherwise true.
	 */
	public boolean isEditable() {
		return true;
	}

	/*-----------------------------------------------------------------------
	 * Utility methods
	 *-----------------------------------------------------------------------
	 */

	/**
	 * Override deserialization to handle the re-creation of our transient data
	 */
	private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		shipmentDelegate = new ShipmentDelegate();
	}

}
