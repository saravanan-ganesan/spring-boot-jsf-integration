package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Date;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.PerformanceVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * Accessor to get data out of the Performance table based on GROUP_NBR,
 * ACCT_NBR, SHIP_DT(s), ORIG_LOC_CD and DEST_LOC_CD.
 * 
 * @author be379961
 *
 */
public class PerformanceAccessor extends OracleBase {
	private static Logger logger = LogManager.getLogger(PerformanceAccessor.class);

	/**
	 * Constructor.
	 * 
	 * @param con
	 */
    public PerformanceAccessor(Connection con) {
        super(con);
    }
    
    private final String selectPerformanceSQL = "select " +
    "SHIP_DT, " +
    "ACCT_NBR, " +
    "LANE_NBR, " +
    "GROUP_NBR, " +
    "ORIG_CNTRY_CD, " +
    "DEST_CNTRY_CD, " +
    "TOTAL_MAWB_QTY, " +
    "TOTAL_CRN_QTY, " +
    "ON_TIME_CRN_QTY, " +
    "LATE_CRN_QTY, " +
    "EXCUS_CRN_QTY, " +
    "ODA_CRN_QTY, " +   
    "NO_POD_CRN_QTY, " +
    "TOTAL_WGT_AMT, " +
    "TOTAL_INV_VALUE_AMT, " +
    "INPUT_TMSTP " +
     "from Performance where ACCT_NBR = ? and SHIP_DT = ? " +
     "and LANE_NBR = ?"; 
    
    /**
     * Get data from Performance table.
     * 
     * @param acctNbr Account Number
     * @param shipDate Ship Date
     * @param laneNbr Lane Number
     * @return Array of PerformanceVO
     * @throws SQLException 
     */
    public List getPerformance(String acctNbr, Calendar shipDate, int laneNbr) 
    throws SQLException {
        
    	ArrayList al = new ArrayList(); 
        try {
            setSqlSignature( selectPerformanceSQL, false, 
            		logger.isDebugEnabled() );
            
            pstmt.setString( 1, acctNbr);
            
            if (shipDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(shipDate.getTimeInMillis());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            pstmt.setInt( 3, laneNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
                       
            	PerformanceVO performanceVO = new PerformanceVO();
            	fetchPerformanceData(performanceVO);
                al.add(performanceVO);
                
                while(rs.next()) {
                	performanceVO = new PerformanceVO();
                	fetchPerformanceData(performanceVO);
                    al.add(performanceVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    
    private final String selectPerformanceList = "select " +
    "SHIP_DT, " +
    "ACCT_NBR, " +
    "LANE_NBR, " +
    "GROUP_NBR, " +
    "ORIG_CNTRY_CD, " +
    "DEST_CNTRY_CD, " +
    "TOTAL_MAWB_QTY, " +
    "TOTAL_CRN_QTY, " +
    "ON_TIME_CRN_QTY, " +
    "LATE_CRN_QTY, " +
    "EXCUS_CRN_QTY, " +
    "ODA_CRN_QTY, " +   
    "NO_POD_CRN_QTY, " +
    "TOTAL_WGT_AMT, " +
    "TOTAL_INV_VALUE_AMT, " +
    "INPUT_TMSTP " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and LANE_NBR = ? and TOTAL_CRN_QTY > 0"; 
    
    /**
     * Get list of data from Performance table.
     * 
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbr
     * @return
     * @throws SQLException
     */
    public List getPerformanceList(String groupNbr, Date fromDate, Date toDate,
    		int laneNbr) throws SQLException {
    	
        ArrayList al = new ArrayList();         
        try {
            setSqlSignature( selectPerformanceList, false, 
            		logger.isDebugEnabled() );
            
            pstmt.setString( 1, groupNbr);
            
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  3, sqlDate);
            } else {
                pstmt.setNull(  3, java.sql.Types.DATE);
            }
            
            pstmt.setInt( 4, laneNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
                       
            	PerformanceVO performanceVO = new PerformanceVO();
            	fetchPerformanceData(performanceVO);
                al.add(performanceVO);
                
                while(rs.next()) {
                	performanceVO = new PerformanceVO();
                	fetchPerformanceData(performanceVO);
                    al.add(performanceVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    
    private final String selectPerformanceSumAllLanesAllGroupsList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
     "from Performance where SHIP_DT >= ? " +
     "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "; 
    
    private final String selectPerformanceSumAllLanesList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )"; 
    
    private final String selectPerformanceSumList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and LANE_NBR = ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )"; 
	
	//Start WR#:179441 Changes    
    private final String selectPerformanceSumListEmp = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
    "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
    "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "+
    "and acct_nbr in (select acct_nbr from acct_lane_service_monitoring where "+
    "GROUP_NBR= ? and EMP_NBR= ?)"; 
    
    private final String selectPerformanceSumListLaneEmp = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
    "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
    "and SHIP_DT <= ? and LANE_NBR = ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "+
    "and acct_nbr in (select acct_nbr from acct_lane_service_monitoring where "+
    "LANE_NBR = ? and GROUP_NBR= ? and EMP_NBR= ?)"; 
    
    private final String selectPerformanceSumOfAllGroupLaneListByEmp = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
    "from Performance p,(select distinct(acct_nbr),lane_nbr from  acct_lane_service_monitoring a where a.emp_nbr= ?)r " +
    "where p.acct_nbr=r.acct_nbr and p.lane_nbr=r.lane_nbr and "+
    "p.SHIP_DT >= ? and p.SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )";
    
    //End WR#:179441 Changes
    /**
     * Get PerformanceVO of sum data from Performance table for the date range,
     * group number, and lane.
     * @param groupNbr group number of interest
     * @param fromDate from date range
     * @param toDate to date range
     * @param laneNbr of interest
     * @param allLanes true for all lanes query
     * @return
     * @throws SQLException
     */
    //WR#:179441 Changes 
    public PerformanceVO getPerformanceSum(String groupNbr, Date fromDate, 
    		Date toDate, int laneNbr, boolean allLanes ,String empNbr) throws SQLException {
    	
        PerformanceVO performanceVO = new PerformanceVO();          
        try {
        	if(groupNbr.equals("All")){
        		if((allLanes) && (!empNbr.equals("All"))){
        			setSqlSignature( selectPerformanceSumOfAllGroupLaneListByEmp, 
            				false, logger.isDebugEnabled() );
        			pstmt.setString(1, empNbr);
        			if (fromDate != null) {
            			java.sql.Date sqlDate =
            				new java.sql.Date(fromDate.getTime());
            			pstmt.setDate(  2, sqlDate);
            		} else {
            			pstmt.setNull(  2, java.sql.Types.DATE);
            		}
                
            		if (toDate != null) {
            			java.sql.Date sqlDate =
            				new java.sql.Date(toDate.getTime());
            			pstmt.setDate(  3, sqlDate);
            		} else {
            			pstmt.setNull(  3, java.sql.Types.DATE);
            		}
        		}else{
        		setSqlSignature( selectPerformanceSumAllLanesAllGroupsList, 
        				false, logger.isDebugEnabled() );
        		if (fromDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(fromDate.getTime());
        			pstmt.setDate(  1, sqlDate);
        		} else {
        			pstmt.setNull(  1, java.sql.Types.DATE);
        		}
            
        		if (toDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(toDate.getTime());
        			pstmt.setDate(  2, sqlDate);
        		} else {
        			pstmt.setNull(  2, java.sql.Types.DATE);
        		}
        	}
        	}else{
        		if (allLanes){
        			if(empNbr.equalsIgnoreCase("All"))
        			setSqlSignature( selectPerformanceSumAllLanesList, false, 
        				logger.isDebugEnabled() );
        			else{
        				setSqlSignature( selectPerformanceSumListEmp, false, 
                				logger.isDebugEnabled() );
        				pstmt.setString( 4, groupNbr);
        				pstmt.setString( 5, empNbr);
        			}
        		}else{
        			if(empNbr.equalsIgnoreCase("All")){
        			setSqlSignature( selectPerformanceSumList, false, 
        				logger.isDebugEnabled() );
        			pstmt.setInt( 4, laneNbr);
        			}
        			else
        			{
        				setSqlSignature( selectPerformanceSumListLaneEmp, false, 
                				logger.isDebugEnabled() );
        				pstmt.setInt( 4, laneNbr);
        				pstmt.setInt( 5, laneNbr);
        				pstmt.setString( 6, groupNbr);
        				pstmt.setString( 7, empNbr);
        			}
        		}
            
        		pstmt.setString( 1, groupNbr);
            
        		if (fromDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(fromDate.getTime());
        			pstmt.setDate(  2, sqlDate);
        		} else {
        			pstmt.setNull(  2, java.sql.Types.DATE);
        		}
            
        		if (toDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(toDate.getTime());
        			pstmt.setDate(  3, sqlDate);
        		} else {
        			pstmt.setNull(  3, java.sql.Types.DATE);
        		}
        	}
            
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	fetchPerformanceSumData(performanceVO);
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return performanceVO;
    }
    
    private final String selectPerformanceGroupNbrAllLanesSumList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) "; 
    
    /**
     * Get PerformanceVO of sum data from Performance table for the date range,
     * group number, lane, and account number.
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbr
     * @param acctNbr
     * @return
     * @throws SQLException
     */
    public PerformanceVO getPerformanceSum(String groupNbr, Date fromDate, 
    		Date toDate) 
    throws SQLException {
    	
        PerformanceVO performanceVO = new PerformanceVO();       
        try {
        	
        	setSqlSignature(selectPerformanceGroupNbrAllLanesSumList, false, 
                		logger.isDebugEnabled() );
            
            pstmt.setString( 1, groupNbr);
            
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  3, sqlDate);
            } else {
                pstmt.setNull(  3, java.sql.Types.DATE);
            }
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	fetchPerformanceSumData(performanceVO);
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return performanceVO;
    }
    private final String selectPerformanceAcctNbrAllLanesSumList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) " +
     "and ACCT_NBR = ?"; 
    
    private final String selectPerformanceAcctNbrSumList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and ACCT_NBR = ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) " +
     "and LANE_NBR = ?"; 
    //Start WR#:179441 Changes
    private final String selectPerformanceAcctNbrAllGroupLanesByEmpSumList = "select " +
    "SUM(TOTAL_MAWB_QTY) TOTALMAWBQTY, " +
    "SUM(TOTAL_CRN_QTY) TOTALCRNQTY, " +
    "SUM(ON_TIME_CRN_QTY) ONTIMECRNQTY, " +
    "SUM(LATE_CRN_QTY) LATECRNQTY, " +
    "SUM(EXCUS_CRN_QTY) EXCUSCRNQTY, " +
    "SUM(ODA_CRN_QTY) ODACRNQTY, " +   
    "SUM(NO_POD_CRN_QTY) NOPODCRNQTY, " +
    "SUM(TOTAL_WGT_AMT) TOTALWGTAMT, " +
    "SUM(TOTAL_INV_VALUE_AMT) TOTALINVVALUEAMT " +
    "from Performance where SHIP_DT >= ? " +
    "and SHIP_DT <= ? and (TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 ) " +
    "and ACCT_NBR = ? and LANE_NBR = ?"; 
    
    /**
     * Get PerformanceVO of sum data from Performance table for the date range,
     * group number, lane, and account number.
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbr
     * @param acctNbr
     * @return
     * @throws SQLException
     */
    public PerformanceVO getPerformanceSum(String groupNbr, Date fromDate, 
    		Date toDate, int laneNbr, String acctNbr, boolean allLanes) 
    throws SQLException {
    	
        PerformanceVO performanceVO = new PerformanceVO();       
        try {
        	if((groupNbr.equals("All")) && (allLanes)){
        		setSqlSignature(selectPerformanceAcctNbrAllGroupLanesByEmpSumList, false, 
                		logger.isDebugEnabled() );
                
                if (fromDate != null) {
                	java.sql.Date sqlDate =
                		new java.sql.Date(fromDate.getTime());
                    pstmt.setDate(  1, sqlDate);
                } else {
                    pstmt.setNull(  1, java.sql.Types.DATE);
                }
                
                if (toDate != null) {
                	java.sql.Date sqlDate =
                		new java.sql.Date(toDate.getTime());
                    pstmt.setDate(  2, sqlDate);
                } else {
                    pstmt.setNull(  2, java.sql.Types.DATE);
                }
                
                pstmt.setString( 3, acctNbr);
                pstmt.setInt(4, laneNbr);
        	}
        	else if (allLanes){
        		setSqlSignature(selectPerformanceAcctNbrAllLanesSumList, false, 
                		logger.isDebugEnabled() );
        		pstmt.setString( 1, groupNbr);
                
                if (fromDate != null) {
                	java.sql.Date sqlDate =
                		new java.sql.Date(fromDate.getTime());
                    pstmt.setDate(  2, sqlDate);
                } else {
                    pstmt.setNull(  2, java.sql.Types.DATE);
                }
                
                if (toDate != null) {
                	java.sql.Date sqlDate =
                		new java.sql.Date(toDate.getTime());
                    pstmt.setDate(  3, sqlDate);
                } else {
                    pstmt.setNull(  3, java.sql.Types.DATE);
                }
                
                pstmt.setString( 4, acctNbr);
        	}else {
        		setSqlSignature(selectPerformanceAcctNbrSumList, false, 
            		logger.isDebugEnabled());
        		pstmt.setInt( 5, laneNbr);
        		
        		pstmt.setString( 1, groupNbr);
                
                if (fromDate != null) {
                	java.sql.Date sqlDate =
                		new java.sql.Date(fromDate.getTime());
                    pstmt.setDate(  2, sqlDate);
                } else {
                    pstmt.setNull(  2, java.sql.Types.DATE);
                }
                
                if (toDate != null) {
                	java.sql.Date sqlDate =
                		new java.sql.Date(toDate.getTime());
                    pstmt.setDate(  3, sqlDate);
                } else {
                    pstmt.setNull(  3, java.sql.Types.DATE);
                }
                pstmt.setString( 4, acctNbr);
        	}//End WR#:179441 Changes
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	fetchPerformanceSumData(performanceVO);
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return performanceVO;
    }
    
    private final String selectPerformanceGroupNbrAllLanes = "select " +
    "distinct GROUP_NBR from Performance where SHIP_DT >= ? and SHIP_DT <= ? " + 
    " and TOTAL_CRN_QTY > 0";
    
    /**
     * Get PerformanceVO of Group Number data from Performance table for a date 
     * range.
     * 
     * @param fromDate
     * @param toDate
     * @return
     * @throws SQLException
     */
    public List getPerformanceGroupNbrList(Date fromDate, Date toDate) 
    	throws SQLException {
    	
    	ArrayList al = new ArrayList();      
        try {
        	
        	setSqlSignature(selectPerformanceGroupNbrAllLanes, false, 
        				logger.isDebugEnabled());
        	
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  1, sqlDate);
            } else {
                pstmt.setNull(  1, java.sql.Types.DATE);
            }
            
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	PerformanceVO performanceVO = new PerformanceVO();
            	performanceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                al.add(performanceVO);
                
                while(rs.next()) {
                	performanceVO = new PerformanceVO();
                	performanceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    al.add(performanceVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    } 
    private final String selectPerformanceAcctNbrAllLanes = "select " +
    "distinct ACCT_NBR " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and TOTAL_CRN_QTY > 0";
    //Start WR#:179441 Changes
    private final String selectPerformanceAcctNbrAllLanesEmp = "select " +
    "distinct ACCT_NBR " +
    "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
    "and SHIP_DT <= ? and TOTAL_CRN_QTY > 0 " +
    "and acct_nbr in (select acct_nbr from acct_lane_service_monitoring where "+
    "GROUP_NBR= ? and EMP_NBR= ?)"; 
    private final String selectPerformanceAcctNbrAllGrpLanesEmp = "select "+
    "distinct(p.ACCT_NBR),p.LANE_NBR,p.GROUP_NBR "+
    "from Performance p, "+
    "(select distinct(ACCT_NBR),LANE_NBR from  acct_lane_service_monitoring a where a.emp_nbr= ?)r "+
    "where p.ACCT_NBR=r.ACCT_NBR and p.LANE_NBR=r.LANE_NBR and "+
    "p.SHIP_DT >= ? and "+
    "p.SHIP_DT <= ? and "+
    "(TOTAL_CRN_QTY > 0 or TOTAL_MAWB_QTY > 0 )";
    //End WR#:179441 Changes
    private final String selectPerformanceAcctNbr = "select " +
    "distinct ACCT_NBR " +
     "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
     "and SHIP_DT <= ? and LANE_NBR = ? and TOTAL_CRN_QTY > 0";
    
    //Start WR#:179441 Changes
    private final String selectPerformanceAcctNbrLaneEmp = "select " +
    "distinct ACCT_NBR " +
    "from Performance where GROUP_NBR = ? and SHIP_DT >= ? " +
    "and SHIP_DT <= ? and LANE_NBR = ?  and TOTAL_CRN_QTY > 0" +
    "and acct_nbr in (select acct_nbr from acct_lane_service_monitoring where "+
    " LANE_NBR = ? and GROUP_NBR= ? and EMP_NBR= ?)"; 
    //End WR#:179441 Changes
    /**
     * Get PerformanceVO of sum data from Performance table for a date range 
     * grouped by account number.
     * 
     * @param groupNbr
     * @param fromDate
     * @param toDate
     * @param laneNbr
     * @return
     * @throws SQLException
     */
    //WR#:179441 Changes 
    public List getPerformanceAcctNbrList(String groupNbr, Date fromDate, 
    		Date toDate, int laneNbr, boolean allLanes, String empNbr) throws SQLException {
    	ArrayList al = new ArrayList();      
        try {
        	if (allLanes){
        		if(empNbr.equalsIgnoreCase("All"))
        		setSqlSignature(selectPerformanceAcctNbrAllLanes, false, 
        				logger.isDebugEnabled());
        		else{
        		setSqlSignature(selectPerformanceAcctNbrAllLanesEmp, false, 
            				logger.isDebugEnabled());
        		pstmt.setString( 4, groupNbr);
        		pstmt.setString( 5, empNbr);
        		}
        	}else{
        		if(empNbr.equalsIgnoreCase("All")){
        		setSqlSignature(selectPerformanceAcctNbr, false, 
        				logger.isDebugEnabled());
        		pstmt.setInt( 4, laneNbr);
        		}else
        		{
        		setSqlSignature(selectPerformanceAcctNbrLaneEmp, false, 
            				logger.isDebugEnabled());
        		pstmt.setInt( 4, laneNbr);
        		pstmt.setInt( 5, laneNbr);
        		pstmt.setString( 6, groupNbr);
        		pstmt.setString( 7, empNbr);
        		}
        	}
            
            pstmt.setString( 1, groupNbr);
            
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  3, sqlDate);
            } else {
                pstmt.setNull(  3, java.sql.Types.DATE);
            }
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	PerformanceVO performanceVO = new PerformanceVO();
            	performanceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                al.add(performanceVO);
                
                while(rs.next()) {
                	performanceVO = new PerformanceVO();
                	performanceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                    al.add(performanceVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
    //Start WR#:179441 Changes
    public List getPerformanceAcctNbrListByEmp(String groupNbr, Date fromDate, 
    		Date toDate, int laneNbr, boolean allLanes, String empNbr) throws SQLException {
    	ArrayList al = new ArrayList();      
        try {
        	
        	setSqlSignature(selectPerformanceAcctNbrAllGrpLanesEmp, false, 
        				logger.isDebugEnabled());
        	pstmt.setString(1, empNbr);
        	
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  3, sqlDate);
            } else {
                pstmt.setNull(  3, java.sql.Types.DATE);
            }
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if (hasResults & rs.next()) {
            	PerformanceVO performanceVO = new PerformanceVO();
            	performanceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
            	performanceVO.set_lane_nbr(rs.getInt("LANE_NBR"));
            	performanceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                al.add(performanceVO);
                
                while(rs.next()) {
                	performanceVO = new PerformanceVO();
                	performanceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
                	performanceVO.set_lane_nbr(rs.getInt("LANE_NBR"));
                	performanceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    al.add(performanceVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }//End WR#:179441 Changes
    private final String selectShipmentViaAcctNbrLaneShipDateSQL = "select " +
    "SHPMT_TYPE_CD, " +
    "PERF_RSULT_CD, " +
    "SHPMT_WGT, " +
    "SHPMT_UOM_CD, " +
    "GROUP_NBR, " +
    "ACCT_NBR, " +
    "LANE_NBR," +
    "SHIP_DT," +
    "SHPR_CNTRY_CD," +
    "RECP_CNTRY_CD," +
    "INV_AMT, " + 
    "ADJ_COMMIT_DT_OFFST_NBR " +
     "from Shipment where GROUP_NBR = ? and ACCT_NBR = ? and LANE_NBR = ? " +
     " and SHIP_DT = ? "; 
    /**
     * Get a list of performance data from the shipment table, based on the 
     * group number, account number, lane number and shipdate.
     * @param anAccountLaneVO contains the group, account and lane numbers.
     * @param shipDate The ship date.
     * @return
     * @throws SQLException
     */
    public List getShipmentViaAcctNbrLaneShipDate(AccountLaneVO anAccountLaneVO, 
    		Calendar shipDate) throws SQLException {
    	
        ArrayList al = new ArrayList();
        try {
            setSqlSignature( selectShipmentViaAcctNbrLaneShipDateSQL, false, 
            		logger.isDebugEnabled() );

            pstmt.setInt( 1, anAccountLaneVO.get_group_nbr());
            pstmt.setString( 2, anAccountLaneVO.get_acct_nbr());
            pstmt.setInt( 3, anAccountLaneVO.get_lane_nbr());
            
            if (shipDate != null) {
            	java.sql.Date sqlDate =
                	new java.sql.Date(shipDate.getTime().getTime());
                pstmt.setDate(  4, sqlDate);
            } else {
                pstmt.setNull(  4, java.sql.Types.DATE);
            }
            
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            if ( hasResults && rs.next() ) { 
            	ShipmentVO shipmentVO = new ShipmentVO();	
            	fetchShipmentData(shipmentVO);
        		al.add(shipmentVO);  //TODO: Why is this here, and verify why is this here.
        		
            	while (rs.next()) {            
            		// shipment found
            		shipmentVO = new ShipmentVO();
            		fetchShipmentData(shipmentVO);
            		al.add(shipmentVO);
            	}
            } else {
                // shipment not found
            	if (logger.isDebugEnabled()) {
            		logger.debug("Shipment not found");
            	}
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " 
            		+ sqle.getSQLState() + "; ErrorCode: " 
            		+ sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    } 
    
    private static final String SQLShipmentAllColumns = "select " +
    "TRKNG_ITEM_NBR, " +
    "TRKNG_ITEM_UNIQ_NBR, " +
    "GROUP_NBR, " +
    "ACCT_NBR, " +
    "LANE_NBR," +
    "SVC_TYPE_CD, " +
    "SHPMT_TYPE_CD, " +
    "TRKNG_ITEM_FORM_CD, " +
    "PACK_TYPE_CD, " +
    "ORIG_LOC_CD, " +
    "DEST_LOC_CD, " +
    "SHPMT_WGT, " +
    "SHPMT_UOM_CD, " +
    "SHIP_DT, " +
    "SHPR_CO_NM, " +
    "SHPR_PH_NBR, " +
    "SHPR_ADDR_LINE_ONE_DESC, " +
    "SHPR_ADDR_LINE_TWO_DESC, " +
    "SHPR_ADDR_LINE_THREE_DESC, " +
    "SHPR_CITY_NM, " +
    "SHPR_PSTL_CD, " +
    "SHPR_CNTRY_CD, " +
    "SHPR_ST_PROV_CD, " +
    "RECP_CO_NM, " +
    "RECP_PH_NBR, " +
    "RECP_ADDR_LINE_ONE_DESC, " +
    "RECP_ADDR_LINE_TWO_DESC, " +
    "RECP_ADDR_LINE_THREE_DESC, " +
    "RECP_CITY_NM, " +
    "RECP_ST_PROV_CD, " +
    "RECP_CNTRY_CD, " +
    "RECP_PSTL_CD, " +
    "ACTL_DEL_NM, " +
    "ACTL_ADDR_LINE_ONE_DESC, " +
    "DEL_DT, " +
    "DEL_DATE_TMZN_OFFST_NBR, " +
    "SPCL_HNDLG_GRP, " +
    "CRTG_AGENT_CO_NM, " +
    "CSTMS_CURR_CD, " +
    "CSTMS_VALUE_AMT, " +
    "DIMNL_WGT, " +
    "INV_AMT, " +
    "SHPMT_PKG_QTY, " +
    "LAST_EVENT_TMSTP, " +
    "LAST_EVENT_TMZN_OFFST_NBR, " +
    "LAST_EVENT_TRACK_TYPE_CD, " +
    "COMMIT_DT, " +
    "ADJ_COMMIT_DT, " +
    "COMMIT_DATE_TMZN_OFFST_NBR, " +
    "ADJ_COMMIT_DT_OFFST_NBR, " +
    "PERF_RSULT_CD, " +
    "INPUT_TMSTP, " +
    "LAST_UPDT_TMSTP, " +
    "DEL_QTY, " +
    "SKID_INTACT_FLG, " +
    "QTY_OBSER_FLG, " + 
    "PKG_PIECE_QTY, " +
    "LAST_STAT_DESC, " +
    "LAST_EVENT_TRACK_LOC_CD ";
    
    /*
     * CRN methods 
     */
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQL = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQL = 
       "   ) row_ " + " where rownum <= ? " +
       " ) " +
       "where rownum_ > ?";
      
    /** Get CRNs */
    private final static String selectCRNShipmentPagingSQL =    
		" from SHIPMENT " + 
		" where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
		" and PERF_RSULT_CD = ? and LANE_NBR = ? and SHPMT_TYPE_CD = 'CRN' ";
    
    private final static String selectCRNShipmentAllLanesPagingSQL = 
    	" from SHIPMENT " + 
        " where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
        " and PERF_RSULT_CD = ? and SHPMT_TYPE_CD = 'CRN' ";
    
    private final static String selectCRNShipmentAllLanesNoPODPagingSQL =    
    	" from SHIPMENT " + 
    	" where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
    	" and PERF_RSULT_CD is null and SHPMT_TYPE_CD = 'CRN' ";
    
    private final static String selectCRNShipmentNoPODPagingSQL =    
    	" from SHIPMENT " + 
    	" where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
    	" and PERF_RSULT_CD is null and LANE_NBR = ? and SHPMT_TYPE_CD = 'CRN'";
    
    private final static String orderByTrkngItemNbrSQL =  " order by TRKNG_ITEM_NBR ";
    private final static String orderByCommitDtSQL =  " order by COMMIT_DT ";
    private final static String orderByDestSQL =  " order by DEST_LOC_CD ";
    private final static String orderByLastStatusSQL =  " order by LAST_STAT_DESC ";
    private final static String orderByRecipSQL =  " order by RECP_CO_NM ";
    
    /**
     * Get a shipment list from the shipment table of CRNS that meet the 
     * criteria below.
     * 
     * @param acctNbr The account number of interest.
     * @param fromDate The ship date from range.
     * @param toDate The ship date to range.
     * @param laneNbr The lane number of interest.
     * @param allLanes interested in all lanes. true for all.
     * @param performanceType the performance type of interest.
     * @return list of shipments.
     * @throws SQLException
     */
    public List getCRNShipments(String acctNbr, Date fromDate, Date toDate, 
    		int laneNbr, boolean allLanes, String performanceType, 
    		int startIndex, int endIndex, String sortColumn, 
    		boolean isSortAscending) 
    			throws SQLException {    
    	ArrayList al = new ArrayList();

    	try {
    		StringBuffer sql = new StringBuffer();
    		
    		// append starting SQL for paging results
            sql.append(PREpagedSQL).append(SQLShipmentAllColumns);
            
    		if (allLanes){
    			if (performanceType.equals("NOPOD")){
    				sql.append(selectCRNShipmentAllLanesNoPODPagingSQL);
    				
    	            // append correct "order by"
    	            if ("trkng_item_nbr".equals(sortColumn)) {
    	                sql.append(orderByTrkngItemNbrSQL);
    	            } else if ("recp_co_nm".equals(sortColumn)) {
    	                sql.append(orderByRecipSQL);
    	            } else if ("dest_loc_cd".equals(sortColumn)) {
    	                sql.append(orderByDestSQL);
    	            } else if ("status".equals(sortColumn)) {
    	                sql.append(orderByLastStatusSQL);
    	            } else if ("commit_dt".equals(sortColumn)) {
    	                sql.append(orderByCommitDtSQL);
    	            } else
    	                sql.append(orderByTrkngItemNbrSQL);
    	            
    				// append descending sort, if necessary
    	            if (!isSortAscending)
    	                sql.append(" DESC ");
    	            
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );
    				pstmt.setInt( 4, endIndex);
    	            pstmt.setInt( 5, startIndex);
    			}else{
    				sql.append(selectCRNShipmentAllLanesPagingSQL);	
    				
    				// append correct "order by"
    	            if ("trkng_item_nbr".equals(sortColumn)) {
    	                sql.append(orderByTrkngItemNbrSQL);
    	            } else if ("recp_co_nm".equals(sortColumn)) {
    	                sql.append(orderByRecipSQL);
    	            } else if ("dest_loc_cd".equals(sortColumn)) {
    	                sql.append(orderByDestSQL);
    	            } else if ("status".equals(sortColumn)) {
    	                sql.append(orderByLastStatusSQL);
    	            } else if ("commit_dt".equals(sortColumn)) {
    	                sql.append(orderByCommitDtSQL);
    	            } else
    	                sql.append(orderByTrkngItemNbrSQL);
    	            
    				// append descending sort, if necessary
    	            if (!isSortAscending)
    	                sql.append(" DESC ");
    	            
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );
    				pstmt.setString( 4, performanceType);
    	            pstmt.setInt( 5, endIndex);
    	            pstmt.setInt( 6, startIndex);
    			}
        		
        	}else{
        		if (performanceType.equals("NOPOD")){
        			sql.append(selectCRNShipmentNoPODPagingSQL);
        			
        			// append correct "order by"
    	            if ("trkng_item_nbr".equals(sortColumn)) {
    	                sql.append(orderByTrkngItemNbrSQL);
    	            } else if ("recp_co_nm".equals(sortColumn)) {
    	                sql.append(orderByRecipSQL);
    	            } else if ("dest_loc_cd".equals(sortColumn)) {
    	                sql.append(orderByDestSQL);
    	            } else if ("status".equals(sortColumn)) {
    	                sql.append(orderByLastStatusSQL);
    	            } else if ("commit_dt".equals(sortColumn)) {
    	                sql.append(orderByCommitDtSQL);
    	            } else
    	                sql.append(orderByTrkngItemNbrSQL);
    	            
    				// append descending sort, if necessary
    	            if (!isSortAscending)
    	                sql.append(" DESC ");
    	            
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );
        			pstmt.setInt( 4, laneNbr);
        			pstmt.setInt( 5, endIndex);
        	        pstmt.setInt( 6, startIndex);
        		}else{
        			sql.append(selectCRNShipmentPagingSQL);
        			
        			// append correct "order by"
    	            if ("trkng_item_nbr".equals(sortColumn)) {
    	                sql.append(orderByTrkngItemNbrSQL);
    	            } else if ("recp_co_nm".equals(sortColumn)) {
    	                sql.append(orderByRecipSQL);
    	            } else if ("dest_loc_cd".equals(sortColumn)) {
    	                sql.append(orderByDestSQL);
    	            } else if ("status".equals(sortColumn)) {
    	                sql.append(orderByLastStatusSQL);
    	            } else if ("commit_dt".equals(sortColumn)) {
    	                sql.append(orderByCommitDtSQL);
    	            } else
    	                sql.append(orderByTrkngItemNbrSQL);
    	            
    				// append descending sort, if necessary
    	            if (!isSortAscending)
    	                sql.append(" DESC ");
    	            
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );
            		pstmt.setString( 4, performanceType);
            		pstmt.setInt( 5, laneNbr);
            		pstmt.setInt( 6, endIndex);
        	        pstmt.setInt( 7, startIndex);
        		}
        	}

    		pstmt.setString( 1, acctNbr);
    		
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  3, sqlDate);
            } else {
                pstmt.setNull(  3, java.sql.Types.DATE);
            }
            

    		if (logger.isDebugEnabled()) {
    			logger.debug(pstmt.toString());
    		}

    		execute();

    		if (hasResults) {
    			while (rs.next()) {        
    				// shipment found
    				ShipmentVO shipmentVO = new ShipmentVO();
    				fetchAllShipmentColumns(shipmentVO);
    				al.add(shipmentVO);
    			}                
    		} else {
    			// shipment not found
    			if (logger.isDebugEnabled()) {
    				logger.debug("Shipment not found");
    			}
    			return null;
    		}   
    	} catch (SQLException sqle) {
    		logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
    				+ "; ErrorCode: " + sqle.getErrorCode());
    		throw sqle;
    	} finally {
    		try {
    			cleanResultSet();
    		} catch (SQLException sqle2) {
    			logger.warn(sqle2.getMessage(), sqle2);
    		}
    	}
    	return al;
    }
    
    private final String selectCRNShipmentCountSQL = "select count(*) count " +   
    "from SHIPMENT " + 
    "Shipment where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
    " and PERF_RSULT_CD = ? and LANE_NBR = ? and SHPMT_TYPE_CD = 'CRN'";
    
    private final String selectCRNShipmentAllLanesCountSQL = 
    "select count(*) count " +   
    "from SHIPMENT " + 
    "Shipment where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
    " and PERF_RSULT_CD = ? and SHPMT_TYPE_CD = 'CRN'";
    
    private final String selectCRNShipmentNoPODCountSQL = 
    "select count(*) count " +   
    "from SHIPMENT " + 
    "Shipment where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
    " and PERF_RSULT_CD is null and LANE_NBR = ? and SHPMT_TYPE_CD = 'CRN'";
    
    private final String selectCRNShipmentAllLanesNoPODCountSQL = 
    "select count(*) count " +   
    "from SHIPMENT " + 
    "Shipment where ACCT_NBR = ? and SHIP_DT >= ? and SHIP_DT <= ? " + 
    " and PERF_RSULT_CD is null and SHPMT_TYPE_CD = 'CRN'";
    
    /**
     * Get a shipment list from the shipment table of CRNS that meet the 
     * criteria below.
     * 
     * @param acctNbr The account number of interest.
     * @param fromDate The ship date from range.
     * @param toDate The ship date to range.
     * @param laneNbr The lane number of interest.
     * @param allLanes interested in all lanes. true for all.
     * @param performanceType the performance type of interest.
     * @return list of shipments.
     * @throws SQLException
     */
    public int getShipmentsCount(String acctNbr, Date fromDate, Date toDate, 
    		int laneNbr, boolean allLanes, String performanceType) 
    			throws SQLException {    
    	int count = 0;

    	try {
    		if (allLanes){
    			if (performanceType.equals("NOPOD")){
    				setSqlSignature(selectCRNShipmentAllLanesNoPODCountSQL, 
    						false, logger.isDebugEnabled());
    			}else{
    				setSqlSignature(selectCRNShipmentAllLanesCountSQL, false, 
            				logger.isDebugEnabled());
        				pstmt.setString( 4, performanceType);
    			}
        		
        	}else{
        		if (performanceType.equals("NOPOD")){
        			setSqlSignature(selectCRNShipmentNoPODCountSQL, false, 
            				logger.isDebugEnabled());
        			pstmt.setInt( 4, laneNbr);
        		}else{
        			setSqlSignature(selectCRNShipmentCountSQL, false, 
            				logger.isDebugEnabled());
            			pstmt.setString( 4, performanceType);
            			pstmt.setInt( 5, laneNbr);
        		}
        	}

    		pstmt.setString( 1, acctNbr);
    		
            if (fromDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(fromDate.getTime());
                pstmt.setDate(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.DATE);
            }
            
            if (toDate != null) {
            	java.sql.Date sqlDate =
            		new java.sql.Date(toDate.getTime());
                pstmt.setDate(  3, sqlDate);
            } else {
                pstmt.setNull(  3, java.sql.Types.DATE);
            }
            

    		if (logger.isDebugEnabled()) {
    			logger.debug(pstmt.toString());
    		}

    		execute();

    		if (hasResults) {
    			if (rs.next()) {        
    				count = rs.getInt("COUNT");
    			}                
    		} else {
    			// shipment not found
    			if (logger.isDebugEnabled()) {
    				logger.debug("Shipment not found");
    			}
    			return count;
    		}   
    	} catch (SQLException sqle) {
    		logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState()
    				+ "; ErrorCode: " + sqle.getErrorCode());
    		throw sqle;
    	} finally {
    		try {
    			cleanResultSet();
    		} catch (SQLException sqle2) {
    			logger.warn(sqle2.getMessage(), sqle2);
    		}
    	}
    	return count;
    }
    
    /**
     * Fetch ShipmentVO data from the shipment table
     * @param shipmentVO
     * @throws SQLException
     */
    private void fetchShipmentData(ShipmentVO shipmentVO) throws SQLException {
    	shipmentVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
		shipmentVO.set_perf_rsult_cd(rs.getString("PERF_RSULT_CD"));
		shipmentVO.set_shpmt_wgt(rs.getInt("SHPMT_WGT"));
		shipmentVO.set_shpmt_uom_cd(rs.getString("SHPMT_UOM_CD").charAt(0));
		shipmentVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
		shipmentVO.set_acct_nbr(rs.getString("ACCT_NBR"));
		shipmentVO.set_lane_nbr(rs.getInt("LANE_NBR"));
		shipmentVO.set_ship_dt((rs.getDate("SHIP_DT")));
		shipmentVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
		shipmentVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
		shipmentVO.set_inv_amt(rs.getInt("INV_AMT"));
		shipmentVO.set_adj_commit_dt_offst_nbr(
				rs.getInt("ADJ_COMMIT_DT_OFFST_NBR"));
    }
    
    /**
     * Fetch PerformanceVO data from the performance table.
     * @param performanceVO
     * @throws SQLException
     */
    private void fetchPerformanceData(PerformanceVO performanceVO) 
    	throws SQLException {
    	performanceVO.set_group_nbr(rs.getInt("GROUP_NBR"));
    	performanceVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	performanceVO.set_acct_nbr(rs.getString("LANE_NBR"));
    	Date rprtDt = (java.util.Date)rs.getTimestamp("SHIP_DT");
        if (rprtDt != null) {
            Calendar accptDtCalendar = Calendar.getInstance();
            accptDtCalendar.setTime(rprtDt);
            performanceVO.set_ship_dt(accptDtCalendar);
        }
    	performanceVO.set_orig_cntry_cd(rs.getString("ORIG_CNTRY_CD"));
    	performanceVO.set_dest_cntry_cd(rs.getString("DEST_CNTRY_CD"));
    	performanceVO.set_total_mawb_qty(
    			rs.getLong("TOTAL_MAWB_QTY"));
    	performanceVO.set_total_crn_qty(rs.getLong("TOTAL_CRN_QTY"));
    	performanceVO.set_on_time_crn_qty(
    			rs.getLong("ON_TIME_CRN_QTY"));
    	performanceVO.set_late_crn_qty(rs.getLong("LATE_CRN_QTY"));
    	performanceVO.set_excus_crn_qty(rs.getLong("EXCUS_CRN_QTY"));
    	performanceVO.set_oda_crn_qty(rs.getLong("ODA_CRN_QTY"));
    	performanceVO.set_no_pod_crn_qty(
    			rs.getLong("NO_POD_CRN_QTY"));
    	performanceVO.set_total_wgt_amt(rs.getLong("TOTAL_WGT_AMT"));
    	performanceVO.set_total_inv_value_amt(
    			rs.getLong("TOTAL_INV_VALUE_AMT"));
    	performanceVO.set_input_tmstp(rs.getDate("INPUT_TMSTP"));
    }
    
    /**
     * Fetch summed PerformanceVO data from Performance table.
     * @param performanceVO
     * @throws SQLException
     */
    private void fetchPerformanceSumData(PerformanceVO performanceVO) 
    	throws SQLException {
    	performanceVO.set_total_mawb_qty(
    			rs.getLong("TOTALMAWBQTY"));
    	performanceVO.set_total_crn_qty(rs.getLong("TOTALCRNQTY"));
    	performanceVO.set_on_time_crn_qty(
    			rs.getLong("ONTIMECRNQTY"));
    	performanceVO.set_late_crn_qty(rs.getLong("LATECRNQTY"));
    	performanceVO.set_excus_crn_qty(rs.getLong("EXCUSCRNQTY"));
    	performanceVO.set_oda_crn_qty(rs.getLong("ODACRNQTY"));
    	performanceVO.set_no_pod_crn_qty(
    			rs.getLong("NOPODCRNQTY"));
    	performanceVO.set_total_wgt_amt(rs.getLong("TOTALWGTAMT"));
    	performanceVO.set_total_inv_value_amt(
    			rs.getLong("TOTALINVVALUEAMT"));
    }
    /**
     * Fetch ShipmentVO data from Shipment table.
     * @param shipmentVO
     * @throws SQLException
     */
    private void fetchAllShipmentColumns(ShipmentVO shipmentVO) throws SQLException {
        shipmentVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
        shipmentVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
        shipmentVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
        shipmentVO.set_acct_nbr(rs.getString("ACCT_NBR"));
        shipmentVO.set_lane_nbr(rs.getInt("LANE_NBR"));
        shipmentVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
        shipmentVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
        shipmentVO.set_trkng_item_form_cd(rs.getInt("TRKNG_ITEM_FORM_CD"));
        shipmentVO.set_pack_type_cd(rs.getInt("PACK_TYPE_CD"));
        shipmentVO.set_orig_loc_cd(rs.getString("ORIG_LOC_CD"));
        shipmentVO.set_dest_loc_cd(rs.getString("DEST_LOC_CD"));
        shipmentVO.set_shpmt_wgt(rs.getInt("SHPMT_WGT"));
        shipmentVO.set_shpmt_uom_cd(rs.getString("SHPMT_UOM_CD").charAt(0));
        
        Date shipDt = (java.util.Date)rs.getTimestamp("SHIP_DT");
        shipmentVO.set_ship_dt(shipDt);
        
        shipmentVO.set_shpr_co_nm(rs.getString("SHPR_CO_NM"));
        shipmentVO.set_shpr_ph_nbr(rs.getString("SHPR_PH_NBR"));
        shipmentVO.set_shpr_addr_line_one_desc(rs.getString("SHPR_ADDR_LINE_ONE_DESC"));
        shipmentVO.set_shpr_addr_line_two_desc(rs.getString("SHPR_ADDR_LINE_TWO_DESC"));
        shipmentVO.set_shpr_addr_line_three_desc(rs.getString("SHPR_ADDR_LINE_THREE_DESC"));
        shipmentVO.set_shpr_city_nm(rs.getString("SHPR_CITY_NM"));
        shipmentVO.set_shpr_pstl_cd(rs.getString("SHPR_PSTL_CD"));
        shipmentVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
        shipmentVO.set_shpr_st_prov_cd(rs.getString("SHPR_ST_PROV_CD"));
        shipmentVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
        shipmentVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
        shipmentVO.set_recp_addr_line_one_desc(rs.getString("RECP_ADDR_LINE_ONE_DESC"));
        shipmentVO.set_recp_addr_line_two_desc(rs.getString("RECP_ADDR_LINE_TWO_DESC"));
        shipmentVO.set_recp_addr_line_three_desc(rs.getString("RECP_ADDR_LINE_THREE_DESC"));
        shipmentVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
        shipmentVO.set_recp_st_prov_cd(rs.getString("RECP_ST_PROV_CD"));
        shipmentVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
        shipmentVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
        shipmentVO.set_actl_del_nm(rs.getString("ACTL_DEL_NM"));
        shipmentVO.set_actl_addr_line_one_desc(rs.getString("ACTL_ADDR_LINE_ONE_DESC"));
        
        Date delDtTmstp = (java.util.Date)rs.getTimestamp("DEL_DT");
        if (delDtTmstp != null) {
            String deldtTmstpTzOffset = rs.getString("DEL_DATE_TMZN_OFFST_NBR");
            TimeZone delDtTz = TimeZone.getTimeZone("GMT" + deldtTmstpTzOffset);
            Calendar delDtCalendar = Calendar.getInstance(delDtTz); 
            delDtCalendar.setTime(delDtTmstp);
            shipmentVO.set_del_dt(delDtCalendar);
        }
        
        shipmentVO.set_spcl_hndlg_grp(rs.getString("SPCL_HNDLG_GRP"));
        shipmentVO.set_crtg_agent_co_nm(rs.getString("CRTG_AGENT_CO_NM"));
        shipmentVO.set_cstms_curr_cd(rs.getString("CSTMS_CURR_CD"));
        shipmentVO.set_cstms_value_amt(rs.getInt("CSTMS_VALUE_AMT"));
        shipmentVO.set_dimnl_wgt(rs.getInt("DIMNL_WGT"));
        shipmentVO.set_inv_amt(rs.getInt("INV_AMT"));
        shipmentVO.set_shpmt_pkg_qt(rs.getInt("SHPMT_PKG_QTY"));
        
        Date lastEventTmstp = (java.util.Date)rs.getTimestamp("LAST_EVENT_TMSTP");
        if (lastEventTmstp != null) {
            String lastEventTmstpTzOffset = rs.getString("LAST_EVENT_TMZN_OFFST_NBR");
            TimeZone lastEventTz= TimeZone.getTimeZone("GMT" + lastEventTmstpTzOffset);
            Calendar lastEventCalendar = Calendar.getInstance(lastEventTz); 
            lastEventCalendar.setTime(lastEventTmstp);
            shipmentVO.set_last_event_tmstp(lastEventCalendar);
        }
        
        shipmentVO.set_last_event_track_type_cd(rs.getString("LAST_EVENT_TRACK_TYPE_CD"));
        
        TimeZone commitDtTz = null;
        Date commitDt = (java.util.Date)rs.getTimestamp("COMMIT_DT");
        if (commitDt != null) {
            String commitDtTzOffset = rs.getString("COMMIT_DATE_TMZN_OFFST_NBR");
            commitDtTz = TimeZone.getTimeZone("GMT" + commitDtTzOffset);
            Calendar commitCalendar = Calendar.getInstance(commitDtTz);
            commitCalendar.setTime(commitDt);
            shipmentVO.set_commit_dt(commitCalendar);
        }
        
        Date adjCommitDt = null;
        adjCommitDt = (java.util.Date)rs.getTimestamp("ADJ_COMMIT_DT");
        if (adjCommitDt != null && commitDtTz !=null) {
            Calendar adjCommitCalendar = Calendar.getInstance(commitDtTz);
            adjCommitCalendar.setTime(adjCommitDt);
            shipmentVO.set_adj_commit_dt(adjCommitCalendar);
        }
        
        shipmentVO.set_adj_commit_dt_offst_nbr(rs.getInt("ADJ_COMMIT_DT_OFFST_NBR"));
        
        shipmentVO.set_perf_rsult_cd(rs.getString("PERF_RSULT_CD"));
        
        shipmentVO.set_delivery_qty(rs.getInt("DEL_QTY"));
        String skidIntactFlg = rs.getString("SKID_INTACT_FLG");
        if (skidIntactFlg != null) {
            shipmentVO.set_skid_intact_flag(skidIntactFlg.charAt(0));
        }
        
        String qtyObserFlg = rs.getString("QTY_OBSER_FLG");
        if (qtyObserFlg != null) {
            shipmentVO.set_quantity_observed_flag(qtyObserFlg.charAt(0));
        }
        
        shipmentVO.set_package_piece_qty(rs.getInt("PKG_PIECE_QTY"));
               
        shipmentVO.set_last_stat_desc(rs.getString("LAST_STAT_DESC"));
        shipmentVO.set_last_event_track_loc_cd(rs.getString("LAST_EVENT_TRACK_LOC_CD"));
        //shipmentVO.set_input_tmstp((java.util.Date)rs.getTimestamp("INPUT_TMSTP"));
        //shipmentVO.set_last_updt_tmstp((java.util.Date)rs.getTimestamp("LAST_UPDT_TMSTP"));

    }
}
