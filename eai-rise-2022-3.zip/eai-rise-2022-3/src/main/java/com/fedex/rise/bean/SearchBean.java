package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.format.LaneFormatter;
import com.fedex.rise.vo.LaneVO;

@JsfController(path = "/findShipper", page = "/pages/jsp/findShipperAccountNumber.jsp", value = "SearchBean")
public class SearchBean implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;

    /** logger */
    private static final Log log = LogFactory.getLog(SearchBean.class);

    private transient ShipperDelegate shipperDelegate = new ShipperDelegate();

    /** Search for Shipper */
    public static String trackingNbr = null;
    public static String acctNbr = null;
    public static String acctNbr2 = null;
    public static String shprNm = null;
    public static String referenceNbr = null;
    public static String trackingNbrMAWB = null;
    public static String trackingNbrMAWB2 = null;
    public static String acctNbrMAWB = null;
    public static String acctNbrMAWB2 = null;
    public static String acctNbrMAWB3 = null;
    public static String acctNmMAWB = null;
    public static String issueCodeCRN = null;
    public static String acctNbrCRN = null;
    public static String returnTrkngNbr = null;
    public static String searchFailed = null;
    public static String recipientName = null;
    public static String laneNbrMAWB = null;
    public static String serviceCode = null;
    public static String laneNbrMAWB2 = null;
    public static String serviceCode2 = null;
    public static String postalCode = null;
    public static String trackingNbrCRN = null;
    public static String addressLineOne = null;
    public static String addressCityName = null;
    public static String addressStateProvince = null;
    public static String addressPostalCode = null;
    public static String returnTrackingNumberMenu = null;
    public static String referenceNumberMenu = new String("SHR");
    private String _selectedIssueCode = null;
    public static String _selectedLane = null;
    public static String _selectedLane2 = null;
    private List _allLanes = new ArrayList();
    private String _originCountryCd = null;
    private String _destCountryCd = null;
    public static Date _shipDate = null;
    public static Date _fromDate = null;
    public static Date _fromDate2 = null;
    public static Date _fromDate3 = null;
    public static Date _fromDate4 = null;
    public static Date _fromDate5 = null;
    public static Date _fromDateFindPackagesDateRange = null;
    public static Date _toDate = null;
    public static Date _toDate2 = null;
    public static Date _toDate3 = null;
    public static Date _toDate4 = null;
    public static Date _toDate5 = null;

    public static String clearancePoint = null;
	private String _selectMenu =  "CA";   
    
	
	
	public static Date _limitOneWeekToDateByCRNRecipientName = null;
	public static Date _limitOneWeekFromDateByCRNRecipientName = null;
	public static Date _limitOneWeekToDateByCRNRecipientPostalCode = null;
	public static Date _limitOneWeekFromDateByCRNRecipientPostalCode = null;
	public static Date _limitOneWeekToDateByCRNWithODA = null;
	public static Date _limitOneWeekFromDateByCRNWithODA = null;
	public static Date _limitOneWeekToDateByCRNRecipientAddress = null;
	public static Date _limitOneWeekFromDateByCRNRecipientAddress = null;
	public static Date _limitOneWeekToDateByMAWBTrackingNumber = null;
	public static Date _limitOneWeekFromDateByMAWBTrackingNumber = null;
    public static Date _limitOneWeekToDateByMAWBShipperName = null;	
	public static Date _limitOneWeekFromDateByMAWBShipperName = null;
    
    public static Date _limitOneWeekToDate = null;
    public static Date _limitOneWeekFromDate = null; 
    public static Date _limitOneWeekToDate2 = null;
    public static Date _limitOneWeekFromDate2 = null;     
    public static Date _limitOneWeekToDate3 = null;
    public static Date _limitOneWeekFromDate3 = null;    
    public static Date _limitOneWeekToDate4 = null;
    public static Date _limitOneWeekFromDate4 = null;      
    public static Date _limitTenDaysToDate = null;
    public static Date _limitTenDaysFromDate = null;        
    public static Date _currentDate = null;
    
    public static String checkResult = null;


	/**
     * @return the checkResult
     */
    public String getCheckResult() {
        return checkResult;
    }
    
    public String getTrackingNbr() {
        return trackingNbr;
    }

    public void setTrackingNbr(String trackingNbr) {
        this.trackingNbr = trackingNbr.trim();
    }

    public String getTrackingNbrCRN() {
        return trackingNbrCRN;
    }

    public void setTrackingNbrCRN(String trackingNbrCRN) {
        this.trackingNbrCRN = trackingNbrCRN.trim();
    }

    public String getAcctNbr() {
        return acctNbr;
    }

    public void setAcctNbr(String acctNbr) {
        this.acctNbr = acctNbr.trim();
    }

    public String getShprNm() {
        return shprNm;
    }

    public void setShprNm(String shprNm) {
        this.shprNm = shprNm.trim();
    }

    public String getReferenceNbr() {
        return referenceNbr;
    }

    public void setReferenceNbr(String referenceNbr) {
        this.referenceNbr = referenceNbr.trim();
    }

    public String getTrackingNbrMAWB() {
        return trackingNbrMAWB;
    }

    public void setTrackingNbrMAWB(String trackingNbrMAWB) {
        this.trackingNbrMAWB = trackingNbrMAWB.trim();
    }

    public String getAcctNbrMAWB() {
        return acctNbrMAWB;
    }

    public void setAcctNbrMAWB(String acctNbrMAWB) {
        this.acctNbrMAWB = acctNbrMAWB.trim();
    }

    public String getAcctNbrMAWB2() {
        return acctNbrMAWB2;
    }

    public void setAcctNbrMAWB2(String acctNbrMAWB2) {
        this.acctNbrMAWB2 = acctNbrMAWB2.trim();
    }

    public String getAcctNbrMAWB3() {
        return acctNbrMAWB3;
    }

    public void setAcctNbrMAWB3(String acctNbrMAWB3) {
        SearchBean.acctNbrMAWB3 = acctNbrMAWB3.trim();
    }

    public String getAcctNmMAWB() {
        return acctNmMAWB;
    }

    public void setAcctNmMAWB(String acctNmMAWB) {
        this.acctNmMAWB = acctNmMAWB.trim();
    }

    public String getLaneNbrMAWB() {
        return laneNbrMAWB;
    }

    public void setLaneNbrMAWB(String laneNbrMAWB) {
        this.laneNbrMAWB = laneNbrMAWB;
    }

    public String getLaneNbrMAWB2() {
        return laneNbrMAWB2;
    }

    public void setLaneNbrMAWB2(String laneNbrMAWB2) {
        this.laneNbrMAWB2 = laneNbrMAWB2;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceCode2() {
        return serviceCode2;
    }

    public void setServiceCode2(String serviceCode2) {
        this.serviceCode2 = serviceCode2;
    }

    public String getIssueCodeCRN() {
        return issueCodeCRN;
    }

    public void setIssueCodeCRN(String issueCodeCRN) {
        this.issueCodeCRN = issueCodeCRN;
    }

    public String getAcctNbrCRN() {
        return acctNbrCRN;
    }

    public void setAcctNbrCRN(String acctNbrCRN) {
        this.acctNbrCRN = acctNbrCRN.trim();
    }

    public String getReturnTrkngNbr() {
        return returnTrkngNbr;
    }

    public void setReturnTrkngNbr(String returnTrkngNbr) {
        this.returnTrkngNbr = returnTrkngNbr.trim();
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName.trim();
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode.trim();
    }

    public String getAddressCityName() {
        return addressCityName;
    }

    public void setAddressCityName(String addressCityName) {
        SearchBean.addressCityName = addressCityName.trim();
    }

    public String getAddressLineOne() {
        return addressLineOne;
    }

    public void setAddressLineOne(String addressLineOne) {
        SearchBean.addressLineOne = addressLineOne.trim();
    }

    public String getAddressPostalCode() {
        return addressPostalCode;
    }

    public void setAddressPostalCode(String addressPostalCode) {
        SearchBean.addressPostalCode = addressPostalCode.trim();
    }

    public String getAddressStateProvince() {
        return addressStateProvince;
    }

    public void setAddressStateProvince(String addressStateProvince) {
        SearchBean.addressStateProvince = addressStateProvince.trim();
    }

    public String getAcctNbr2() {
        return acctNbr2;
    }

    public void setAcctNbr2(String acctNbr2) {
        SearchBean.acctNbr2 = acctNbr2.trim();
    }

    public String getTrackingNbrMAWB2() {
        return trackingNbrMAWB2;
    }

    public void setTrackingNbrMAWB2(String trackingNbrMAWB2) {
        SearchBean.trackingNbrMAWB2 = trackingNbrMAWB2.trim();
    }

	public String getClearancePoint() {
		return clearancePoint;
	}

	public void setClearancePoint(String clearancePoint) {
		SearchBean.clearancePoint = clearancePoint;
	}
    
    public String getSearchFailed() {
        return searchFailed;
    }

    public void setSearchFailed(String searchFailed) {
        this.searchFailed = searchFailed;
    }

    public String getReferenceNumberMenu() {
        return referenceNumberMenu;
    }

    public void setReferenceNumberMenu(String referenceNumberMenu) {
        SearchBean.referenceNumberMenu = referenceNumberMenu;
    }  
    
    /**
     * @return the selectedLane
     */
    public String getSelectedLane() {
        return _selectedLane;
    }

    /**
     * @param selectedLane
     *            the selectedLane to set
     */
    public void setSelectedLane(String selectedLane) {
        _selectedLane = selectedLane;
    }

    /**
     * @return the selectedLane2
     */
    public String getSelectedLane2() {
        return _selectedLane2;
    }

    /**
     * @param selectedLane2
     *            the selectedLane2 to set
     */
    public void setSelectedLane2(String selectedLane2) {
        _selectedLane2 = selectedLane2;
    }
    
    

    // Calendar Functions -------------------------------------------------

    /**
     * @return the _shipDate
     */
    public Date getShipDate() {
        if (_shipDate == null) {
            _shipDate = new Date();
        }
        return _shipDate;
    }

    /**
     * @param shipDate
     *            the _shipDate to set
     */
    public void setShipDate(Date shipDate) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();            
        _currentDate = currentDate.getTime();    	
    	if (shipDate.after(_currentDate)){
    		shipDate = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}     	
        _shipDate = shipDate;
    }

    /**
     * @return the _fromDate
     */
    public Date getFromDate() {
        // Set the default date.
        if (_fromDate == null) {
            _fromDate = new Date();
            Calendar startDate = Calendar.getInstance();
            int day = 1;
            int month = startDate.get(Calendar.MONTH);
            int year = startDate.get(Calendar.YEAR);
            if (month == Calendar.JANUARY) {
                month = Calendar.DECEMBER;
                year--;
            } else {
                month--;
            }
            startDate.set(year, month, day);
            _fromDate = startDate.getTime();
        }
        return _fromDate;
    }

    /**
     * @param fromDate
     *            the _fromDate to set
     */
    public void setFromDate(Date fromDate) {
        _fromDate = fromDate;
    }

    /**
     * @return the _toDate
     */
    public Date getToDate() {
        if (_toDate == null) {
            _toDate = new Date();
        }
        return _toDate;
    }

    /**
     * @param toDate
     *            the _toDate to set
     */
    public void setToDate(Date toDate) {
        _toDate = toDate;
    }

    /**
     * @return the _fromDate2
     */
    public Date getFromDate2() {
        // Set the default date.
        if (_fromDate2 == null) {
            _fromDate2 = new Date();
            Calendar startDate = Calendar.getInstance();
            int day = 1;
            int month = startDate.get(Calendar.MONTH);
            int year = startDate.get(Calendar.YEAR);
            if (month == Calendar.JANUARY) {
                month = Calendar.DECEMBER;
                year--;
            } else {
                month--;
            }
            startDate.set(year, month, day);
            _fromDate2 = startDate.getTime();
        }
        return _fromDate2;
    }

    /**
     * @param fromDate2
     *            the _fromDate2 to set
     */
    public void setFromDate2(Date fromDate2) {
        _fromDate2 = fromDate2;
    }

    /**
     * @return the _toDate2
     */
    public Date getToDate2() {
        if (_toDate2 == null) {
            _toDate2 = new Date();
        }
        return _toDate2;
    }

    /**
     * @param toDate
     *            the _toDate to set
     */
    public void setToDate2(Date toDate2) {
        _toDate2 = toDate2;
    }

    /**
     * @return the _fromDate3
     */
    public Date getFromDate3() {
        // Set the default date.
        if (_fromDate3 == null) {
            _fromDate3 = new Date();
            Calendar startDate = Calendar.getInstance();
            int day = 1;
            int month = startDate.get(Calendar.MONTH);
            int year = startDate.get(Calendar.YEAR);
            if (month == Calendar.JANUARY) {
                month = Calendar.DECEMBER;
                year--;
            } else {
                month--;
            }
            startDate.set(year, month, day);
            _fromDate3 = startDate.getTime();
        }
        return _fromDate3;
    }

    /**
     * @param fromDate3
     *            the _fromDate2 to set
     */
    public void setFromDate3(Date fromDate3) {
        _fromDate3 = fromDate3;
    }

    /**
     * @return the _toDate3
     */
    public Date getToDate3() {
        if (_toDate3 == null) {
            _toDate3 = new Date();
        }
        return _toDate3;
    }

    /**
     * @param toDate
     *            the _toDate to set
     */
    public void setToDate3(Date toDate3) {
        _toDate3 = toDate3;
    }

    /**
     * @return the _fromDate4
     */
    public Date getFromDate4() {
        // Set the default date.
        if (_fromDate4 == null) {
            _fromDate4 = new Date();
            Calendar startDate = Calendar.getInstance();
            int day = 1;
            int month = startDate.get(Calendar.MONTH);
            int year = startDate.get(Calendar.YEAR);
            if (month == Calendar.JANUARY) {
                month = Calendar.DECEMBER;
                year--;
            } else {
                month--;
            }
            startDate.set(year, month, day);
            _fromDate4 = startDate.getTime();
        }
        return _fromDate4;
    }

    /**
     * @param fromDate
     *            the _fromDate4 to set
     */
    public void setFromDate4(Date fromDate4) {
        _fromDate4 = fromDate4;
    }

    /**
     * @return the _toDate4
     */
    public Date getToDate4() {
        if (_toDate4 == null) {
            _toDate4 = new Date();
        }
        return _toDate4;
    }

    /**
     * @param toDate4
     *            the _toDate4 to set
     */
    public void setToDate4(Date toDate4) {
        _toDate4 = toDate4;
    }

    /**
     * @return the _fromDate5
     */
    public Date getFromDate5() {
        // Set the default date.
        if (_fromDate5 == null) {
            _fromDate5 = new Date();
        }
        return _fromDate5;
    }

    /**
     * @param fromDate
     *            the _fromDate5 to set
     */
    public void setFromDate5(Date fromDate5) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();            
        _currentDate = currentDate.getTime();    	
    	if (fromDate5.after(_currentDate)){
    		fromDate5 = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}     	
        _fromDate5 = fromDate5;
    }    	

    /**
     * @return the _toDate5
     */
    public Date getToDate5() {
        if (_toDate5 == null) {
            _toDate5 = new Date();
        }
        return _toDate5;
    }

    /**
     * @param toDate5
     *            the _toDate5 to set
     */
    public void setToDate5(Date toDate5) {
        _toDate5 = toDate5;
    }
    
    

// ------------------------------------------------------------------------------
// -- TEST AREA FOR DATE RANGES -------------------------------------------------
// ------------------------------------------------------------------------------    
//    limitOneWeekFromDateByMAWBShipperName
    

    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDateByMAWBShipperName() {
        if (_limitOneWeekToDateByMAWBShipperName == null) {
        	_limitOneWeekToDateByMAWBShipperName = new Date();
        }
        return _limitOneWeekToDateByMAWBShipperName;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDateByMAWBShipperName() {
        if (_limitOneWeekFromDateByMAWBShipperName == null) {
        	_limitOneWeekFromDateByMAWBShipperName = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
    		_limitOneWeekFromDateByMAWBShipperName = startDate.getTime();            
        }
        return _limitOneWeekFromDateByMAWBShipperName;
    }   

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDateByMAWBShipperName(Date limitOneWeekFromDateByMAWBShipperName) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDateByMAWBShipperName.after(_limitOneWeekToDateByMAWBShipperName)){
    		limitOneWeekFromDateByMAWBShipperName = _limitOneWeekToDateByMAWBShipperName;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    	_limitOneWeekFromDateByMAWBShipperName = limitOneWeekFromDateByMAWBShipperName;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDateByMAWBShipperName(Date limitOneWeekToDateByMAWBShipperName) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDateByMAWBShipperName.after(_currentDate)){
    		limitOneWeekToDateByMAWBShipperName = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDateByMAWBShipperName.before(_limitOneWeekFromDateByMAWBShipperName)){
    		limitOneWeekToDateByMAWBShipperName.setTime(_limitOneWeekFromDateByMAWBShipperName.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDateByMAWBShipperName = limitOneWeekToDateByMAWBShipperName;
    	    } 
     
    
    
    
    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDateByMAWBTrackingNumber() {
        if (_limitOneWeekToDateByMAWBTrackingNumber == null) {
        	_limitOneWeekToDateByMAWBTrackingNumber = new Date();
        }
        return _limitOneWeekToDateByMAWBTrackingNumber;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDateByMAWBTrackingNumber() {
        if (_limitOneWeekFromDateByMAWBTrackingNumber == null) {
        	_limitOneWeekFromDateByMAWBTrackingNumber = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
    		_limitOneWeekFromDateByMAWBTrackingNumber = startDate.getTime();            
        }
        return _limitOneWeekFromDateByMAWBTrackingNumber;
    }   

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDateByMAWBTrackingNumber(Date limitOneWeekFromDateByMAWBTrackingNumber) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDateByMAWBTrackingNumber.after(_limitOneWeekToDateByMAWBTrackingNumber)){
    		limitOneWeekFromDateByMAWBTrackingNumber = _limitOneWeekToDateByMAWBTrackingNumber;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    	_limitOneWeekFromDateByMAWBTrackingNumber = limitOneWeekFromDateByMAWBTrackingNumber;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDateByMAWBTrackingNumber(Date limitOneWeekToDateByMAWBTrackingNumber) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDateByMAWBTrackingNumber.after(_currentDate)){
    		limitOneWeekToDateByMAWBTrackingNumber = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDateByMAWBTrackingNumber.before(_limitOneWeekFromDateByMAWBTrackingNumber)){
    		limitOneWeekToDateByMAWBTrackingNumber.setTime(_limitOneWeekFromDateByMAWBTrackingNumber.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDateByMAWBTrackingNumber = limitOneWeekToDateByMAWBTrackingNumber;
    	    } 
    
    
    
    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDateByCRNRecipientName() {
        if (_limitOneWeekToDateByCRNRecipientName == null) {
        	_limitOneWeekToDateByCRNRecipientName = new Date();
        }
        return _limitOneWeekToDateByCRNRecipientName;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDateByCRNRecipientName() {
        if (_limitOneWeekFromDateByCRNRecipientName == null) {
        	_limitOneWeekFromDateByCRNRecipientName = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
    		_limitOneWeekFromDateByCRNRecipientName = startDate.getTime();            
        }
        return _limitOneWeekFromDateByCRNRecipientName;
    }   

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDateByCRNRecipientName(Date limitOneWeekFromDateByCRNRecipientName) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDateByCRNRecipientName.after(_limitOneWeekToDateByCRNRecipientName)){
    		limitOneWeekFromDateByCRNRecipientName = _limitOneWeekToDateByCRNRecipientName;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    	_limitOneWeekFromDateByCRNRecipientName = limitOneWeekFromDateByCRNRecipientName;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDateByCRNRecipientName(Date limitOneWeekToDateByCRNRecipientName) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDateByCRNRecipientName.after(_currentDate)){
    		limitOneWeekToDateByCRNRecipientName = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDateByCRNRecipientName.before(_limitOneWeekFromDateByCRNRecipientName)){
    		limitOneWeekToDateByCRNRecipientName.setTime(_limitOneWeekFromDateByCRNRecipientName.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDateByCRNRecipientName = limitOneWeekToDateByCRNRecipientName;
    	    } 
    
    
    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDateByCRNRecipientPostalCode() {
        if (_limitOneWeekToDateByCRNRecipientPostalCode == null) {
        	_limitOneWeekToDateByCRNRecipientPostalCode = new Date();
        }
        return _limitOneWeekToDateByCRNRecipientPostalCode;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDateByCRNRecipientPostalCode() {
        if (_limitOneWeekFromDateByCRNRecipientPostalCode == null) {
        	_limitOneWeekFromDateByCRNRecipientPostalCode = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
    		_limitOneWeekFromDateByCRNRecipientPostalCode = startDate.getTime();            
        }
        return _limitOneWeekFromDateByCRNRecipientPostalCode;
    }   

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDateByCRNRecipientPostalCode(Date limitOneWeekFromDateByCRNRecipientPostalCode) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDateByCRNRecipientPostalCode.after(_limitOneWeekToDateByCRNRecipientPostalCode)){
    		limitOneWeekFromDateByCRNRecipientPostalCode = _limitOneWeekToDateByCRNRecipientPostalCode;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    	_limitOneWeekFromDateByCRNRecipientPostalCode = limitOneWeekFromDateByCRNRecipientPostalCode;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDateByCRNRecipientPostalCode(Date limitOneWeekToDateByCRNRecipientPostalCode) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDateByCRNRecipientPostalCode.after(_currentDate)){
    		limitOneWeekToDateByCRNRecipientPostalCode = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDateByCRNRecipientPostalCode.before(_limitOneWeekFromDateByCRNRecipientPostalCode)){
    		limitOneWeekToDateByCRNRecipientPostalCode.setTime(_limitOneWeekFromDateByCRNRecipientPostalCode.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDateByCRNRecipientPostalCode = limitOneWeekToDateByCRNRecipientPostalCode;
    	    }
    
    
//    limitOneWeekFromDateByCRNWithODA   
    
    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDateByCRNWithODA() {
        if (_limitOneWeekToDateByCRNWithODA == null) {
        	_limitOneWeekToDateByCRNWithODA = new Date();
        }
        return _limitOneWeekToDateByCRNWithODA;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDateByCRNWithODA() {
        if (_limitOneWeekFromDateByCRNWithODA == null) {
        	_limitOneWeekFromDateByCRNWithODA = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
    		_limitOneWeekFromDateByCRNWithODA = startDate.getTime();            
        }
        return _limitOneWeekFromDateByCRNWithODA;
    }   

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDateByCRNWithODA(Date limitOneWeekFromDateByCRNWithODA) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDateByCRNWithODA.after(_limitOneWeekToDateByCRNWithODA)){
    		limitOneWeekFromDateByCRNWithODA = _limitOneWeekToDateByCRNWithODA;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    	_limitOneWeekFromDateByCRNWithODA = limitOneWeekFromDateByCRNWithODA;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDateByCRNWithODA(Date limitOneWeekToDateByCRNWithODA) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDateByCRNWithODA.after(_currentDate)){
    		limitOneWeekToDateByCRNWithODA = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDateByCRNWithODA.before(_limitOneWeekFromDateByCRNWithODA)){
    		limitOneWeekToDateByCRNWithODA.setTime(_limitOneWeekFromDateByCRNWithODA.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDateByCRNWithODA = limitOneWeekToDateByCRNWithODA;
    	    }    
    
// limitOneWeekFromDateByCRNRecipientAddress    
    
    
    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDateByCRNRecipientAddress() {
        if (_limitOneWeekToDateByCRNRecipientAddress == null) {
        	_limitOneWeekToDateByCRNRecipientAddress = new Date();
        }
        return _limitOneWeekToDateByCRNRecipientAddress;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDateByCRNRecipientAddress() {
        if (_limitOneWeekFromDateByCRNRecipientAddress == null) {
        	_limitOneWeekFromDateByCRNRecipientAddress = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
    		_limitOneWeekFromDateByCRNRecipientAddress = startDate.getTime();            
        }
        return _limitOneWeekFromDateByCRNRecipientAddress;
    }   

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDateByCRNRecipientAddress(Date limitOneWeekFromDateByCRNRecipientAddress) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDateByCRNRecipientAddress.after(_limitOneWeekToDateByCRNRecipientAddress)){
    		limitOneWeekFromDateByCRNRecipientAddress = _limitOneWeekToDateByCRNRecipientAddress;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
    	_limitOneWeekFromDateByCRNRecipientAddress = limitOneWeekFromDateByCRNRecipientAddress;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDateByCRNRecipientAddress(Date limitOneWeekToDateByCRNRecipientAddress) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDateByCRNRecipientAddress.after(_currentDate)){
    		limitOneWeekToDateByCRNRecipientAddress = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDateByCRNRecipientAddress.before(_limitOneWeekFromDateByCRNRecipientAddress)){
    		limitOneWeekToDateByCRNRecipientAddress.setTime(_limitOneWeekFromDateByCRNRecipientAddress.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDateByCRNRecipientAddress = limitOneWeekToDateByCRNRecipientAddress;
    	    }       
    
    
    
    
    
    
    
    /**
     * @return the _limitOneWeekToDate
     */
    public Date getLimitOneWeekToDate() {
        if (_limitOneWeekToDate == null) {
            _limitOneWeekToDate = new Date();
        }
        return _limitOneWeekToDate;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate
     */
    public Date getLimitOneWeekFromDate() {
        if (_limitOneWeekFromDate == null) {
            _limitOneWeekFromDate = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);        	
            _limitOneWeekFromDate = startDate.getTime();            
        }
        return _limitOneWeekFromDate;
    }   
    

    /**
     * @param limitOneWeekFromDate the _limitOneWeekFromDate to set
     */
    public void setLimitOneWeekFromDate(Date limitOneWeekFromDate) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDate.after(_limitOneWeekToDate)){
    		limitOneWeekFromDate = _limitOneWeekToDate;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}
        _limitOneWeekFromDate = limitOneWeekFromDate;      
    	    } 

    /**
     * @param limitOneWeekToDate the _limitOneWeekToDate to set
     */
    public void setLimitOneWeekToDate(Date limitOneWeekToDate) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();          
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDate.after(_currentDate)){
    		limitOneWeekToDate = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDate.before(_limitOneWeekFromDate)){
    		limitOneWeekToDate.setTime(_limitOneWeekFromDate.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    
    	_limitOneWeekToDate = limitOneWeekToDate;
    	    } 

    
    /**
     * @return the _limitOneWeekToDate2
     */
    public Date getLimitOneWeekToDate2() {
        if (_limitOneWeekToDate2 == null) {
            _limitOneWeekToDate2 = new Date();
        }
        return _limitOneWeekToDate2;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate2
     */
    public Date getLimitOneWeekFromDate2() {
        if (_limitOneWeekFromDate2 == null) {
            _limitOneWeekFromDate2 = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);            
            _limitOneWeekFromDate2 = startDate.getTime();            
        }
        return _limitOneWeekFromDate2;
    }     
    
    /**
     * @param limitOneWeekFromDate2 the _limitOneWeekFromDate2 to set
     */
    public void setLimitOneWeekFromDate2(Date limitOneWeekFromDate2) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDate2.after(_limitOneWeekToDate2)){
    		limitOneWeekFromDate2 = _limitOneWeekToDate2;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}

        _limitOneWeekFromDate2 = limitOneWeekFromDate2;
    	    } 

    /**
     * @param limitOneWeekToDate2 the _limitOneWeekToDate2 to set
     */
    public void setLimitOneWeekToDate2(Date limitOneWeekToDate2) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();            
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDate2.after(_currentDate)){
    		limitOneWeekToDate2 = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDate2.before(_limitOneWeekFromDate2)){
    		limitOneWeekToDate2.setTime(_limitOneWeekFromDate2.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    	
    	_limitOneWeekToDate2 = limitOneWeekToDate2;
    	    }   
    
    /**
     * @return the _limitOneWeekToDate3
     */
    public Date getLimitOneWeekToDate3() {
        if (_limitOneWeekToDate3 == null) {
            _limitOneWeekToDate3 = new Date();
        }
        return _limitOneWeekToDate3;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate3
     */
    public Date getLimitOneWeekFromDate3() {
        if (_limitOneWeekFromDate3 == null) {
            _limitOneWeekFromDate3 = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);            
            _limitOneWeekFromDate3 = startDate.getTime();            
        }
        return _limitOneWeekFromDate3;
    }     
    
    /**
     * @param limitOneWeekFromDate3 the _limitOneWeekFromDate3 to set
     */
    public void setLimitOneWeekFromDate3(Date limitOneWeekFromDate3) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDate3.after(_limitOneWeekToDate3)){
    		limitOneWeekFromDate3 = _limitOneWeekToDate3;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}

        _limitOneWeekFromDate3 = limitOneWeekFromDate3;
    	    } 

    /**
     * @param limitOneWeekToDate3 the _limitOneWeekToDate3 to set
     */
    public void setLimitOneWeekToDate3(Date limitOneWeekToDate3) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();            
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDate3.after(_currentDate)){
    		limitOneWeekToDate3 = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}	    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDate3.before(_limitOneWeekFromDate3)){
    		limitOneWeekToDate3.setTime(_limitOneWeekFromDate3.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    	
    	_limitOneWeekToDate3 = limitOneWeekToDate3;
    	    }    
//--------------------------    

    /**
     * @return the _limitOneWeekToDate4
     */
    public Date getLimitOneWeekToDate4() {
        if (_limitOneWeekToDate4 == null) {
            _limitOneWeekToDate4 = new Date();
        }
        return _limitOneWeekToDate4;
    }
 
    
    /**
     * @return the _limitOneWeekFromDate4
     */
    public Date getLimitOneWeekFromDate4() {
        if (_limitOneWeekFromDate4 == null) {
            _limitOneWeekFromDate4 = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -7);            
            _limitOneWeekFromDate4 = startDate.getTime();            
        }
        return _limitOneWeekFromDate4;
    }     
    
    /**
     * @param limitOneWeekFromDate4 the _limitOneWeekFromDate4 to set
     */
    public void setLimitOneWeekFromDate4(Date limitOneWeekFromDate4) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	// If fromDate is greater than _toDate shall set them equal.
    	if (limitOneWeekFromDate4.after(_limitOneWeekToDate4)){
    		limitOneWeekFromDate4 = _limitOneWeekToDate4;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}

        _limitOneWeekFromDate4 = limitOneWeekFromDate4;
    	    } 

    /**
     * @param limitOneWeekToDate4 the _limitOneWeekToDate4 to set
     */
    public void setLimitOneWeekToDate4(Date limitOneWeekToDate4) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();            
        _currentDate = currentDate.getTime();    	
    	if (limitOneWeekToDate4.after(_currentDate)){
    		limitOneWeekToDate4 = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}	    	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitOneWeekToDate4.before(_limitOneWeekFromDate4)){
    		limitOneWeekToDate4.setTime(_limitOneWeekFromDate4.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    	
    	_limitOneWeekToDate4 = limitOneWeekToDate4;
    	    }     
    
    
    /**
     * @return the _limitTenDaysToDate
     */
    public Date getLimitTenDaysToDate() {
        if (_limitTenDaysToDate == null) {
            _limitTenDaysToDate = new Date();          
        }
        return _limitTenDaysToDate;
    }
 
    
    /**
     * @return the _limitTenDaysFromDate
     */
    public Date getLimitTenDaysFromDate() {    	
        if (_limitTenDaysFromDate == null) {
            _limitTenDaysFromDate = new Date();
    		Calendar startDate = Calendar.getInstance();
    		startDate.add(Calendar.DAY_OF_YEAR, -10);            
            _limitTenDaysFromDate = startDate.getTime();
        }
        return _limitTenDaysFromDate;
    }   
    

    /**
     * @param _limitTenDaysFromDate the _limitTenDaysFromDate to set
     */
    public void setLimitTenDaysFromDate(Date limitTenDaysFromDate) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
        
    	// If fromDate is greater than _toDate shall set them equal. 	
    	if (limitTenDaysFromDate.after(_limitTenDaysToDate)){
    		limitTenDaysFromDate = _limitTenDaysToDate;
    		
    		log.info("The From Date is greater than the To Date and has been reset to equal the To Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The From Date is greater than the To Date and has been reset to equal the To Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		
    	}

        _limitTenDaysFromDate = limitTenDaysFromDate;
    	    } 

    /**
     * @param limitTenDaysToDate the _limitTenDaysToDate to set
     */
    public void setLimitTenDaysToDate(Date limitTenDaysToDate) {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar currentDate = Calendar.getInstance();            
        _currentDate = currentDate.getTime();    	
    	if (limitTenDaysToDate.after(_currentDate)){
    		limitTenDaysToDate = _currentDate;
    		log.info("The To Date is greater than todays date. From date has been reset to todays date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is greater than todays date. From date has been reset to todays date.", 
            		null);
            facesContext.addMessage(null, facesMessage);		    		
    	}	
    	// If toDate is before the _fromDate shall set them equal.
    	if (limitTenDaysToDate.before(_limitTenDaysFromDate)){
    		limitTenDaysToDate.setTime(_limitTenDaysFromDate.getTime());
    		
    		log.info("The To Date is less than the From Date and has been reset to equal the From Date.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"The To Date is less than the From Date and has been reset to equal the From Date.", 
            		null);
            facesContext.addMessage(null, facesMessage);
    	}    	
    	_limitTenDaysToDate = limitTenDaysToDate;
    	    }     
    
// ------------------------------------------------------------------------------    
// -- END OF TEST AREA FOR DATE RANGES ------------------------------------------    
// ------------------------------------------------------------------------------
    

    
    // ---------------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------------

    /**
     * Search for the Shipper by Name 
     */
    public String doSearchForShipperByShprNm() {
            if (shprNm.length() < 2) {
                FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                        "Shipper Name of at least 2 characters is required!", null);
                FacesContext facesContext = FacesContext.getCurrentInstance();
                facesContext.addMessage(null, facesMessage);
                return "failed";
            } else {
                checkResult = "shprNm";
            }

        return "success";
    }

    /**
     * Search for the Shipper by Account Number
     */
    public String doSearchForShipperByAcctNbr() {
            if (acctNbr.length() < 4) {
                FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                        "Account Number of at least 4 digits is required!", null);
                FacesContext facesContext = FacesContext.getCurrentInstance();
                facesContext.addMessage(null, facesMessage);
                return "failed";
            } else {
                try {
                    Integer.parseInt(acctNbr);
                } catch (NumberFormatException e) {
                    FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                        "Account Number must be numeric!", null);
                    FacesContext facesContext = FacesContext.getCurrentInstance();
                    facesContext.addMessage(null, facesMessage);
                    return "failed";
                }
                
                checkResult = "acctNbr";
            }

        return "success";
    }

    /**
     * Search for the Shipment by Tracking Number 
     */    
    public String doSearchForShipmentByTrkngNbr() {
        if (trackingNbr.length() < 4) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Tracking Number of at least 4 characters is required!", null);
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, facesMessage);
            return "failed";
        } else {
            checkResult = "trackingNbr";
            return "success";
        }
    }
        
    /**
     * Search for the Shipment by Reference Number
     */    
    public String doSearchForShipmentByRefNbr() {
        if (referenceNbr.length() < 4) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Reference Number of at least 4 digits is required!", null);
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, facesMessage);
            return "failed";
        } else {
            checkResult = "referenceNbr";
            return "success";
        }
    }
    
    
    /**
     * Search for the Shipment (MAWB) by Tracking Number
     */    
    public String doSearchForShipmentsMAWBsByTrackingNbr() {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate = Calendar.getInstance();
		greatestTestToDate.setTime(_limitOneWeekFromDateByMAWBTrackingNumber);
		greatestTestToDate.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDateByMAWBTrackingNumber.after(greatestTestToDate.getTime())){
			_limitOneWeekToDateByMAWBTrackingNumber = greatestTestToDate.getTime();  
			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";
		}else if (trackingNbrMAWB.length() < 4){
    			log.info("Please make sure account name is at least 4 characters long.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please make sure account name is at least 4 characters long.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
    		}else{
    	        checkResult = "trackingNbrMAWB";
    	        return "successByTrackingNumber"; 			
    		}     	
    }    
    
    /**
     * Search for the Shipment (MAWB) by Account Name
     */    
    public String doSearchForShipmentsMAWBsByAcctNm() {
    	
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate2 = Calendar.getInstance();
		greatestTestToDate2.setTime(_limitOneWeekFromDateByMAWBShipperName);
		greatestTestToDate2.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDateByMAWBShipperName.after(greatestTestToDate2.getTime())){
			_limitOneWeekToDateByMAWBShipperName = greatestTestToDate2.getTime();  
			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";
		}else if (acctNmMAWB.length() < 2){
    			log.info("Please make sure account name is at least 2 characters long.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please make sure account name is at least 2 characters long.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
    		}else{
    	        checkResult = "acctNmMAWB";
    	        return "successByShipperName"; 			
    		}     	
    }    
    
    /**
     * Search for the Shipment (MAWB) by Account Nbr and Ship Date Range
     */    
    public String doSearchForShipmentsMAWBsByAcctNbr() {
    	
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate3 = Calendar.getInstance();
		greatestTestToDate3.setTime(_limitOneWeekFromDate3);
		greatestTestToDate3.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDate3.after(greatestTestToDate3.getTime())){
			_limitOneWeekToDate3 = greatestTestToDate3.getTime();  
			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please limit your date range to 7.  To date has been changed to from date plus 7 days.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";
		}else if (acctNbrMAWB3.length() < 4){ 
    			log.info("Please make sure account name is at least 4 characters long.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please make sure account name is at least 4 characters long.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
    		}else{
    	        checkResult = "shipDateRange";
    	        return "success"; 			
    		}      	
    }    
    
    /**
     * Search for the Shipment (MAWB) by Account Name or Ship Date 
     */    
    public String doSearchForShipmentsMAWBsByAcctNbrShipDate() {
        if (acctNbrMAWB2.length() < 4) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Account Number of at least 4 digits is required!", null);
            FacesContext facesContext = FacesContext.getCurrentInstance();
            facesContext.addMessage(null, facesMessage);
            return "failed";
        } else {
            checkResult = "shipDate";
            return "success";
        }
    }    
    

    public void validateShipperName(FacesContext context, UIComponent toValidate, Object value) {
        String shipperName = (String) value;
        if (shipperName.length() < 4) {
            ((UIInput) toValidate).setValid(false);
        }
    }

    public String doSearchByTrkngNbr() {
        checkResult = "trackingNbr";
        return "success";
    }

    public String doSearchByReferenceNbr() {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate2 = Calendar.getInstance();
		greatestTestToDate2.setTime(_limitOneWeekFromDate);
		greatestTestToDate2.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDate.after(greatestTestToDate2.getTime())){
			_limitOneWeekToDate = greatestTestToDate2.getTime();  
			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";
		}else if (referenceNbr.length() < 4){  
    			log.info("Please make sure your reference # is a least 4 characters long.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please make sure your reference # is a least 4 characters long.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
    		}else{
    			Calendar setToDateTime = Calendar.getInstance();
    			setToDateTime.setTime(_limitOneWeekToDate);
    			setToDateTime.set(Calendar.HOUR, 23);
		    	setToDateTime.set(Calendar.MINUTE, 59);
		    	setToDateTime.set(Calendar.SECOND, 59);   
    			_limitOneWeekToDate = setToDateTime.getTime();
    			Calendar setFromDateTime = Calendar.getInstance();
    			setFromDateTime.setTime(_limitOneWeekFromDate);
    			setFromDateTime.set(Calendar.HOUR, 00);
		    	setFromDateTime.set(Calendar.MINUTE, 00);
		    	setFromDateTime.set(Calendar.SECOND, 01);   
    			_limitOneWeekFromDate = setFromDateTime.getTime();      			
    			
    	        checkResult = "referenceNbr";
    	        return "success"; 			
    		}       			
    }

    public String doSearchByTrkngNbrMAWB() {
        checkResult = "trackingNbrMAWB";
        return "success";
    }

    public String doSearchByAcctNmMAWB() {
        checkResult = "acctNmMAWB";
        return "success";
    }

    public String doSearchByIssueCodeCRN() {
        checkResult = "issueCodeCRNacctNbrCRN";
        return "success";
    }

    public String doSearchByReturnTrkngNbr() {
        checkResult = "returnTrkngNbr";
        return "successReturnTrackingNumber";
    }

    public String doSearchByRecipientName() {
    	
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate2 = Calendar.getInstance();
		greatestTestToDate2.setTime(_limitOneWeekFromDateByCRNRecipientName);
		greatestTestToDate2.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDateByCRNRecipientName.after(greatestTestToDate2.getTime())){
			_limitOneWeekToDateByCRNRecipientName = greatestTestToDate2.getTime();  
    			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
		}else if (recipientName.length() < 3){  
			log.info("Please make sure your recipient name is a least 3 characters long.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please make sure your recipient name is a least 3 characters long.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";                
    		}else{
    	        checkResult = "recipientName";
    	        return "successByRecipientName"; 			
    		}       	
    }
    

    public String doSearchByShipDate() {
        checkResult = "shipDate";
        return "success";
    }

    public String doSearchByShipDateRange() {
        checkResult = "shipDateRange";
        return "success";
    }
    
  
    public String doSearchByPostalCode() {
    	
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate = Calendar.getInstance();
		greatestTestToDate.setTime(_limitOneWeekFromDateByCRNRecipientPostalCode);
		greatestTestToDate.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDateByCRNRecipientPostalCode.after(greatestTestToDate.getTime())){
			_limitOneWeekToDateByCRNRecipientPostalCode = greatestTestToDate.getTime();  
    			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
		}else if (postalCode.length() < 5){  
			log.info("Please make sure your postal code is a least 5 characters long.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please make sure your postal code is a least 5 characters long.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";                
    		}else{
    	        checkResult = "postalCode";
    	        return "successByRecipientPostalCode";    			
    		}    	
 	

    }    
    
    public String doSearchForMonitorByAcctNbr() {
        checkResult = "findMonitorAcctNbr";
        return "success";
    }

    public String doSearchForMonitorByTrkngNbr() {
        checkResult = "findMonitorTrkngNbr";
        return "success";
    }

    public String doSearchByWithODACRN() {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate4 = Calendar.getInstance();
		greatestTestToDate4.setTime(_limitOneWeekFromDateByCRNWithODA);
		greatestTestToDate4.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDateByCRNWithODA.after(greatestTestToDate4.getTime())){
			_limitOneWeekToDateByCRNWithODA = greatestTestToDate4.getTime();  
    			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
		}else if (acctNbr.length() < 4){  
			log.info("Please make sure your account # is a least 4 characters long.");
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_WARN, 
            		"Please make sure your account # is a least 4 characters long.", 
            		null);
            facesContext.addMessage(null, facesMessage);
            return "failed";
		}else{
    	        checkResult = "withODACRN";
    	        return "successByWithODA"; 			
    		}     	
    }

    public String doSearchByWithoutPODCRN() {
        checkResult = "withoutPODCRN";
        return "success";
    }

    public String doSearchByFindMissingData() {
        checkResult = "findMissingData";
        return "success";
    }

    public String doSearchByAddress() {
    	
    	FacesContext facesContext = FacesContext.getCurrentInstance();
		Calendar greatestTestToDate = Calendar.getInstance();
		greatestTestToDate.setTime(_limitOneWeekFromDateByCRNRecipientAddress);
		greatestTestToDate.add(Calendar.DAY_OF_YEAR, 7);
		if (_limitOneWeekToDateByCRNRecipientAddress.after(greatestTestToDate.getTime())){
			_limitOneWeekToDateByCRNRecipientAddress = greatestTestToDate.getTime();  
    			log.info("Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.");
                FacesMessage facesMessage = new FacesMessage(
                		FacesMessage.SEVERITY_WARN, 
                		"Please limit your date range to 7 days.  To date has been changed to from date plus 7 days.", 
                		null);
                facesContext.addMessage(null, facesMessage);
                return "failed";
		}else if (addressLineOne.length() < 4){  
        			log.info("Please make sure your address is a least 4 characters long.");
                    FacesMessage facesMessage = new FacesMessage(
                    		FacesMessage.SEVERITY_WARN, 
                    		"Please make sure your address is a least 4 characters long.", 
                    		null);
                    facesContext.addMessage(null, facesMessage);
                    return "failed";
		}else if (addressCityName.length() < 2){  
            			log.info("Please make sure your city name is a least 2 characters long.");
                        FacesMessage facesMessage = new FacesMessage(
                        		FacesMessage.SEVERITY_WARN, 
                        		"Please make sure your city name is a least 2 characters long.", 
                        		null);
                        facesContext.addMessage(null, facesMessage);
                        return "failed";
		}else if (addressStateProvince.length() != 2){  
                			log.info("Please make sure your State is in its 2 letter format code. Ex. Colorado = CO.");
                            FacesMessage facesMessage = new FacesMessage(
                            		FacesMessage.SEVERITY_WARN, 
                            		"Please make sure your State is in its 2 letter format code. Ex. Colorado = CO.", 
                            		null);
                            facesContext.addMessage(null, facesMessage);
                            return "failed"; 		                
		}else if (addressPostalCode.length() < 3){  
                    			log.info("Please make sure you entered a valid postal code.");
                                FacesMessage facesMessage = new FacesMessage(
                                		FacesMessage.SEVERITY_WARN, 
                                		"Please make sure you entered a valid postal code.", 
                                		null);
                                facesContext.addMessage(null, facesMessage);
                                return "failed"; 		                
    		}else{
    	        checkResult = "searchByAddress";
    	        return "successByRecipientAddress";    			
    		}      	
    }
    
    public String doRampHubSearch() {
        checkResult = "rampHubSearch";
        return "success";
    }    

    // --------------------------------------------------------
    // | Populate Issue Code Drop Down Code In Development. |
    // --------------------------------------------------------

    // Public List getIssueCodes() {
    // Set set = issueCdsByDescList.keySet();
    // Iterator iter = set.iterator();
    // while (iter.hasNext()) {
    // logger.debug((String)iter.next());
    // }
    // }

    /**
     * @return the selectedIssueCode
     */
    public String getSelectedIssueCode() {
        return _selectedIssueCode;
    }

    /**
     * @param selectedIssueCode
     *            the selectedIssueCode to set
     */
    public void setSelectedIssueCode(String selectedIssueCode) {
        _selectedIssueCode = selectedIssueCode;
    }

    /**
     * Get all possible Lanes
     * 
     * @return List of SelectItems for the lanes
     */
    public List getAllLanes() {
        //_allLanes = shipperDelegate.getLanes();
        List laneSelectItems = new ArrayList(_allLanes.size());
        for (Iterator itr = _allLanes.iterator(); itr.hasNext();) {
            LaneVO lane = (LaneVO) itr.next();
            String laneStr = LaneFormatter.format(lane.get_orig_cntry_cd(), lane
                    .get_dest_cntry_cd());
            laneSelectItems.add(new SelectItem(Integer.toString(lane.get_lane_nbr()), laneStr));

            // reselect the selected lane
            if (lane.get_orig_cntry_cd().equals(_originCountryCd)
                    && lane.get_dest_cntry_cd().equals(_destCountryCd)) {
                _selectedLane = String.valueOf(lane.get_lane_nbr());
            }
        }
        return laneSelectItems;
    }

    /**
     * Get all possible Lanes 2
     * 
     * @return List of SelectItems for the lanes
     */
    public List getAllLanes2() {
        //_allLanes = shipperDelegate.getLanes();
        List laneSelectItems = new ArrayList(_allLanes.size());
        for (Iterator itr = _allLanes.iterator(); itr.hasNext();) {
            LaneVO lane = (LaneVO) itr.next();
            String laneStr = LaneFormatter.format(lane.get_orig_cntry_cd(), lane
                    .get_dest_cntry_cd());
            laneSelectItems.add(new SelectItem(Integer.toString(lane.get_lane_nbr()), laneStr));

            // reselect the selected lane
            if (lane.get_orig_cntry_cd().equals(_originCountryCd)
                    && lane.get_dest_cntry_cd().equals(_destCountryCd)) {
                _selectedLane = String.valueOf(lane.get_lane_nbr());
            }
        }
        return laneSelectItems;
    }

// Test Area for List -------------------
    
private static SelectItem[] destinationCountryMenu = {
   	new SelectItem("CA","CA"),
   	new SelectItem("US","US"),
   	new SelectItem("MY","MY"),
   	new SelectItem("JP","JP"),
   	new SelectItem("FR","FR"),
   	new SelectItem("NZ","NZ"),
   	new SelectItem("HK","HK"),
   	new SelectItem("TW","TW"),
   	new SelectItem("MX","MX"),
   	new SelectItem("DE","DE"),
   	new SelectItem("GB","GB"),
   	new SelectItem("AU","AU"),
   	new SelectItem("KR","KR"),
   	new SelectItem("SB","SB"),
   	new SelectItem("TH","TH"),
   	new SelectItem("ID","ID"),
};
    
public SelectItem[] getdestinationCountryMenu() {
    	return destinationCountryMenu;
}
    
private static SelectItem[] clearancePointMenuCA = {
	new SelectItem("","ALL"),
	new SelectItem("WINNIPEG","WINNIPEG"),
	new SelectItem("GLOUCESTER","GLOUCESTER"),
	new SelectItem("OLDCASTLE","OLDCASTLE"),
	new SelectItem("MISSISSAUGA","MISSISSAUGA"),
	new SelectItem("EDMONTON","EDMONTON"),
	new SelectItem("CALGARY","CALGARY"),
	new SelectItem("RICHMOND","RICHMOND"),
	new SelectItem("MIRABEL","MIRABEL"),
};
	
/**
 * @return clearancePointMenuCA
 */
public SelectItem[] getClearancePointMenuCA() {
	return clearancePointMenuCA;
}

private static SelectItem[] clearancePointMenuUS = {
	new SelectItem("","ALL"),
	new SelectItem("AK","ANCHORAGE"),
	new SelectItem("IN","INDIANAPOLIS"),
	new SelectItem("FL","MIAMI"),
	new SelectItem("TN","MEMPHIS"),
};
	
/**
 * @return clearancePointMenuUS
 */
public SelectItem[] getClearancePointMenuUS() {
	return clearancePointMenuUS;
}

private static SelectItem[] clearancePointMenuAll = {
	new SelectItem("","ALL"),
};
	
/**
 * @return clearancePointMenuAll
 */
public SelectItem[] getClearancePointMenuAll() {
	return clearancePointMenuAll;
}

/**
 * @return the _selectMenu
 */
public String getSelectMenu() {
	if (_selectMenu == null){
		_selectMenu =  "CA";
	}
    return _selectMenu;
}

/**
 * @param selectMenu the _selectMenu to set
 */
public void setSelectMenu(String selectMenu) {
	_selectMenu = selectMenu;
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuCA() {
	return _selectMenu.equalsIgnoreCase("CA");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuUS() {
	return _selectMenu.equalsIgnoreCase("US");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuMY() {
	return _selectMenu.equalsIgnoreCase("MY");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuJP() {
	return _selectMenu.equalsIgnoreCase("JP");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuFR() {
	return _selectMenu.equalsIgnoreCase("FR");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuNZ() {
	return _selectMenu.equalsIgnoreCase("NZ");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuHK() {
	return _selectMenu.equalsIgnoreCase("HK");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuTW() {
	return _selectMenu.equalsIgnoreCase("TW");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuMX() {
	return _selectMenu.equalsIgnoreCase("MX");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuDE() {
	return _selectMenu.equalsIgnoreCase("DE");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuGB() {
	return _selectMenu.equalsIgnoreCase("GB");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuAU() {
	return _selectMenu.equalsIgnoreCase("AU");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuKR() {
	return _selectMenu.equalsIgnoreCase("KR");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuSB() {
	return _selectMenu.equalsIgnoreCase("SB");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuTH() {
	return _selectMenu.equalsIgnoreCase("TH");
}

/**
 * @return the _selectMenu
 */
public boolean getSelectMenuID() {
	return _selectMenu.equalsIgnoreCase("ID");
}



// End Test Area for List ----------------    
    
    
    
    /**
     * @return the destCountryCd
     */
    public String getDestCountryCd() {
        return _destCountryCd;
    }

    /**
     * @param destCountryCd
     *            the destCountryCd to set
     */
    public void setDestCountryCd(String destCountryCd) {
        _destCountryCd = destCountryCd;
    }

    /**
     * @return the originCountryCd
     */
    public String getOriginCountryCd() {
        return _originCountryCd;
    }

    /**
     * @param originCountryCd
     *            the originCountryCd to set
     */
    public void setOriginCountryCd(String originCountryCd) {
        _originCountryCd = originCountryCd;
    }

    /** 
     * Reset all attributes to there default value
     */
    public void reset() {
        shprNm = null;              
        acctNbr = null;
        trackingNbr = null;
        referenceNbr = null;
        referenceNumberMenu = new String("SHR");
        _toDate2 = null;
        _fromDate2 = null;             
        acctNbrMAWB = null;
        _toDate = null;
        _fromDate = null; 
        laneNbrMAWB = null;
        serviceCode = null;
        acctNmMAWB = null;
        _toDate3 = null;
        _fromDate3 = null;              
        issueCodeCRN = null;
        acctNbrCRN = null;
        trackingNbrCRN = null;
        _toDate4 = null;
        _fromDate4 = null;             
        returnTrkngNbr = null;
        _toDate = null;
        _fromDate = null;               
        recipientName = null;
        _toDate2 = null;
        _fromDate2 = null;             
        _shipDate = null;
        serviceCode2 = null;
        acctNbrMAWB2 = null;
        _selectedLane2 = null;
        _toDate4 = null;
        _fromDate4 = null;
        serviceCode = null;
        acctNbrMAWB3 = null;
        _selectedLane = null;            
        _toDate3 = null;
        _fromDate3 = null;
        postalCode = null;
        acctNbr = null;
        trackingNbr = null;
        acctNbr = null;
        trackingNbrMAWB = null;
        _fromDate5 = null;
        acctNbr2 = null;
        trackingNbrMAWB2 = null;
        addressLineOne = null;
        addressCityName = null;
        addressStateProvince = null;
        addressPostalCode = null; 
        //Start WR#:179441 Changes
        //checkResult = null;
        //End WR#:179441 Changes
        _limitOneWeekToDate = null;
        _limitOneWeekFromDate = null;
        _limitOneWeekToDate2 = null;
        _limitOneWeekFromDate2 = null;   
        _limitOneWeekToDate3 = null;
        _limitOneWeekFromDate3 = null; 
        _limitOneWeekToDate4 = null;
        _limitOneWeekFromDate4 = null;         
        _limitTenDaysToDate = null;
        _limitTenDaysFromDate = null;  
        
        _limitOneWeekToDateByCRNRecipientName = null;
        _limitOneWeekFromDateByCRNRecipientName = null;
        _limitOneWeekToDateByCRNRecipientPostalCode = null;
        _limitOneWeekFromDateByCRNRecipientPostalCode = null;
        _limitOneWeekToDateByCRNWithODA = null;
        _limitOneWeekFromDateByCRNWithODA = null;
        _limitOneWeekToDateByCRNRecipientAddress = null;
        _limitOneWeekFromDateByCRNRecipientAddress = null;
        _limitOneWeekToDateByMAWBTrackingNumber = null;
        _limitOneWeekFromDateByMAWBTrackingNumber = null;
        _limitOneWeekToDateByMAWBShipperName = null;
        _limitOneWeekFromDateByMAWBShipperName = null;
        
        clearancePoint = null;
        _selectMenu = "CA";
        _currentDate = null;
    }





}