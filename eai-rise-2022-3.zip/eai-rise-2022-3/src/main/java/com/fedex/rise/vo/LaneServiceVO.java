package com.fedex.rise.vo;

import java.io.Serializable;

public class LaneServiceVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String _svc_type_cd;
    private int    _lane_nbr;
    private int    _group_nbr;
    private String _acct_nbr;
    private String _commit_days_qty;
    private String _prim_cont_nm;
    private String _prim_cont_ph_nbr;
    private String _prim_cont_fax_nbr;
    private String _prim_cont_email_desc;
    private String _scndy_cont_nm;
    private String _scndy_cont_ph_nbr;
    private String _scndy_cont_fax_nbr;
    private String _scndy_cont_email_desc;
    private char   _pickup_day_grp;
    private char   _lift_day_grp;
    
    public LaneServiceVO(String _svc_type_cd, int _lane_nbr, int _group_nbr, String _acct_nbr) {
        super();
        this._svc_type_cd = _svc_type_cd;
        this._lane_nbr = _lane_nbr;
        this._group_nbr = _group_nbr;
        this._acct_nbr = _acct_nbr;
    }
    
    public LaneServiceVO() {
    }

    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }
    /**
     * @param _acct_nbr the _acct_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr;
    }
    /**
     * @return the _commit_days_qty
     */
    public String get_commit_days_qty() {
        return _commit_days_qty;
    }
    /**
     * @param _commit_days_qty the _commit_days_qty to set
     */
    public void set_commit_days_qty(String _commit_days_qty) {
        this._commit_days_qty = _commit_days_qty;
    }
    /**
     * @return the _group_nbr
     */
    public int get_group_nbr() {
        return _group_nbr;
    }

    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_group_nbr(int _group_nbr) {
        this._group_nbr = _group_nbr;
    }

    /**
     * @return the _lane_nbr
     */
    public int get_lane_nbr() {
        return _lane_nbr;
    }
    /**
     * @param _lane_nbr the _lane_nbr to set
     */
    public void set_lane_nbr(int _lane_nbr) {
        this._lane_nbr = _lane_nbr;
    }
    /**
     * @return the _lift_day_grp
     */
    public char get_lift_day_grp() {
        return _lift_day_grp;
    }
    /**
     * @param _lift_day_grp the _lift_day_grp to set
     */
    public void set_lift_day_grp(char _lift_day_grp) {
        this._lift_day_grp = _lift_day_grp;
    }
    /**
     * @return the _pickup_day_grp
     */
    public char get_pickup_day_grp() {
        return _pickup_day_grp;
    }
    /**
     * @param _pickup_day_grp the _pickup_day_grp to set
     */
    public void set_pickup_day_grp(char _pickup_day_grp) {
        this._pickup_day_grp = _pickup_day_grp;
    }
    /**
     * @return the _prim_cont_email_desc
     */
    public String get_prim_cont_email_desc() {
        return _prim_cont_email_desc;
    }
    /**
     * @param _prim_cont_email_desc the _prim_cont_email_desc to set
     */
    public void set_prim_cont_email_desc(String _prim_cont_email_desc) {
        this._prim_cont_email_desc = _prim_cont_email_desc;
    }
    /**
     * @return the _prim_cont_fax_nbr
     */
    public String get_prim_cont_fax_nbr() {
        return _prim_cont_fax_nbr;
    }
    /**
     * @param _prim_cont_fax_nbr the _prim_cont_fax_nbr to set
     */
    public void set_prim_cont_fax_nbr(String _prim_cont_fax_nbr) {
        this._prim_cont_fax_nbr = _prim_cont_fax_nbr;
    }
    /**
     * @return the _prim_cont_nm
     */
    public String get_prim_cont_nm() {
        return _prim_cont_nm;
    }
    /**
     * @param _prim_cont_nm the _prim_cont_nm to set
     */
    public void set_prim_cont_nm(String _prim_cont_nm) {
        this._prim_cont_nm = _prim_cont_nm;
    }
    /**
     * @return the _prim_cont_ph_nbr
     */
    public String get_prim_cont_ph_nbr() {
        return _prim_cont_ph_nbr;
    }
    /**
     * @param _prim_cont_ph_nbr the _prim_cont_ph_nbr to set
     */
    public void set_prim_cont_ph_nbr(String _prim_cont_ph_nbr) {
        this._prim_cont_ph_nbr = _prim_cont_ph_nbr;
    }
    /**
     * @return the _scndy_cont_email_desc
     */
    public String get_scndy_cont_email_desc() {
        return _scndy_cont_email_desc;
    }
    /**
     * @param _scndy_cont_email_desc the _scndy_cont_email_desc to set
     */
    public void set_scndy_cont_email_desc(String _scndy_cont_email_desc) {
        this._scndy_cont_email_desc = _scndy_cont_email_desc;
    }
    /**
     * @return the _scndy_cont_fax_nbr
     */
    public String get_scndy_cont_fax_nbr() {
        return _scndy_cont_fax_nbr;
    }
    /**
     * @param _scndy_cont_fax_nbr the _scndy_cont_fax_nbr to set
     */
    public void set_scndy_cont_fax_nbr(String _scndy_cont_fax_nbr) {
        this._scndy_cont_fax_nbr = _scndy_cont_fax_nbr;
    }
    /**
     * @return the _scndy_cont_nm
     */
    public String get_scndy_cont_nm() {
        return _scndy_cont_nm;
    }
    /**
     * @param _scndy_cont_nm the _scndy_cont_nm to set
     */
    public void set_scndy_cont_nm(String _scndy_cont_nm) {
        this._scndy_cont_nm = _scndy_cont_nm;
    }
    /**
     * @return the _scndy_cont_ph_nbr
     */
    public String get_scndy_cont_ph_nbr() {
        return _scndy_cont_ph_nbr;
    }
    /**
     * @param _scndy_cont_ph_nbr the _scndy_cont_ph_nbr to set
     */
    public void set_scndy_cont_ph_nbr(String _scndy_cont_ph_nbr) {
        this._scndy_cont_ph_nbr = _scndy_cont_ph_nbr;
    }
    /**
     * @return the _svc_type_cd
     */
    public String get_svc_type_cd() {
        return _svc_type_cd;
    }
    /**
     * @param _svc_type_cd the _svc_type_cd to set
     */
    public void set_svc_type_cd(String _svc_type_cd) {
        this._svc_type_cd = _svc_type_cd;
    }


}
