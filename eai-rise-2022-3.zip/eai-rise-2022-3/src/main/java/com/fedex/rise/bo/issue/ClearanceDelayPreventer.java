package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class ClearanceDelayPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(ClearanceDelayPreventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static ClearanceDelayPreventer _instance = new ClearanceDelayPreventer();

    static {
        // The previous scans below will prevent a new issue being created.
    	_preventingScans.add(RiseConstants.ECCO);
       	_preventingScans.add(RiseConstants.DEX);
    }
  
    private ClearanceDelayPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	// If it has been delivered, do not create any new events.
        if (DeliveryPreventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (_preventingScans.contains(anPastEventVO.get_track_type_cd())) {
            logger.debug("Issue prevented by Clearance Delay Scans Preventer.");
            return true;
        }
        
        // If a STAT65 event previous to the current event.
    	if (anPastEventVO.get_track_type_cd().equalsIgnoreCase(RiseConstants.STAT) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("65")){
        	logger.debug("Issue prevented by STAT 65");
        	return true;
        }
             
        return false;
    }

    public static ClearanceDelayPreventer getInstance() {
        return _instance;
    }
}
