package com.fedex.rise.auth;

import java.sql.SQLException;
import java.util.Date;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.logging.log4j.ThreadContext;

import com.fedex.rise.bean.UserBean;
import com.fedex.rise.db.MonitorReportDAO;
import com.fedex.rise.util.ServiceLocatorException;

/** 
 * This class monitors the total number of sessions created from the
 * time the application is loaded, the current number of sessions in memory,
 * and the maximum number of sessions that have ever been in memory at any one
 * time.
 */
public class HttpSessionMonitor implements HttpSessionListener {

    private transient final Log log = LogFactory.getLog(this.getClass());

    /** count of active sessions */
    private long totalSessionCount = 0;
	private long currentSessionCount = 0;
	private long maxSessionCount = 0;

    public static final String HTTP_SESSION_MONITOR = "httpSessionMonitor";
   
    
    /**
     * Default constructor for HttpSessionMonitor.
     */
    public HttpSessionMonitor() {
        super();
        log.info("A HttpSessionMonitor has been instantiated.");
    }

    public synchronized void sessionCreated(HttpSessionEvent event){
        HttpSession session = event.getSession();
        
        synchronized (this) {
          ++totalSessionCount;
          ++currentSessionCount;
          if (maxSessionCount < currentSessionCount)
              maxSessionCount = currentSessionCount;
        }

        if (log.isDebugEnabled()) {
           String message = new StringBuffer("New Session created: ").append(session.getId())
              .append(", currentSessionCount: ").append(currentSessionCount)
              .append(", maxSessionCount: ").append(maxSessionCount)
              .append(", totalSessionCount: ").append(totalSessionCount).toString();

           log.debug(message);
        }
        
        session.setAttribute("sessionstarted", new Date());
    }  
    
	/**
	 * This method is invoked whenever a session has been destroyed. The object may be destroyed
	 * due to an explicit call to invalidate method or because the elapsed time since the last client
	 * access exceeds the session timeout.
	 *
	 * @param event Pass in the HttpSessionEvent.
	 * @see javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet.http.HttpSessionEvent)
	 */
    public  void sessionDestroyed(HttpSessionEvent event) {
        HttpSession session = event.getSession();
        
        synchronized (this) {
           currentSessionCount--;
        }

        // if user found in session, then set log4j NDC, so user id logged
        UserBean user = (UserBean)session.getAttribute("UserBean");
        String userId;
        if (user != null) {
            userId = user.getUserId();
        }else {
        	log.debug("UserBean is null");
            userId = new String("");
        }
        
        Date d = (Date)session.getAttribute("sessionstarted");
        long durationTime = System.currentTimeMillis() - d.getTime();
        String message = new StringBuffer("Session destroyed: ").append(session.getId())
           .append(", duration: "+(durationTime))
           .append("ms, currentSessionCount: ").append(currentSessionCount)
           .append(", maxSessionCount: ").append(maxSessionCount)
           .append(", totalSessionCount: ").append(totalSessionCount).toString();
        
        // Set duration time for the monitor employee to the database.
        if (user != null && user.getRole() != null){
        	if (user.getRole().equalsIgnoreCase("M")){
        		setDurationTime(durationTime, user.getUserId());
        	}
        }
        
        // if user found in session, then set NDC and exit session
        ThreadContext.push(userId);
        log.debug(message);
        ThreadContext.pop();
        
        /* Debugging for session stuff
        Enumeration stuff = session.getAttributeNames();
        while (stuff.hasMoreElements()) {
            String name = (String) stuff.nextElement();
            // Object value = session.getAttribute(name);
            log.debug("Attribute Name:"+name);
        }
        */
    }    
    
    /**
     * Converts time in milliseconds to a <code>String</code> in the format Days HH:mm:ss.SSS.
     * 
     * @param time the time in milliseconds.
     * @return a <code>String</code> representing the time in the format Days HH:mm:ss.SSS.
     */
    public static String millisecondsToString(long time) {
        int milliseconds = (int)(time % 1000);
        int seconds = (int)((time/1000) % 60);
        int minutes = (int)((time/60000) % 60);
        int hours = (int)((time/3600000) % 24);
        int days = (int)((time/3600000)/24); // hours += days*24;
        String millisecondsStr = (milliseconds<10 ? "00" : (milliseconds<100 ? "0" : ""))+milliseconds;
        String secondsStr = (seconds<10 ? "0" : "")+seconds;
        String minutesStr = (minutes<10 ? "0" : "")+minutes;
        String hoursStr = (hours<10 ? "0" : "")+hours;
        return new String(days+" Days "+hoursStr+":"+minutesStr+":"+secondsStr+"."+millisecondsStr);
    }
    
    /**
     * If the employee is a monitor, shall insert or update the DURATION_QTY for this specific monitor.
     * 
     * @param duration time in milliseconds
     * @param employeeNbr
     * @return void
     */
    private void setDurationTime(long durationTime, String employeeNbr){
    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
    	try {
    		monitorReportDAO.setDuration(durationTime, employeeNbr);
    	} catch (ServiceLocatorException sle) { 
        	log.error("Service Locator Exception: ", sle);
    	}catch (SQLException e){
    		log.error("SQLException exception", e);
    	}
    }
}
