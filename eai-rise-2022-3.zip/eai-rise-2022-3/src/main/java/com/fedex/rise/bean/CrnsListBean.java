//<%-- WR #:CRN all for OC, JDK maintenance and weblgoic startup changes  --%>
package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIData;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.tree2.TreeNode;
import org.springframework.stereotype.Component;

import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.issue.IssueDesc;
import com.fedex.rise.bo.issue.RiseIssues;
import com.fedex.rise.util.Pageable;
import com.fedex.rise.util.PagedList;
import com.fedex.rise.util.SortableList;
import com.fedex.rise.vo.ShipmentVO;

/**
 * CRN Summary List Backing bean
 */
@Component("crnsListBean")
public class CrnsListBean extends SortableList implements Serializable,
		Pageable {
	/** serial id for serialization versioning */
	private static final long serialVersionUID = 1L;

	private static final Log log = LogFactory.getLog(CrnsListBean.class);

	/** selected CRN */
	private CrnBean _selectedCrnBean = null;

	/** The selected filter, CRN's can be filtered by issue type */
	private String _filterByIssueStr = "-1";

	/** delegate to get shipment data */
	private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();

	/** list of shipments (MAWBBean) */
	private transient PagedList _shipments = null;
	private transient DataModel _dataModel = null;

	private boolean _issuesOnly = true;

	/**
	 * UIData component binding to CRN List table. Here so we can reset to page
	 * 1 after filtering
	 */
	private transient UIData _crnListUIData;

	private transient MonitorTreeBean _monitorTreeBean;
	private transient UserPreferencesBean _userPref;

	
	/**
	 * Constructor
	 */
	public CrnsListBean() {
		 super("ship_dt"); // default sort column

	}

	/**
	 * Set the monitorTreeBean, this is done via dependency injection of the
	 * Bean as specified in the Myfaces faces-config.xml.
	 * 
	 * @param monitorTreeBean
	 */
	public void setMonitorTreeBean(MonitorTreeBean monitorTreeBean) {
		_monitorTreeBean = monitorTreeBean;
		// WR#:179441 Changes
		if (_monitorTreeBean.getSelectedNode() != null) {
			// determine whether to get issuesOnly or all, based on selected
			// tree node
			if (_monitorTreeBean.getSelectedNode().getDescription()
					.equals("All"))
				_issuesOnly = false;
		}
	}

	/**
	 * Set the user preferences, this is done via dependency injection of the
	 * Bean as specified in the Myfaces faces-config.xml.
	 * 
	 * @param userPref
	 */
	public void setUserPreferencesBean(UserPreferencesBean userPref) {
		_userPref = userPref;
	}

	// ==========================================================================
	// Getters
	// ==========================================================================

	/** set CRNList UI data */
	public void setUIData(UIData uiData) {
		_crnListUIData = uiData;
	}

	/** get CRNList UI data */
	public UIData getUIData() {
		return _crnListUIData;
	}

	/**
	 * Get the CRN that is selected in the list
	 * 
	 * @return
	 */
	public CrnBean getSelectedCRN() {
		return _selectedCrnBean;
	}

	/**
	 * Get the CRN data model list
	 * 
	 * @return DataModel
	 */
	public DataModel getData() {

		// get the page size, if it is changed by UI
		int maxRows = 100;
		if (_userPref != null)
			maxRows = _userPref.getMaxCrnRowsInt();

		// shipments are cached here, and since we are request scope, and since
		// getData() can be
		// called multiple times, we only get from DB once. And since we are
		// request scope it is
		// gotten fresh each request.
		if (_shipments == null) {
			_shipments = new PagedList(this, maxRows);
		} else
			_shipments.setPageSize(maxRows); // reset page size if changed

		_dataModel = new ListDataModel(_shipments);
		return _dataModel;
	}

	/**
	 * setData only called to update data if 'preservedatamodel=true' in
	 * dataTable on jsp
	 * 
	 * @param dataModel
	 */
	public void setData(DataModel dataModel) {
		System.out.println("preserved datamodel updated");
		_dataModel = dataModel;

		// don't recreate shipment, because after saving state we
		// want to re-populate the shipment list.
		// _shipments = (List)_dataModel.getWrappedData();
	}

	/**
	 * Get a list of all issue types, to be used as a filter (unique list of
	 * issue types)
	 * 
	 * @return
	 */
	public List getFilters() {
		// get the list of distinct Issues on all this MAWB's CRNs

		ShipmentVO mawb = _monitorTreeBean.getSelectedMAWB().getShipment();
		List issueTypeCds = null;
//		List issueTypeCds = shipmentDelegate.getCRNIssues(
//				mawb.get_trkng_item_nbr(), mawb.get_trkng_item_uniq_nbr());

		// iterate through issue codes and get descriptions, merge duplicate
		// descriptions
		HashMap issueDescs = new HashMap();
		for (Iterator i = issueTypeCds.iterator(); i.hasNext();) {
			String issueTypeCd = (String) i.next();
			IssueDesc desc = RiseIssues.getIssueDesc(Integer
					.parseInt(issueTypeCd));
			if (desc != null) {
				String shortDesc = desc.getShortTextDesc();

				// see if description is already in the hash map, if so, update
				// the description
				// in the hash map and concat the issue type codes (user should
				// only see one desc)
				String value = (String) issueDescs.get(shortDesc);
				if (value == null)
					issueDescs.put(desc.getShortTextDesc(), issueTypeCd);
				else {
					issueDescs.put(desc.getShortTextDesc(), value + ":"
							+ issueTypeCd);
				}
			} else {
				log.error("No Desc from IssueTypeCd: " + issueTypeCd);
			}
		}

		// Create the SelectItem list of issues
		List filters = new ArrayList(issueTypeCds.size());
		filters.add(new SelectItem("-1", "-")); // add no filtering as default
												// choice

		// iterate through issue to the the codes and descriptions
		for (Iterator i = issueDescs.entrySet().iterator(); i.hasNext();) {
			Map.Entry issue = (Map.Entry) i.next();
			// issue.value contains the type cd(s) and issue.key is the
			// description (shown in dropdown)
			filters.add(new SelectItem((String) issue.getValue(),
					(String) issue.getKey()));
		}

		return filters;
	}

	/**
	 * get selected filter
	 */
	public String getFilter() {
		return _filterByIssueStr;
	}

	/**
	 * set selected filter
	 */
	public void setFilter(String filter) {
		_filterByIssueStr = filter;
	}

	/**
	 * @return true if filter set
	 */
	public boolean isFiltered() {
		return !_filterByIssueStr.equals("-1");
	}

	/*-----------------------------------------------------------------------
	 * Methods for call back from PagedList 
	 *-----------------------------------------------------------------------
	 */

	/**
	 * Get the specified page from the backend/database for the selected tree
	 * node.
	 * 
	 * @see com.fedex.rise.util.Pageable#getPage(int, int)
	 */
	public List getPage(int page, int pageSize) {

		Map params = FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap();
		MonitorTreeBean _monitorTreeBean = (MonitorTreeBean) params
				.get("monitorTreeBean");
		TreeNode node = _monitorTreeBean.getSelectedNode();
		String nodeId = node.getIdentifier();
		if (node == null)
			return null;

		String[] nodes = nodeId.split(":");
		String shipper = nodes[0].trim();
		String accountNbr = nodes[1].trim();
		String lane = nodes[2].trim();
		String serviceTypeCd = nodes[3].trim();
		String issuesOrAll = nodes[4].trim();
		log.info("CrnsListBean getSize calling nodeId " + nodeId + "shipper "
				+ shipper + "accountNbr " + accountNbr + "lane " + lane
				+ "serviceTypeCd " + serviceTypeCd + "issuesOrAll "
				+ issuesOrAll);

		int shipperNbr = Integer.valueOf(shipper).intValue();
		int laneNbr = Integer.valueOf(lane).intValue();

		int startIndex = (page - 1) * pageSize;
		int endIndex = (page * pageSize);

		int shipDateOffsetInt = 0;
		if (_monitorTreeBean.getShipDateOffsetStr() != null) {
			shipDateOffsetInt = Integer.valueOf(
					_monitorTreeBean.getShipDateOffsetStr()).intValue();
		}

		log.info("crnslistbean getsize method dateoffset" + shipDateOffsetInt);

		// ShipmentVO mawb = _monitorTreeBean.getSelectedMAWB().getShipment();

		/*
		 * String[] filterByIssues = _filterByIssueStr.split(":"); if
		 * (filterByIssues!=null && filterByIssues[0].endsWith("-1"))
		 * filterByIssues = null; // no filtering
		 */
		// list of shipments, items in list are CRNBean
		/*
		 * List shipments = shipmentDelegate.getCrns(mawb.get_trkng_item_nbr(),
		 * mawb.get_trkng_item_uniq_nbr(), _issuesOnly, startIndex, endIndex,
		 * getSort(), isAscending(), filterByIssues, mawb.get_ship_dt());
		 * shipperNbr, accountNbr, laneNbr, serviceTypeCd
		 */
		// insterad of null need to pass filter details
		// int shipDateOffsetInt=183;
		List shipments = null;
//		List shipments = shipmentDelegate.getAllCrns(shipperNbr, accountNbr,
//				laneNbr, serviceTypeCd, startIndex, endIndex, getSort(),
//				isAscending(), shipDateOffsetInt, null);

		return shipments;
	}

	/**
	 * Get the size of the list of tracking numbers for the selected tree node.
	 * 
	 * @see com.fedex.rise.util.Pageable#getSize()
	 */
	public int getSize() {

		int size = 0;
		try {
			Map params = FacesContext.getCurrentInstance().getExternalContext()
					.getSessionMap();
			MonitorTreeBean _monitorTreeBean = (MonitorTreeBean) params
					.get("monitorTreeBean");
			TreeNode node = _monitorTreeBean.getSelectedNode();

			if (node == null)
				return 0;

			String nodeId = node.getIdentifier();
			String[] nodes = nodeId.split(":");
			String shipper = nodes[0].trim();
			String accountNbr = nodes[1].trim();
			String lane = nodes[2].trim();
			String serviceTypeCd = nodes[3].trim();
			String issuesOrAll = nodes[4].trim();
			log.info("CrnsListBean getSize calling nodeId " + nodeId
					+ "shipper " + shipper + "accountNbr " + accountNbr
					+ "lane " + lane + "serviceTypeCd " + serviceTypeCd
					+ "issuesOrAll " + issuesOrAll);

			int shipperNbr = Integer.valueOf(shipper).intValue();
			int laneNbr = Integer.valueOf(lane).intValue();

			int shipDateOffsetInt = 0;
			if (_monitorTreeBean.getShipDateOffsetStr() != null) {
				shipDateOffsetInt = Integer.valueOf(
						_monitorTreeBean.getShipDateOffsetStr()).intValue();
			}

			log.info("crnslistbean getsize method dateoffset"
					+ shipDateOffsetInt);

			// ShipmentVO mawb =
			// _monitorTreeBean.getSelectedMAWB().getShipment();

			/*
			 * String[] filterByIssues = _filterByIssueStr.split(":"); if
			 * (filterByIssues!=null && filterByIssues[0].endsWith("-1"))
			 * filterByIssues = null; // no filtering
			 */
			// list of shipments, items in list are CRNBean
			/*
			 * size = shipmentDelegate.getCrnCount(mawb.get_trkng_item_nbr(),
			 * mawb.get_trkng_item_uniq_nbr(), _issuesOnly, filterByIssues);
			 */
			// int shipDateOffsetInt=183;
//			size = shipmentDelegate.getAllCrnsCount(shipperNbr, accountNbr,
//					laneNbr, serviceTypeCd, shipDateOffsetInt);
			/*
			 * size = shipmentDelegate.getCrnCount("654182020402", "2458017000",
			 * false, null);
			 */
		} catch (Exception e) {
			log.error("CrnsListBean getSize Unable to get the data ", e);
		}

		return size;
	}

	// ==========================================================================
	// Actions
	// ==========================================================================

	/**
	 * Resolve the selected Issues Action
	 */
	public String markIssuesResolvedAction() {
		List crns = (List) _dataModel.getWrappedData();

		// split issue type cds from selected issues to filter by
		String[] issueTypeCds = _filterByIssueStr.split(":");
		if (issueTypeCds == null || issueTypeCds[0].equals("-1"))
			return null; // must be filtered

		// these issue type cds should have same desc, so get first
		String issueDesc = RiseIssues.getIssueDesc(
				Integer.parseInt(issueTypeCds[0])).getShortTextDesc();

		// iterate through all CRNs
		for (Iterator itr = crns.iterator(); itr.hasNext();) {
			CrnBean crn = (CrnBean) itr.next();

			boolean resolvedFlag = crn.getResolveIssue();
			// if issue flag is to be resolved then mark filtered issue as
			// resolved
			if (resolvedFlag) {
				List issues = crn.getIssues();
				// iterate through all our issues, to find correct issue
				for (Iterator itr2 = issues.iterator(); itr2.hasNext();) {
					IssueBean issueBean = (IssueBean) itr2.next();
					if (issueBean.getDesc().equals(issueDesc)) {
						issueBean.markIssueResolvedAction();
					}
				}
			}
		}
		_shipments = null; // reset, so we get new list from DB, showing
							// resolved status

		// TODO: handle errors

		return null;
	}

	/**
	 * Filter the CRNs by the selected issue type
	 */
	public String filterAction() {
		if (_crnListUIData != null) {
			_crnListUIData.setFirst(0); // set CRN List to page 1
			// clear list so it is refreshed, even after validation error
			_crnListUIData.getChildren().clear();
		}

		return null; // redisplay the page
	}

/*	public String selectMonitorTreeNodeAction(ActionEvent event) throws AbortProcessingException {
		if (_crnListUIData != null) {
			_crnListUIData.setFirst(0); // set MAWB List to page 1
			// clear list so it is refreshed, even after validation error
			_crnListUIData.getChildren().clear();
		}

		return "showMawbs"; // redisplay the page
	}
*/
	// ==========================================================================
	// Navigation methods
	// ==========================================================================

	public void pagingAction(ActionEvent event) throws AbortProcessingException {
		if (_crnListUIData != null) {
			// clear list so it is refreshed, even after validation error
			_crnListUIData.getChildren().clear();
		}
	}

	/**
	 * Navigation to get the CRN details
	 * 
	 * @return
	 */
	public String getCRNDetail() {
		FacesContext context = FacesContext.getCurrentInstance();
		Map requestParams = context.getExternalContext()
				.getRequestParameterMap();

		String trackingNbr = (String) requestParams.get("trkng_item_nbr");
		String trackingUniqNbr = (String) requestParams
				.get("trkng_item_uniq_nbr");
//		CrnBean _selectedCrnBean = shipmentDelegate.getCrn(trackingNbr,
//				trackingUniqNbr);

		if (trackingNbr != null && trackingUniqNbr != null) {
			// tell the controller which bean is selected, because the
			// controller is session scope,
			// but we are only request scope
			_monitorTreeBean.setSelectedCRN(_selectedCrnBean);

			log.info("Select CRN Detail: " + trackingNbr);

			// navigate to the detail screen
			return "showCrnDetail";
		} else {
			// shouldn't happen
			return null;
		}
	}

	/**
	 * Navigation to get the Next CRN details
	 * 
	 * @return
	 */
	public String getNextCRNDetail() {
		log.info("Select next CRN Detail");
		return "nextCrnDetail";
	}

	/**
	 * Navigation to get the Previous CRN details
	 * 
	 * @return
	 */
	public String getPreviousCRNDetail() {
		log.info("Select prev CRN Detail");
		return "prevCrnDetail";
	}

	/**
	 * Navigation back to the CRN List, on MAWB details
	 * 
	 * @return
	 */
	public String getCrnList() {
		log.info("Select CRN List");

		// Set to go back to the CRN List on tab 3
		Map params = FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap();
		MawbTabbedPaneBean tabbedPaneBean = (MawbTabbedPaneBean) params
				.get("MawbTabbedPaneBean");
		tabbedPaneBean.setSelectedIndex(3);

		return "showCrnList";
	}

	public String getCrnIssues() {
		log.info("Select CRN Issues");

		return "showCrnIssues";
	}

	/**
	 * Navigation back to the MAWB detail
	 * 
	 * @return
	 */
	public String getMawb() {
		log.info("Select Mawb ");

		// Set to go back to the MAWB Detail on tab 0
		Map params = FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap();
		MawbTabbedPaneBean tabbedPaneBean = (MawbTabbedPaneBean) params
				.get("MawbTabbedPaneBean");
		tabbedPaneBean.setSelectedIndex(0);

		return "showCrnList";
	}

	// ==========================================================================
	// Protected Methods
	// ==========================================================================

	protected boolean isDefaultAscending(String sortColumn) {
		return true;
	}

	protected void sort(final String column, final boolean ascending) {
		// sort handled by SQL in database, but we still need the column and
		// ascending info
	}

	/*-----------------------------------------------------------------------
	 * Private Methods
	 *-----------------------------------------------------------------------
	 */

	/**
	 * Override deserialization to handle the re-creation of our transient data
	 */
	private void readObject(java.io.ObjectInputStream in) throws IOException,
			ClassNotFoundException {
		in.defaultReadObject();
		shipmentDelegate = new ShipmentDelegate();
	}

}
