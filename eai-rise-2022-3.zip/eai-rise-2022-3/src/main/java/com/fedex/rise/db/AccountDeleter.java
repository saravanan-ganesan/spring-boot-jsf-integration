package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class AccountDeleter extends OracleBase {

    private static Logger logger = LogManager.getLogger(AccountDeleter.class);

    public AccountDeleter(Connection con) {
        super(con);
    }

    private static final String deleteAccountSQL = "Delete from Account where " +
                "GROUP_NBR = ? and ACCT_NBR = ?";

    public void deleteAccount(int aGroupNbr, String anAccountNbr) throws SQLException {

        try {
            setSqlSignature(deleteAccountSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, aGroupNbr);
            pstmt.setString(2, anAccountNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode());
           logger.error(sqle);
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
