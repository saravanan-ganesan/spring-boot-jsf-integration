package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.bo.UserDelegate;
import com.fedex.rise.format.EmployeeNameFormatter;
import com.fedex.rise.format.LaneFormatter;
import com.fedex.rise.format.ServiceTypeFormatter;
import com.fedex.rise.vo.AccountGroupVO;
import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.LaneVO;
import com.fedex.rise.xref.SvcLvlDescCodes;

/**
 * Backer bean for Shipper Tree. Basically makes a TreeNode available.
 * 
 */
public class ShipperBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(ShipperBean.class);

    /** Delegate to get shipper data */
    private ShipperDelegate shipperDelegate = new ShipperDelegate();
    /** Delegate to get user data (list of monitors) */
    private UserDelegate userDelegate = new UserDelegate();

    /** ShipperTree */
    private ShipperTreeBean _shipperTreeBean = null;
   
    /** determine whether to show add account dialog or not */
    private boolean _addDialogCollapsed = true;
    
    /** editable attributes */
    private int _commitDaysQty = 0;
    private String _shipperName =  null;
    private String _accountName =  null;
    private String _accountNbr =  null;
    private String[] _chosenLaneNbrs = new String[0];
     // to handle the empty values for monitors it is defined as new instead of null
    private String[] _manyMonitor = new String[0];
    private String[] _selectedServiceTypeCds = null;
    
    /** Monitor for mass assigning monitors */
    private String _selectedMonitor = null;
    
    /** other key values, to identify the Shipper */
    private String _shipperNbr = null;
    
    /** cached list of lanes */
    private List _allLanes = new ArrayList();
    
    private String _selectedLane = null;
    private String _originCountryCd = null;
    private String _destCountryCd = null;
  
    /** list of valid services */
    static private List _allServices = new ArrayList();
    static {
        HashMap services = SvcLvlDescCodes.getAll();
        Iterator itr = services.entrySet().iterator();
        while (itr.hasNext()) {
           Map.Entry entry = (Map.Entry)itr.next();
           String svcTypeCd = (String)entry.getKey();
           String svcTypeDesc = (String)entry.getValue();
           
           // create SelectItem with the key (svcTypeCd) and a formatted display value
           _allServices.add(new SelectItem(svcTypeCd, ServiceTypeFormatter.format(svcTypeCd, svcTypeDesc)));
        }
    }
    
    /** 
     * Default Constructor
     */
    public ShipperBean() {
        shipperDelegate = new ShipperDelegate();
        
        // get the ShipperTreeBean from the session, so we can get access to 
        // the selected shipper node (we'll need the shipperNbr) 
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        _shipperTreeBean = (ShipperTreeBean)params.get("shipperTreeBean");
        init();
    }
    
    private void init() {
        // Get the selected node key values (shipperNbr)
        String[] keys = _shipperTreeBean.getSelectedKeys();
        
        // if key is zero, then this is really the "shippers" node and we don't 
        // have a specific shipper, because we will be listing all shippers
        if (!keys[0].equals("0")) {
            _shipperNbr = keys[0];
        
            AccountGroupVO accountGroupVO = shipperDelegate.getShipper(_shipperNbr);
            _shipperName = accountGroupVO.get_group_nm();
        }
    }
   
    
    /*--------------------------------------------------------------------- 
     * Getter/Setter methods
     *---------------------------------------------------------------------
     */
    
    /**
     * Get all possible Lanes
     * @return List of SelectItems for the lanes
     */
    public List getAllLanes() {
        _allLanes = shipperDelegate.getLanes();
        List laneSelectItems = new ArrayList(_allLanes.size());
        for (Iterator itr=_allLanes.iterator(); itr.hasNext(); ) {
            LaneVO lane = (LaneVO)itr.next();
            String laneStr = LaneFormatter.format(lane.get_orig_cntry_cd(),
                      lane.get_dest_cntry_cd());
            laneSelectItems.add(new SelectItem(Integer.toString(lane.get_lane_nbr()), laneStr));
            
            // reselect the selected lane
            if (lane.get_orig_cntry_cd().equals(_originCountryCd) && 
                lane.get_dest_cntry_cd().equals(_destCountryCd)) {
                _selectedLane = String.valueOf(lane.get_lane_nbr());
            }
        }
        return laneSelectItems;
    }
    
    /**
     * Get the lanesNbrs that are on the account
     * @return
     */
    public String[] getChosenLaneNbrs() {
        return _chosenLaneNbrs;
    }
    
    /**
     * Set the lanesNbrs that should be on the account
     * @param list array of laneNbrs
     */
    public void setChosenLaneNbrs( String[] list ) {
        _chosenLaneNbrs = list;
    }
    /**
     * Get the monitors that are on the account
     * @return
     */
    public String[] getManyMonitor() {
        return _manyMonitor;
    }
    
    /**
     * Set the Monitors that should be on the account
     * @param list array of laneNbrs
     */
    public void setManyMonitor( String[] monitors ) {
        _manyMonitor = monitors;
    }
    
    /**
     * @return the account name
     */
    public String getAccountName() {
        return _accountName;
    }
    
    /**
     * @param accountName new accountName to set
     */
    public void setAccountName(String accountName) {
        _accountName = accountName.trim();
    }
    
    /**
     * @return the accountNbr
     */
    public String getAccountNbr() {
        return _accountNbr;
    }
    
    /**
     * @param accountNbr the new accountNbr to set
     */
    public void setAccountNbr(String accountNbr) {
        _accountNbr = accountNbr.trim();
    }
    
    public String getShipperName() {
        return _shipperName;
    }
   
    public void setShipperName(String shipperName) {
        _shipperName = shipperName;
    }

    /**
     * get selected Monitor, for mass assigning monitors
     */
    public String getSelectedMonitor() {
        log.debug("Entering getSelectedMonitor()");
        return _selectedMonitor;
    }
        
    /**
     * set selected Monitor 
     */
    public void setSelectedMonitor(String monitor) {
        log.debug("Entering setSelectedMonitor()");
        _selectedMonitor = monitor;
    }
    
    /**
     * Get if the add account dialog collapsed or not
     * @return true if collapsed
     */
    public boolean isAddDialogCollapsed()
    {
        return _addDialogCollapsed;
    }

    /**
     * Set the add account dialog collapsed or not
     * @param collapsed true for collapsed
     */
    public void setAddDialogCollapsed(boolean collapsed)
    {
        _addDialogCollapsed = collapsed;
    }

    /**
     * set selected Services (Add Services to a Lane)
     * @param services array of service type codes
     */
    public void setSelectedServices(String[] services) {
        log.debug("Entering setSelectedServices()");
        
        _selectedServiceTypeCds = services;
    }
    
    /**
     * get selected Services (Services on a Lane)
     * @return services array of service type codes
     */
    public String[] getSelectedServices() {
        log.debug("Entering getSelectedServices()");
        
        if (_selectedServiceTypeCds == null) {
           return new String[0]; // no services yet, so default to none
        } else {
           //return services;
           return _selectedServiceTypeCds;
        }
    }
    
    /**
     * Get the list of valid services
     * @return
     */
    public List getAllServices() {
        return _allServices;
    }
    
    /**
     * @return the _commitDaysQty
     */
    public String getCommitDaysQty() {
        return String.valueOf(_commitDaysQty);
    }


    /**
     * @param daysQty the _commitDaysQty to set
     */
    public void setCommitDaysQty(String daysQty) {
        _commitDaysQty = Integer.parseInt(daysQty);
    }
    
    
    /*--------------------------------------------------------------------- 
     * Action methods
     *---------------------------------------------------------------------
     */
   

    /**
     * Add Shipper - provide the ability to add a new shipper with one screen.
     * @return void
     */
    
    public void addShipperAction() {
        log.debug("Entering addShipperAction()");
              
        // The following fields can not be null.
        // _shipperName the name of the new shipper.
        // _accountNbr the account number of the shipper.
        // _accountName account name of the shipper.
        // _chosenLaneNbrs the chosen lane numbers to be monitored for this shipper.
        // _selectedServiceTypeCds the selected service types to be monitored.
        // _manyMonitor the monitor name that will monitor this shipper,
        // account, service type and lane number.
        if (_shipperName != null && _shipperName.length()>0 &&
        		_accountNbr != null && _accountNbr.length()>0 &&
        		_accountName != null && _accountName.length()>0 &&
        		_chosenLaneNbrs != null &&_chosenLaneNbrs.length >0 &&
        		_selectedServiceTypeCds != null && _selectedServiceTypeCds.length >0 &&        		       		
        		_manyMonitor != null &&_manyMonitor.length >0) {
        	// create a new shipper
        	shipperDelegate.addShipper(_shipperName);
           
        	// Set the node to go to to node zero.
            _shipperTreeBean.setForceNodeZero(true);
           
        } else {
           // Missing required data.
        	log.info("Missing Required Data: Must enter data in all fields.");
        	FacesContext facesContext = FacesContext.getCurrentInstance();
            FacesMessage facesMessage = new FacesMessage(
            		FacesMessage.SEVERITY_ERROR, 
            		"Missing Required Data:",   //summary
            		"Must enter data in all fields.");
            facesContext.addMessage(null, facesMessage);
            return;
        }
        
        // Get the account group number
        if (_shipperName != null && _shipperName.length()>0) {
        	AccountGroupVO accountGroupVO = new AccountGroupVO();
        	accountGroupVO = shipperDelegate.getShipperFromName(_shipperName);
        	if (accountGroupVO != null){
        		_shipperNbr = String.valueOf(accountGroupVO.get_group_nbr());
        	}
         } else {
        	 log.error("A duplicate of the shipper name");
         }
        
        // Create the new account with account name and number.
        if (_accountNbr != null && _accountNbr.length()>0 && _shipperNbr != null && _shipperNbr.length()>0) {
            shipperDelegate.addAccountToShipper(_shipperNbr, _accountNbr, _accountName);
            
            // tell shipper so this new node will be selected in the tree
            _shipperTreeBean.notifyAccountAdded(_accountNbr);          
            
            // add these lanes to the shippers account (causes adds, deletes, updates)
            if (_chosenLaneNbrs != null){
            	int size = _chosenLaneNbrs.length;
            	shipperDelegate.addLanesToShipper(_shipperNbr, _accountNbr, _chosenLaneNbrs);
           
            	for(int var =0; var < size ; var++){
            		if (_chosenLaneNbrs[var] != null && _selectedServiceTypeCds != null) {	
            			// add these lanes to the shippers account (causes adds, deletes, updates)
            			shipperDelegate.addServiceToShipper(_shipperNbr, _accountNbr, _chosenLaneNbrs[var], 
            				_selectedServiceTypeCds);
                
            			// update the service for this lane
            			if (_selectedServiceTypeCds != null){
            				int length = _selectedServiceTypeCds.length;
            				for(int i =0; i < length ; i++){
            				shipperDelegate.updateLaneService(_shipperNbr, _accountNbr, _chosenLaneNbrs[var], 
            					_selectedServiceTypeCds[i], _commitDaysQty);
            				
            					//update the monitors
            						if (_manyMonitor != null){            							
            						shipperDelegate.addAcctLaneServiceManyMonitor(_shipperNbr, _accountNbr, 
            							_chosenLaneNbrs[var], _selectedServiceTypeCds[i], _manyMonitor);
            					}
            				}
            			}
            		}
            	}
            }
        }  
    }
   
    /**
     * Delete Shipper 
     */
    public void deleteShipperAction() {
        log.debug("Entering deleteShipperAction()");
        
        if (shipperDelegate.deleteShipper(_shipperNbr) == 0) {
            // Error, assume it was because accounts haven't been deleted  
            FacesContext context = FacesContext.getCurrentInstance();
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Deletion Error:",   //summary
                "All of this shipper's accounts must first be deleted!");
            context.addMessage(null, facesMsg);
        } else {
           // tell shipper of deletion
           _shipperTreeBean.notifyDelete();
        }
    }
    
    /**
     * Save Shipper 
     */
    public void saveShipperAction() {
        log.debug("Entering saveShipperAction()");   
        shipperDelegate.updateShipper(_shipperNbr, _shipperName);
    }
    
    /**
     * Add Account to a Shipper
     */
    public String addAccountAction() {
        log.debug("Entering addAccountAction()");

        if (_accountNbr != null && _accountNbr.length()>0) {
           shipperDelegate.addAccountToShipper(_shipperNbr, _accountNbr, _accountName);
           
           // tell shipper so this new node will be selected in the tree
           _shipperTreeBean.notifyAccountAdded(_accountNbr);
           _addDialogCollapsed = true;  // hide add account dialog after add
        } 
        return "success";
    }
    
    /**
     * Get the list of all valid monitors
     * @return
     */
    public List getMmonitors() {
        List users = userDelegate.getUsers();
        List mmonitors = new ArrayList(users.size());
        for (Iterator itr=users.iterator(); itr.hasNext(); ) {
            EmployeeVO user = (EmployeeVO)itr.next();
            if (UserRole.isMonitor(user.get_emp_role_cd())) {
                String monitorName = EmployeeNameFormatter.format(user.get_emp_first_nm(), user.get_emp_last_nm(),
                        user.get_emp_nbr());
                mmonitors.add(new SelectItem(user.get_emp_nbr(), monitorName));
            }
        }
        return mmonitors;
    }
    public List getMonitors() {
        List users = userDelegate.getUsers();
        List monitors = new ArrayList(users.size());
        monitors.add(new SelectItem("0", ""));  // no monitor as default choice
        for (Iterator itr=users.iterator(); itr.hasNext(); ) {
            EmployeeVO user = (EmployeeVO)itr.next();
            if (UserRole.isMonitor(user.get_emp_role_cd())) {
                String monitorName = EmployeeNameFormatter.format(user.get_emp_first_nm(), user.get_emp_last_nm(),
                        user.get_emp_nbr());
                monitors.add(new SelectItem(user.get_emp_nbr(), monitorName));
            }
        }
        return monitors;
    }

}

