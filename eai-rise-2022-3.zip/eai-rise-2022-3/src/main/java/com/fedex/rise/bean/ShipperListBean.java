/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.fedex.rise.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.util.ColumnHeader;
import com.fedex.rise.util.SortableList;

/**
 * Shipper Summary List Backing bean
 */
public class ShipperListBean extends SortableList {
    
    private static final Log log = LogFactory.getLog(ShipperListBean.class);
    
    private static final int SORT_ASCENDING = 1;
    private static final int SORT_DESCENDING = -1;
    // TODO: paging
    //private static final int MAX_ROWS = 14;
    private static final int MAX_ROWS = 9999;
  
     
    private DataModel data;
    private DataModel columnHeaders;
   
    /** cached shippers */
    private List shippers = null;
    private String _selectedMonitor = null;
    
    
    /**
     * Constructor
     */
    public ShipperListBean() {
        super("Shipper Name");  // default sort by shipper name
        
        // create header row
        List headerList = new ArrayList();
        headerList.add(new ColumnHeader("Shipper Name", "150", false));
        headerList.add(new ColumnHeader("Account Name", "150", false));
        headerList.add(new ColumnHeader("Account Number", "80", false));
        headerList.add(new ColumnHeader("Lane", "60", false));
        headerList.add(new ColumnHeader("Service", "60", false));
        headerList.add(new ColumnHeader("Monitor", "100", false));
        headerList.add(new ColumnHeader("Select", "3", true)); // editable checkbox
        columnHeaders = new ListDataModel(headerList);
    }

    
    // ==========================================================================
    // Getters
    // ==========================================================================

    /**
     * Return the number of rows to show on a page
     * @return
     */
    public int getRowsPerPage() {
        // if no data then no rows 
        if (data == null) return 0;
       
        // if less than a page, then return actual number of rows
        int rows = data.getRowCount();
        if (rows > MAX_ROWS)
            return MAX_ROWS;
        else
            return rows;
    }
   
    /**
     * Get the Shipper data model list
     * @return DataModel
     */
    public DataModel getData() {
        populateShipperList();
            
        sort(getSort(), isAscending());
        return data;
    }

    /**
     * 
     * @param datamodel
     */
    void setData(DataModel datamodel) {
        System.out.println("preserved datamodel updated");
        // just here to see if the datamodel is updated if
        // preservedatamodel=true
    }

    public DataModel getColumnHeaders() {
        return columnHeaders;
    }

    public Object getColumnValue() {
        Object columnValue = null;
        if (data.isRowAvailable() && columnHeaders.isRowAvailable()) {
            columnValue = ((List) data.getRowData()).get(columnHeaders.getRowIndex());
        }
        return columnValue;
    }

    public void setColumnValue(Object value) {
        if (data.isRowAvailable() && columnHeaders.isRowAvailable()) {
            ((List) data.getRowData()).set(columnHeaders.getRowIndex(), value);
        }
    }

    public String getColumnWidth() {
        String columnWidth = null;
        if (data.isRowAvailable() && columnHeaders.isRowAvailable()) {
            columnWidth = ((ColumnHeader) columnHeaders.getRowData()).getWidth();
        }
        return columnWidth;
    }

    public boolean isValueModifiable() {
        boolean valueModifiable = false;
        if (data.isRowAvailable() && columnHeaders.isRowAvailable()) {
            valueModifiable = ((ColumnHeader) columnHeaders.getRowData()).isEditable();
            
            // if editible, also check if service level present, 
            // if not, then change it to not editiable
            if (valueModifiable) {
                String serviceTypeCd = (String)((List)data.getRowData()).get(4);
                if (serviceTypeCd == null || serviceTypeCd.length() == 0) {
                    valueModifiable = false;
                }
            }  
        }
        return valueModifiable;
    }

    /**
     * First column (tracking number) is a link to get to details
     * @return true if it is first column
     */
    public boolean isLink() {
        boolean valueLink = false;
        return valueLink;
    }
   
    public boolean isSelected() {
        Object selected = ((List)data.getRowData()).get(columnHeaders.getRowIndex());
        return ((Boolean)selected).booleanValue();
    }
    
    public void setSelected(boolean selected) {
        ((List)data.getRowData()).set(columnHeaders.getRowIndex(), Boolean.valueOf(selected));
    }
    
    public String updateMonitorsAction() {
        log.debug("Entering updateMonitorAction()");
        List rows = (List)data.getWrappedData();
        for (Iterator rowItr = rows.iterator(); rowItr.hasNext(); ) {
            List columns = (List) rowItr.next();
            Object oSelected = columns.get(6);
            
            if (oSelected instanceof Boolean) {
                Boolean selected = (Boolean)oSelected;
                if (selected.booleanValue()) {
                    String keyStr = (String)columns.get(7);
                    String[] key = keyStr.split(":");
                    String shipperNbr = key[0];
                    String accountNbr = key[1];
                    String laneNbr = key[2];
                    String serviceTypeCd = key[3];
                    String oldMonitor;                    
                    //Get the old monitor which is the row selected
                    
                    String oldMonitorObj = columns.get(5).toString();
                 // Check for null monitor value
                    if (oldMonitorObj != null && oldMonitorObj.length() > 0)                    	
                    {
                     oldMonitor = oldMonitorObj.substring(oldMonitorObj.indexOf('(')+1,oldMonitorObj.lastIndexOf(')'));
                    }
                    
                    else
                    {
                    	 oldMonitor = null;
                    }
                    	
                    // update the monitor for the service
                   ShipperDelegate shipperDelegate = new ShipperDelegate();
                    if (_selectedMonitor.equals("0")){
                        
                    	shipperDelegate.updateSelectedAcctLaneServiceMonitor(shipperNbr, accountNbr, laneNbr, 
        						serviceTypeCd, null, oldMonitor);
                    }else{
                        shipperDelegate.updateSelectedAcctLaneServiceMonitor(shipperNbr, accountNbr, laneNbr, 
                        						serviceTypeCd, _selectedMonitor, oldMonitor);                    	
                    	
                    }
                    //Update the GROUP_NBR in the SHIPMENT table of past shipments, if needed.
                    shipperDelegate.updateGroupNbrPastShipments(shipperNbr, 
                    		accountNbr, laneNbr, serviceTypeCd);
               }
            }
        }
        
        return null;
    }
    
    /**
     * get selected Monitor
     */
    public String getSelectedMonitor() {
        log.debug("Entering getSelectedMonitor()");
        return _selectedMonitor;
    }
   
    /**
     * set selected Monitor
     * @param selectedMonitor
     */
    public void setSelectedMonitor(String selectedMonitor) {
        log.debug("Entering setSelectedMonitor()");
        _selectedMonitor = selectedMonitor;
    }
    
    // ==========================================================================
    // Protected Methods
    // ==========================================================================

    protected boolean isDefaultAscending(String sortColumn) {
        return true;
    }

    protected void sort(final String column, final boolean ascending) {
        if (column != null) {
            int columnIndex = getColumnIndex(column);
            int direction = (ascending) ? SORT_ASCENDING : SORT_DESCENDING;
            sort(columnIndex, direction);
        }
    }

    protected void sort(final int columnIndex, final int direction) {
        Comparator comparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                int result = 0;
                Object column1 = ((List) o1).get(columnIndex);
                Object column2 = ((List) o2).get(columnIndex);
                if (column1 == null && column2 != null)
                    result = -1;
                else if (column1 == null && column2 == null)
                    result = 0;
                else if (column1 != null && column2 == null)
                    result = 1;
                else {
                    if ((column1 instanceof Comparable) && (column2 instanceof Comparable))
                       result = ((Comparable) column1).compareTo(column2) * direction;
                    else
                       result = ((Comparable) column1.toString()).compareTo(column2.toString()) * direction;
                }
                return result;
            }
        };
        Collections.sort((List) data.getWrappedData(), comparator);
    }

    
    // ==========================================================================
    // Private Methods
    // ==========================================================================

    private int getColumnIndex(final String columnName) {
        int columnIndex = -1;
        List headers = (List) columnHeaders.getWrappedData();
        for (int i = 0; i < headers.size() && columnIndex == -1; i++) {
            ColumnHeader header = (ColumnHeader) headers.get(i);
            if (header.getLabel().equals(columnName)) {
                columnIndex = i;
            }
        }
        return columnIndex;
    }

    /**
     * Get the list of Shippers (data rows)
     */
    private void populateShipperList() {
       // node selected so get data for this account, lane, service, etc.
       List rowList = new ArrayList();

       ShipperDelegate shipperDelegate = new ShipperDelegate();
       shippers = shipperDelegate.getAllShippers();
       
       // Shippers
       Iterator itr = shippers.iterator();
//       while (itr.hasNext()) {
//           MonitoredAccountsVO shipper = (MonitoredAccountsVO)itr.next();
//           
//           List colList = new ArrayList();
//           colList.add(shipper.get_groupNm());
//           colList.add(shipper.get_acctName()); 
//           colList.add(shipper.get_acctNbr()); 
//          
//           // lane
//           colList.add(LaneFormatter.format(shipper.get_origCntryCd(),
//                   shipper.get_destCntryCd()));
//          
//           // service type 
//           String svcTypeCd = shipper.get_svcTypeCd(); 
//           String svcDesc = SvcLvlDescCodes.lookupCd(svcTypeCd);
//           colList.add(ServiceTypeFormatter.format(svcTypeCd, svcDesc));
//          
//           // monitor
//           String monitorName = EmployeeNameFormatter.format(
//                   shipper.get_monitorFirstName(),
//                   shipper.get_monitorLastName(),
//                   shipper.get_monitorEmpNbr());
//           if (monitorName !=null) {
//              colList.add(monitorName);
//           } else {
//              colList.add("");
//           } 
//          
//           // if no service type, then can't assign monitors, so no checkbox
//           if (svcTypeCd != null) {
//               colList.add(new Boolean(false)); // initially unchecked
//           } else {
//               colList.add(""); // no checkbox
//           }
//           
//           // key values (not being displayed on UI, but used for monitor updates)
//           colList.add(shipper.get_groupNbr() + ":" 
//                   + shipper.get_acctNbr() + ":" 
//                   + shipper.get_laneNbr() + ":"
//                   + svcTypeCd); 
//           
//           rowList.add(colList);
//       }
       
       data = new ListDataModel(rowList);
    }
    
}
