package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.SystemMessageVO;

public class SystemMessageDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(SystemMessageDAO.class);

    /**
     * Get all system messages
     * @return
     * @throws SQLException
     */
    public void persistSystemMessage(SystemMessageVO aVO) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            SystemMessagePersister persister = new SystemMessagePersister(connection);
            persister.persistSystemMessage(aVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
    }
    
    /**
     * Get all system messages
     * @return
     * @throws SQLException
     */
    public List getSystemMessages() throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            SystemMessageAccessor accessor = new SystemMessageAccessor(connection);
            return accessor.getSystemMessages();
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }
    
    public void updateSystemMessage(SystemMessageVO aVO) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            SystemMessageUpdater updater = new SystemMessageUpdater(connection);
            updater.updateSystemMessage(aVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
    }
    
    public void deleteSystemMessage(int aMsgNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            SystemMessageDeleter deleter = new SystemMessageDeleter(connection);
            deleter.deleteSystemMessage(aMsgNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
    }
}
