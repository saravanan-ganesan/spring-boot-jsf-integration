package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class MonitorReportVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String 		_emp_nbr;
    private String 		_emp_first_nm;
    private String 		_emp_last_nm;
    private String 		_trkng_item_nbr;
    private String 		_trkng_item_uniq_nbr;
    private String 		_acct_nbr;
    private String 		_shpmt_type_cd;
    private String 		_recp_co_nm;
    private String 		_recp_ph_nbr;
    private String 		_acct_nm;
    private String 		_ship_dt_str;
    private String 		_commit_dt_str;
    private String 		_issue_type_scan;
    private String 		_issue_type_name;
    private Calendar   	_work_dt;  
    private Calendar 	_commit_dt;
    private Date   		_ship_dt;
    private int         _issue_type_cd;
    private int         _num_issues_begin_shift;  
    private int         _num_issues_end_shift; 
    private int        	_num_issues_presented;         
    private int        	_num_issues_resolved;      
    private int        	_num_mawb_resolved;   
    private int        	_num_crn_resolved;      
    private int        	_num_hits;             
    private int        	_total_duration; 
    private int        	_total_number_accounts; 

    
    public MonitorReportVO() {
    }
 
    /**
     * @return the _issue_type_name
     */
    public String get_issue_type_name() {
        return _issue_type_name;
    }

    /**
     * @param _issue_type_name the _issue_type_name to set
     */
    public void set_issue_type_name(String _issue_type_name) {
        this._issue_type_name = _issue_type_name.trim();
    }
    /**
     * @return the _issue_type_scan
     */
    public String get_issue_type_scan() {
        return _issue_type_scan;
    }

    /**
     * @param _commit_dt_str the _commit_dt_str to set
     */
    public void set_issue_type_scan(String _issue_type_scan) {
        this._issue_type_scan = _issue_type_scan.trim();
    }
    /**
     * @return the _commit_dt_str
     */
    public String get_commit_dt_str() {
        return _commit_dt_str;
    }

    /**
     * @param _commit_dt_str the _commit_dt_str to set
     */
    public void set_commit_dt_str(String _commit_dt_str) {
        this._commit_dt_str = _commit_dt_str.trim();
    }
    
    /**
     * @return the _ship_dt_str
     */
    public String get_ship_dt_str() {
        return _ship_dt_str;
    }

    /**
     * @param _ship_dt_str the _ship_dt_str to set
     */
    public void set_ship_dt_str(String _ship_dt_str) {
        this._ship_dt_str = _ship_dt_str.trim();
    }
    
    /**
     * @return the _acct_nm
     */
    public String get_acct_nm() {
        return _acct_nm;
    }

    /**
     * @param _acct_nm the _acct_nm to set
     */
    public void set_acct_nm(String _acct_nm) {
        this._acct_nm = _acct_nm.trim();
    }
    
    /**
     * @return the _recp_ph_nbr
     */
    public String get_recp_ph_nbr() {
        return _recp_ph_nbr;
    }

    /**
     * @param _recp_ph_nbr the _recp_ph_nbr to set
     */
    public void set_recp_ph_nbr(String _recp_ph_nbr) {
        this._recp_ph_nbr = _recp_ph_nbr.trim();
    }
    
    /**
     * @return the _recp_co_nm
     */
    public String get_recp_co_nm() {
        return _recp_co_nm;
    }

    /**
     * @param _recp_co_nm the _recp_co_nm to set
     */
    public void set_recp_co_nm(String _recp_co_nm) {
        this._recp_co_nm = _recp_co_nm.trim();
    }
    
    /**
     * @return the _shpmt_type_cd
     */
    public String get_shpmt_type_cd() {
        return _shpmt_type_cd;
    }

    /**
     * @param _shpmt_type_cd the _shpmt_type_cd to set
     */
    public void set_shpmt_type_cd(String _shpmt_type_cd) {
        this._shpmt_type_cd = _shpmt_type_cd.trim();
    }
    
    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }

    /**
     * @param _acct_nbr the _acct_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr.trim();
    }
    
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }

    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr.trim();
    }
    
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }

    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr.trim();
    }
    
    /**
     * @return the _emp_first_nm
     */
    public String get_emp_first_nm() {
        return _emp_first_nm;
    }

    /**
     * @param _emp_first_nm the _emp_first_nm to set
     */
    public void set_emp_first_nm(String _emp_first_nm) {
        this._emp_first_nm = _emp_first_nm.trim();
    }

    /**
     * @return the _emp_last_nm
     */
    public String get_emp_last_nm() {
        return _emp_last_nm;
    }

    /**
     * @param _emp_last_nm the _emp_last_nm to set
     */
    public void set_emp_last_nm(String _emp_last_nm) {
        this._emp_last_nm = _emp_last_nm.trim();
    }

    /**
     * @return the _emp_nbr
     */
    public String get_emp_nbr() {
        return _emp_nbr;
    }

    /**
     * @param _emp_nbr the _emp_nbr to set
     */
    public void set_emp_nbr(String _emp_nbr) {
        this._emp_nbr = _emp_nbr.trim();
    }

  
    /**
     * @return the _work_dt
     */
    public Calendar get_work_dt() {
        return _work_dt;
    }
    
    /**
     * @param _work_dt the _work_dt to set
     */
    public void set_work_dt(Calendar _work_dt) {
        this._work_dt = _work_dt;
    }
    
    /**
     * @return the _commit_dt
     */
    public Calendar get_commit_dt() {
        return _commit_dt;
    }

    /**
     * @param _commit_dt the _commit_dt to set
     */
    public void set_commit_dt(Calendar _commit_dt) {
        this._commit_dt = _commit_dt;
    }
    
    /**
     * @return the _ship_dt
     */
    public Date get_ship_dt() {
        return _ship_dt;
    }
    
    /**
     * @param _ship_dt the _ship_dt to set
     */
    public void set_ship_dt(Date _ship_dt) {
        this._ship_dt = _ship_dt;
    }
    
    /**
     * @return the _num_issues_begin_shift
     */
    public int get_num_issues_begin_shift() {
        return _num_issues_begin_shift;
    }
    
    /**
     * @param _num_issues_begin_shift the _num_issues_begin_shift to set
     */
    public void set_num_issues_begin_shift(int _num_issues_begin_shift) {
        this._num_issues_begin_shift = _num_issues_begin_shift;
    }
    
    /**
     * @return the _num_issues_end_shift
     */
    public int get_num_issues_end_shift() {
        return _num_issues_end_shift;
    }
    
    /**
     * @param _num_issues_end_shift the _num_issues_end_shift to set
     */
    public void set_num_issues_end_shift(int _num_issues_end_shift) {
        this._num_issues_end_shift = _num_issues_end_shift;
    }
    
    /**
     * @return the _num_issues_presented
     */
    public int get_num_issues_presented() {
        return _num_issues_presented;
    }
    
    /**
     * @param _num_issues_presented the _num_issues_presented to set
     */
    public void set_num_issues_presented(int _num_issues_presented) {
        this._num_issues_presented = _num_issues_presented;
    }
    
    /**
     * @return the _num_issues_resolved
     */
    public int get_num_issues_resolved() {
        return _num_issues_resolved;
    }
    
    /**
     * @param _num_issues_resolved the _num_issues_resolved to set
     */
    public void set_num_issues_resolved(int _num_issues_resolved) {
        this._num_issues_resolved = _num_issues_resolved;
    }
    
    /**
     * @return the _num_mawb_resolved
     */
    public int get_num_mawb_resolved() {
        return _num_mawb_resolved;
    }
    
    /**
     * @param _num_mawb_resolved the _num_mawb_resolved to set
     */
    public void set_num_mawb_resolved(int _num_mawb_resolved) {
        this._num_mawb_resolved = _num_mawb_resolved;
    }
    
    /**
     * @return the _num_crn_resolved
     */
    public int get_num_crn_resolved() {
        return _num_crn_resolved;
    }
    
    /**
     * @param _num_crn_resolved the _num_crn_resolved to set
     */
    public void set_num_crn_resolved(int _num_crn_resolved) {
        this._num_crn_resolved = _num_crn_resolved;
    }
    
    /**
     * @return the _num_hits
     */
    public int get_num_hits() {
        return _num_hits;
    }
    
    /**
     * @param _num_hits the _num_hits to set
     */
    public void set_num_hits(int _num_hits) {
        this._num_hits = _num_hits;
    }
    
    /**
     * @return the _total_duration
     */
    public int get_total_duration() {
        return _total_duration;
    }
    
    /**
     * @param _total_duration the _total_duration to set
     */
    public void set_total_duration(int _total_duration) {
        this._total_duration = _total_duration;
    }
    
    /**
     * @return the _total_number_accounts
     */
    public int get_total_number_accounts() {
        return _total_number_accounts;
    }
    
    /**
     * @param _total_number_accounts the _total_number_accounts to set
     */
    public void set_total_number_accounts(int _total_number_accounts) {
        this._total_number_accounts = _total_number_accounts;
    }
    
    /**
     * @return the _issue_type_cd
     */
    public int get_issue_type_cd() {
        return _issue_type_cd;
    }
    
    /**
     * @param _issue_type_cd the _issue_type_cd to set
     */
    public void set_issue_type_cd(int _issue_type_cd) {
        this._issue_type_cd = _issue_type_cd;
    }
}
