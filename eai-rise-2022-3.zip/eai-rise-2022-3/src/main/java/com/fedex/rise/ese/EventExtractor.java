package com.fedex.rise.ese;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.asn.UTF8String.enhancedevent_.EnhancedEvent;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.xref.EventNotesDescCodes;

/**
 * This class pulls the data out for the Event table.
 */
public class EventExtractor extends BaseEventExtractor {
    
    private static Logger logger = LogManager.getLogger(EventExtractor.class);
    
    /**
     * This constructor will parse both the base data, and the event data
     * @param anEE an enhanced event
     * @throws ESEParseException if part of the message is missing, and we desparately need it
     */
    EventExtractor(EnhancedEvent anEE) throws ESEParseException {
        super(anEE);     
    }

    /**
     * This constructor can use a BaseEventExtractor which has already parsed the
     * base events.
     * @param aBaseEventExtractor a base event extractor which has already parsed its data
     * @throws ESEParseExceptionif part of the message is missing, and we desparately need it
     */
    EventExtractor(BaseEventExtractor aBaseEventExtractor)
                   throws ESEParseException {
        super(aBaseEventExtractor);     
    }
    
    public EventVO extract() throws ESEParseException {
        EventVO eventVO = new EventVO();
        
        eventVO.set_trkng_item_nbr(trackItemNumber);
        eventVO.set_trkng_item_uniq_nbr(trackItemUniqNumber);
        
        eventVO.set_track_type_cd(trackTypeCd);

        eventVO.set_event_crtn_tmstp(eventCreationTmstp);

        // how an airbill was entered, scanned/manual
        if (ml.hasAirbill_entry_type()) {
            eventVO.set_trkng_item_entry_type_cd(ml.getAirbill_entry_type().stringValue());
        }
        
        // Yes, only present in ECCO scan in masterlist, used to determine arrc or cc
        if (ml.hasEcco_typ_code()) {
            eventVO.set_ecco_type_cd((char)ml.getEcco_typ_code().getChar(0));
        }
        
        if (ml.hasEcco_comment_code()) {
            eventVO.set_ecco_comm_cd((char)ml.getEcco_comment_code().getChar(0));
        }
 
        // found across several track types, mostly 07
        if (ml.hasTrack_exception_code()) {
            eventVO.set_track_excp_cd(ml.getTrack_exception_code().stringValue());
        }
 
        if (ml.hasTrack_location_code()) {
            eventVO.set_track_loc_cd(ml.getTrack_location_code().stringValue());
        }
        
        // CE's do not have this field, all other scan types do, most of the time it is the
        // same as loc cd, but sometimes it is different, not sure we need it
        if (ml.hasAdmin_loc_code()) {
            eventVO.set_admin_loc_cd(ml.getAdmin_loc_code().stringValue());
        }

        // employee who did scan
        if (ml.hasEmployee_number()) {
            String employeeNbr = ml.getEmployee_number().stringValue().trim();
            if (employeeNbr.length() > 0) {
                eventVO.set_scan_emp_nbr(employeeNbr);
            }
        } else {
            if (ml.hasKeyer_id()) {
                String employeeNbr = ml.getKeyer_id().stringValue().trim();
                if (employeeNbr.length() > 0) {
                    eventVO.set_scan_emp_nbr(employeeNbr);
                }                
            }
        }
        
        // what device event was created on
        if (ml.hasTrack_source_cd()) {
            eventVO.set_track_src_cd(ml.getTrack_source_cd().stringValue());
        }
        
        // sequence number of event, unique by tracking number
        if (ml.hasEvent_sequence_nbr()) {
            eventVO.set_event_sqnc_nbr(ml.getEvent_sequence_nbr().stringValue());
        }
        
        // These following fields are grouped together into one field in the db
        // The fields are key value pairs separated by '|', which is done in the
        // setter method.
        
        // get comments, there can be two locations
        if (ml.hasComment()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.COMMENTS + ":" + ml.getComment().stringValue());
        }
        
        if (ml.hasComments()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.COMMENTS + ":" + ml.getComments().stringValue());
        }
        
        // container number
        if (ml.hasContainer_nbr()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.CONTAINER_NBR + ":" + ml.getContainer_nbr().stringValue());
        }
        
        // cons number
        if (ml.hasCons_nbr()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.CONS_NBR + ":" + ml.getCons_nbr().stringValue());
        }
        
        // These two fields are concatenated together to make the CER control number
        // The date part is only MMDD and the number part is a 6 digit number with leading zeroes
        if (ml.hasComplaint_create_date() && ml.hasComplaint_ctrl_seq()) {
            String date = ml.getComplaint_create_date().stringValue().substring(4);
            String nbr = ml.getComplaint_ctrl_seq().stringValue();
            if (nbr.length() < 6) {
                StringBuffer sb = new StringBuffer(nbr);
                while (sb.length() < 6) { sb.insert(0, '0'); }
                nbr = sb.toString();
            }
            eventVO.set_event_note_desc(EventNotesDescCodes.CER_CTRL_NBR + ":" +
                date + nbr);
        }
           
        if (ml.hasComplaint_queue_type_cd()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.CER_QUEUE_TYPE + ":" + ml.getComplaint_queue_type_cd().stringValue());
        }

        // Looks like PF8 will show only one of these
        if (ml.hasDelivered_address_desc()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.DELVRD_ADDR_DESC + ":" + ml.getDelivered_address_desc().stringValue());
        } else {
            if (ml.hasRecipient_address_desc()) {
                eventVO.set_event_note_desc(EventNotesDescCodes.RECP_ADDR_DESC + ":" + ml.getRecipient_address_desc().stringValue());
            }
        }
        
        if (ml.hasDoor_tag_id()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.DOOR_TAG + ":" + ml.getDoor_tag_id().stringValue());
        }
        
        if (ml.hasStation_eta_time()) {
            String stationEtaTime = ml.getStation_eta_time().stringValue();
            // doesn't appear PF8 shows times of 0000
            if (!stationEtaTime.equals("0000")) {
                eventVO.set_event_note_desc(EventNotesDescCodes.STATION_ETA_TIME + ":" + stationEtaTime);
            }
        }
        
        if (ml.hasFuture_date()) {
            eventVO.set_event_note_desc(EventNotesDescCodes.FUTURE_DATE + ":" + ml.getFuture_date().stringValue());
        }
        
        if (ml.hasReattempted_delivery_time()) {
            String reattemptDeliveryTime = ml.getReattempted_delivery_time().stringValue();
            // doesn't appear PF8 shows times of 0000
            if (!reattemptDeliveryTime.equals("0000")) {
                eventVO.set_event_note_desc(EventNotesDescCodes.REATTEMPT_DELIVERY_TIME + ":" + reattemptDeliveryTime);
            }
        }
        
        if ((eventVO.get_event_note_desc() != null) && (eventVO.get_event_note_desc().length() > 256)) {
            logger.info("Truncating event note description, too long");
            String truncString = new String(eventVO.get_event_note_desc().substring(0,255));
            eventVO.set_event_note_desc(truncString);
        }
        return eventVO;
    }
}

