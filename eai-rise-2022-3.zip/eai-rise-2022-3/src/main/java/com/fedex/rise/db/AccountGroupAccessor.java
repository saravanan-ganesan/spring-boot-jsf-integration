package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.AccountGroupVO;
/**
 * Account Group table accessor class.
 * 
 * @author be379961
 *
 */
public class AccountGroupAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(AccountGroupAccessor.class);
    /**
     * Constructor
     * @param con
     */
    public AccountGroupAccessor(Connection con) {
        super(con);
    }
    
    private final String selectAccountGroupNameSQL = "select " +
    "GROUP_NBR, " +
    "GROUP_NM, " +
    "GROUP_DESC " +  
     "from Account_Group where GROUP_NM = ?";
    
    private final String selectAccountGroupSQL = "select " +
        "GROUP_NBR, " +
        "GROUP_NM, " +
        "GROUP_DESC " +  
         "from Account_Group where GROUP_NBR = ?";       
    
    private final String selectAccountGroupTableSQL = "select " +
        "GROUP_NBR, " +
        "GROUP_NM, " +
        "GROUP_DESC " +  
         "from Account_Group order by GROUP_NM"; 
    /**
     * Return the list of AccountGroupVO for a GROUP_NM
     * @param String of GROUP_NM of interest
     * @return list of AccountGroupVO for a GROUP_NM
     * @throws Exception 
     */
    public AccountGroupVO getAccountGroup(String groupName) throws SQLException {
        AccountGroupVO accountGroupVO = null;
                
        try {
            setSqlSignature( selectAccountGroupNameSQL, false, logger.isDebugEnabled() );
            
            pstmt.setString( 1, groupName);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                if (rs.next()) {
                    accountGroupVO = new AccountGroupVO();
                        
                    accountGroupVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountGroupVO.set_group_nm(rs.getString("GROUP_NM"));
                    accountGroupVO.set_group_desc("GROUP_DESC");
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return accountGroupVO;
    }
    
    /**
     * Return the list of AccountGroupVO for a GROUP_NBR
     * @param anAccountGroupVO AccountGroupVO with a GROUP_NBR of interest
     * @return list of AccountGroupVO for a GROUP_NBR
     * @throws Exception 
     */
    public AccountGroupVO getAccountGroup(int groupNbr) throws SQLException {
        AccountGroupVO accountGroupVO = null;
                
        try {
            setSqlSignature( selectAccountGroupSQL, false, logger.isDebugEnabled() );
            
            pstmt.setInt( 1, groupNbr);
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                if (rs.next()) {
                    accountGroupVO = new AccountGroupVO();
                        
                    accountGroupVO.set_group_nbr(rs.getInt("GROUP_NBR"));
                    accountGroupVO.set_group_nm(rs.getString("GROUP_NM"));
                    accountGroupVO.set_group_desc("GROUP_DESC");
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return accountGroupVO;
    }  
    /**
     * Return the list of AccountGroupVO for the Account Group table.
     * @return list of AccountGroupVO for the Account Group table.
     * @throws SQLException 
     */
    public List getAccountGroupTable() throws SQLException {
        ArrayList al = new ArrayList(); 
                
        try {
            setSqlSignature( selectAccountGroupTableSQL, false, logger.isDebugEnabled() );
                 
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    AccountGroupVO accountGroupVO = new AccountGroupVO();
                    
                    accountGroupVO.set_group_nbr(rs.getInt("GROUP_NBR"));   
                    accountGroupVO.set_group_nm(rs.getString("GROUP_NM"));
                    accountGroupVO.set_group_desc("GROUP_DESC");
                    
                    al.add(accountGroupVO);
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return al;
    }
}
