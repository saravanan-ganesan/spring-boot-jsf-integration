package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.IssueVO;

public class IssueUpdater extends OracleBase {
    private static Logger logger = LogManager.getLogger(IssueUpdater.class);

    public IssueUpdater(Connection con) {
        super(con);
    }

    private static final String updateIssueSQL = "Update Issue set " +
        "ISSUE_TMSTP = ?, " +
        "RES_DT = ?, " +
        "RES_DESC = ?, " +
        "RES_EMP_NBR = ?, " +
        "EVENT_CRTN_TMSTP = ?, " +
        "LAST_UPDT_TMSTP = SYSDATE " +
            "WHERE TRKNG_ITEM_NBR = ? AND " +
            "TRKNG_ITEM_UNIQ_NBR = ? AND " +
            "ISSUE_TYPE_CD = ?";

    /**
     * Update an Issue
     * @param anIssueVO
     * @throws SQLException
     */
    public void updateIssue(IssueVO anIssueVO) throws SQLException {

        try {
            setSqlSignature(updateIssueSQL, false, logger.isDebugEnabled());

            if (anIssueVO.getIssue_tmstp() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(anIssueVO.getIssue_tmstp().getTime());
                pstmt.setTimestamp(  1, sqlDate);
            } else {
                pstmt.setNull(  1, java.sql.Types.TIMESTAMP);
            }                
            if (anIssueVO.getRes_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(anIssueVO.getRes_dt().getTime());
                pstmt.setTimestamp(  2, sqlDate);
            } else {
                pstmt.setNull(  2, java.sql.Types.TIMESTAMP);
            }            
            pstmt.setString( 3, anIssueVO.get_res_desc());  
           
            pstmt.setString( 4, anIssueVO.get_res_emp_nbr());
            
            if (anIssueVO.getEvent_crtn_tmstp() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(anIssueVO.getEvent_crtn_tmstp().getTime());
                pstmt.setTimestamp(  5, sqlDate);
            } else {
                pstmt.setNull(  5, java.sql.Types.TIMESTAMP);
            }              
            
            pstmt.setString( 6, anIssueVO.getTrkng_item_nbr());
            pstmt.setString( 7, anIssueVO.getTrkng_item_uniq_nbr());           
            pstmt.setInt( 8, anIssueVO.getIssue_type_cd());
       
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
    }
    
}
