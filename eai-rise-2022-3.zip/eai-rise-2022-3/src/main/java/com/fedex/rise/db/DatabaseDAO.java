package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.config.ConfigurationManager;
import com.fedex.rise.util.ServiceLocator;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.RewriteVO;

/**
 * This class behaves as a facade to the persistent mechanism.
 */
public class DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(DatabaseDAO.class);

    /**
     * Default constructor for DatabaseDAO.
     */
    public DatabaseDAO() {
    }

    /**
     * This method returns XA or nonXA initialized connection. It gets the non
     * Distributed transaction connection to the database by calling the
     * overloaded method initializeConnection(boolean tx), with false as the
     * input parameter.
     *
     * @throws ServiceLocatorException
     *             Encapsulates all types of exceptions associated with
     *             ServiceLocator due to NamingExceptions and other exceptions
     *             when performing JNDI lookups.
     * @throws SQLException
     *             Encapsulates any exception in regards to getting the
     *             connection.
     *
     * @return Database connection.
     */
    protected Connection initializeConnection() throws ServiceLocatorException,
            SQLException {
        return initializeConnection(false);
    }

    /**
     * This method returns XA or nonXA initialized connection to be used by
     * the respective method. The default transaction isolation level is set to
     * Connection.TRANSACTION_READ_COMMITTED (this is to avoid dirty reads when
     * more than one thread is trying to read the same data). There is also
     * retry logic in obtaining a connection which clears the data source from
     * service locator cache. This retry logic is to handle the situation of a
     * stale data source.
     *
     * @param tx Pass in true to return the XA connection, otherwise return non
     * XA connection.
     * @throws ServiceLocatorException
     *             Encapsulates all types of exceptions associated with
     *             ServiceLocator due to NamingExceptions and other exceptions
     *             when performing JNDI lookups.
     * @throws SQLException
     *             Encapsulates any exception in regards to getting the
     *             connection.
     * @return Database connection.
     */
    protected Connection initializeConnection(boolean tx)
            throws ServiceLocatorException, SQLException {
        boolean error = false;
        int retry = 0;
        int dataSourceNumRetries = Integer.parseInt(ConfigurationManager.get(
                "DATASOURCE_NUM_RETRIES", "1"));

        // if Distributed transactions then get TxDataSource, else get normal
        String dataSourceName = null;
        if (tx) {
            dataSourceName = ConfigurationManager.get("TXDATASOURCE",
                    "RiseJDBCTXDataSource");
        } else {
            dataSourceName = ConfigurationManager.get("DATASOURCE",
                    "RiseJDBCDataSource");
        }

        DataSource dataSource = null;
        Connection connection = null;

        do {
            try {
                dataSource = ServiceLocator.getInstance().getDataSource(
                        dataSourceName);
                connection = dataSource.getConnection();
                error = false;
            } catch (ServiceLocatorException sle) {
                logger.info("Retry attempt: " + retry + " of "
                        + dataSourceNumRetries);
                Object[] logParms = { dataSourceName };
                logger.error(logParms);
                logger.warn(sle);
                if (retry >= dataSourceNumRetries)
                    throw sle;
                error = true;
                ServiceLocator.getInstance().resetKeyValue(dataSourceName);
            } catch (SQLException sqle) {
                logger.info("Retry attempt: " + retry + " of "
                        + dataSourceNumRetries);
                logger.error("DB Connection Exception");
                logger.warn(sqle);
                closeConnection(connection);
                if (retry >= dataSourceNumRetries)
                    throw sqle;
                error = true;
                ServiceLocator.getInstance().resetKeyValue(dataSourceName);
            }
        } while (error && retry++ < dataSourceNumRetries);

        return connection;
    }

    /**
     * This method closes the connection, therefore releasing the connection
     * back to the connection pool.
     *
     * @param connection Pass in the connection to close.
     */
    protected void closeConnection(Connection connection) {
        try {
            if (connection != null && !connection.isClosed())
                connection.close();
        } catch (SQLException sqle) {
            logger.error("DB Release Exception", sqle);
        }
    }

    /**
     * This method is used to persist a record into the REWRITE table for 
     * research.
     *
     * @param aRiseVO  
     * @throws SQLException 
     */
    public void doPersist(RewriteVO aRiseVO) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            RewritePersister persister = new RewritePersister(connection);
            persister.persist(aRiseVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }
    
}// end of class
