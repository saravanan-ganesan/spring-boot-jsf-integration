package com.fedex.rise.bo;

import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.ShipmentVO;

/**
 * This class is used to merge a shipment already in the database with
 * the possibly new data in the current event.
 *
 */
public class MergeShipment {
    /** Logger */
    private static Logger logger = LogManager.getLogger(MergeShipment.class);
    
    boolean changed = false;
    boolean outOfOrder = false;
    
    StringBuffer sb = new StringBuffer();
    
    public boolean merge(ShipmentVO aNewShipment, ShipmentVO anExistingShipment, 
            Calendar anEventTimestamp, String aTrackTypeCd) {
        
        if ((anExistingShipment.get_last_event_tmstp() != null)  &&
            (anExistingShipment.get_last_event_tmstp().after(anEventTimestamp))) {
            // leave the latest event time stamp as it is
            outOfOrder = true;
            logger.info("Events are out of order.");
        } else {
            // The latest event is now, this event's timestamp
            sb.append("|LastEventTmstp:");
            sb.append(anExistingShipment.get_last_event_tmstp().getTime());
            sb.append(':');
            sb.append(anEventTimestamp.getTime());
            anExistingShipment.set_last_event_tmstp(anEventTimestamp);
            
            sb.append("|LastTrackTypeCd:");
            sb.append(anExistingShipment.get_last_event_track_type_cd());
            sb.append(':');
            sb.append(aTrackTypeCd);
            anExistingShipment.set_last_event_track_type_cd(aTrackTypeCd);
                         
            changed = true;
        }
        
        String ns = null;

        // Strings
        ns = compareString(aNewShipment.get_last_event_track_loc_cd(), anExistingShipment.get_last_event_track_loc_cd(), "Last Event Track Loc Cd");
        anExistingShipment.set_last_event_track_loc_cd(ns);
        ns = compareString(aNewShipment.get_acct_nbr(), anExistingShipment.get_acct_nbr(), "Account Nbr");
        anExistingShipment.set_acct_nbr(ns);
        ns = compareString(aNewShipment.get_svc_type_cd(), anExistingShipment.get_svc_type_cd(), "Service Type Cd");
        anExistingShipment.set_svc_type_cd(ns);
        ns = compareShpmtTypeCd(aNewShipment.get_shpmt_type_cd(), anExistingShipment.get_shpmt_type_cd(), "Shpmt Type Cd");
        anExistingShipment.set_shpmt_type_cd(ns);
        ns = compareString(aNewShipment.get_orig_loc_cd(), anExistingShipment.get_orig_loc_cd(), "Orig Loc Cd");
        anExistingShipment.set_orig_loc_cd(ns);
        ns = compareString(aNewShipment.get_dest_loc_cd(), anExistingShipment.get_dest_loc_cd(), "Dest Loc Cd");
        anExistingShipment.set_dest_loc_cd(ns);
        ns = compareString(aNewShipment.get_shpr_co_nm(), anExistingShipment.get_shpr_co_nm(), "Shpr Comp Nm");
        anExistingShipment.set_shpr_co_nm(ns);
        ns = compareString(aNewShipment.get_shpr_ph_nbr(), anExistingShipment.get_shpr_ph_nbr(), "Shpr Phone Nbr");
        anExistingShipment.set_shpr_ph_nbr(ns);
        ns = compareString(aNewShipment.get_shpr_addr_line_one_desc(), anExistingShipment.get_shpr_addr_line_one_desc(), "Shpr Addr L1 Desc");
        anExistingShipment.set_shpr_addr_line_one_desc(ns);
        ns = compareString(aNewShipment.get_shpr_addr_line_two_desc(), anExistingShipment.get_shpr_addr_line_two_desc(), "Shpr Addr L2 Desc");
        anExistingShipment.set_shpr_addr_line_two_desc(ns);
        ns = compareString(aNewShipment.get_shpr_addr_line_three_desc(), anExistingShipment.get_shpr_addr_line_three_desc(), "Shpr Addr L3 Desc");
        anExistingShipment.set_shpr_addr_line_three_desc(ns);
        ns = compareString(aNewShipment.get_shpr_city_nm(), anExistingShipment.get_shpr_city_nm(), "Shpr City Nm");
        anExistingShipment.set_shpr_city_nm(ns);
        ns = compareString(aNewShipment.get_shpr_pstl_cd(), anExistingShipment.get_shpr_pstl_cd(), "Shpr Pstl Cd");
        anExistingShipment.set_shpr_pstl_cd(ns);
        ns = compareString(aNewShipment.get_shpr_cntry_cd(), anExistingShipment.get_shpr_cntry_cd(), "Shpr Cntry Cd");
        anExistingShipment.set_shpr_cntry_cd(ns);
        ns = compareString(aNewShipment.get_shpr_st_prov_cd(), anExistingShipment.get_shpr_st_prov_cd(), "Shpr st/prov cd");
        anExistingShipment.set_shpr_st_prov_cd(ns);
        ns = compareString(aNewShipment.get_recp_co_nm(), anExistingShipment.get_recp_co_nm(), "Recp Co Nm");
        anExistingShipment.set_recp_co_nm(ns);
        ns = compareString(aNewShipment.get_recp_ph_nbr(), anExistingShipment.get_recp_ph_nbr(), "Recp Phone Nbr");
        anExistingShipment.set_recp_ph_nbr(ns);
        ns = compareString(aNewShipment.get_recp_addr_line_one_desc(), anExistingShipment.get_recp_addr_line_one_desc(), "Recp Addr L1 Desc");
        anExistingShipment.set_recp_addr_line_one_desc(ns);
        ns = compareString(aNewShipment.get_recp_addr_line_two_desc(), anExistingShipment.get_recp_addr_line_two_desc(), "Recp Addr L2 Desc");
        anExistingShipment.set_recp_addr_line_two_desc(ns);
        ns = compareString(aNewShipment.get_recp_addr_line_three_desc(), anExistingShipment.get_recp_addr_line_three_desc(), "Recp Addr L3 Desc");
        anExistingShipment.set_recp_addr_line_three_desc(ns);
        ns = compareString(aNewShipment.get_recp_city_nm(), anExistingShipment.get_recp_city_nm(), "Recp City Nm");
        anExistingShipment.set_recp_city_nm(ns);
        ns = compareString(aNewShipment.get_recp_st_prov_cd(), anExistingShipment.get_recp_st_prov_cd(), "Recp St/prov cd");
        anExistingShipment.set_recp_st_prov_cd(ns);
        ns = compareString(aNewShipment.get_recp_cntry_cd(), anExistingShipment.get_recp_cntry_cd(), "Recp Cntry Cd");
        anExistingShipment.set_recp_cntry_cd(ns);
        ns = compareString(aNewShipment.get_recp_pstl_cd(), anExistingShipment.get_recp_pstl_cd(), "Recp Postal Cd");
        anExistingShipment.set_recp_pstl_cd(ns);
        ns = compareString(aNewShipment.get_actl_del_nm(), anExistingShipment.get_actl_del_nm(), "Actl Del Nm");
        anExistingShipment.set_actl_del_nm(ns);
        ns = compareString(aNewShipment.get_actl_addr_line_one_desc(), anExistingShipment.get_actl_addr_line_one_desc(), "Actl Addr L1 Desc");
        anExistingShipment.set_actl_addr_line_one_desc(ns);
        
        // Problem is this the status has been changed by the status calculator if it was worthy
        // to change, but the event out of order flag in this code can trump the 
        // change taking place.  So take the change if different no matter if the event
        // is out of order or not.  Status's are based on weights.
        String oldStatus = anExistingShipment.get_last_stat_desc();
        String newStatus = aNewShipment.get_last_stat_desc();
        if ((newStatus != null) && !newStatus.equals(oldStatus)) {
            sb.append("|Status:");
            sb.append(oldStatus);
            sb.append(":");
            sb.append(newStatus);
            sb.append("|Status Loc:");
            sb.append(anExistingShipment.get_last_stat_track_loc_cd());
            sb.append(":");
            sb.append(aNewShipment.get_last_stat_track_loc_cd());
            sb.append("|Status timestamp:");
            sb.append(anExistingShipment.get_last_stat_tmstp());
            sb.append(":");
            sb.append(aNewShipment.get_last_stat_tmstp());
            changed = true;
            anExistingShipment.set_last_stat_desc(newStatus);           
            anExistingShipment.set_last_stat_track_loc_cd(aNewShipment.get_last_stat_track_loc_cd());
            anExistingShipment.set_last_stat_tmstp(aNewShipment.get_last_stat_tmstp());
        } else {
            // if same status, but newer timestamp, take the new timestamp and location
            if ((newStatus != null) && newStatus.equals(oldStatus)) {
                if ((anExistingShipment.get_last_stat_tmstp() == null) || (aNewShipment.get_last_stat_tmstp().after(anExistingShipment.get_last_stat_tmstp()))) {
                    sb.append("|Status Loc:");
                    sb.append(anExistingShipment.get_last_stat_track_loc_cd());
                    sb.append(":");
                    sb.append(aNewShipment.get_last_stat_track_loc_cd());
                    sb.append("|Status timestamp:");
                    sb.append(anExistingShipment.get_last_stat_tmstp());
                    sb.append(":");
                    sb.append(aNewShipment.get_last_stat_tmstp());
                    changed = true;
                    anExistingShipment.set_last_stat_track_loc_cd(aNewShipment.get_last_stat_track_loc_cd());
                    anExistingShipment.set_last_stat_tmstp(aNewShipment.get_last_stat_tmstp());
                }
            }
        }

        ns = compareString(aNewShipment.get_spcl_hndlg_grp(), anExistingShipment.get_spcl_hndlg_grp(), "Special Handling");
        anExistingShipment.set_spcl_hndlg_grp(ns);
        ns = compareString(aNewShipment.get_crtg_agent_co_nm(), anExistingShipment.get_crtg_agent_co_nm(), "Crtg Agent Co Nm");
        anExistingShipment.set_crtg_agent_co_nm(ns);
        ns = compareString(aNewShipment.get_cstms_curr_cd(), anExistingShipment.get_cstms_curr_cd(), "Cstms Curr Cd");
        anExistingShipment.set_cstms_curr_cd(ns);

        ns = compareStringNull(aNewShipment.get_perf_rsult_cd(), anExistingShipment.get_perf_rsult_cd(), "Performance Result Code");
        anExistingShipment.set_perf_rsult_cd(ns);

        // ints
        int ni = 0;
        ni = compareInt(aNewShipment.get_trkng_item_form_cd(), anExistingShipment.get_trkng_item_form_cd(), "Form Cd");
        anExistingShipment.set_trkng_item_form_cd(ni);
        ni = compareInt(aNewShipment.get_pack_type_cd(), anExistingShipment.get_pack_type_cd(), "Pack Type");
        anExistingShipment.set_pack_type_cd(ni);
        ni = compareInt(aNewShipment.get_shpmt_wgt(), anExistingShipment.get_shpmt_wgt(), "Shpmt Wgt");
        anExistingShipment.set_shpmt_wgt(ni);
        ni = compareInt(aNewShipment.get_cstms_value_amt(), anExistingShipment.get_cstms_value_amt(), "Cstms Value");
        anExistingShipment.set_cstms_value_amt(ni);
        ni = compareInt(aNewShipment.get_shpmt_pkg_qt(), anExistingShipment.get_shpmt_pkg_qt(), "Shmpt Pkg Qt");
        anExistingShipment.set_shpmt_pkg_qt(ni);    
        ni = compareInt(aNewShipment.get_lane_nbr(), anExistingShipment.get_lane_nbr(), "Lane number");
        anExistingShipment.set_lane_nbr(ni);
        ni = compareInt(aNewShipment.get_grp_nbr(), anExistingShipment.get_grp_nbr(), "Group number");
        anExistingShipment.set_grp_nbr(ni);        
        ni = compareInt(aNewShipment.get_delivery_qty(), anExistingShipment.get_delivery_qty(), "Delivery Quantity");
        anExistingShipment.set_delivery_qty(ni);   
        ni = compareInt(aNewShipment.get_package_piece_qty(), anExistingShipment.get_package_piece_qty(), "Package Piece Quantity");
        anExistingShipment.set_package_piece_qty(ni);    
        
        // chars
        char nc = 0;
        nc = compareChar(aNewShipment.get_shpmt_uom_cd(), anExistingShipment.get_shpmt_uom_cd(), "Shpmt UOM Cd");
        anExistingShipment.set_shpmt_uom_cd(nc);
        nc = compareChar(aNewShipment.get_skid_intact_flag(), anExistingShipment.get_skid_intact_flag(), "Skid Intact Flag");
        anExistingShipment.set_skid_intact_flag(nc);   
        
        nc = compareChar(aNewShipment.get_quantity_observed_flag(), anExistingShipment.get_quantity_observed_flag(), "Quantity Observed Flag");
        anExistingShipment.set_quantity_observed_flag(nc); 
      
        // Compare Calendars
        Calendar nd = null;
        nd = compareCalendar(aNewShipment.get_del_dt(), anExistingShipment.get_del_dt(), "Del Dt");
        anExistingShipment.set_del_dt(nd);
        nd = compareCalendar(aNewShipment.get_commit_dt(), anExistingShipment.get_commit_dt(), "Commit Dt");
        anExistingShipment.set_commit_dt(nd);
        nd = compareCalendar(aNewShipment.get_adj_commit_dt(), anExistingShipment.get_adj_commit_dt(), "Adj Commit Dt");
        anExistingShipment.set_adj_commit_dt(nd);
        nd = compareCalendar(aNewShipment.get_cleared_cstms_tmstp(), anExistingShipment.get_cleared_cstms_tmstp(), "Customs Cleared Dt");
        anExistingShipment.set_cleared_cstms_tmstp(nd);
      
        // Compare Dates
        Date ndate = null;
        ndate = compareDate(aNewShipment.get_ship_dt(), anExistingShipment.get_ship_dt(), "Ship Dt");
        anExistingShipment.set_ship_dt(ndate);
        
        if (sb.length() > 0) {
            logger.info(sb.toString());
        }
        return changed;
    }
    
    // if events are not out of order, we can assume that we want the new value if there
    // is a new value.  If events are out of order, and the old value is null/empty, go ahead
    // and take the value, even though the event is out of order
      
    /**
     * Compares the string already in the database with the one that just came in 
     * the event.  It will uppercase the strings so that we don't waste time updating
     * strings that just the case has changed.  It will return the new string if 
     * it is replacing a null, if it has changed.
     * @param aNewString the string that just came in the event
     * @param anOldString the string in the database
     * @param anId what text to use to identify this field for debugging
     * @return the string to be used
     */
    public String compareString(String aNewString, String anOldString, String anId) {
        if (aNewString != null ) { // new string is not null
            if (aNewString.length() > 0) { // length of new string is not zero
                String newString = aNewString.toUpperCase();
                String oldString = null;
                if (anOldString != null) {
                    oldString = anOldString.toUpperCase();
                }
                if (!newString.equals(oldString)) { // if two strings are different
                    // Store the new string if not out of order, or we don't have an old string
                    if ((!outOfOrder) || (anOldString == null) || (anOldString.length() == 0)) {                
                        sb.append("|");
                        sb.append(anId);
                        sb.append(":");
                        sb.append(anOldString);
                        sb.append(":");
                        sb.append(aNewString);
                        changed = true;
                        return aNewString;
                    }
                }
            }
        }
        return anOldString;
    }
    
    /**
     * This method is used for the performance column only.
     * This will allow the performance to only be calculated one time. 
     * It will only store the performance if it didn't have one
     * from a previous event.
     * @param aNewString the string that just came in the event
     * @param anOldString the string in the database
     * @param anId what text to use to identify this field for debugging
     * @return the string to be used
     */
    public String compareStringNull(String aNewString, String anOldString, String anId) {
        if (aNewString != null ) { // new string is not null
            if (aNewString.length() > 0) { // length of new string is not zero
            	// Store the new string if we don't have an old string
                if ((anOldString == null) || (anOldString.length() == 0)) {                
                	sb.append("|");
                    sb.append(anId);
                    sb.append(":");
                    sb.append(anOldString);
                    sb.append(":");
                    sb.append(aNewString);
                    changed = true;
                    return aNewString;
                }
            }
        }
        return anOldString;
    }
    
    /**
     * Returns a new int, if different from the old. If the new
     * value is zero, don't replace what is in the database since
     * zero is the default value for an int.
     * @param aNewInt
     * @param anOldInt
     * @param anId
     * @return
     */
    public int compareInt(int aNewInt, int anOldInt, String anId) {
        if ((aNewInt != anOldInt) && (aNewInt != 0)) {
            if (!outOfOrder || (anOldInt == 0)) {
                sb.append("|"); 
                sb.append(anId);
                sb.append(":");
                sb.append(anOldInt);
                sb.append(":");
                sb.append(aNewInt);
                changed = true;
                return aNewInt;
            }
        }
        return anOldInt;
    }    
    
    public char compareChar(char aNewChar, char anOldChar, String anId) {
        if ((aNewChar != anOldChar) && (aNewChar != ' ')) {
            if (!outOfOrder || anOldChar == ' ') {
                sb.append("|");
                sb.append(anId);
                sb.append(":");
                sb.append(anOldChar);
                sb.append(":");
                sb.append(aNewChar);
                changed = true;
                return aNewChar;
            }
        }
        return anOldChar;
    }
    
    public Date compareDate(Date aNewDate, Date anOldDate, String anId) {
        if (aNewDate != null) {
            if (!aNewDate.equals(anOldDate)) {
                if (!outOfOrder || (anOldDate == null)) {            
                    sb.append("|");
                    sb.append(anId);
                    sb.append(":");
                    sb.append(anOldDate);
                    sb.append(":");
                    sb.append(aNewDate);
                    changed = true;
                    return aNewDate;
                }
            }
        }
        return anOldDate;        
    } 

    public Calendar compareCalendar(Calendar aNewDate, Calendar anOldDate, String anId) {
        if (aNewDate != null) {
            if (!aNewDate.equals(anOldDate)) {
                if (!outOfOrder || (anOldDate == null)) {            
                    sb.append("|");
                    sb.append(anId);
                    sb.append(":");
                    if (anOldDate == null) {
                        sb.append("null");
                    } else {
                        sb.append(anOldDate.getTime());
                    }
                    sb.append(":");
                    sb.append(aNewDate.getTime());
                    changed = true;
                    return aNewDate;
                }
            }
        }
        return anOldDate;        
    } 
    
    public String compareShpmtTypeCd(String aNewShpmtTypeCd, String anExistingShpmtTypeCd, String anId) {
        // Never allow the shipment type to digress to Unknown
        if (aNewShpmtTypeCd.equals(RiseConstants.UNK)) {
        	if (anExistingShpmtTypeCd != null) {
        			return anExistingShpmtTypeCd;
        	}else{
        		sb.append("|");
                sb.append(anId);
                sb.append(":");
                sb.append("");
                sb.append(":");
                sb.append(aNewShpmtTypeCd);
                changed = true;
        		return aNewShpmtTypeCd;
        	}
        }
        
        if (anExistingShpmtTypeCd != null) {
        	// If it is already PWRK, RTRN don't override.
            if (anExistingShpmtTypeCd.equals(RiseConstants.PWRK) ||
               (anExistingShpmtTypeCd.equals(RiseConstants.RTRN))) {
                return anExistingShpmtTypeCd;
            }
            
            // If it is an UNK than can override it.
            if (anExistingShpmtTypeCd.equals(RiseConstants.UNK)){
        		sb.append("|");
                sb.append(anId);
                sb.append(":");
                sb.append(anExistingShpmtTypeCd);
                sb.append(":");
                sb.append(aNewShpmtTypeCd);
                changed = true;
        		return aNewShpmtTypeCd;
            }
            // If the new shipment type code is different than the old one.
            if ((aNewShpmtTypeCd != null) && !aNewShpmtTypeCd.equals(anExistingShpmtTypeCd)) {
            	sb.append("|");
                sb.append(anId);
                sb.append(":");
                sb.append(anExistingShpmtTypeCd);
                sb.append(":");
                sb.append(aNewShpmtTypeCd);
                changed = true;
        		return aNewShpmtTypeCd;
            }
        }
        
        return anExistingShpmtTypeCd; 
    }
}
