package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;

public class AdminDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(AdminDAO.class);
    
    /**
     * Get all shippers, accounts, lanes, services.
     * @return
     * @throws SQLException
     */
    public List getAllShippers() throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            AdminAccessor accessor = new AdminAccessor(connection);
            return accessor.getAllShippers();
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }
}
