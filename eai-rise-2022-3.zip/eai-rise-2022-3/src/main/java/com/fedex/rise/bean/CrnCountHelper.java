package com.fedex.rise.bean;

import java.util.List;
import java.util.ListIterator;

import com.fedex.rise.util.RiseConstants;

public class CrnCountHelper {

    private static int getCount(List aCrnCountStateList, String aTrackTypeCd, String aTrackExcpCd) {
        ListIterator iter = aCrnCountStateList.listIterator();
//        while (iter.hasNext()) {
//            CrnStateCountVO crnStateCountVO = (CrnStateCountVO)iter.next();
//            if (crnStateCountVO.get_trackTypeCd().equals(aTrackTypeCd)) {
//                if (aTrackExcpCd.equals("*") ||
//                   ((aTrackExcpCd != null) && (crnStateCountVO.get_trackExcpCd().equals(aTrackExcpCd)))) {
//                    return crnStateCountVO.get_count();
//                } else {
//                    if ((aTrackExcpCd == null) && (crnStateCountVO.get_trackExcpCd() == null)) {
//                        return crnStateCountVO.get_count();
//                    }
//                }
//            }
//        }
        return 0;
    }
    

    public static int getDACRCount(List aCrnCountStateList) {
        return getCount(aCrnCountStateList, RiseConstants.STAT, "34");
    }
    
    public static int getReturnCount(List aCrnCountStateList) {
        return getCount(aCrnCountStateList, RiseConstants.STAT, "14");
    }
    
    /**
     * I know this usually has an exception code with it, but for now we
     *   don't care what it is.  So we will use an '*' as a don't care
     * @param aCrnCountStateList
     * @return
     */
    public static int getCanceledCount(List aCrnCountStateList) {
        return getCount(aCrnCountStateList, RiseConstants.MDE_CANCEL, "*");
    }
    
    public static int getPodCount(List aCrnCountStateList) {
        return getCount(aCrnCountStateList, RiseConstants.POD, "*");
    }
    
    public static int getDDexCount(List aCrnCountStateList) {
        return getCount(aCrnCountStateList, RiseConstants.DDEX, "*");
    }
    
    public static int getDeliveredCount(List aCrnCountStateList) {
        return getPodCount(aCrnCountStateList) + getDDexCount(aCrnCountStateList);
    }
    
    /**
     * Get the total count of CRNs we have knowledge of, this doesn't come
     * from the database and is a bit of a hack to save a trip to the database.
     * MonitorDAO adds this count
     * @param aCrnCountStateList
     * @return
     */
    public static int getTotalCount(List aCrnCountStateList) {
        return getCount(aCrnCountStateList, "*", "*");
    }
}
