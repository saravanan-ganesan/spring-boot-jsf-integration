package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocator;
import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.CrnStateCountVO;
import com.fedex.rise.vo.MAWBAttributesVO;
import com.fedex.rise.vo.ShipmentCommentVO;
import com.fedex.rise.vo.ShipmentVO;

public class MonitorDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(MonitorDAO.class);
    
    /**
     * 
     * @param anEmplyNbr
     * @return
     * @throws SQLException
     */
    public List getMonitoredAccounts(String anEmplyNbr) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            MonitoredAccountsAccessor monitoredAccountsAccessor = new MonitoredAccountsAccessor(connection);
            // Determine if the employee is a Resctricted Monitor (RM)
            if (monitoredAccountsAccessor.isEmployeeRestrictedMonitor(anEmplyNbr)){
            	List monitorAccounts = null;
            	monitorAccounts = monitoredAccountsAccessor.getMonitoredAccounts(anEmplyNbr);
            	// Determine if RM has been assigned companies.
            	if (monitorAccounts.size() > 0){
            		return monitorAccounts; // RM assigned companies
            	}else{ 
            		// RM not assigned companies, so return all of them companines.
            		// This RM is probably sales, marketing, ramp, hub, or brokers.
            		return monitoredAccountsAccessor.getAllMonitoredAccounts();
            	}
            }else {// This is a NOT a Restricted Monitor. 
            	return monitoredAccountsAccessor.getMonitoredAccounts(anEmplyNbr);
            }
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }      
        return null;
    }
    
    public List getMAWBShipments(int aGroupNbr, String anAcctNbr,
                                 int aLaneNbr, String aServiceType,
                                 boolean issuesOnly, int aStartIndex, 
                                 int anEndIndex, String sortColumn, 
                                 boolean isSortAscending, int shipDateOffsetInt) 
    							 throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            List mawbs = null;
            if (issuesOnly)
               mawbs = accessor.getMAWBShipmentsWithIssues(aGroupNbr, anAcctNbr, 
            		   aLaneNbr, aServiceType, aStartIndex, anEndIndex, 
            		   sortColumn, isSortAscending, shipDateOffsetInt);
            else 
               mawbs = accessor.getMAWBShipments(aGroupNbr, anAcctNbr, aLaneNbr, 
            		   aServiceType, aStartIndex, anEndIndex, sortColumn, 
            		   isSortAscending, shipDateOffsetInt);
            return mawbs;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    public int getMAWBShipmentsCount(int aGroupNbr, String anAcctNbr,
                                 int aLaneNbr, String aServiceType,
                                 boolean issuesOnly, int shipDateOffsetInt) 
    								throws SQLException {
        int count = 0;
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            if (issuesOnly)
               count = accessor.getMAWBShipmentsWithIssuesCount(aGroupNbr, 
            		   anAcctNbr, aLaneNbr, aServiceType, shipDateOffsetInt);
            else 
               count = accessor.getMAWBShipmentsCount(aGroupNbr, anAcctNbr, 
            		   aLaneNbr, aServiceType, shipDateOffsetInt);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return count;        
    }
    //WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
	public int getAllCrnsCount(int aGroupNbr, String anAcctNbr, int laneNbr, String serviceTypeCd, int shipDateOffsetInt) throws SQLException {
		int count = 0;
		Connection connection = null;

		try {
			connection = initializeConnection();
			ShipmentAccessor accessor = new ShipmentAccessor(connection);
			count = accessor.getAllCrnsCount(aGroupNbr, anAcctNbr,
					laneNbr, serviceTypeCd, shipDateOffsetInt);
		} catch (ServiceLocatorException sle) {
			logger.error("Service Locator Exception: ", sle);
		} catch (SQLException sqle) {
			logger.error("DB SQL ERROR", sqle);
			throw sqle;
		} finally {
			closeConnection(connection);
		}
		return count;        
}
    
    
	
	
	public List getFilterByIssues() throws SQLException {
		Connection connection = null;

		try {
			logger.info("Fetching Issues :");
			connection = initializeConnection();
			IssuesAccessor accessor = new IssuesAccessor(connection);
			return accessor.getFilterByIssues();
		} catch (ServiceLocatorException sle) {
			logger.error("Service Locator Exception: ", sle);
		} catch (SQLException sqle) {
			logger.error("DB SQL ERROR", sqle);
			throw sqle;
		} finally {
			closeConnection(connection);
		}
		return null;
	}
	
	public List getfilterByIssueDetails(String[] filterByIssues, int shipDateOffsetInt) throws SQLException {

		Connection connection = null;

		try {

			connection = initializeConnection();
			ShipmentAccessor accessor = new ShipmentAccessor(connection);
			logger.info("Fetching Filtered Issues :");
			return accessor.getfilterByIssueDetails(filterByIssues, shipDateOffsetInt);
		} catch (ServiceLocatorException sle) {
			logger.error("Service Locator Exception: ", sle);
		} catch (SQLException sqle) {
			logger.error("DB SQL ERROR", sqle);
			throw sqle;
		} finally {
			closeConnection(connection);
		}
		return null;
	}
	
	////////////////////////////////////////////////////////
    
    public ShipmentVO getShipment(String aTrkngItemNbr, String aTrkngUniqItemNbr)
        throws SQLException {
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            return accessor.getShipment(aTrkngItemNbr, aTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }   
    
    public List getShipmentViaRtrnTrkngNbr(String aRtrnTrkngItemNbr, String aRtrnTrkngUniqItemNbr)
        throws SQLException {
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            return accessor.getShipmentViaRtrnTrkngNbr(aRtrnTrkngItemNbr, aRtrnTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }   
    
    /**
     * Get the list of CRNs for a MAWB 
     * Allows "paging" the results by selecting the first and last index to retrieve.
     * 
     * @param aParntTrkngItemNbr MAWB tracking number
     * @param aParntTrkngUniqItemNbr MAWB tracking unique number
     * @param issuesOnly true to get only CRNs with issue
     * @param aStartIndex start rownum, for paging results
     * @param anEndIndex end rownum, for paging results
     * @param sortColumn column to sort on
     * @param isSortAscending true to filter by Ascending, false for descending
     * @param filterByIssues the Issue Type Cd(s) to filter on 
     * @param shipDt MAWB ship date 
     * @return List of ShipmentVOs
     * @throws SQLException
     */
    public List getCRNShipments(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr, boolean issuesOnly,
            int startIndex, int endIndex, String sortColumn, boolean isSortAscending, String[] filterByIssues,
            Date shipDt) 
            throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            List crns = accessor.getCRNShipments(aParntTrkngItemNbr, 
            		aParntTrkngUniqItemNbr, startIndex, endIndex, sortColumn, 
            		isSortAscending, filterByIssues, issuesOnly, shipDt);
            return crns;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    // WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
    public List getAllCrns(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd,
            int startIndex, int endIndex, String sortColumn, boolean isSortAscending, int shipDateOffsetInt,
            String[] filterByIssues) 
            throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            List crns = accessor.getAllCrns(shipperNbr, accountNbr, laneNbr, serviceTypeCd,startIndex,endIndex,sortColumn,isSortAscending,shipDateOffsetInt,filterByIssues);
            return crns;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    
    
    /**
     * Get the list of CRN Issues for a MAWB 
     * 
     * @param aParntTrkngItemNbr MAWB tracking number
     * @param aParntTrkngUniqItemNbr MAWB tracking unique number
     * @return List of Issue Type Cds
     * @throws SQLException
     */
    public List getCRNIssues(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr) throws SQLException {    
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentAccessor accessor = new ShipmentAccessor(connection);
            List issues = accessor.getCRNIssues(aParntTrkngItemNbr, aParntTrkngUniqItemNbr);
            return issues;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        
        return new ArrayList(); // no issues
    }
    
    public List getEvents(String aTrkngItemNbr, String aTrkngUniqItemNbr)
        throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            EventsAccessor accessor = new EventsAccessor(connection);
            return accessor.getEvents(aTrkngItemNbr, aTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }      
    
    public List getIssues(String aTrkngItemNbr, String aTrkngUniqItemNbr)
        throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            IssuesAccessor accessor = new IssuesAccessor(connection);
            return accessor.getActiveIssues(aTrkngItemNbr, aTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    public List getComments(String aTrkngItemNbr, String aTrkngUniqItemNbr)
        throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentCommentsAccessor accessor = new ShipmentCommentsAccessor(connection);
            return accessor.getShipmentComments(aTrkngItemNbr, aTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    public void saveComment(ShipmentCommentVO aShipmentCommentVO) throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentCommentPersister persister = new ShipmentCommentPersister(connection);
            persister.persist(aShipmentCommentVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }
    
    
    public void saveMAWBAttributes(MAWBAttributesVO aVO) throws SQLException {
        Connection connection = null;
        
        try {
            connection = initializeConnection();
            MawbAttributesUpdater updater = new MawbAttributesUpdater(connection);
            updater.updateMawbAttributes(aVO);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }
   
    /**
     * @param aTrkngItemNbr MAWB tracking number 
     * @param aTrkngItemUniqNbr
     * @return list of CRN status counts, includes count of total CRNs we've seen for this MAWB
     * @throws SQLException
     */
    public List getCrnStateCounts(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
        Connection connection = null;
        
        try {
            connection = initializeConnection();
            CrnStateCountAccessor accessor = new CrnStateCountAccessor(connection);
            List counts = accessor.getCrnStateCounts(aTrkngItemNbr, aTrkngItemUniqNbr);
            
            // Add the total CRN count, so we don't have to make a trip from UI to EJB layer more than once
            int count = accessor.getCrnCount(aTrkngItemNbr, aTrkngItemUniqNbr);
            CrnStateCountVO vo = new CrnStateCountVO();
            vo.set_count(count);
            vo.set_trackTypeCd("*"); 
            vo.set_trackExcpCd("*");
            counts.add(vo);
            
            return counts;
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;
    }  

    /**
     * @param aTrkngItemNbr MAWB tracking number
     * @param aTrkngItemUniqNbr
     * @param issuesOnly true if only want count of CRNS with issues
     * @param filterByIssues the Issue Type Cd(s) to filter on 
     * @return count of CRNS, issues only or all
     * @throws SQLException
     */
    public int getCrnCount(String aTrkngItemNbr, String aTrkngItemUniqNbr, boolean issuesOnly,
            String[] filterByIssues) throws SQLException {
        Connection connection = null;
        
        int count = 0;
        try {
            connection = initializeConnection();
            CrnStateCountAccessor accessor = new CrnStateCountAccessor(connection);
            if (filterByIssues!=null && filterByIssues.length>0)
                count = accessor.getCrnCountByIssues(aTrkngItemNbr, aTrkngItemUniqNbr, filterByIssues);
            else if (issuesOnly)
                count = accessor.getCrnCountWithIssues(aTrkngItemNbr, aTrkngItemUniqNbr);
            else 
                count = accessor.getCrnCount(aTrkngItemNbr, aTrkngItemUniqNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return count;
    }  
 
    public void adjustCRNCommitDates(int aCRNDeliveryDtAdjustment, String aTrkngItemNbr,
            String aTrkngItemUniqNbr) throws SQLException {
        
        Connection connection = null;
        // transaction part of event processing
        UserTransaction userTransaction = null;
        
        try {
        	userTransaction = ServiceLocator.getInstance().getUserTransaction();
            userTransaction.begin();
            
            connection = initializeConnection(true);
    
            CrnCommitDateAdjuster updater = new CrnCommitDateAdjuster(connection);
            updater.adjustCRNCommitDates(aCRNDeliveryDtAdjustment, aTrkngItemNbr, aTrkngItemUniqNbr);
            updater.adjustMAWBCommitDates(aCRNDeliveryDtAdjustment, aTrkngItemNbr, aTrkngItemUniqNbr);
            
            userTransaction.commit();
        // These exceptions really have to do with starting a transaction
        } catch (NotSupportedException e) {     // begin
        	logger.error("Not Supported Exception: ", e);
        } catch (SystemException e) {           // begin
        	logger.error("System Exception: ", e);
        // These exception have to do with commit exceptions
        } catch (RollbackException e) {         // commit
            // Logged to indicate that the transaction has been rolled back rather than committed
        	logger.error("Rollback Exception: ", e);
        } catch (HeuristicMixedException e) {   // commit
            // Logged to indicate that a heuristic decision was made and that some relevant updates have been committed
            // while others have been rolled back. 
        	logger.error("Heuristic Mixed Exception: ", e);
        } catch (HeuristicRollbackException e) { // commit
            // Logged to indicate that a heuristic decision was made and that all relevant updates have been rolled back.
        	logger.error("Heuristic Rollback Exception: ", e);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } catch (Exception e) {
        	logger.info("Catching unexpected exception in transaction.");
            try {
                logger.info("Rolling back.");
                userTransaction.rollback();
            } catch (IllegalStateException e1) {
                logger.error(e1);
            } catch (SecurityException e1) {
                logger.error(e1);
            } catch (SystemException e1) {
                logger.error(e1);
            }
        } finally {
            closeConnection(connection);
            
            int status = Status.STATUS_UNKNOWN;
            try {
                status = userTransaction.getStatus();
            } catch (SystemException e) {
                logger.debug("Exception getting transaction status.", e);
            }
            logger.debug("Transaction Status: " + logUserTransStatus(status));
        }
    }
    
    public List getReferenceNotes(String aTrkngItemNbr, String aTrkngUniqItemNbr)
        throws SQLException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ReferenceNotesAccessor accessor = new ReferenceNotesAccessor(connection);
            return accessor.getReferenceNotes(aTrkngItemNbr, aTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }
    
    public List getRelatedAirbills(String aTrkngItemNbr, String aTrkngUniqItemNbr)
                                   throws SQLException {
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            AssociatedShipmentAccessor accessor = new AssociatedShipmentAccessor(connection);
            return accessor.getAssociatedShipments(aTrkngItemNbr, aTrkngUniqItemNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
        return null;        
    }   
    
    public void saveWorkedStatus(String statusCd, String aTrkngItemNbr, String aTrkngItemUniqNbr) 
                                   throws SQLException {
        
        Connection connection = null;

        try {
            connection = initializeConnection();
            ShipmentWorkedStatusPersister persister = new ShipmentWorkedStatusPersister(connection);
            persister.saveWorkedStatus(statusCd, aTrkngItemNbr, aTrkngItemUniqNbr);
        } catch (ServiceLocatorException sle) {
            logger.error("Service Locator Exception: ", sle);
        } catch (SQLException sqle) {
            logger.error("DB SQL ERROR", sqle);
            throw sqle;
        } finally {
            closeConnection(connection);
        }
    }   
    
    private String logUserTransStatus(int aStatus) {
        switch (aStatus) {
            // A transaction is associated with the target object and it is in the active state.
            case Status.STATUS_ACTIVE:
                return "Status Active";
            // A transaction is associated with the target object and it has been committed.  
            case Status.STATUS_COMMITTED: 
                return "Status Committed";
            // A transaction is associated with the target object and it is in the process of committing.  
            case Status.STATUS_COMMITTING: 
                return "Status Committing";
            // A transaction is associated with the target object and it has been marked for rollback, perhaps as a result of a setRollbackOnly operation. 
            case Status.STATUS_MARKED_ROLLBACK:
                return "Status Marked Rollback";
            // No transaction is currently associated with the target object.  
            case Status.STATUS_NO_TRANSACTION:
                return "Status No Transaction";
            // A transaction is associated with the target object and it has been prepared.  
            case Status.STATUS_PREPARED:
                return "Status Prepared";
            // A transaction is associated with the target object and it is in the process of preparing.  
            case Status.STATUS_PREPARING: 
                return "Status Preparing";
            // A transaction is associated with the target object and the outcome has been determined to be rollback.  
            case Status.STATUS_ROLLEDBACK: 
                return "Status Rolledback";
            // A transaction is associated with the target object and it is in the process of rolling back.  
            case Status.STATUS_ROLLING_BACK: 
                return "Status Rolling Back";
            //case Status.STATUS_UNKNOWN  
        }
        return "Status Unknown";

    }
}
