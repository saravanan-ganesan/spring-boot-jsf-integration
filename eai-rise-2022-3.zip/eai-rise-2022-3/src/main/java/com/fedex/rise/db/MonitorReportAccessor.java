package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Date;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EmployeeVO;
import com.fedex.rise.vo.MonitorReportVO;
import com.fedex.rise.cache.EmployeeCacheDAO;

/**
 * Accessor to get Monitor Report Data.
 * 
 * @author be379961
 *
 */
public class MonitorReportAccessor extends OracleBase {
	private static Logger logger = LogManager.getLogger(MonitorReportAccessor.class);

	/**
	 * Constructor.
	 * 
	 * @param con
	 */
    public MonitorReportAccessor(Connection con) {
        super(con);
    }
    
    /** Paging SQL to get subset of results */
    private final static String PREpagedSQL = 
       "select * from " +
       " (select row_.*, rownum rownum_ from ( ";
    
    private final static String POSTpagedSQL = 
       "   ) row_ " + " where rownum <= ? " +
       " ) " +
       "where rownum_ > ?";
       
    private final String selectNumberMonitorAccountsSQL = "select " +
    "ACCOUNT_QTY " +
    "from Monitor_Report where WORK_DT = ? and EMP_NBR = ?";
    
    private final String selectNbrHitsWorkDateSQL = "select " +
    "EMP_NBR, " +
    "WORK_DT, " +
    "HIT_QTY  " +
    "from Monitor_Report where WORK_DT = ? ";
    
    private final String selectMonitorReportSQL = "select " +
    "EMP_NBR, " +
    "WORK_DT, " +
    "BEGIN_HAND_QTY, " +
    "ISSUE_RCVD_QTY, " +
    "END_HAND_QTY, " +
    "ISSUE_RSLV_QTY, " +
    "ACCOUNT_QTY, " +
    "MAWB_RSLV_QTY, " +
    "CRN_RSLV_QTY, " +
    "HIT_QTY, " +
    "DURATION_QTY " +
    "from Monitor_Report where WORK_DT >= ? and WORK_DT <= ? " +
    "and EMP_NBR = ?";
    
    private final String selectMonitorReportSumSQL = "select " +
    "SUM(BEGIN_HAND_QTY) BEGINHANDQTY, " +
    "SUM(ISSUE_RCVD_QTY) ISSUERCVDQTY, " +
    "SUM(END_HAND_QTY) ENDHANDQTY, " +
    "SUM(ISSUE_RSLV_QTY) ISSUERSLVQTY, " +
    "SUM(MAWB_RSLV_QTY) MAWBRSLVQTY, " +
    "SUM(CRN_RSLV_QTY) CRNRSLVQTY, " +
    "SUM(HIT_QTY) HITQTY, " +
    "SUM(DURATION_QTY)  DURATIONQTY " +
    "from Monitor_Report where WORK_DT >= ? and WORK_DT <= ? " +
    "and EMP_NBR = ?";
    
    
    private final String selectCountIssuesBeginingShiftSQL = "select " +
    "count (i.TRKNG_ITEM_NBR) " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a " +
    "where i.ISSUE_TMSTP <= ? and i.ISSUE_TMSTP >= ? " +
    "and a.EMP_NBR = ? " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and (i.RES_DT is null or i.RES_DT>= ?) ";
    
    private final String selectTrackingNbrsIssuesBeginingShiftCountSQL = "select " +
    "count(i.TRKNG_ITEM_NBR) count " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where i.ISSUE_TMSTP <= ? and i.ISSUE_TMSTP >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.EMP_NBR = ? " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and (i.RES_DT is null or i.RES_DT>= ?) ";
    
    private final String selectTrackingNbrsIssuesBeginingShiftSQL = "select " +
    "i.TRKNG_ITEM_NBR, " +
    "i.TRKNG_ITEM_UNIQ_NBR, " +
    "i.ACCT_NBR, " +
    "i.ISSUE_TYPE_CD, " +
    "s.SHIP_DT, " +
    "s.COMMIT_DT, " +
    "s.COMMIT_DATE_TMZN_OFFST_NBR, " +
    "s.SHPMT_TYPE_CD, " +
    "s.RECP_CO_NM, " +
    "s.RECP_PH_NBR, " +
    "acct.ACCT_NM " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where i.ISSUE_TMSTP <= ? and i.ISSUE_TMSTP >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.EMP_NBR = ? " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and (i.RES_DT is null or i.RES_DT>= ?) ";
    
    private final String selectCountIssuesEndShiftSQL = "select " +
    "count (i.TRKNG_ITEM_NBR) " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a " +
    "where i.ISSUE_TMSTP <= ? and i.ISSUE_TMSTP >= ? " +
    "and a.EMP_NBR = ? " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and (i.RES_DT is null) ";
    
    private final String selectTrackingNbrsIssuesEndiningShiftSQL = "select " +
    "i.TRKNG_ITEM_NBR, " +
    "i.TRKNG_ITEM_UNIQ_NBR, " +
    "i.ACCT_NBR, " +
    "i.ISSUE_TYPE_CD, " +
    "s.SHIP_DT, " +
    "s.COMMIT_DT, " +
    "s.COMMIT_DATE_TMZN_OFFST_NBR, " +
    "s.SHPMT_TYPE_CD, " +
    "s.RECP_CO_NM, " +
    "s.RECP_PH_NBR, " +
    "acct.ACCT_NM " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where i.ISSUE_TMSTP <= ? and i.ISSUE_TMSTP >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.EMP_NBR = ? " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and (i.RES_DT is null) ";
    
    private final String selectTrackingNbrsIssuesEndiningShiftCountSQL = "select " +
    "count(i.TRKNG_ITEM_NBR) count " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where i.ISSUE_TMSTP <= ? and i.ISSUE_TMSTP >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.EMP_NBR = ? " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and (i.RES_DT is null) ";
    
    private final String selectCountNumIssuesReceivedSQL = "select " +
    "count (i.TRKNG_ITEM_NBR) " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a " +
    "where i.ISSUE_TMSTP >= ? and i.ISSUE_TMSTP <= ? " +
    "and a.EMP_NBR = ? " +
    "and (i.RES_EMP_NBR = ? or i.RES_DT is null) " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD ";
    
    private final String selectTrackingNbrsIssuesRcvdSQL = "select " +
    "i.TRKNG_ITEM_NBR, " +
    "i.TRKNG_ITEM_UNIQ_NBR, " +
    "i.ACCT_NBR, " +
    "i.ISSUE_TYPE_CD, " +
    "s.SHIP_DT, " +
    "s.COMMIT_DT, " +
    "s.COMMIT_DATE_TMZN_OFFST_NBR, " +
    "s.SHPMT_TYPE_CD, " +
    "s.RECP_CO_NM, " +
    "s.RECP_PH_NBR, " +
    "acct.ACCT_NM " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where i.ISSUE_TMSTP >= ? and i.ISSUE_TMSTP <= ? " +
    "and a.EMP_NBR = ? " +
    "and (i.RES_EMP_NBR = ? or i.RES_DT is null) " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD ";
    
    private final String selectTrackingNbrsIssuesRcvdCountSQL = "select " +
    "count(i.TRKNG_ITEM_NBR) count " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where i.ISSUE_TMSTP >= ? and i.ISSUE_TMSTP <= ? " +
    "and a.EMP_NBR = ? " +
    "and (i.RES_EMP_NBR = ? or i.RES_DT is null) " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD ";
    
    private final String selectCountResolvedSQL = "select " +
    "count (TRKNG_ITEM_NBR) " +
    "from ISSUE where TRUNC(RES_DT) = ? " +
    "and RES_EMP_NBR = ? "; 
    
    private final String selectEmployeeAccountsSQL = "select " +
    "count (distinct(ACCT_NBR)) " +
    "from ACCT_LANE_SERVICE_MONITORING where EMP_NBR = ? ";
    
    private final String selectCountMAWBResolvedSQL = "select " +
    "count (i.TRKNG_ITEM_NBR) " +
    "from ISSUE i " +
    "INNER JOIN SHIPMENT s ON " +
    "i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "where TRUNC(i.RES_DT) = ? " +
    "and i.RES_EMP_NBR = ? and i.INPUT_TMSTP >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and s.SHPMT_TYPE_CD = 'MAWB' " +
    "and s.SHIP_DT >= ? ";
    
    private final String selectCountCRNResolvedSQL = "select " +
    "count (i.TRKNG_ITEM_NBR) " +
    "from ISSUE i " +
    "INNER JOIN SHIPMENT s ON " +
    "i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "where TRUNC(i.RES_DT) = ? " +
    "and i.RES_EMP_NBR = ? and i.INPUT_TMSTP >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and s.SHPMT_TYPE_CD = 'CRN' " +
    "and s.SHIP_DT >= ? ";
    
    private final String selectTrackingNbrsIssuesResolvedSQL = "select " +
    "i.TRKNG_ITEM_NBR, " +
    "i.TRKNG_ITEM_UNIQ_NBR, " +
    "i.ACCT_NBR, " +
    "i.ISSUE_TYPE_CD, " +
    "s.SHIP_DT, " +
    "s.COMMIT_DT, " +
    "s.COMMIT_DATE_TMZN_OFFST_NBR, " +
    "s.SHPMT_TYPE_CD, " +
    "s.RECP_CO_NM, " +
    "s.RECP_PH_NBR, " +
    "acct.ACCT_NM " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where trunc(i.RES_DT) >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.EMP_NBR = ? " +
    "and i.RES_EMP_NBR = a.EMP_NBR " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and trunc(i.RES_DT) <= ? ";
    
    private final String selectTrackingNbrsIssuesResolvedCountSQL = "select " +
    "count(i.TRKNG_ITEM_NBR) count " +
    "from ISSUE i,  ACCT_LANE_SERVICE_MONITORING a, SHIPMENT s, ACCOUNT acct " +
    "where TRUNC(i.RES_DT) >= ? " +
    "and i.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR " +
    "and i.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " +
    "and a.EMP_NBR = ? " +
    "and i.RES_EMP_NBR = a.EMP_NBR " +
    "and a.GROUP_NBR = i.GROUP_NBR " +
    "and a.ACCT_NBR = i.ACCT_NBR " +
    "and acct.GROUP_NBR = i.GROUP_NBR " +
    "and acct.ACCT_NBR = i.ACCT_NBR " +
    "and a.LANE_NBR = i.LANE_NBR " +
    "and a.SVC_TYPE_CD = i.SVC_TYPE_CD " +
    "and trunc(i.RES_DT) <= ? ";
    
    private final static String orderByShipDtSQL =  " order by s.SHIP_DT ";
    private final static String orderByTrkngItemNbrSQL =  " order by i.TRKNG_ITEM_NBR ";
    private final static String orderByCommitDtSQL =  " order by s.COMMIT_DT ";
    private final static String orderByAcctNbrSQL =  " order by i.ACCT_NBR ";
    private final static String orderByShpmtTypeCdSQL =  " order by s.SHPMT_TYPE_CD ";
    private final static String orderByAcctNmSQL =  " order by acct.ACCT_NM ";
    private final static String orderRecpCoNmSQL =  " order by s.RECP_CO_NM ";
    private final static String orderRecpPhNbrSQL =  " order by s.RECP_PH_NBR ";
    private final static String orderIssueTypeCdSQL =  " order by i.ISSUE_TYPE_CD ";
    
    /**
     * Get the count of issues resolved for the employee.
     * 
     * @param employeeVO
     * @param workDate
     * @return count of issues resolved for the employee
     * @throws SQLException 
     */
    public int getIssuesResolvedCount(EmployeeVO employeeVO, Date workDate) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){	  	
    		try {
    			setSqlSignature( selectCountResolvedSQL, false, logger.isDebugEnabled() );

    			if (workDate != null) {
    				java.sql.Date sqlDate =
    				new java.sql.Date(workDate.getTime());
    				pstmt.setDate(  1, sqlDate);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.DATE);
    			}
            
    			pstmt.setString(  2, employeeVO.get_emp_nbr());
            
 
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
               
    				while(rs.next()) {
    					count = rs.getInt(1);
    				}
    			} else {
    				// Employee has not resolved issues for this date.
    				logger.debug("Resolved issues not found for : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    					+ ": ErrorCode: " + sqle.getErrorCode()); 
    				throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
        
        return count;
    }
    
    /**
     * Get the number of accounts this employee monitors.
     * 
     * @param employeeVO
     * @return count of the number of accounts this employee monitors.
     * @throws SQLException 
     */
    public int getEmployeeAccountsCount(EmployeeVO employeeVO) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){	  	
    		try {
    			setSqlSignature( selectEmployeeAccountsSQL, false, logger.isDebugEnabled() );
    				
    			pstmt.setString(  1, employeeVO.get_emp_nbr());
            
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
    				while(rs.next()) {
    	                   count = rs.getInt(1);
    				}
    			} else {
    				// Employee has no accounts.
    				logger.debug("Accounts not found for : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    				}
    			} catch (SQLException sqle) {
    				logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    						+ ": ErrorCode: " + sqle.getErrorCode()); 
    				throw sqle;
    			} finally {
    				try {
    					cleanResultSet();
    				} catch (SQLException sqle2) {
    					logger.warn(sqle2.getMessage(), sqle2);
    				}
        		}
    	}
        
        return count;
    }
   
    
    /**
     * Get the count of MAWB issues resolved for the employee.
     * 
     * @param employeeVO
     * @param workDate
     * @return count of MAWB issues resolved for the employee
     * @throws SQLException 
     */
    public int getMAWBResolvedCount(EmployeeVO employeeVO, Date workDate) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){  	
    		try {
    			setSqlSignature( selectCountMAWBResolvedSQL, false, logger.isDebugEnabled() );

    			if (workDate != null) {
    				java.sql.Date sqlDate =
    					new java.sql.Date(workDate.getTime());
    				pstmt.setDate(  1, sqlDate);
   				
    				Calendar workCalendar = Calendar.getInstance();
    				workCalendar.setTime(workDate);
    				workCalendar.set(Calendar.HOUR_OF_DAY, 0);// 0:00 MTN Time
    				workCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 days
    				java.sql.Date sqlDate2 = new java.sql.Date(workCalendar.getTimeInMillis());
    				pstmt.setDate(  3, sqlDate2);    				
    				pstmt.setDate(  4, sqlDate2);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.DATE);
    				pstmt.setNull(  3, java.sql.Types.DATE);
    				pstmt.setNull(  4, java.sql.Types.DATE);
    			}
            
    			pstmt.setString(  2, employeeVO.get_emp_nbr());
            
 
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
               
    				while(rs.next()) {
    					count = rs.getInt(1);
    						
    				}
    			} else {
    				// Employee has not resolved MAWB for this date.
    				logger.debug("Employee has not resolved MAWB for this date : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    						+ ": ErrorCode: " + sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
        
        return count;
    }
    
    /**
     * Get the count of CRN issues resolved for the employee.
     * 
     * @param employeeVO
     * @param workDate
     * @return count of CRN issues resolved for the employee
     * @throws SQLException 
     */
    public int getCRNResolvedCount(EmployeeVO employeeVO, Date workDate) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){
    			  	
    		try {
    			setSqlSignature( selectCountCRNResolvedSQL, false, logger.isDebugEnabled() );

    			if (workDate != null) {
    				java.sql.Date sqlDate =
    					new java.sql.Date(workDate.getTime());
    				pstmt.setDate(  1, sqlDate);
    				
    				Calendar workCalendar = Calendar.getInstance();
    				workCalendar.setTime(workDate);
    				workCalendar.set(Calendar.HOUR_OF_DAY, 0);// 0:00 MTN Time
    				workCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 days
    				java.sql.Date sqlDate2 = new java.sql.Date(workCalendar.getTimeInMillis());
    				pstmt.setDate(  3, sqlDate2);
    				pstmt.setDate(  4, sqlDate2);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.DATE);
    				pstmt.setNull(  3, java.sql.Types.DATE);
    				pstmt.setNull(  4, java.sql.Types.DATE);
    			}
            
    			pstmt.setString(  2, employeeVO.get_emp_nbr());
            
 
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
               
    				while(rs.next()) {
    					count = rs.getInt(1);
    				}
    			} else {
    				// Employee has not resolved CRNs for this date.
    				logger.debug("Employee has not resolved CRNs for this date. : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    					+ ": ErrorCode: " + sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
        
        return count;
    }
    
    /**
     * Get the count of issues received by the employee for the workDate.
     * 
     * @param employeeVO
     * @param workDate
     * @return count of received by the employee
     * @throws SQLException 
     */
    public int getIssuesReceivedCount(EmployeeVO employeeVO, Date workDate) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){	  	
    		try {
    			setSqlSignature( selectCountNumIssuesReceivedSQL, false, logger.isDebugEnabled() );

    			if (workDate != null) {
    				Calendar fromCalendar = Calendar.getInstance();
    				fromCalendar.setTime(workDate);// From today
    				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
  
    				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
    				pstmt.setTimestamp(  1, sqlDate);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.TIMESTAMP);
    			}
            
    			if (workDate != null) {
    				Calendar toCalendar = Calendar.getInstance();
    				toCalendar.setTime(workDate);// From today
    				toCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 MTN Time
   
    				java.sql.Timestamp sqlDate = new java.sql.Timestamp(toCalendar.getTimeInMillis());
    				pstmt.setTimestamp(  2, sqlDate);
    			} else {
    				pstmt.setNull(  2, java.sql.Types.TIMESTAMP);
    			}
    			pstmt.setString(  3, employeeVO.get_emp_nbr());
    			pstmt.setString(  4, employeeVO.get_emp_nbr());
            
 
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
               
    				while(rs.next()) {
    					count = rs.getInt(1);
    				}
    			} else {
    				// Employee has not received issues for this day.
    				logger.debug("Employee has not received issues for this day : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    					+ ": ErrorCode: " + sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
        
        return count;
    }
    
    /**
     * Get the count of issues presented to the monitor at the begining of the work day.
     * 
     * @param employeeVO
     * @param workDate
     * @return count of issues presented to the monitor at the begining of the work day
     * @throws SQLException
     */
    public int getIssuesBeginingShiftCount(EmployeeVO employeeVO, Date workDate) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){	  	
    		try {
    			setSqlSignature( selectCountIssuesBeginingShiftSQL, false, logger.isDebugEnabled() );
    				   				
    			if (workDate != null) {
    				Calendar toCalendar = Calendar.getInstance();
    				toCalendar.setTime(workDate);// From today
    				toCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 MTN Time
   
    				java.sql.Timestamp sqlDate = new java.sql.Timestamp(toCalendar.getTimeInMillis());
    				pstmt.setTimestamp(  1, sqlDate);
    				pstmt.setTimestamp(  4, sqlDate);
    				
    				toCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 day 7:00 MTN Time
    				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(toCalendar.getTimeInMillis());
    				pstmt.setTimestamp(  2, sqlDate2);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.TIMESTAMP);
    				pstmt.setNull(  2, java.sql.Types.TIMESTAMP);
    				pstmt.setNull(  4, java.sql.Types.TIMESTAMP);
    			}
    			pstmt.setString(  3, employeeVO.get_emp_nbr());
            
 
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
               
    				while(rs.next()) {
    					count = rs.getInt(1);
    				}
    			} else {
    				// Employee has not received issues for the beginning of the work day.
    				logger.debug("Employee has not received issues for the beginning of the work day : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    					+ ": ErrorCode: " + sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
        
        return count;
    }
    
    /**
     * Get the count of issues presented to the monitor at the end of the work day.
     * 
     * @param employeeVO
     * @param workDate
     * @return count of issues presented to the monitor at the end of the work day
     * @throws SQLException
     */
    public int getIssuesEndShiftCount(EmployeeVO employeeVO, Date workDate) 
    	throws SQLException {
        
    	int count = 0; 
    	if (employeeVO != null){	  	
    		try {
    			setSqlSignature( selectCountIssuesEndShiftSQL, false, logger.isDebugEnabled() );
    				   				
    			if (workDate != null) {
    				Calendar toCalendar = Calendar.getInstance();
    				toCalendar.setTime(workDate);// From today
    				toCalendar.set(Calendar.HOUR_OF_DAY, 17);//End of Shift 17:00.
   
    				java.sql.Timestamp sqlDate = new java.sql.Timestamp(toCalendar.getTimeInMillis());
    				pstmt.setTimestamp(  1, sqlDate);
    				
    				toCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 day 17:00 MTN Time
    				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(toCalendar.getTimeInMillis());
    				pstmt.setTimestamp(  2, sqlDate2);
    			} else {
    				pstmt.setNull(  1, java.sql.Types.TIMESTAMP);
    				pstmt.setNull(  2, java.sql.Types.TIMESTAMP);
    			}
    			pstmt.setString(  3, employeeVO.get_emp_nbr());
            
 
    			if (logger.isDebugEnabled()) {
    				logger.debug(pstmt.toString());
    			}
            
    			execute();

    			if ( hasResults ) {
               
    				while(rs.next()) {
    					count = rs.getInt(1);
    						
    				}
    			} else {
    				// Employee has not received issues for the end of the work day.
    				logger.debug("Resolved issues not found for : " + employeeVO.get_emp_first_nm() + " " + employeeVO.get_emp_last_nm());
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
    					+ ": ErrorCode: " + sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
    			try {
    				cleanResultSet();
    			} catch (SQLException sqle2) {
    				logger.warn(sqle2.getMessage(), sqle2);
    			}
    		}
    	}
        
        return count;
    }
    
    /**
     * Get data from Monitor Report table.
     * 
     * @param employeeVO
     * @param fromDate
     * @param ltoDate
     * @return Array of MonitorReportVO
     * @throws SQLException 
     */
    public List getMonitorReport(EmployeeVO employeeVO, Date fromDate, Date toDate) 
    	throws SQLException {
        
    	ArrayList al = new ArrayList(); 
    	if (employeeVO != null){
    		try {
    			setSqlSignature( selectMonitorReportSQL, false, logger.isDebugEnabled() );
    			if (fromDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(fromDate.getTime());
        			pstmt.setDate(  1, sqlDate);
        		} else {
        			pstmt.setNull(  1, java.sql.Types.DATE);
        		}
                
        		if (fromDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(toDate.getTime());
        			pstmt.setDate(  2, sqlDate);
        		} else {
        			pstmt.setNull(  2, java.sql.Types.DATE);
        		}
        		pstmt.setString(  3, employeeVO.get_emp_nbr());
                
     
        		if (logger.isDebugEnabled()) {
        			logger.debug(pstmt.toString());
        		}
                
    			execute();

    			if (hasResults & rs.next()) {
                       
    				MonitorReportVO monitorReportVO = new MonitorReportVO();
    				fetchMonitorReportData(monitorReportVO);
    				al.add(monitorReportVO);
                
    				while(rs.next()) {
    					monitorReportVO = new MonitorReportVO();
    					fetchMonitorReportData(monitorReportVO);
    					al.add(monitorReportVO);
    				}
    			} else {
    				return null;
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
            try {
                	cleanResultSet();
            	} catch (SQLException sqle2) {
            		logger.warn(sqle2.getMessage(), sqle2);
            	}
    		}
    	}
        return al;
    }
    
    /**
     * Get data from Monitor Report table.
     * 
     * @param employeeVO
     * @param fromDate
     * @param ltoDate
     * @return Array of MonitorReportVO
     * @throws SQLException 
     */
    public List getMonitorReport(Date workDate) 
    	throws SQLException {
        
    	ArrayList al = new ArrayList(); 

    	try {
    		setSqlSignature( selectNbrHitsWorkDateSQL, false, logger.isDebugEnabled() );
    		if (workDate != null) {
        		java.sql.Date sqlDate =
        			new java.sql.Date(workDate.getTime());
        		pstmt.setDate(  1, sqlDate);
        	} else {
        		pstmt.setNull(  1, java.sql.Types.DATE);
        	}
     
        	if (logger.isDebugEnabled()) {
        		logger.debug(pstmt.toString());
        	}
                
    		execute();

    		if (hasResults & rs.next()) {
                       
    		MonitorReportVO monitorReportVO = new MonitorReportVO();
    		fetchMonitorReportHitData(monitorReportVO);
    		al.add(monitorReportVO);
                
    			while(rs.next()) {
    				monitorReportVO = new MonitorReportVO();
    				fetchMonitorReportHitData(monitorReportVO);
    				al.add(monitorReportVO);
    			}
    		} else {
    			return null;
    		}
    	} catch (SQLException sqle) {
    		logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            	+ sqle.getSQLState() + ": ErrorCode: " 
            	+ sqle.getErrorCode()); 
    		throw sqle;
    	} finally {
           try {
                cleanResultSet();
            } catch (SQLException sqle2) {
            	logger.warn(sqle2.getMessage(), sqle2);
            }
    	}

        return al;
    }
    
    /**
     * Get data from Monitor Report table.
     * 
     * @param monitorType
     * @param employeeVO
     * @param fromDate
     * @param ltoDate
     * @return Array of MonitorReportVO
     * @throws SQLException 
     */
    public List getMonitorReport(String monitorType, EmployeeVO employeeVO, Date fromDate, Date toDate) 
    	throws SQLException {
        
    	ArrayList al = new ArrayList(); 
    	if (employeeVO != null){
    		try {
    			if (monitorType.compareToIgnoreCase("BOH") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesBeginingShiftSQL, false, logger.isDebugEnabled() );
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				if (fromDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(fromDate);// From date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
        				pstmt.setTimestamp(4, sqlDate);
        				
        				fromCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 days 7:00 AM MTN Time
        				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  2, sqlDate2);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            			pstmt.setNull(2, java.sql.Types.DATE);
            			pstmt.setNull(4, java.sql.Types.DATE);
            		}
    			}else if (monitorType.compareToIgnoreCase("RCVD") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesRcvdSQL, false, logger.isDebugEnabled() );
    				if (fromDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(fromDate);// From date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            		}
    				if (toDate != null) {
    					Calendar toCalendar = Calendar.getInstance();
        				toCalendar.setTime(toDate);// To date
        				toCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 MTN Time
       
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(toCalendar.getTimeInMillis());
        				pstmt.setTimestamp(2, sqlDate);
            		} else {
            			pstmt.setNull(2, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				pstmt.setString(4, employeeVO.get_emp_nbr());
    			}else if (monitorType.compareToIgnoreCase("EOH") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesEndiningShiftSQL, false, logger.isDebugEnabled() );
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				if (toDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(toDate);// To date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
        				
        				fromCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 days 17:00 AM MTN Time
        				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  2, sqlDate2);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            			pstmt.setNull(2, java.sql.Types.DATE);
            		}
    			}else if (monitorType.compareToIgnoreCase("Resolved") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesResolvedSQL, false, logger.isDebugEnabled() );
    				pstmt.setString(2, employeeVO.get_emp_nbr());
    				if (fromDate != null) {
    					java.sql.Date sqlDate =
    	    				new java.sql.Date(fromDate.getTime());
    					pstmt.setDate(  1, sqlDate);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            		}
    				if (toDate != null) {
    					java.sql.Date sqlDate =
    	    				new java.sql.Date(toDate.getTime());
        				pstmt.setDate(3, sqlDate);
            		} else {
            			pstmt.setNull(3, java.sql.Types.DATE);
            		}
    			}
    			
    			
        		
                
     
        		if (logger.isDebugEnabled()) {
        			logger.debug(pstmt.toString());
        		}
                
    			execute();

    			if (hasResults & rs.next()) {
                       
    				MonitorReportVO monitorReportVO = new MonitorReportVO();
    				monitorReportVO.set_emp_first_nm(employeeVO.get_emp_first_nm());
      	        	monitorReportVO.set_emp_last_nm(employeeVO.get_emp_last_nm());
      	        	monitorReportVO.set_emp_nbr(employeeVO.get_emp_nbr());
      	        	fetchTrackingMonitorReportData(monitorReportVO);
    				al.add(monitorReportVO);
                
    				while(rs.next()) {
    					monitorReportVO = new MonitorReportVO();
    					monitorReportVO.set_emp_first_nm(employeeVO.get_emp_first_nm());
          	        	monitorReportVO.set_emp_last_nm(employeeVO.get_emp_last_nm());
          	        	monitorReportVO.set_emp_nbr(employeeVO.get_emp_nbr());
          	        	fetchTrackingMonitorReportData(monitorReportVO);
    					al.add(monitorReportVO);
    				}
    			} else {
    				return null;
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
            try {
                	cleanResultSet();
            	} catch (SQLException sqle2) {
            		logger.warn(sqle2.getMessage(), sqle2);
            	}
    		}
    	}
        return al;
    }
    
    /**
     * Get data from Monitor Report table.
     * 
     * @param monitorType
     * @param employeeVO
     * @param fromDate
     * @param ltoDate
     * @return int of MonitorReportVO
     * @throws SQLException 
     */
    public int getMonitorCount(String monitorType, EmployeeVO employeeVO, Date fromDate, Date toDate) 
    	throws SQLException {
        
    	int size = 0; 
    	if (employeeVO != null){
    		try {
    			if (monitorType.compareToIgnoreCase("BOH") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesBeginingShiftCountSQL, false, logger.isDebugEnabled() );
    				if (fromDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(fromDate);// From date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
        				pstmt.setTimestamp(4, sqlDate);
        				
        				fromCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 day 7:00 MTN Time
        				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  2, sqlDate2);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            			pstmt.setNull(2, java.sql.Types.DATE);
            			pstmt.setNull(4, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    			}else if (monitorType.compareToIgnoreCase("RCVD") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesRcvdCountSQL, false, logger.isDebugEnabled() );
    				if (fromDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(fromDate);// From date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            		}
    				if (toDate != null) {
    					Calendar toCalendar = Calendar.getInstance();
        				toCalendar.setTime(toDate);// To date
        				toCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 MTN Time
       
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(toCalendar.getTimeInMillis());
        				pstmt.setTimestamp(2, sqlDate);
            		} else {
            			pstmt.setNull(2, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				pstmt.setString(4, employeeVO.get_emp_nbr());
    			}else if (monitorType.compareToIgnoreCase("EOH") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesEndiningShiftCountSQL, false, logger.isDebugEnabled() );
    				if (toDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(toDate);// To date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
        				
        				fromCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 day 7:00 MTN Time
        				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  2, sqlDate2);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            			pstmt.setNull(2, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    			}else if (monitorType.compareToIgnoreCase("Resolved") == 0){
    				setSqlSignature( selectTrackingNbrsIssuesResolvedCountSQL, false, logger.isDebugEnabled() );
    				if (fromDate != null) {
    					java.sql.Date sqlDate =
    	    				new java.sql.Date(fromDate.getTime());
    					pstmt.setDate(  1, sqlDate);
            		} else {
            			pstmt.setNull(  1, java.sql.Types.DATE);
            		}
    				if (toDate != null) {
    					java.sql.Date sqlDate =
    	    				new java.sql.Date(toDate.getTime());
        				pstmt.setDate(3, sqlDate);
            		} else {
            			pstmt.setNull(3, java.sql.Types.DATE);
            		}
    				pstmt.setString(2, employeeVO.get_emp_nbr());
    			}
                
     
        		if (logger.isDebugEnabled()) {
        			logger.debug(pstmt.toString());
        		}
                
    			execute();

    			if (hasResults) {
        			if (rs.next()) {        
        				size = rs.getInt("COUNT");
        			}                
        		} else {
        			// no data found
        			if (logger.isDebugEnabled()) {
        				logger.debug("no data found");
        			}
        			return size;
        		}  
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
            try {
                	cleanResultSet();
            	} catch (SQLException sqle2) {
            		logger.warn(sqle2.getMessage(), sqle2);
            	}
    		}
    	}
        return size;
    }
    
    /**
     * Get data from Monitor Report table.
     * 
     * @param monitorType
     * @param employeeVO
     * @param fromDate
     * @param ltoDate
     * @return Array of MonitorReportVO
     * @throws SQLException 
     */
    public List getMonitorReport(String monitorType, EmployeeVO employeeVO, Date fromDate, Date toDate, 
    		int startIndex, int endIndex, String sortColumn, boolean isSortAscending) 
    	throws SQLException {
        
    	ArrayList al = new ArrayList(); 
    	if (employeeVO != null){
    		try {
    			StringBuffer sql = new StringBuffer();
        		
        		// append starting SQL for paging results
                sql.append(PREpagedSQL);
                
    			if (monitorType.compareToIgnoreCase("BOH") == 0){
    				sql.append(selectTrackingNbrsIssuesBeginingShiftSQL);
    				
    				if ("Ship Date".equals(sortColumn)) {
    					sql.append(orderByShipDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Trk #".equals(sortColumn)){
    	            	sql.append(orderByTrkngItemNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Commit Date".equals(sortColumn)){
    	            	sql.append(orderByCommitDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Acct #".equals(sortColumn)){
    	            	sql.append(orderByAcctNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Shipment Code".equals(sortColumn)){
    	            	sql.append(orderByShpmtTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Shipper".equals(sortColumn)){
    	            	sql.append(orderByAcctNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Recipient".equals(sortColumn)){
    	            	sql.append(orderRecpCoNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Recipient Ph #".equals(sortColumn)){
    	            	sql.append(orderRecpPhNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Issue Type".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }else if ("Issue Name".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }
    				
    				sql.append(POSTpagedSQL);
    				
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );
    				if (fromDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(fromDate);// From date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
        				pstmt.setTimestamp(4, sqlDate);
        				
        				fromCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 days 7:00 AM MTN Time     			      
        				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  2, sqlDate2);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            			pstmt.setNull(2, java.sql.Types.DATE);
            			pstmt.setNull(4, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				pstmt.setInt( 5, endIndex);
    	            pstmt.setInt( 6, startIndex);
    			}else if (monitorType.compareToIgnoreCase("RCVD") == 0){
    				sql.append(selectTrackingNbrsIssuesRcvdSQL);
    				
    				if ("Ship Date".equals(sortColumn)) {
    					sql.append(orderByShipDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Trk #".equals(sortColumn)){
    	            	sql.append(orderByTrkngItemNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Commit Date".equals(sortColumn)){
    	            	sql.append(orderByCommitDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Acct #".equals(sortColumn)){
    	            	sql.append(orderByAcctNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Shipment Code".equals(sortColumn)){
    	            	sql.append(orderByShpmtTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Shipper".equals(sortColumn)){
    	            	sql.append(orderByAcctNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Recipient".equals(sortColumn)){
    	            	sql.append(orderRecpCoNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Recipient Ph #".equals(sortColumn)){
    	            	sql.append(orderRecpPhNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Issue Type".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Issue Name".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled() );
    				if (fromDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(fromDate);// From date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 7);// 7:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            		}
    				if (toDate != null) {
    					Calendar toCalendar = Calendar.getInstance();
        				toCalendar.setTime(toDate);// To date
        				toCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 MTN Time
       
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(toCalendar.getTimeInMillis());
        				pstmt.setTimestamp(2, sqlDate);
            		} else {
            			pstmt.setNull(2, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				pstmt.setString(4, employeeVO.get_emp_nbr());
    				pstmt.setInt( 5, endIndex);
    	            pstmt.setInt( 6, startIndex);
    			}else if (monitorType.compareToIgnoreCase("EOH") == 0){
    				sql.append(selectTrackingNbrsIssuesEndiningShiftSQL);
    				
    				if ("Ship Date".equals(sortColumn)) {
    					sql.append(orderByShipDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Trk #".equals(sortColumn)){
    	            	sql.append(orderByTrkngItemNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Commit Date".equals(sortColumn)){
    	            	sql.append(orderByCommitDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Acct #".equals(sortColumn)){
    	            	sql.append(orderByAcctNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Shipment Code".equals(sortColumn)){
    	            	sql.append(orderByShpmtTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Shipper".equals(sortColumn)){
    	            	sql.append(orderByAcctNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Recipient".equals(sortColumn)){
    	            	sql.append(orderRecpCoNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Recipient Ph #".equals(sortColumn)){
    	            	sql.append(orderRecpPhNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Issue Type".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Issue Name".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled());
    				if (toDate != null) {
    					Calendar fromCalendar = Calendar.getInstance();
        				fromCalendar.setTime(toDate);// To date
        				fromCalendar.set(Calendar.HOUR_OF_DAY, 17);// 17:00 AM MTN Time
      
        				java.sql.Timestamp sqlDate = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  1, sqlDate);
        				
        				fromCalendar.add(Calendar.DAY_OF_YEAR, -10);// -10 days 17:00 AM MTN Time
        				java.sql.Timestamp sqlDate2 = new java.sql.Timestamp(fromCalendar.getTimeInMillis());
        				pstmt.setTimestamp(  2, sqlDate2);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            			pstmt.setNull(2, java.sql.Types.DATE);
            		}
    				pstmt.setString(3, employeeVO.get_emp_nbr());
    				pstmt.setInt( 4, endIndex);
    	            pstmt.setInt( 5, startIndex);
    			}else if (monitorType.compareToIgnoreCase("Resolved") == 0){
    				sql.append(selectTrackingNbrsIssuesResolvedSQL);
    				
    				if ("Ship Date".equals(sortColumn)) {
    					sql.append(orderByShipDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Trk #".equals(sortColumn)){
    	            	sql.append(orderByTrkngItemNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Commit Date".equals(sortColumn)){
    	            	sql.append(orderByCommitDtSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Acct #".equals(sortColumn)){
    	            	sql.append(orderByAcctNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Shipment Code".equals(sortColumn)){
    	            	sql.append(orderByShpmtTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Shipper".equals(sortColumn)){
    	            	sql.append(orderByAcctNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Recipient".equals(sortColumn)){
    	            	sql.append(orderRecpCoNmSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Recipient Ph #".equals(sortColumn)){
    	            	sql.append(orderRecpPhNbrSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Issue Type".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    				}else if ("Issue Name".equals(sortColumn)){
    	            	sql.append(orderIssueTypeCdSQL);
    					if (!isSortAscending){
    						sql.append(" DESC ");
    					}
    	            }
    				sql.append(POSTpagedSQL);
    				setSqlSignature( sql.toString(), false, logger.isDebugEnabled());
    				if (fromDate != null) {
    					java.sql.Date sqlDate =
    	    				new java.sql.Date(fromDate.getTime());
        				pstmt.setDate(  1, sqlDate);
            		} else {
            			pstmt.setNull(1, java.sql.Types.DATE);
            		}
    				if (toDate != null) {
    					java.sql.Date sqlDate =
    	    				new java.sql.Date(toDate.getTime());
        				pstmt.setDate(3, sqlDate);
            		} else {
            			pstmt.setNull(3, java.sql.Types.DATE);
            		}
    				pstmt.setString(2, employeeVO.get_emp_nbr());
    				pstmt.setInt( 4, endIndex);
    	            pstmt.setInt( 5, startIndex);
    			}
                
     
        		if (logger.isDebugEnabled()) {
        			logger.debug(pstmt.toString());
        		}
                
    			execute();

    			if (hasResults & rs.next()) {
                       
    				MonitorReportVO monitorReportVO = new MonitorReportVO();
    				monitorReportVO.set_emp_first_nm(employeeVO.get_emp_first_nm());
      	        	monitorReportVO.set_emp_last_nm(employeeVO.get_emp_last_nm());
      	        	monitorReportVO.set_emp_nbr(employeeVO.get_emp_nbr());
      	        	fetchTrackingMonitorReportData(monitorReportVO);
    				al.add(monitorReportVO);
                
    				while(rs.next()) {
    					monitorReportVO = new MonitorReportVO();
    					monitorReportVO.set_emp_first_nm(employeeVO.get_emp_first_nm());
          	        	monitorReportVO.set_emp_last_nm(employeeVO.get_emp_last_nm());
          	        	monitorReportVO.set_emp_nbr(employeeVO.get_emp_nbr());
          	        	fetchTrackingMonitorReportData(monitorReportVO);
    					al.add(monitorReportVO);
    				}
    			} else {
    				return null;
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
            try {
                	cleanResultSet();
            	} catch (SQLException sqle2) {
            		logger.warn(sqle2.getMessage(), sqle2);
            	}
    		}
    	}
        return al;
    }
    
    /**
     * Get SUM data from Monitor Report table.
     * 
     * @param employeeVO
     * @param fromDate
     * @param ltoDate
     * @return MonitorReportVO
     * @throws SQLException 
     */
    public MonitorReportVO getMonitorReportSum(EmployeeVO employeeVO, Date fromDate, Date toDate) 
    	throws SQLException {
        
    	MonitorReportVO mvo = null;
    	if (employeeVO != null){
    		try {
    			setSqlSignature( selectMonitorReportSumSQL, false, logger.isDebugEnabled() );
    			if (fromDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(fromDate.getTime());
        			pstmt.setDate(  1, sqlDate);
        		} else {
        			pstmt.setNull(  1, java.sql.Types.DATE);
        		}
                
        		if (fromDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(toDate.getTime());
        			pstmt.setDate(  2, sqlDate);
        		} else {
        			pstmt.setNull(  2, java.sql.Types.DATE);
        		}
        		pstmt.setString(  3, employeeVO.get_emp_nbr());
        		
        		if (logger.isDebugEnabled()) {
        			logger.debug(pstmt.toString());
        		}
                
    			execute();

    			if (hasResults & rs.next()) {
                       
    				MonitorReportVO monitorReportVO = new MonitorReportVO();
    				fetchMonitorReportSumData(monitorReportVO);
    				mvo = monitorReportVO;
    			} else {
    				return null;
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
            try {
                	cleanResultSet();
            	} catch (SQLException sqle2) {
            		logger.warn(sqle2.getMessage(), sqle2);
            	}
    		}
    	}
        return mvo;
    }
    
    /**
     * Get the number of accounts employee monitors on a specific date from the 
     * Monitor_Report table.
     * 
     * @param employeeVO
     * @param ltoDate
     * @return int numAccounts
     * @throws SQLException 
     */
    public int getNumberMonitorAccounts(EmployeeVO employeeVO, Date toDate) 
    	throws SQLException {
        
    	int numAccounts = 0;
    	if (employeeVO != null){
    		try {
    			setSqlSignature( selectNumberMonitorAccountsSQL, false, logger.isDebugEnabled() );
    			if (toDate != null) {
        			java.sql.Date sqlDate =
        				new java.sql.Date(toDate.getTime());
        			pstmt.setDate(  1, sqlDate);
        		} else {
        			pstmt.setNull(  1, java.sql.Types.DATE);
        		}
        		pstmt.setString(  2, employeeVO.get_emp_nbr());
        		
        		if (logger.isDebugEnabled()) {
        			logger.debug(pstmt.toString());
        		}
                
    			execute();

    			if (hasResults & rs.next()) {
    				numAccounts = rs.getInt("ACCOUNT_QTY");
    			} else {
    				return 0;
    			}
    		} catch (SQLException sqle) {
    			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " 
            		+ sqle.getSQLState() + ": ErrorCode: " 
            		+ sqle.getErrorCode()); 
    			throw sqle;
    		} finally {
            try {
                	cleanResultSet();
            	} catch (SQLException sqle2) {
            		logger.warn(sqle2.getMessage(), sqle2);
            	}
    		}
    	}
        return numAccounts;
    }
    /**
     * Fetch MonitorReportVO data from the monitor report table.
     * @param monitorReportVO
     * @throws SQLException
     */
    private void fetchMonitorReportData(MonitorReportVO monitorReportVO) 
    	throws SQLException {
    	monitorReportVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	
    	if (EmployeeCacheDAO.containsKey(monitorReportVO.get_emp_nbr())){
    		monitorReportVO.set_emp_first_nm(EmployeeCacheDAO.get(monitorReportVO.get_emp_nbr()).get_emp_first_nm());
    		monitorReportVO.set_emp_last_nm(EmployeeCacheDAO.get(monitorReportVO.get_emp_nbr()).get_emp_last_nm());
    	}
    	
    	Date workDt = (java.util.Date)rs.getTimestamp("WORK_DT");
        if (workDt != null) {
            Calendar accptDtCalendar = Calendar.getInstance();
            accptDtCalendar.setTime(workDt);
            monitorReportVO.set_work_dt(accptDtCalendar);
        }
        monitorReportVO.set_num_issues_begin_shift(rs.getInt("BEGIN_HAND_QTY"));
        monitorReportVO.set_num_issues_presented(rs.getInt("ISSUE_RCVD_QTY"));
        monitorReportVO.set_num_issues_end_shift(rs.getInt("END_HAND_QTY"));
        monitorReportVO.set_num_issues_resolved(rs.getInt("ISSUE_RSLV_QTY"));
        monitorReportVO.set_total_number_accounts(rs.getInt("ACCOUNT_QTY"));
        monitorReportVO.set_num_mawb_resolved(rs.getInt("MAWB_RSLV_QTY"));
        monitorReportVO.set_num_crn_resolved(rs.getInt("CRN_RSLV_QTY"));
        monitorReportVO.set_num_hits(rs.getInt("HIT_QTY"));
        monitorReportVO.set_total_duration(rs.getInt("DURATION_QTY"));
    }
    
    /**
     * Fetch MonitorReportVO data from the monitor report table.
     * @param monitorReportVO
     * @throws SQLException
     */
    private void fetchMonitorReportHitData(MonitorReportVO monitorReportVO) 
    	throws SQLException {
    	monitorReportVO.set_emp_nbr(rs.getString("EMP_NBR"));
    	
    	Date workDt = (java.util.Date)rs.getTimestamp("WORK_DT");
        if (workDt != null) {
            Calendar accptDtCalendar = Calendar.getInstance();
            accptDtCalendar.setTime(workDt);
            monitorReportVO.set_work_dt(accptDtCalendar);
        }
        
        monitorReportVO.set_num_hits(rs.getInt("HIT_QTY"));
    }
    
    /**
     * Fetch Tracking data for MonitorReportVO data from the monitor report table.
     * @param monitorReportVO
     * @throws SQLException
     */
    private void fetchTrackingMonitorReportData(MonitorReportVO monitorReportVO) 
    	throws SQLException {
    	monitorReportVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
    	monitorReportVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
    	monitorReportVO.set_acct_nbr(rs.getString("ACCT_NBR"));
    	monitorReportVO.set_issue_type_cd(rs.getInt("ISSUE_TYPE_CD"));
    	
    	Date shipDt = (java.util.Date)rs.getTimestamp("SHIP_DT");
    	monitorReportVO.set_ship_dt(shipDt);
    	
    	TimeZone commitDtTz = null;
        Date commitDt = (java.util.Date)rs.getTimestamp("COMMIT_DT");
        if (commitDt != null) {
            String commitDtTzOffset = rs.getString("COMMIT_DATE_TMZN_OFFST_NBR");
            commitDtTz = TimeZone.getTimeZone("GMT" + commitDtTzOffset);
            Calendar commitCalendar = Calendar.getInstance(commitDtTz);
            commitCalendar.setTime(commitDt);
            monitorReportVO.set_commit_dt(commitCalendar);
        }
    	
        monitorReportVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
        
        monitorReportVO.set_recp_co_nm(new String(" "));
        if (rs.getString("RECP_CO_NM") != null){
        	monitorReportVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
        }
        
        monitorReportVO.set_recp_ph_nbr(new String(" "));
        if (rs.getString("RECP_PH_NBR") != null){
        	monitorReportVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
        }
        
        monitorReportVO.set_acct_nm(rs.getString("ACCT_NM"));
    }
    
    /**
     * Fetch MonitorReportVO data from the monitor report table.
     * @param monitorReportVO
     * @throws SQLException
     */
    private void fetchMonitorReportSumData(MonitorReportVO monitorReportVO) 
    	throws SQLException {
        monitorReportVO.set_num_issues_begin_shift(rs.getInt("BEGINHANDQTY"));
        monitorReportVO.set_num_issues_presented(rs.getInt("ISSUERCVDQTY"));
        monitorReportVO.set_num_issues_end_shift(rs.getInt("ENDHANDQTY"));
        monitorReportVO.set_num_issues_resolved(rs.getInt("ISSUERSLVQTY"));
        monitorReportVO.set_num_mawb_resolved(rs.getInt("MAWBRSLVQTY"));
        monitorReportVO.set_num_crn_resolved(rs.getInt("CRNRSLVQTY"));
        monitorReportVO.set_num_hits(rs.getInt("HITQTY"));
        monitorReportVO.set_total_duration(rs.getInt("DURATIONQTY"));
    }
}
