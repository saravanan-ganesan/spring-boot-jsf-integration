package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.ReferenceNoteVO;

public class ReferenceNoteDAO extends DatabaseDAO {
    /** Logger */
    private static Logger logger = LogManager.getLogger(ReferenceNoteDAO.class);
        
    /**
     * This method is used to persist a record into the ReferenceNote table.
     *
     * @param aReferenceNotes a list of shipment reference notes
     * @throws SQLException 
     * @throws ServiceLocatorException 
     */
    public void doPersist(List aReferenceNotes) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ReferenceNotePersister persister = new ReferenceNotePersister(connection);
            Iterator iter = aReferenceNotes.iterator();
            while(iter.hasNext()) {
                persister.persist((ReferenceNoteVO)iter.next());
            }
        } finally {
            closeConnection(connection);
        }
    }  
    
    public List getReferenceNotes(String trkng_item_nbr, String trkng_item_uniq_nbr) throws SQLException, ServiceLocatorException {
        Connection connection = null;

        try {
            connection = initializeConnection();
            ReferenceNotesAccessor accessor = new ReferenceNotesAccessor(connection);
            List list = accessor.getReferenceNotes(trkng_item_nbr, trkng_item_uniq_nbr);
            return list;
        } finally {
            closeConnection(connection);
        }
    }
}
