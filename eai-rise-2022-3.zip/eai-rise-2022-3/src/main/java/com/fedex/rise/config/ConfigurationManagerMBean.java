package com.fedex.rise.config;

public interface ConfigurationManagerMBean {
    public void reload();

    public void setProperty(String aKey, String aValue);
}
