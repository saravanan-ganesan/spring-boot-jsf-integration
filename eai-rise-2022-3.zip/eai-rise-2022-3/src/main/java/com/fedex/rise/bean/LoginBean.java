package com.fedex.rise.bean;

import com.fedex.rise.annotation.JsfController;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsfController(path = "/", page = "/pages/jsp/login.jsp", value = "loginBean")
public class LoginBean extends BaseBean {

	public void login() {
		redirect("/home");
	}
}
