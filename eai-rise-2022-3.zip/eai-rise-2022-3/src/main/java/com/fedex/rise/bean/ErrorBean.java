package com.fedex.rise.bean;

import com.fedex.rise.annotation.JsfController;

@JsfController(path = "/error", page = "/pages/jsp/error.jsp", value = "errorBean")
public class ErrorBean extends BaseBean {

}
