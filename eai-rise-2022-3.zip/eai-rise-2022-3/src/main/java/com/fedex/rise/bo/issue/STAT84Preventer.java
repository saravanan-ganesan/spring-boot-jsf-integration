package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class STAT84Preventer extends Preventer{
	private static Logger logger = LogManager.getLogger(STAT84Preventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static STAT84Preventer _instance = new STAT84Preventer();

    static {
        // The previous scan of a STAT 84
    	_preventingScans.add(RiseConstants.STAT);
    }
  
    private STAT84Preventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	
        // If a STAT84 event previous to the current event.
    	if (_preventingScans.contains(anPastEventVO.get_track_type_cd()) && 
        		anPastEventVO.get_track_excp_cd().equalsIgnoreCase("84")){
        	logger.debug("Issue prevented by Stat 84");
        	return true;
        }
        
        return false;
    }

    public static STAT84Preventer getInstance() {
        return _instance;
    }

}
