package com.fedex.rise.config;

/**
 * This is the class that contains all the properties that will be used by the other
 * applications. The property file location is stored in a constant and will contain
 * Name:value seperated by a ":" or spaces.
 */

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.Vector;

import com.fedex.rise.util.Utilities;

public class ConfigurationManager implements ConfigurationManagerMBean {
    /**
     * This instance variable used so that this object can be an MBean. And so
     * we can be a singleton
     */
    private static ConfigurationManager _configManager = new ConfigurationManager();

    /**
     * All the properties read from the Configuration file will be stored in a
     * java.util.Properties object. This is a static object and will be looked
     * up only once.
     */
    protected static Properties _configProperties = new Properties();

    /**
     * This variable contains the Overall Config file's location. If this file
     * has to be relocated, this class will have to be modified and recompiled.
     */
    protected static final String CONFIG_FILE = "properties/rise.properties";

    /**
     * This variable contains the Default Rise Config file name. This file must
     * be in the CLASSPATH (usually bundled in the JAR, WAR, or EAR)
     */
    protected static final String DEFAULT_CONFIG_FILE = "com/fedex/rise/config/rise.default.properties";

    /**
     * The key of a property that describes the fully qualified host name.
     */
    public static final String HOSTNAME = "HOSTNAME";

    /**
     * The key of a property that describes the host name minus the domain.
     */
    public static final String SHORTHOSTNAME = "SHORTHOSTNAME";

    /**
     * A list of listeners to be notified when a configuration event occurs.
     */
    protected static Vector _listenerList = new Vector();

    // make sure the initialize after we instantiate ourselves
    static {
        ConfigurationManager.populateConfigProperties();
    }

    /**
     * Public constructor, required for MBean, not intended for use
     */
    public ConfigurationManager() {
        registerMBean();        
        Utilities.logPackageVersion(this.getClass().getPackage());
    }

    /**
     * This method will register the MBean with Weblogic.
     */
    private void registerMBean() {
        // TODO: JMX anyone?
        //CRMMBeanHelper.registerMBean(this, OLLConstants.OLL_MBEAN_DOMAIN
        //        + ":Name=ConfigurationManager");
    }

    /**
     * @return the appropriate value for the key
     * 
     * If the "key" is not found, a NULL will be returned. The calling class
     * will have to make sure the value returned is NOT null, otherwise, it will
     * blow up with NullPointerException
     */
    public static String get(String key) {
        return (String) _configProperties.getProperty(key);
    }

    /**
     * @return the appropriate value for the key
     * 
     * If the "key" is not found, the defaultVal will be returned.
     */
    public static String get(String key, String defaultVal) {
        return (String) _configProperties.getProperty(key, defaultVal);
    }
    
    /**
     * This method loads the java.util.Properties object from the config file.
     * The Properties are loaded using the "load()" method.
     */
    public static void populateConfigProperties() {
        System.out.println("***** INFO *****"
                + "Loading parameters from config file");
        
        // Load DEFAULT properties first
        Properties defaultProperties = null;
        try {
            InputStream in = null;
            defaultProperties = new Properties();
            in = _configManager.getClass().getClassLoader()
                    .getResourceAsStream(DEFAULT_CONFIG_FILE);
            if (in != null) {
                defaultProperties.load(in);
                in.close();
                System.out.println("Loading defaults successful");
            } else {
                System.out.println("No default configuration file found: "
                        + DEFAULT_CONFIG_FILE);
            }
        } catch (FileNotFoundException e) {
            System.out.println("xNo default configuration file found: "
                    + DEFAULT_CONFIG_FILE);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Initialize the config properties with the default first, so they can
        // be overridden
        Properties configProperties = new Properties(defaultProperties);

        // This section will get the fully qualifed host name and a short
        // host name and put them in as properties to be used where it
        // would be beneficial to know the hostname of the machine the
        // code is running on.
        String hostname = null;
        try {
        	hostname = getHostName();
        } catch (UnknownHostException uhe) {
        	uhe.printStackTrace();
        }
        
        //System.out.println("Local InetAddress.getHostName is: "
        //        + ia.getHostName());
        configProperties.setProperty(HOSTNAME, hostname);

        String shortHostName = null;
        int endIndex = hostname.indexOf('.');
        if (endIndex != -1) {
            shortHostName = hostname.substring(0, endIndex);
        } else {
            shortHostName = hostname;
        }

        configProperties.setProperty(SHORTHOSTNAME, shortHostName);

        String configFile = System.getProperty("rise.config.file");
        if ((configFile == null) || (configFile.equals(""))) {
            configFile = CONFIG_FILE;
            System.out.println("System Property rise.config.file not found." +
                    " Using default location. " + CONFIG_FILE);
        }

        try {
            BufferedInputStream bis = new BufferedInputStream(
                    new FileInputStream(configFile));
            configProperties.load(bis);
            if (configProperties.getProperty("VERBOSE", "true").equals("true")) {
                System.out.println("application config " + configFile);
                configProperties.list(System.out);
            }
            bis.close();

            System.out.println("***** INFO *****"
                    + "Loading parameters from config file successful");
            _configProperties = configProperties;

        } catch (IOException e) {
            System.out.println("Failed loading application config " + configFile);
            e.printStackTrace();
        }
    }

    /**
     * This method is used to fire configuration Events to all the listeners in
     * the list.
     */

    public void fireEvent() {
        Vector target;
        synchronized (this) {
            target = (Vector) _listenerList.clone();
        }
        for (int i = 0; i < target.size(); i++) {
            ConfigurationEventListener eventListener = (ConfigurationEventListener) target
                    .elementAt(i);
            eventListener.processConfigurationEvent();
        }
        
        if (_configProperties.getProperty("VERBOSE", "true").equals("true")) {
            // Print out new config values in weblogic log
            _configProperties.list(System.out);
        }
    }

    /**
     * This method is used to add a ConfigurationEventListener object to the
     * list.
     * 
     * @param aConfigurationEventListener
     *            A ConfigurationEventListener object
     */
    public static void addConfigurationEventListener(
            ConfigurationEventListener aConfigurationEventListener) {
        _listenerList.addElement(aConfigurationEventListener);
    }

    /**
     * This method is used to remove a ConfigurationEventListener object from
     * the list.
     * 
     * @param aConfigurationEventListener
     *            A ConfigurationEventListener object.
     * @return true if the argument was component of this vector, false
     *         otherwise.
     */
    public static boolean removeConfigurationEventListener(
            ConfigurationEventListener aConfigurationEventListener) {
        return _listenerList.removeElement(aConfigurationEventListener);
    }

    /**
     * This method is used to reload the config file, called via JMX All
     * listeners are notified that the configuration has changed
     */
    public void reload() {
        populateConfigProperties();
        fireEvent();
    }

    /**
     * This method is used to set a property and let all
     * configurationEventListeners know that the change occured, so that they
     * may reconfigure. This method is called via JMX.
     * 
     * @param aKey
     *            the properties key value
     * @param aValue
     *            the value of the property defined by the key
     */
    public void setProperty(String aKey, String aValue) {
        if ((aKey != null) && (aValue != null) && (_configProperties != null)) {
            try {
                _configProperties.setProperty(aKey, aValue);
                fireEvent();
            } catch (Exception e) {
                System.out.println(e);
                e.printStackTrace();
            }
        }
    }
    
	private static String getHostName() throws UnknownHostException {
		String localHostname = null;
		localHostname = System.getenv("CNAME");
		if (localHostname == null || localHostname.equalsIgnoreCase("")) {
			InetAddress address = InetAddress.getLocalHost();
			localHostname = address.getCanonicalHostName();
		}
		return localHostname;
	}
}
