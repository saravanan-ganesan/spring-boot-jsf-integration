package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.FilterByIssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class ShipmentAccessor extends OracleBase {
	private static Logger logger = LogManager.getLogger(ShipmentAccessor.class);

	public ShipmentAccessor(Connection con) {
		super(con);
	}

	private static final String SQLShipmentAllColumnsDistinct = "select distinct " + "s.TRKNG_ITEM_NBR, "
			+ "s.TRKNG_ITEM_UNIQ_NBR, " + "s.GROUP_NBR, " + "s.ACCT_NBR, " + "s.LANE_NBR," + "s.SVC_TYPE_CD, "
			+ "s.SHPMT_TYPE_CD, " + "s.TRKNG_ITEM_FORM_CD, " + "s.PACK_TYPE_CD, " + "s.ORIG_LOC_CD, "
			+ "s.DEST_LOC_CD, " + "s.SHPMT_WGT, " + "s.SHPMT_UOM_CD, " + "s.SHIP_DT, " + "s.SHPR_CO_NM, "
			+ "s.SHPR_PH_NBR, " + "s.SHPR_ADDR_LINE_ONE_DESC, " + "s.SHPR_ADDR_LINE_TWO_DESC, "
			+ "s.SHPR_ADDR_LINE_THREE_DESC, " + "s.SHPR_CITY_NM, " + "s.SHPR_PSTL_CD, " + "s.SHPR_CNTRY_CD, "
			+ "s.SHPR_ST_PROV_CD, " + "s.RECP_CO_NM, " + "s.RECP_PH_NBR, " + "s.RECP_ADDR_LINE_ONE_DESC, "
			+ "s.RECP_ADDR_LINE_TWO_DESC, " + "s.RECP_ADDR_LINE_THREE_DESC, " + "s.RECP_CITY_NM, "
			+ "s.RECP_ST_PROV_CD, " + "s.RECP_CNTRY_CD, " + "s.RECP_PSTL_CD, " + "s.ACTL_DEL_NM, "
			+ "s.ACTL_ADDR_LINE_ONE_DESC, " + "s.DEL_DT, " + "s.DEL_DATE_TMZN_OFFST_NBR, " + "s.SPCL_HNDLG_GRP, "
			+ "s.CRTG_AGENT_CO_NM, " + "s.CSTMS_CURR_CD, " + "s.CSTMS_VALUE_AMT, " + "s.DIMNL_WGT, " + "s.INV_AMT, "
			+ "s.SHPMT_PKG_QTY, " + "s.LAST_EVENT_TMSTP, " + "s.LAST_EVENT_TMZN_OFFST_NBR, "
			+ "s.LAST_EVENT_TRACK_TYPE_CD, " + "s.COMMIT_DT, " + "s.ADJ_COMMIT_DT, " + "s.COMMIT_DATE_TMZN_OFFST_NBR, "
			+ "s.ADJ_COMMIT_DT_OFFST_NBR, " + "s.PERF_RSULT_CD, " + "s.INPUT_TMSTP, " + "s.LAST_UPDT_TMSTP, "
			+ "s.DEL_QTY, " + "s.SKID_INTACT_FLG, " + "s.QTY_OBSER_FLG, " + "s.PKG_PIECE_QTY, " + "s.LAST_STAT_DESC, "
			+ "s.LAST_EVENT_TRACK_LOC_CD, " + "s.LAST_STAT_TRACK_LOC_CD, " + "s.LAST_STAT_TMSTP, "
			+ "s.CLEARED_CSTMS_TMSTP, " + "s.CLEARED_CSTMS_TMZN_OFFSET_NBR, " + "s.WRK_STAT_CD ";

	// WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
	private static final String SQLShipmentAllColumnsNotDistinctWithAlias = "select " + "s.TRKNG_ITEM_NBR, "
			+ "s.TRKNG_ITEM_UNIQ_NBR, " + "s.GROUP_NBR, " + "s.ACCT_NBR, " + "s.LANE_NBR," + "s.SVC_TYPE_CD, "
			+ "s.SHPMT_TYPE_CD, " + "s.TRKNG_ITEM_FORM_CD, " + "s.PACK_TYPE_CD, " + "s.ORIG_LOC_CD, "
			+ "s.DEST_LOC_CD, " + "s.SHPMT_WGT, " + "s.SHPMT_UOM_CD, " + "s.SHIP_DT, " + "s.SHPR_CO_NM, "
			+ "s.SHPR_PH_NBR, " + "s.SHPR_ADDR_LINE_ONE_DESC, " + "s.SHPR_ADDR_LINE_TWO_DESC, "
			+ "s.SHPR_ADDR_LINE_THREE_DESC, " + "s.SHPR_CITY_NM, " + "s.SHPR_PSTL_CD, " + "s.SHPR_CNTRY_CD, "
			+ "s.SHPR_ST_PROV_CD, " + "s.RECP_CO_NM, " + "s.RECP_PH_NBR, " + "s.RECP_ADDR_LINE_ONE_DESC, "
			+ "s.RECP_ADDR_LINE_TWO_DESC, " + "s.RECP_ADDR_LINE_THREE_DESC, " + "s.RECP_CITY_NM, "
			+ "s.RECP_ST_PROV_CD, " + "s.RECP_CNTRY_CD, " + "s.RECP_PSTL_CD, " + "s.ACTL_DEL_NM, "
			+ "s.ACTL_ADDR_LINE_ONE_DESC, " + "s.DEL_DT, " + "s.DEL_DATE_TMZN_OFFST_NBR, " + "s.SPCL_HNDLG_GRP, "
			+ "s.CRTG_AGENT_CO_NM, " + "s.CSTMS_CURR_CD, " + "s.CSTMS_VALUE_AMT, " + "s.DIMNL_WGT, " + "s.INV_AMT, "
			+ "s.SHPMT_PKG_QTY, " + "s.LAST_EVENT_TMSTP, " + "s.LAST_EVENT_TMZN_OFFST_NBR, "
			+ "s.LAST_EVENT_TRACK_TYPE_CD, " + "s.COMMIT_DT, " + "s.ADJ_COMMIT_DT, " + "s.COMMIT_DATE_TMZN_OFFST_NBR, "
			+ "s.ADJ_COMMIT_DT_OFFST_NBR, " + "s.PERF_RSULT_CD, " + "s.INPUT_TMSTP, " + "s.LAST_UPDT_TMSTP, "
			+ "s.DEL_QTY, " + "s.SKID_INTACT_FLG, " + "s.QTY_OBSER_FLG, " + "s.PKG_PIECE_QTY, " + "s.LAST_STAT_DESC, "
			+ "s.LAST_EVENT_TRACK_LOC_CD, " + "s.LAST_STAT_TRACK_LOC_CD, " + "s.LAST_STAT_TMSTP, "
			+ "s.CLEARED_CSTMS_TMSTP, " + "s.CLEARED_CSTMS_TMZN_OFFSET_NBR, " + "s.WRK_STAT_CD ";

	private static final String SQLShipmentAllColumnsNotDistinct = "select " + "TRKNG_ITEM_NBR, "
			+ "TRKNG_ITEM_UNIQ_NBR, " + "GROUP_NBR, " + "ACCT_NBR, " + "LANE_NBR," + "SVC_TYPE_CD, "
			+ "SHPMT_TYPE_CD, " + "TRKNG_ITEM_FORM_CD, " + "PACK_TYPE_CD, " + "ORIG_LOC_CD, " + "DEST_LOC_CD, "
			+ "SHPMT_WGT, " + "SHPMT_UOM_CD, " + "SHIP_DT, " + "SHPR_CO_NM, " + "SHPR_PH_NBR, "
			+ "SHPR_ADDR_LINE_ONE_DESC, " + "SHPR_ADDR_LINE_TWO_DESC, " + "SHPR_ADDR_LINE_THREE_DESC, "
			+ "SHPR_CITY_NM, " + "SHPR_PSTL_CD, " + "SHPR_CNTRY_CD, " + "SHPR_ST_PROV_CD, " + "RECP_CO_NM, "
			+ "RECP_PH_NBR, " + "RECP_ADDR_LINE_ONE_DESC, " + "RECP_ADDR_LINE_TWO_DESC, "
			+ "RECP_ADDR_LINE_THREE_DESC, " + "RECP_CITY_NM, " + "RECP_ST_PROV_CD, " + "RECP_CNTRY_CD, "
			+ "RECP_PSTL_CD, " + "ACTL_DEL_NM, " + "ACTL_ADDR_LINE_ONE_DESC, " + "DEL_DT, "
			+ "DEL_DATE_TMZN_OFFST_NBR, " + "SPCL_HNDLG_GRP, " + "CRTG_AGENT_CO_NM, " + "CSTMS_CURR_CD, "
			+ "CSTMS_VALUE_AMT, " + "DIMNL_WGT, " + "INV_AMT, " + "SHPMT_PKG_QTY, " + "LAST_EVENT_TMSTP, "
			+ "LAST_EVENT_TMZN_OFFST_NBR, " + "LAST_EVENT_TRACK_TYPE_CD, " + "COMMIT_DT, " + "ADJ_COMMIT_DT, "
			+ "COMMIT_DATE_TMZN_OFFST_NBR, " + "ADJ_COMMIT_DT_OFFST_NBR, " + "PERF_RSULT_CD, " + "INPUT_TMSTP, "
			+ "LAST_UPDT_TMSTP, " + "DEL_QTY, " + "SKID_INTACT_FLG, " + "QTY_OBSER_FLG, " + "PKG_PIECE_QTY, "
			+ "LAST_STAT_DESC, " + "LAST_EVENT_TRACK_LOC_CD, " + "LAST_STAT_TRACK_LOC_CD, " + "LAST_STAT_TMSTP, "
			+ "CLEARED_CSTMS_TMSTP, " + "CLEARED_CSTMS_TMZN_OFFSET_NBR, " + "WRK_STAT_CD ";

	private static final String SQLShipmentAllColumnsForFilterBean = "select distinct " + "a.ASSOC_TRKNG_ITEM_NBR, "
			+ "s.TRKNG_ITEM_NBR, " + "s.TRKNG_ITEM_UNIQ_NBR, " + "actg.GROUP_NM, " + "act.ACCT_NM, " + "s.SHPR_CNTRY_CD, " + "s.RECP_CNTRY_CD, " + "s.SVC_TYPE_CD, "  + "s.ACCT_NBR, " + "s.SHPMT_TYPE_CD, " + "s.ORIG_LOC_CD, " + "s.DEST_LOC_CD, "
			+ "s.SHIP_DT, " + "s.COMMIT_DT, " + "s.COMMIT_DATE_TMZN_OFFST_NBR, " + "s.LAST_EVENT_TRACK_LOC_CD, " + "s.LAST_STAT_TRACK_LOC_CD, " + "s.LAST_STAT_DESC, " + "s.LAST_STAT_TMSTP, " + "e.EMP_FIRST_NM, "
			+ "e.EMP_LAST_NM, " + "alsm.EMP_NBR ";

	private static final String selectShipmentSQL = SQLShipmentAllColumnsNotDistinct + "from SHIPMENT where "
			+ "TRKNG_ITEM_NBR = ? AND " + "TRKNG_ITEM_UNIQ_NBR = ?";

	private final static String selectShipmentWithIssuesForFilterSQLPre = "where s.TRKNG_ITEM_NBR= a.TRKNG_ITEM_NBR "
			+ "and s.TRKNG_ITEM_UNIQ_NBR=a.TRKNG_ITEM_UNIQ_NBR " + "and s.TRKNG_ITEM_NBR=i.TRKNG_ITEM_NBR "
			+ "and s.TRKNG_ITEM_UNIQ_NBR=i.TRKNG_ITEM_UNIQ_NBR " + "and s.ACCT_NBR=alsm.ACCT_NBR " + "and s.ACCT_NBR=act.ACCT_NBR " + "and s.group_nbr=actg.group_nbr "
			+ "and alsm.EMP_NBR=e.EMP_NBR " + "and i.RES_DT is null " + "and s.SHIP_DT >= trunc(SYSDATE - ? ) "
			+ "and i.ISSUE_TMSTP <= SYSDATE "; // issue
												// is
												// active

	private final static String selectShipmentWithIssuesSQLFiltered = " and ISSUE_TYPE_CD IN (";

	public ShipmentVO getShipment(String trkng_item_nbr, String trkng_item_uniq_nbr) throws SQLException {
		ShipmentVO shipmentVO = new ShipmentVO();

		try {
			setSqlSignature(selectShipmentSQL, false, logger.isDebugEnabled());

			pstmt.setString(1, trkng_item_nbr);
			pstmt.setString(2, trkng_item_uniq_nbr);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults && rs.next()) {
				// shipment found
				fetchAllShipmentColumns(shipmentVO);

				while (rs.next()) { // should only be one row
					logger.error("Multiple Shipments found for:" + trkng_item_nbr + ":" + trkng_item_uniq_nbr);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return shipmentVO;
	}

	private static final String selectShipmentForUpdateSQL = SQLShipmentAllColumnsNotDistinct
			+ "from SHIPMENT s where " + "TRKNG_ITEM_NBR = ? AND " + "TRKNG_ITEM_UNIQ_NBR = ? for update wait 10 ";

	public ShipmentVO getShipmentForUpdate(String trkng_item_nbr, String trkng_item_uniq_nbr) throws SQLException {
		ShipmentVO shipmentVO = new ShipmentVO();

		try {
			setSqlSignature(selectShipmentForUpdateSQL, false, logger.isDebugEnabled());

			pstmt.setString(1, trkng_item_nbr);
			pstmt.setString(2, trkng_item_uniq_nbr);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults && rs.next()) {
				// shipment found
				fetchAllShipmentColumns(shipmentVO);

				while (rs.next()) { // should only be one row
					logger.error("Multiple Shipments found for:" + trkng_item_nbr + ":" + trkng_item_uniq_nbr);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			// Resource Busy
			if (sqle.getMessage().indexOf("ORA-30006") != -1) {
				logger.info("Resource is Busy");
				throw new ResourceBusyException(sqle);
			}
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return shipmentVO;
	}

	// Could narrow this search a bit by using the delivery date of the CRN
	// The AWB should leave on or within a day or two of the delivery
	private final static String selectShipmentViaRtrnOrPaprTrkngNbrSQL = "select S.* from Shipment s, Associated_Shipment a where "
			+ "s.trkng_item_nbr = a.trkng_item_nbr and "
			+ "(assoc_track_type_code = 'W' or assoc_track_type_code = 'R') and " + "a.trkng_item_nbr = ?";

	public List getShipmentViaRtrnOrPaprTrkngNbr(String aRtrnTrkngNbr) throws SQLException {
		ArrayList al = new ArrayList();

		try {
			setSqlSignature(selectShipmentViaRtrnOrPaprTrkngNbrSQL, false, logger.isDebugEnabled());

			pstmt.setString(1, aRtrnTrkngNbr);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {
					// shipment found
					ShipmentVO shipmentVO = new ShipmentVO();
					fetchAllShipmentColumns(shipmentVO);
					al.add(shipmentVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	/*
	 * Monitor methods
	 */

	/** Paging SQL to get subset of results */
	private final static String PREpagedSQL = "select * from " + " (select row_.*, rownum rownum_ from ( ";

	private final static String POSTpagedSQL = "   ) row_ " + " where rownum <= ? " + " ) " + "where rownum_ > ?";

	private final static String orderByTrkngItemNbrSQL = " order by TRKNG_ITEM_NBR ";
	private final static String orderByShipDtFastSQL = " order by INPUT_TMSTP ";
	// private final static String orderByShipDtSQL = " order by SHIP_DT ";
	private final static String orderByCommitDtSQL = " order by COMMIT_DT ";
	private final static String orderByDestSQL = " order by DEST_LOC_CD ";
	private final static String orderByLastStatusSQL = " order by LAST_STAT_DESC ";
	private final static String orderByRecipSQL = " order by RECP_CO_NM ";

	/** Get all MAWBs */
	private final static String selectMAWBShipmentSQL = "from SHIPMENT where " + "GROUP_NBR = ? AND "
			+ "ACCT_NBR = ? AND " + "LANE_NBR = ? AND " + "SVC_TYPE_CD = ? AND " + "SHPMT_TYPE_CD = 'MAWB' AND "
			+ "SHIP_DT > (SYSDATE - ? ) ";

	/** Get all MAWBs, order by tracking item nbr ascending, and paged SQL */
	private final static String selectMAWBShipmentOrderByTrkngNbrPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsNotDistinct + selectMAWBShipmentSQL + orderByTrkngItemNbrSQL + POSTpagedSQL;
	/** Get all MAWBs, order by tracking item nbr descending, and paged SQL */
	private final static String selectMAWBShipmentOrderByTrkngNbrDescPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsNotDistinct + selectMAWBShipmentSQL + orderByTrkngItemNbrSQL + " DESC "
			+ POSTpagedSQL;
	/** Get all MAWBs, order by ship date ascending, and paged SQL */
	private final static String selectMAWBShipmentOrderByShipDtPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsNotDistinct + selectMAWBShipmentSQL + orderByShipDtFastSQL + POSTpagedSQL;
	/** Get all MAWBs, order by ship date descending, and paged SQL */
	private final static String selectMAWBShipmentOrderByShipDtDescPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsNotDistinct + selectMAWBShipmentSQL + orderByShipDtFastSQL + " DESC " + POSTpagedSQL;

	/** count all MAWBs SQL */
	private final static String countMAWBShipmentSQL = "select count(*) count " + selectMAWBShipmentSQL;
	// start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
	private final static String countCRNAllShipmentSQL = "select count(*) count FROM (select distinct s.TRKNG_ITEM_NBR, s.TRKNG_ITEM_UNIQ_NBR from"
			+ " ASSOCIATED_SHIPMENT a, SHIPMENT s where a.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR and a.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR and "
			+ "s.shpmt_TYPE_CD='CRN' and a.ASSOC_TRACK_TYPE_CODE = 'P' and  s.GROUP_NBR = ? and s.ACCT_NBR = ? and s.LANE_NBR = ? and s.SVC_TYPE_CD = ? "
			+ "and s.ship_dt > (SYSDATE - ?) and a.assoc_trkng_item_nbr not in (select distinct ss.trkng_item_nbr from shipment ss))";

	// end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
	/**
	 * Get a list of MAWBs. Allows "paging" the results by selecting the first
	 * and last index to retrieve.
	 * 
	 * @param aGroupNbr
	 * @param anAcctNbr
	 * @param aLaneNbr
	 * @param aServiceType
	 * @param aStartIndex
	 * @param anEndIndex
	 * @return List of ShipmentVOs
	 * @throws SQLException
	 */
	public List getMAWBShipments(int aGroupNbr, String anAcctNbr, int aLaneNbr, String aServiceType, int aStartIndex,
			int anEndIndex, String sortColumn, boolean isSortAscending, int shipDateOffsetInt) throws SQLException {

		ArrayList al = new ArrayList();

		try {
			if ("trkng_item_nbr".equals(sortColumn)) {
				if (isSortAscending)
					setSqlSignature(selectMAWBShipmentOrderByTrkngNbrPagedSQL, false, logger.isDebugEnabled());
				else
					setSqlSignature(selectMAWBShipmentOrderByTrkngNbrDescPagedSQL, false, logger.isDebugEnabled());
			} else if ("ship_dt".equals(sortColumn)) {
				if (isSortAscending)
					setSqlSignature(selectMAWBShipmentOrderByShipDtPagedSQL, false, logger.isDebugEnabled());
				else
					setSqlSignature(selectMAWBShipmentOrderByShipDtDescPagedSQL, false, logger.isDebugEnabled());
			} else {
				setSqlSignature(selectMAWBShipmentOrderByShipDtDescPagedSQL, false, logger.isDebugEnabled());
			}

			pstmt.setInt(1, aGroupNbr);
			pstmt.setString(2, anAcctNbr);
			pstmt.setInt(3, aLaneNbr);
			pstmt.setString(4, aServiceType);
			pstmt.setInt(5, shipDateOffsetInt);
			pstmt.setInt(6, anEndIndex);
			pstmt.setInt(7, aStartIndex);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {

					// shipment found
					ShipmentVO shipmentVO = new ShipmentVO();
					fetchAllShipmentColumns(shipmentVO);
					al.add(shipmentVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	/**
	 * Count of MAWBs with issues or that have CRNS without issues.
	 * 
	 * @param aGroupNbr
	 * @param anAcctNbr
	 * @param aLaneNbr
	 * @param aServiceType
	 * @param aShipDateOffsetInt
	 * @return count number of rows/MAWBs
	 * @throws SQLException
	 */
	public int getMAWBShipmentsCount(int aGroupNbr, String anAcctNbr, int aLaneNbr, String aServiceType,
			int aShipDateOffsetInt) throws SQLException {

		int count = 0;

		try {
			setSqlSignature(countMAWBShipmentSQL, false, logger.isDebugEnabled());

			pstmt.setInt(1, aGroupNbr);
			pstmt.setString(2, anAcctNbr);
			pstmt.setInt(3, aLaneNbr);
			pstmt.setString(4, aServiceType);
			pstmt.setInt(5, aShipDateOffsetInt); // days back, if change value,
													// make sure the SQL matches

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				if (rs.next()) {
					count = rs.getInt("COUNT");
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return count;
	}

	// WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
	public int getAllCrnsCount(int aGroupNbr, String anAcctNbr, int laneNbr, String serviceTypeCd, int shipDateOffsetInt)
			throws SQLException {

		int count = 0;

		try {
			setSqlSignature(countCRNAllShipmentSQL, false, logger.isDebugEnabled());

			pstmt.setInt(1, aGroupNbr);
			pstmt.setString(2, anAcctNbr);
			pstmt.setInt(3, laneNbr);
			pstmt.setString(4, serviceTypeCd);
			pstmt.setInt(5, shipDateOffsetInt); // days back, if change value,
												// make sure the SQL matches
			// pstmt.setInt( 5, 183);
			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				if (rs.next()) {
					count = rs.getInt("COUNT");
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return count;
	}

	// Get all MAWBs that have issues or MAWBs that have CRNs with open issues
	private final static String selectMAWBShipmentWithIssuesSQL = "from ASSOCIATED_SHIPMENT a, ISSUE i, SHIPMENT s "
			+ "where " + "a.ASSOC_TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR "
			+ "and a.ASSOC_TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR " + "and s.shpmt_TYPE_CD='MAWB' "
			+ "and s.INPUT_TMSTP > (SYSDATE - ?) " + "and a.TRKNG_ITEM_NBR= i.TRKNG_ITEM_NBR "
			+ "and a.TRKNG_ITEM_UNIQ_NBR = i.TRKNG_ITEM_UNIQ_NBR " + "and a.ASSOC_TRACK_TYPE_CODE = 'P' "
			+ "and i.ACCT_NBR = ? " + "and i.LANE_NBR = ? " + "and i.SVC_TYPE_CD = ? " + "and i.GROUP_NBR = ? "
			+ "and i.RES_DT is null and i.ISSUE_TMSTP <= SYSDATE " + "and i.INPUT_TMSTP > (SYSDATE - ?) "
			+ "and a.INPUT_TMSTP > (SYSDATE - ?) ";

	/**
	 * Get all MAWBs that have issues or MAWBs that have CRNs with open issues,
	 * order by tracking item nbr ascending, and paged SQL
	 */
	private final static String selectMAWBShipmentWithIssuesOrderByTrkngNbrPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsDistinct + selectMAWBShipmentWithIssuesSQL + orderByTrkngItemNbrSQL + POSTpagedSQL;
	/**
	 * Get all MAWBs that have issues or MAWBs that have CRNs with open issues,
	 * order by tracking item nbr descending, and paged SQL
	 */
	private final static String selectMAWBShipmentWithIssuesOrderByTrkngNbrDescPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsDistinct + selectMAWBShipmentWithIssuesSQL + orderByTrkngItemNbrSQL + " DESC "
			+ POSTpagedSQL;
	/**
	 * Get all MAWBs that have issues or MAWBs that have CRNs with open issues,
	 * order by ship date ascending, and paged SQL
	 */
	private final static String selectMAWBShipmentWithIssuesOrderByShipDtPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsDistinct + selectMAWBShipmentWithIssuesSQL + orderByShipDtFastSQL + POSTpagedSQL;
	/**
	 * Get all MAWBs that have issues or MAWBs that have CRNs with open issues,
	 * order by ship date descending, and paged SQL
	 */
	private final static String selectMAWBShipmentWithIssuesOrderByShipDtDescPagedSQL = PREpagedSQL
			+ SQLShipmentAllColumnsDistinct + selectMAWBShipmentWithIssuesSQL + orderByShipDtFastSQL + " DESC "
			+ POSTpagedSQL;

	/**
	 * Count all MAWBs that have issues or MAWBs that have CRNs with open issues
	 * SQL
	 */
	private final static String countMAWBShipmentWithIssuesSQL = "select count(*) count FROM (select distinct s.TRKNG_ITEM_NBR, s.TRKNG_ITEM_UNIQ_NBR "
			+ selectMAWBShipmentWithIssuesSQL + ") ";

	/**
	 * Get a list of MAWB with issues or that have CRNS with issues. Allows
	 * "paging" the results by selecting the first and last index to retrieve.
	 * 
	 * @param aGroupNbr
	 * @param anAcctNbr
	 * @param aLaneNbr
	 * @param aServiceType
	 * @param aStartIndex
	 * @param anEndIndex
	 * @param sortColumn
	 * @param isSortAscending
	 * @param anEndIndex
	 * @return List of ShipmentVOs
	 * @throws SQLException
	 */
	public List getMAWBShipmentsWithIssues(int aGroupNbr, String anAcctNbr, int aLaneNbr, String aServiceType,
			int aStartIndex, int anEndIndex, String sortColumn, boolean isSortAscending, int shipDateOffsetInt)
			throws SQLException {

		ArrayList al = new ArrayList();

		try {
			if ("trkng_item_nbr".equals(sortColumn)) {
				if (isSortAscending)
					setSqlSignature(selectMAWBShipmentWithIssuesOrderByTrkngNbrPagedSQL, false, logger.isDebugEnabled());
				else
					setSqlSignature(selectMAWBShipmentWithIssuesOrderByTrkngNbrDescPagedSQL, false,
							logger.isDebugEnabled());
			} else if ("ship_dt".equals(sortColumn)) {
				if (isSortAscending)
					setSqlSignature(selectMAWBShipmentWithIssuesOrderByShipDtPagedSQL, false, logger.isDebugEnabled());
				else
					setSqlSignature(selectMAWBShipmentWithIssuesOrderByShipDtDescPagedSQL, false,
							logger.isDebugEnabled());
			} else {
				setSqlSignature(selectMAWBShipmentWithIssuesOrderByShipDtPagedSQL, false, logger.isDebugEnabled());
			}
			pstmt.setInt(1, shipDateOffsetInt); // days back, if change value,
												// make sure the Count SQL
												// matches
			pstmt.setString(2, anAcctNbr);
			pstmt.setInt(3, aLaneNbr);
			pstmt.setString(4, aServiceType);
			pstmt.setInt(5, aGroupNbr);
			pstmt.setInt(6, shipDateOffsetInt); // days back, if change value,
												// make sure the Count SQL
												// matches
			pstmt.setInt(7, shipDateOffsetInt); // days back, if change value,
												// make sure the Count SQL
												// matches
			pstmt.setInt(8, anEndIndex);
			pstmt.setInt(9, aStartIndex);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {

					// shipment found
					ShipmentVO shipmentVO = new ShipmentVO();
					fetchAllShipmentColumns(shipmentVO);
					al.add(shipmentVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	/**
	 * Count a list of MAWB with issues or that have CRNS with issues.
	 * 
	 * @param aGroupNbr
	 * @param anAcctNbr
	 * @param aLaneNbr
	 * @param aServiceType
	 * @param shipDateOffsetInt
	 * @return count number of rows/MAWBs
	 * @throws SQLException
	 */
	public int getMAWBShipmentsWithIssuesCount(int aGroupNbr, String anAcctNbr, int aLaneNbr, String aServiceType,
			int shipDateOffsetInt) throws SQLException {

		int count = 0;

		try {
			setSqlSignature(countMAWBShipmentWithIssuesSQL, false, logger.isDebugEnabled());

			pstmt.setInt(1, shipDateOffsetInt); // days back, if change value,
												// make sure the Count SQL
												// matches
			pstmt.setString(2, anAcctNbr);
			pstmt.setInt(3, aLaneNbr);
			pstmt.setString(4, aServiceType);
			pstmt.setInt(5, aGroupNbr);
			pstmt.setInt(6, shipDateOffsetInt); // days back, if change value,
												// make sure the Count SQL
												// matches
			pstmt.setInt(7, shipDateOffsetInt); // days back, if change value,
												// make sure the Count SQL
												// matches

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				if (rs.next()) {
					count = rs.getInt("COUNT");
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return count;
	}

	// Could narrow this search a bit by using the delivery date of the CRN
	// The AWB should leave on or within a day or two of the delivery
	private static String selectShipmentViaRtrnTrkngNbrsSQL = SQLShipmentAllColumnsNotDistinct + "from SHIPMENT where "
			+ "RTRN_TRKNG_ITEM_NBR = ? and" + " RTRN_TRKNG_ITEM_UNIQ_NBR = ?";

	public List getShipmentViaRtrnTrkngNbr(String aRtrnTrkngItemNbr, String aRtrnTrkngUniqItemNbr) throws SQLException {
		ArrayList al = new ArrayList();

		try {
			setSqlSignature(selectShipmentViaRtrnTrkngNbrsSQL, false, logger.isDebugEnabled());

			pstmt.setString(1, aRtrnTrkngItemNbr);
			pstmt.setString(2, aRtrnTrkngUniqItemNbr);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {
					// shipment found
					ShipmentVO shipmentVO = new ShipmentVO();
					fetchAllShipmentColumns(shipmentVO);
					al.add(shipmentVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	private final static String selectCRNShipmentSQL = "from SHIPMENT s " + "where "
			+ "(TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) IN "
			+ "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR from ASSOCIATED_SHIPMENT "
			+ " where ASSOC_TRKNG_ITEM_NBR  = ? "
			+ "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null))";

	private final static String selectCRNShipmentWithIssuesSQL = "from SHIPMENT s " + "where "
			+ "(TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) IN " + "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR "
			+ "from ISSUE "
			+ "where RES_DT is null "
			+ "and ISSUE_TMSTP <= SYSDATE "
			+ // issues is active
			"and (TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) IN " + "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR "
			+ "from ASSOCIATED_SHIPMENT " + "where ASSOC_TRKNG_ITEM_NBR  = ? "
			+ "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null)"
			+ "and ASSOC_TRACK_TYPE_CODE = 'P' ))";

	private final static String PREselectCRNShipmentByIssueSQL = "from SHIPMENT s " + "where "
			+ "(TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) IN " + "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR "
			+ "from ISSUE " + "where RES_DT is null " + "and ISSUE_TYPE_CD IN ( ? ";

	private final static String POSTselectCRNShipmentByIssueSQL = ") "
			+ "and ISSUE_TMSTP <= SYSDATE "
			+ // issues is active
			"and (TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) IN " + "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR "
			+ "from ASSOCIATED_SHIPMENT " + "where ASSOC_TRKNG_ITEM_NBR  = ? "
			+ "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null )"
			+ "and ASSOC_TRACK_TYPE_CODE = 'P' ))";

	// start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
	private final static String POSTselectALLCRNsSQL = " from SHIPMENT s,ASSOCIATED_SHIPMENT a where s.GROUP_NBR = ?  AND s.ACCT_NBR = ? AND s.LANE_NBR = ? AND s.SVC_TYPE_CD = ? AND s.SHPMT_TYPE_CD = 'CRN' "
			+ " AND s.SHIP_DT > (SYSDATE - ? ) "
			+ " AND a.TRKNG_ITEM_NBR = s.TRKNG_ITEM_NBR and a.TRKNG_ITEM_UNIQ_NBR = s.TRKNG_ITEM_UNIQ_NBR and a.ASSOC_TRACK_TYPE_CODE = 'P' and a.assoc_trkng_item_nbr not in (select distinct ss.trkng_item_nbr from shipment ss) ";

	// end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes

	/**
	 * Get the list of CRNs for a MAWB Allows "paging" the results by selecting
	 * the first and last index to retrieve.
	 * 
	 * @param aParntTrkngItemNbr
	 *            MAWB tracking number
	 * @param aParntTrkngUniqItemNbr
	 *            MAWB tracking unique number
	 * @param aStartIndex
	 *            start rownum, for paging results
	 * @param anEndIndex
	 *            end rownum, for paging results
	 * @param sortColumn
	 *            column to sort on
	 * @param isSortAscending
	 *            true to filter by Ascending, false for descending
	 * @param filterByIssues
	 *            the Issue Type Cd(s) to filter on
	 * @param issuesOnly
	 *            true to get only CRNs with issue
	 * @param shipDt
	 *            of the MAWB
	 * @return List of ShipmentVOs
	 * @throws SQLException
	 */
	public List getCRNShipments(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr, int aStartIndex,
			int anEndIndex, String sortColumn, boolean isSortAscending, String[] filterByIssues, boolean issuesOnly,
			Date shipDt) throws SQLException {

		ArrayList al = new ArrayList();

		try {
			StringBuffer sql = new StringBuffer();

			// append starting SQL for paging results
			sql.append(PREpagedSQL).append(SQLShipmentAllColumnsNotDistinct);

			// append main SQL
			if (filterByIssues != null && filterByIssues.length > 0) {
				sql.append(PREselectCRNShipmentByIssueSQL);
				for (int i = 1; i < filterByIssues.length; i++) {
					sql.append(", ? ");
				}
				sql.append(POSTselectCRNShipmentByIssueSQL);
			} else if (issuesOnly)
				sql.append(selectCRNShipmentWithIssuesSQL);
			else
				sql.append(selectCRNShipmentSQL);

			// append correct "order by"
			if ("trkng_item_nbr".equals(sortColumn)) {
				sql.append(orderByTrkngItemNbrSQL);
			} else if ("recp_co_nm".equals(sortColumn)) {
				sql.append(orderByRecipSQL);
			} else if ("dest_loc_cd".equals(sortColumn)) {
				sql.append(orderByDestSQL);
			} else if ("status".equals(sortColumn)) {
				sql.append(orderByLastStatusSQL);
			} else if ("commit_dt".equals(sortColumn)) {
				sql.append(orderByCommitDtSQL);
			} else
				sql.append(orderByTrkngItemNbrSQL);

			// append descending sort, if necessary
			if (!isSortAscending)
				sql.append(" DESC ");

			sql.append(POSTpagedSQL);
			setSqlSignature(sql.toString(), false, logger.isDebugEnabled());
			int i = 0;
			if (filterByIssues != null && filterByIssues.length > 0) {
				while (i < filterByIssues.length)
					pstmt.setInt(i + 1, Integer.parseInt(filterByIssues[i++]));
			}

			pstmt.setString(++i, aParntTrkngItemNbr);
			pstmt.setString(++i, aParntTrkngUniqItemNbr);
			pstmt.setInt(++i, anEndIndex);
			pstmt.setInt(++i, aStartIndex);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {
					// shipment found
					ShipmentVO shipmentVO = new ShipmentVO();
					fetchAllShipmentColumns(shipmentVO);
					al.add(shipmentVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	public List getAllCrns(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd, int startIndex,
			int endIndex, String sortColumn, boolean isSortAscending, int shipDateOffsetInt, String[] filterByIssues)
			throws SQLException {

		ArrayList al = new ArrayList();

		try {
			StringBuffer sql = new StringBuffer();

			// append starting SQL for paging results
			sql.append(PREpagedSQL).append(SQLShipmentAllColumnsNotDistinctWithAlias);

			/*
			 * append main SQL if (filterByIssues != null &&
			 * filterByIssues.length > 0) {
			 * sql.append(PREselectCRNShipmentByIssueSQL); for (int i=1;
			 * i<filterByIssues.length; i++) { sql.append(", ? "); }
			 * sql.append(POSTselectCRNShipmentByIssueSQL); } else if
			 * (issuesOnly) sql.append(selectCRNShipmentWithIssuesSQL); else
			 * sql.append(selectCRNShipmentSQL);
			 */

			sql.append(POSTselectALLCRNsSQL);

			// append correct "order by"
			if ("trkng_item_nbr".equals(sortColumn)) {
				sql.append(orderByTrkngItemNbrSQL);
			} else if ("recp_co_nm".equals(sortColumn)) {
				sql.append(orderByRecipSQL);
			} else if ("dest_loc_cd".equals(sortColumn)) {
				sql.append(orderByDestSQL);
			} else if ("status".equals(sortColumn)) {
				sql.append(orderByLastStatusSQL);
			} else if ("commit_dt".equals(sortColumn)) {
				sql.append(orderByCommitDtSQL);
			} else
				sql.append(orderByTrkngItemNbrSQL);

			// append descending sort, if necessary
			if (!isSortAscending)
				sql.append(" DESC ");

			sql.append(POSTpagedSQL);

			setSqlSignature(sql.toString(), false, logger.isDebugEnabled());

			pstmt.setInt(1, shipperNbr);
			pstmt.setString(2, accountNbr);
			pstmt.setInt(3, laneNbr);
			pstmt.setString(4, serviceTypeCd);
			pstmt.setInt(5, shipDateOffsetInt);
			// pstmt.setInt(5, 183);
			pstmt.setInt(6, endIndex);
			pstmt.setInt(7, startIndex);

			/*
			 * setSqlSignature( sql.toString(), false, logger.isDebugEnabled()
			 * ); int i=0; if (filterByIssues != null && filterByIssues.length >
			 * 0) { while (i < filterByIssues.length) pstmt.setInt( i+1,
			 * Integer.parseInt(filterByIssues[i++])); }
			 * 
			 * pstmt.setString( ++i, aParntTrkngItemNbr); pstmt.setString( ++i,
			 * aParntTrkngUniqItemNbr); pstmt.setInt(++i, anEndIndex);
			 * pstmt.setInt(++i, aStartIndex);
			 */

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {
					// shipment found
					ShipmentVO shipmentVO = new ShipmentVO();
					fetchAllShipmentColumns(shipmentVO);
					al.add(shipmentVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	private final static String selectCRNIssuesSQL = "select distinct ISSUE_TYPE_CD "
			+ "from ISSUE "
			+ "where RES_DT is null "
			+ "and ISSUE_TMSTP <= SYSDATE "
			+ // issues is active
			"and (TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR) IN " + "(select TRKNG_ITEM_NBR, TRKNG_ITEM_UNIQ_NBR "
			+ "from ASSOCIATED_SHIPMENT " + "where ASSOC_TRKNG_ITEM_NBR  = ? "
			+ "and (ASSOC_TRKNG_ITEM_UNIQ_NBR = ? or ASSOC_TRKNG_ITEM_UNIQ_NBR is null)"
			+ "and ASSOC_TRACK_TYPE_CODE = 'P' )";

	/**
	 * Get the list of CRN Issues for a MAWB
	 * 
	 * @param aParntTrkngItemNbr
	 *            MAWB tracking number
	 * @param aParntTrkngUniqItemNbr
	 *            MAWB tracking unique number
	 * @return List of Issue Type Cds
	 * @throws SQLException
	 */
	public List getCRNIssues(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr) throws SQLException {

		ArrayList issues = new ArrayList();

		try {
			setSqlSignature(selectCRNIssuesSQL, false, logger.isDebugEnabled());

			pstmt.setString(1, aParntTrkngItemNbr);
			pstmt.setString(2, aParntTrkngUniqItemNbr);

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}

			execute();

			if (hasResults) {
				while (rs.next()) {
					String issueTypeCd = String.valueOf(rs.getInt("ISSUE_TYPE_CD"));
					issues.add(issueTypeCd);
				}
			} else {
				// shipment not found
				logger.info("No CRN Issues for MAWB: " + aParntTrkngItemNbr);
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return issues;
	}

	

	public List getfilterByIssueDetails(String[] filterByIssues, int shipDateOffsetInt) throws SQLException {
		ArrayList al = new ArrayList();

		try {
			StringBuffer sql = new StringBuffer();

			// sql.append(PREpagedSQL);Associated_Shipment
			sql.append(SQLShipmentAllColumnsForFilterBean);
			sql.append("from SHIPMENT s, ISSUE i, EMPLOYEE e, ASSOCIATED_SHIPMENT a , ACCT_LANE_SERVICE_MONITORING alsm , ACCOUNT_GROUP actg , ACCOUNT act  ");

			sql.append(selectShipmentWithIssuesForFilterSQLPre);

			if ((filterByIssues != null) && (filterByIssues.length > 0)) {
				sql.append(selectShipmentWithIssuesSQLFiltered);
				for (int i = 0; i < filterByIssues.length; i++) {
					sql.append("?,");
				}
				sql.deleteCharAt(sql.length() - 1);
				sql.append(')');
			}

			setSqlSignature(sql.toString(), false, logger.isDebugEnabled());

			pstmt.setInt(1, shipDateOffsetInt);

			int index = 2;
			if ((filterByIssues != null) && (filterByIssues.length > 0)) {
				for (int i = 0; i < filterByIssues.length; i++) {
					pstmt.setInt(index++, Integer.parseInt(filterByIssues[i]));
				}
			}

			if (logger.isDebugEnabled()) {
				logger.debug(pstmt.toString());
			}
			
			if (logger.isDebugEnabled()) {
				logger.debug("BEFORE EXECUTING QUERY");
			}

			execute();

			if (hasResults) {
				while (rs.next()) {

					// shipment found
					FilterByIssueVO filterissueVO = new FilterByIssueVO();
				
					fetchAllShipmentColumnsForFilters(filterissueVO);
					al.add(filterissueVO);
				}
			} else {
				// shipment not found
				logger.info("Shipment not found");
				return null;
			}
		} catch (SQLException sqle) {
			logger.error("DB_SQL_ERROR: " + sqle.getMessage() + "; SQLState: " + sqle.getSQLState() + "; ErrorCode: "
					+ sqle.getErrorCode());
			throw sqle;
		} finally {
			try {
				cleanResultSet();
			} catch (SQLException sqle2) {
				logger.warn(sqle2.getMessage(), sqle2);
			}
		}
		return al;
	}

	// //////////////////////////////

	/**
	 * Fetch all columns from the result set and populate the ShipmenVO
	 * 
	 * @param shipmentVO
	 * @throws SQLException
	 */
	private void fetchAllShipmentColumns(ShipmentVO shipmentVO) throws SQLException {
		shipmentVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
		shipmentVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
		shipmentVO.set_grp_nbr(rs.getInt("GROUP_NBR"));
		shipmentVO.set_acct_nbr(rs.getString("ACCT_NBR"));
		shipmentVO.set_lane_nbr(rs.getInt("LANE_NBR"));
		shipmentVO.set_svc_type_cd(rs.getString("SVC_TYPE_CD"));
		shipmentVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
		shipmentVO.set_trkng_item_form_cd(rs.getInt("TRKNG_ITEM_FORM_CD"));
		shipmentVO.set_pack_type_cd(rs.getInt("PACK_TYPE_CD"));
		shipmentVO.set_orig_loc_cd(rs.getString("ORIG_LOC_CD"));
		shipmentVO.set_dest_loc_cd(rs.getString("DEST_LOC_CD"));
		shipmentVO.set_shpmt_wgt(rs.getInt("SHPMT_WGT"));
		shipmentVO.set_shpmt_uom_cd(rs.getString("SHPMT_UOM_CD").charAt(0));

		Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
		shipmentVO.set_ship_dt(shipDt);

		shipmentVO.set_shpr_co_nm(rs.getString("SHPR_CO_NM"));
		shipmentVO.set_shpr_ph_nbr(rs.getString("SHPR_PH_NBR"));
		shipmentVO.set_shpr_addr_line_one_desc(rs.getString("SHPR_ADDR_LINE_ONE_DESC"));
		shipmentVO.set_shpr_addr_line_two_desc(rs.getString("SHPR_ADDR_LINE_TWO_DESC"));
		shipmentVO.set_shpr_addr_line_three_desc(rs.getString("SHPR_ADDR_LINE_THREE_DESC"));
		shipmentVO.set_shpr_city_nm(rs.getString("SHPR_CITY_NM"));
		shipmentVO.set_shpr_pstl_cd(rs.getString("SHPR_PSTL_CD"));
		shipmentVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
		shipmentVO.set_shpr_st_prov_cd(rs.getString("SHPR_ST_PROV_CD"));
		shipmentVO.set_recp_co_nm(rs.getString("RECP_CO_NM"));
		shipmentVO.set_recp_ph_nbr(rs.getString("RECP_PH_NBR"));
		shipmentVO.set_recp_addr_line_one_desc(rs.getString("RECP_ADDR_LINE_ONE_DESC"));
		shipmentVO.set_recp_addr_line_two_desc(rs.getString("RECP_ADDR_LINE_TWO_DESC"));
		shipmentVO.set_recp_addr_line_three_desc(rs.getString("RECP_ADDR_LINE_THREE_DESC"));
		shipmentVO.set_recp_city_nm(rs.getString("RECP_CITY_NM"));
		shipmentVO.set_recp_st_prov_cd(rs.getString("RECP_ST_PROV_CD"));
		shipmentVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
		shipmentVO.set_recp_pstl_cd(rs.getString("RECP_PSTL_CD"));
		shipmentVO.set_actl_del_nm(rs.getString("ACTL_DEL_NM"));
		shipmentVO.set_actl_addr_line_one_desc(rs.getString("ACTL_ADDR_LINE_ONE_DESC"));

		Date delDtTmstp = (java.util.Date) rs.getTimestamp("DEL_DT");
		if (delDtTmstp != null) {
			String deldtTmstpTzOffset = rs.getString("DEL_DATE_TMZN_OFFST_NBR");
			TimeZone delDtTz = TimeZone.getTimeZone("GMT" + deldtTmstpTzOffset);
			Calendar delDtCalendar = Calendar.getInstance(delDtTz);
			delDtCalendar.setTime(delDtTmstp);
			shipmentVO.set_del_dt(delDtCalendar);
		}

		shipmentVO.set_spcl_hndlg_grp(rs.getString("SPCL_HNDLG_GRP"));
		shipmentVO.set_crtg_agent_co_nm(rs.getString("CRTG_AGENT_CO_NM"));
		shipmentVO.set_cstms_curr_cd(rs.getString("CSTMS_CURR_CD"));
		shipmentVO.set_cstms_value_amt(rs.getInt("CSTMS_VALUE_AMT"));
		shipmentVO.set_dimnl_wgt(rs.getInt("DIMNL_WGT"));
		shipmentVO.set_inv_amt(rs.getInt("INV_AMT"));
		shipmentVO.set_shpmt_pkg_qt(rs.getInt("SHPMT_PKG_QTY"));

		Date lastEventTmstp = (java.util.Date) rs.getTimestamp("LAST_EVENT_TMSTP");
		if (lastEventTmstp != null) {
			String lastEventTmstpTzOffset = rs.getString("LAST_EVENT_TMZN_OFFST_NBR");
			TimeZone lastEventTz = TimeZone.getTimeZone("GMT" + lastEventTmstpTzOffset);
			Calendar lastEventCalendar = Calendar.getInstance(lastEventTz);
			lastEventCalendar.setTime(lastEventTmstp);
			shipmentVO.set_last_event_tmstp(lastEventCalendar);
		}

		shipmentVO.set_last_event_track_type_cd(rs.getString("LAST_EVENT_TRACK_TYPE_CD"));

		TimeZone commitDtTz = null;
		Date commitDt = (java.util.Date) rs.getTimestamp("COMMIT_DT");
		if (commitDt != null) {
			String commitDtTzOffset = rs.getString("COMMIT_DATE_TMZN_OFFST_NBR");
			commitDtTz = TimeZone.getTimeZone("GMT" + commitDtTzOffset);
			Calendar commitCalendar = Calendar.getInstance(commitDtTz);
			commitCalendar.setTime(commitDt);
			shipmentVO.set_commit_dt(commitCalendar);
		}

		Date adjCommitDt = null;
		adjCommitDt = (java.util.Date) rs.getTimestamp("ADJ_COMMIT_DT");
		if (adjCommitDt != null && commitDtTz != null) {
			Calendar adjCommitCalendar = Calendar.getInstance(commitDtTz);
			adjCommitCalendar.setTime(adjCommitDt);
			shipmentVO.set_adj_commit_dt(adjCommitCalendar);
		}

		shipmentVO.set_adj_commit_dt_offst_nbr(rs.getInt("ADJ_COMMIT_DT_OFFST_NBR"));

		shipmentVO.set_perf_rsult_cd(rs.getString("PERF_RSULT_CD"));

		shipmentVO.set_delivery_qty(rs.getInt("DEL_QTY"));
		String skidIntactFlg = rs.getString("SKID_INTACT_FLG");
		if (skidIntactFlg != null) {
			shipmentVO.set_skid_intact_flag(skidIntactFlg.charAt(0));
		}

		String qtyObserFlg = rs.getString("QTY_OBSER_FLG");
		if (qtyObserFlg != null) {
			shipmentVO.set_quantity_observed_flag(qtyObserFlg.charAt(0));
		}

		shipmentVO.set_package_piece_qty(rs.getInt("PKG_PIECE_QTY"));

		shipmentVO.set_last_stat_desc(rs.getString("LAST_STAT_DESC"));
		shipmentVO.set_last_event_track_loc_cd(rs.getString("LAST_EVENT_TRACK_LOC_CD"));

		shipmentVO.set_last_stat_track_loc_cd(rs.getString("LAST_STAT_TRACK_LOC_CD"));
		Date lastStatTmstp = (java.util.Date) rs.getTimestamp("LAST_STAT_TMSTP");
		if (lastStatTmstp != null) {
			shipmentVO.set_last_stat_tmstp(lastStatTmstp);
		}

		Date clearedCstmsTmstp = (java.util.Date) rs.getTimestamp("CLEARED_CSTMS_TMSTP");
		if (clearedCstmsTmstp != null) {
			String clearedCstmsTmstpTzOffset = rs.getString("CLEARED_CSTMS_TMZN_OFFSET_NBR");
			TimeZone clearedCstmsTz = TimeZone.getTimeZone("GMT" + clearedCstmsTmstpTzOffset);
			Calendar clearedCstmsCal = Calendar.getInstance(clearedCstmsTz);
			clearedCstmsCal.setTime(clearedCstmsTmstp);
			shipmentVO.set_cleared_cstms_tmstp(clearedCstmsCal);
		}

		shipmentVO.set_wrk_stat_cd(rs.getString("WRK_STAT_CD"));

	}

	private void fetchAllShipmentColumnsForFilters(FilterByIssueVO filterissueVO) throws SQLException {
		filterissueVO.set_assoc_trkng_item_nbr(rs.getString("ASSOC_TRKNG_ITEM_NBR"));
		filterissueVO.set_trkng_item_nbr(rs.getString("TRKNG_ITEM_NBR"));
		filterissueVO.set_trkng_item_uniq_nbr(rs.getString("TRKNG_ITEM_UNIQ_NBR"));
		filterissueVO.set_group_nm(rs.getString("GROUP_NM"));
		filterissueVO.set_acct_nm(rs.getString("ACCT_NM"));
		filterissueVO.set_shpr_cntry_cd(rs.getString("SHPR_CNTRY_CD"));
		filterissueVO.set_recp_cntry_cd(rs.getString("RECP_CNTRY_CD"));
		filterissueVO.set_SVC_TYPE_CD(rs.getString("SVC_TYPE_CD"));
		filterissueVO.set_acct_nbr(rs.getString("ACCT_NBR"));
		filterissueVO.set_shpmt_type_cd(rs.getString("SHPMT_TYPE_CD"));
		filterissueVO.set_orig_loc_cd(rs.getString("ORIG_LOC_CD"));
		filterissueVO.set_dest_loc_cd(rs.getString("DEST_LOC_CD"));

		Date shipDt = (java.util.Date) rs.getTimestamp("SHIP_DT");
		filterissueVO.set_ship_dt(shipDt);

		TimeZone commitDtTz = null;
		Date commitDt = (java.util.Date) rs.getTimestamp("COMMIT_DT");
		if (commitDt != null) {
			String commitDtTzOffset = rs.getString("COMMIT_DATE_TMZN_OFFST_NBR");
			commitDtTz = TimeZone.getTimeZone("GMT" + commitDtTzOffset);
			Calendar commitCalendar = Calendar.getInstance(commitDtTz);
			commitCalendar.setTime(commitDt);
			filterissueVO.set_commit_dt(commitCalendar);
		}
		
		
		filterissueVO.set_last_event_track_loc_cd(rs.getString("LAST_EVENT_TRACK_LOC_CD"));
		filterissueVO.set_last_stat_track_loc_cd(rs.getString("LAST_STAT_TRACK_LOC_CD"));

		filterissueVO.set_last_stat_desc(rs.getString("LAST_STAT_DESC"));

		Date lastStatTmstp = (java.util.Date) rs.getTimestamp("LAST_STAT_TMSTP");
		if (lastStatTmstp != null) {
			filterissueVO.set_last_stat_tmstp(lastStatTmstp);
		}

		filterissueVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
		filterissueVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
		filterissueVO.set_emp_nbr(rs.getString("EMP_NBR"));
	}

}
