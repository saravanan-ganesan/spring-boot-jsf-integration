package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ReferenceNoteVO;

public class ReferenceNotePersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(ReferenceNotePersister.class);
    
    public ReferenceNotePersister(Connection con) {
        super(con);
    }
    
    private static final String insertReferenceNoteSQL =
        "Insert into Reference_Note(" +
        "TRKNG_ITEM_NBR, " +          // VARCHAR2(12) 
        "TRKNG_ITEM_UNIQ_NBR," +      // VARCHAR2(10)
        "REF_CRTN_TMSTP, " + 
        "REF_TYPE_CD, " +              // VARCHAR2(3)
        "REF_NOTE_DESC) "  +
         "values(?,?,SYSDATE,?,?)";
    
    public void persist(ReferenceNoteVO aReferenceNoteVO) throws SQLException {
        try {
            setSqlSignature( insertReferenceNoteSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aReferenceNoteVO.get_trkng_item_nbr());
            pstmt.setString( 2, aReferenceNoteVO.get_trkng_item_uniq_nbr());
            pstmt.setString( 3, aReferenceNoteVO.get_ref_type_cd());
            pstmt.setString( 4, aReferenceNoteVO.get_ref_note_desc());

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch (SQLException sqle) {
            // Duplicate
            if (sqle.getMessage().indexOf("ORA-00001") != -1) {
                logger.info("Duplicate Reference Note detected");
                return;
            }
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }    
}
