package com.fedex.rise.bo;

import java.sql.SQLException;
import java.util.List;

import com.fedex.rise.db.SearchDAO;

import java.util.Date;

public class SearchBO {

    public List searchByShprNm(String aShprNm) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByShprNm(aShprNm);
    }	    

    public List searchByAcctNbr(String aAcctNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByAcctNbr(aAcctNbr);
    }     
    
    public List searchByTrkngNbr(String aTrkngNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByTrkngNbr(aTrkngNbr);
    }
 //Start WR#:179441 Changes
    public List searchByAll() throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByAll();
    }
    
    public List searchByGroupLaneNbr(int groupNbr,int laneNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByGroupLaneNbr(groupNbr,laneNbr);
    }
//End WR#:179441 Changes    
    public List searchByReferenceNbr(String aReferenceNbr, String aReferenceNumberMenu, Date _limitOneWeekFromDate, Date _limitOneWeekToDate) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByReferenceNbr(aReferenceNbr, aReferenceNumberMenu, _limitOneWeekFromDate, _limitOneWeekToDate);
    }  
    
    public int getCRNShipmentsCountTrackingNumber(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountTrackingNumber(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber);
    }        
    
    public List searchByTrkngNbrMAWB(String aTrkngNbrMAWB, Date _limitOneWeekToDateByMAWBTrackingNumber, Date _limitOneWeekFromDateByMAWBTrackingNumber, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByTrkngNbrMAWB(aTrkngNbrMAWB, _limitOneWeekToDateByMAWBTrackingNumber, _limitOneWeekFromDateByMAWBTrackingNumber, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }       
    
    public int getCRNShipmentsCountShipperName(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountShipperName(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName);
    }    
    
    public List searchByAcctNmMAWB(String aAcctNmMAWB, Date _limitOneWeekToDateByMAWBShipperName, Date _limitOneWeekFromDateByMAWBShipperName, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByAcctNmMAWB(aAcctNmMAWB, _limitOneWeekToDateByMAWBShipperName, _limitOneWeekFromDateByMAWBShipperName, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }     
    
    public List searchByIssueCodeCRN(String aTrackingNbrCRN, String aIssueCodeCRN, String aAcctNbrCRN, Date _toDate4, Date _fromDate4) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByIssueCodeCRN(aTrackingNbrCRN, aIssueCodeCRN, aAcctNbrCRN, _toDate4, _fromDate4);
    }     
    
    public int getCRNShipmentsCountReturnTrackingNumber(String aReturnTrkngNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountReturnTrackingNumber(aReturnTrkngNbr);
    }    
   
    public List searchByReturnTrkngNbr(String aReturnTrkngNbr, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByReturnTrkngNbr(aReturnTrkngNbr, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }    
    
    public int getCRNShipmentsCountRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, _limitOneWeekFromDateByCRNRecipientName);
    }    
    
    public List searchByRecipientName(String aRecipientName, Date _limitOneWeekToDateByCRNRecipientName, Date _limitOneWeekFromDateByCRNRecipientName, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByRecipientName(aRecipientName, _limitOneWeekToDateByCRNRecipientName, _limitOneWeekFromDateByCRNRecipientName, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }      
    
    public List searchByShipDate(Date _shipDate, String aServiceCode2, String aAcctNbrMAWB2, String aSelectedLane2) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByShipDate(_shipDate, aServiceCode2, aAcctNbrMAWB2, aSelectedLane2);
    }    

  //WR#:179441 Changes
    public List searchByShipDateRange(Date _limitOneWeekToDate3, Date _limitOneWeekFromDate3, String aServiceCode, String aAcctNbrMAWB3, String aSelectedLane, String sortColumn,boolean ascending) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByShipDateRange(_limitOneWeekToDate3, _limitOneWeekFromDate3, aServiceCode, aAcctNbrMAWB3, aSelectedLane,sortColumn,ascending);
    }     
    
    public int getCRNShipmentsCountRecipientPostalCode(String aPostalCode, Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountRecipientPostalCode(aPostalCode, _limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode);
    }        
    
    public List searchByPostalCode(Date _limitOneWeekToDateByCRNRecipientPostalCode, Date _limitOneWeekFromDateByCRNRecipientPostalCode, String aPostalCode, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByPostalCode(_limitOneWeekToDateByCRNRecipientPostalCode, _limitOneWeekFromDateByCRNRecipientPostalCode, aPostalCode, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }   

    public int getMAWBShipmentsCount(Date _shipDate, String _selectMenu, 
    		String aClearancePoint) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getMAWBShipmentsCount(_shipDate, _selectMenu, aClearancePoint);
    }
    
    public List rampHubSearch(Date _shipDate, String _selectMenu, String aClearancePoint,
    		String sortColumn, boolean isSortAscending, int startIndex, 
    		int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.rampHubSearch(_shipDate, _selectMenu, aClearancePoint,
    			sortColumn, isSortAscending, startIndex, endIndex);
    }    
    
    public List searchByFindMonitorAcctNbr(String aAcctNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByFindMonitorAcctNbr(aAcctNbr);
    }
    
    public List searchByFindMonitorTrkngNbr(String aTrackingNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByFindMonitorTrkngNbr(aTrackingNbr);
    }
    
    public int getCRNShipmentsCountWithODA(String aPostalCode, Date _limitOneWeekToDateByCRNWithODA, Date _limitOneWeekFromDateByCRNWithODA) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountWithODA(aPostalCode, _limitOneWeekToDateByCRNWithODA, _limitOneWeekFromDateByCRNWithODA);
    }       
    
    public List searchByWithODACRN(String aAcctNbr, Date _limitOneWeekFromDateByCRNWithODA, Date _limitOneWeekToDateByCRNWithODA, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByWithODACRN(aAcctNbr, _limitOneWeekFromDateByCRNWithODA, _limitOneWeekToDateByCRNWithODA, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }   
    
    public List searchByWithoutPODCRN(String aAcctNbr2, String aTrackingNbrMAWB2) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByWithoutPODCRN(aAcctNbr2, aTrackingNbrMAWB2);
    }
    
    public List searchByFindMissingData(String aAcctNbr) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByFindMissingData(aAcctNbr);
    } 
    
    public int getCRNShipmentsCountRecipientAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNWithODA, Date _limitOneWeekFromDateByCRNWithODA) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.getCRNShipmentsCountRecipientAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNWithODA, _limitOneWeekFromDateByCRNWithODA);
    }      
    
    public List searchByAddress(String aAddressLineOne, String aAddressCityName, String aAddressStateProvince, String aAddressPostalCode, Date _limitOneWeekToDateByCRNRecipientAddress, Date _limitOneWeekFromDateByCRNRecipientAddress, String sortColumn, boolean isSortAscending, 
    		int startIndex, int endIndex) throws SQLException {
    	SearchDAO searchDAO = new SearchDAO();
    	return searchDAO.searchByAddress(aAddressLineOne, aAddressCityName, aAddressStateProvince, aAddressPostalCode, _limitOneWeekToDateByCRNRecipientAddress, _limitOneWeekFromDateByCRNRecipientAddress, sortColumn, isSortAscending, 
        		startIndex, endIndex);
    }    
    
}
