package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.ShipmentVO;

public class ShipmentPersister extends OracleBase {
    private static Logger logger = LogManager.getLogger(ShipmentPersister.class);
    
    public ShipmentPersister(Connection con) {
        super(con);
    }
 
    private static final String insertShipmentSQL =
        "Insert into Shipment(" +
        "TRKNG_ITEM_NBR, " +
        "TRKNG_ITEM_UNIQ_NBR, " +
        "GROUP_NBR, " +
        "ACCT_NBR, " +
        "LANE_NBR, " +
        "SVC_TYPE_CD, " +
        "SHPMT_TYPE_CD, " +
        "TRKNG_ITEM_FORM_CD, " +
        "PACK_TYPE_CD, " +
        "ORIG_LOC_CD, " +
        "DEST_LOC_CD, " +
        "SHPMT_WGT, " +
        "SHPMT_UOM_CD, " +
        "SHPR_CO_NM, " +
        "SHPR_PH_NBR, " +
        "SHPR_ADDR_LINE_ONE_DESC, " +
        "SHPR_ADDR_LINE_TWO_DESC, " +
        "SHPR_ADDR_LINE_THREE_DESC, " +
        "SHPR_CITY_NM, " +
        "SHPR_PSTL_CD, " +
        "SHPR_CNTRY_CD, " +
        "SHPR_ST_PROV_CD, " +
        "RECP_CO_NM, " +
        "RECP_PH_NBR, " +
        "RECP_ADDR_LINE_ONE_DESC, " +
        "RECP_ADDR_LINE_TWO_DESC, " +
        "RECP_ADDR_LINE_THREE_DESC, " +
        "RECP_CITY_NM, " +
        "RECP_ST_PROV_CD, " +
        "RECP_CNTRY_CD, " +
        "RECP_PSTL_CD, " +
        "ACTL_DEL_NM, " +
        "ACTL_ADDR_LINE_ONE_DESC, " +
        "DEL_DT, " +
        "DEL_DATE_TMZN_OFFST_NBR, " +
        "SPCL_HNDLG_GRP, " +
        "CRTG_AGENT_CO_NM, " +
        "CSTMS_CURR_CD, " +
        "CSTMS_VALUE_AMT, " +
        "DIMNL_WGT, " +
        "INV_AMT, " +
        "SHPMT_PKG_QTY, " +
        "LAST_EVENT_TMSTP, " +
        "LAST_EVENT_TMZN_OFFST_NBR, " +
        "LAST_EVENT_TRACK_TYPE_CD, " +
        "COMMIT_DT, " +
        "ADJ_COMMIT_DT, " +
        "COMMIT_DATE_TMZN_OFFST_NBR, " +
        "PERF_RSULT_CD, " +
        "DEL_QTY, " +
        "SKID_INTACT_FLG, " +
        "QTY_OBSER_FLG, " +
        "PKG_PIECE_QTY, " +
        "SHIP_DT, " +
        "ADJ_COMMIT_DT_OFFST_NBR, " +
        "LAST_STAT_DESC, " +
        "LAST_EVENT_TRACK_LOC_CD, " +
        "INPUT_TMSTP, " +
        "LAST_UPDT_TMSTP) " +
         "values(?,?,?,?,?,?,?,?," + // 8
                "?,?,?,?,?,?,?,?," + // 16
                "?,?,?,?,?,?,?,?," + // 24
                "?,?,?,?,?,?,?,?," + // 32
                "?,?,?,?,?,?,?,?," + // 40
                "?,?,?,?,?,?,?,?," + // 48
                "?,?,?,?,?,?,?,?," + // 56
                "?,SYSDATE,SYSDATE)";  // 59

    /**
     * Persist shipment information to the database, return true
     * if successful, false if constraint violation(duplicate)
     * @param aShipmentVO
     * @return
     * @throws SQLException
     */
    public boolean persist(ShipmentVO aShipmentVO) throws SQLException {
        try {
            setSqlSignature( insertShipmentSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, aShipmentVO.get_trkng_item_nbr());
            pstmt.setString( 2, aShipmentVO.get_trkng_item_uniq_nbr());
            pstmt.setInt(    3, aShipmentVO.get_grp_nbr());
            pstmt.setString( 4, aShipmentVO.get_acct_nbr());
            pstmt.setInt(    5, aShipmentVO.get_lane_nbr());
            pstmt.setString( 6, aShipmentVO.get_svc_type_cd());
            pstmt.setString( 7, aShipmentVO.get_shpmt_type_cd());
            pstmt.setInt(    8, aShipmentVO.get_trkng_item_form_cd());
            pstmt.setInt(    9, aShipmentVO.get_pack_type_cd());
            pstmt.setString(10, aShipmentVO.get_orig_loc_cd());
            pstmt.setString(11, aShipmentVO.get_dest_loc_cd());
            pstmt.setInt(   12, aShipmentVO.get_shpmt_wgt());
            pstmt.setString(13, String.valueOf(aShipmentVO.get_shpmt_uom_cd()));
            pstmt.setString(14, aShipmentVO.get_shpr_co_nm());
            pstmt.setString(15, aShipmentVO.get_shpr_ph_nbr());
            pstmt.setString(16, aShipmentVO.get_shpr_addr_line_one_desc());
            pstmt.setString(17, aShipmentVO.get_shpr_addr_line_two_desc());
            pstmt.setString(18, aShipmentVO.get_shpr_addr_line_three_desc());
            pstmt.setString(19, aShipmentVO.get_shpr_city_nm());
            pstmt.setString(20, aShipmentVO.get_shpr_pstl_cd());
            pstmt.setString(21, aShipmentVO.get_shpr_cntry_cd());
            pstmt.setString(22, aShipmentVO.get_shpr_st_prov_cd());
            pstmt.setString(23, aShipmentVO.get_recp_co_nm());
            pstmt.setString(24, aShipmentVO.get_recp_ph_nbr());
            pstmt.setString(25, aShipmentVO.get_recp_addr_line_one_desc());
            pstmt.setString(26, aShipmentVO.get_recp_addr_line_two_desc());
            pstmt.setString(27, aShipmentVO.get_recp_addr_line_three_desc());
            pstmt.setString(28, aShipmentVO.get_recp_city_nm());
            pstmt.setString(29, aShipmentVO.get_recp_st_prov_cd());
            pstmt.setString(30, aShipmentVO.get_recp_cntry_cd());
            pstmt.setString(31, aShipmentVO.get_recp_pstl_cd());
            pstmt.setString(32, aShipmentVO.get_actl_del_nm());
            pstmt.setString(33, aShipmentVO.get_actl_addr_line_one_desc());
            if (aShipmentVO.get_del_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentVO.get_del_dt().getTimeInMillis());
                pstmt.setTimestamp(  34, sqlDate);
                pstmt.setString(35, formatTZ(aShipmentVO.get_del_dt().getTimeZone().getID()));
            } else {
                pstmt.setNull(34, java.sql.Types.TIMESTAMP);
                pstmt.setNull(35, java.sql.Types.VARCHAR);
            }           
            pstmt.setString(36, aShipmentVO.get_spcl_hndlg_grp());
            pstmt.setString(37, aShipmentVO.get_crtg_agent_co_nm());
            pstmt.setString(38, aShipmentVO.get_cstms_curr_cd());
            pstmt.setInt(   39, aShipmentVO.get_cstms_value_amt());
            pstmt.setInt(   40, aShipmentVO.get_dimnl_wgt());
            pstmt.setInt(   41, aShipmentVO.get_inv_amt());
            pstmt.setInt(   42, aShipmentVO.get_shpmt_pkg_qt());

            if (aShipmentVO.get_last_event_tmstp() != null) {
                java.sql.Timestamp timeStamp = new java.sql.Timestamp(aShipmentVO.get_last_event_tmstp().getTimeInMillis());
                pstmt.setTimestamp(43, timeStamp);
                pstmt.setString(44, formatTZ(aShipmentVO.get_last_event_tmstp().getTimeZone().getID()));
            } else {
                pstmt.setNull(43, java.sql.Types.TIMESTAMP);
                pstmt.setNull(44, java.sql.Types.VARCHAR);
            }
            
            pstmt.setString(45, aShipmentVO.get_last_event_track_type_cd());
            
            if (aShipmentVO.get_commit_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentVO.get_commit_dt().getTimeInMillis());
                pstmt.setTimestamp(46, sqlDate);
            } else {
                pstmt.setNull(46, java.sql.Types.TIMESTAMP);
            }  

            if (aShipmentVO.get_adj_commit_dt() != null) {
                java.sql.Timestamp sqlDate = new java.sql.Timestamp(aShipmentVO.get_adj_commit_dt().getTimeInMillis());
                pstmt.setTimestamp(47, sqlDate);
            } else {
                pstmt.setNull(47 , java.sql.Types.TIMESTAMP);

            }            

            if (aShipmentVO.get_commit_dt() != null) {
                pstmt.setString(48, formatTZ(aShipmentVO.get_commit_dt().getTimeZone().getID()));
            } else {
                pstmt.setNull(48, java.sql.Types.VARCHAR);
            }

            pstmt.setString(49, aShipmentVO.get_perf_rsult_cd());
                     
            pstmt.setInt(50, aShipmentVO.get_delivery_qty());
            pstmt.setString(51, String.valueOf(aShipmentVO.get_skid_intact_flag()));
            pstmt.setString(52, String.valueOf(aShipmentVO.get_quantity_observed_flag()));
            pstmt.setInt(53, aShipmentVO.get_package_piece_qty());
            
            if (aShipmentVO.get_ship_dt() != null) {
            	java.sql.Date sqlDate = 
            		new java.sql.Date(aShipmentVO.get_ship_dt().getTime());
            	pstmt.setDate(54, sqlDate);
            } else {
            	pstmt.setNull(54, java.sql.Types.DATE);
            }
            pstmt.setInt(55, aShipmentVO.get_adj_commit_dt_offst_nbr());

            pstmt.setString(56, aShipmentVO.get_last_stat_desc());            
            pstmt.setString(57, aShipmentVO.get_last_event_track_loc_cd());
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

            return true;
        } catch (SQLException sqle) {
            // Duplicate
            if (sqle.getMessage().indexOf("ORA-00001") != -1) {
                logger.info("Duplicate shipment record insertion detected, probably a parallel event");
                throw new UniqueConstraintException(sqle);
            }
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }
    
}
