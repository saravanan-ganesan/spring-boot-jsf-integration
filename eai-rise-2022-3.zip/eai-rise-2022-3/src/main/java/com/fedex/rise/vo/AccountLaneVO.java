package com.fedex.rise.vo;

import java.io.Serializable;

public class AccountLaneVO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int _group_nbr;
    private String _acct_nbr;
    private int    _lane_nbr;
    private String _rtrn_acct_nbr;
    private String _rtrn_addr_line_one_desc;
    private String _rtrn_addr_line_two_desc;
    private String _rtrn_addr_line_three_desc;
    private String _rtrn_city_nm;
    private String _rtrn_st_prov_cd;
    private String _rtrn_cont_nm;
    private String _rtrn_cont_ph_nbr;
    private String _im_of_rec_nm;
    private String _im_of_rec_addr_line_one_desc;
    private String _im_of_rec_addr_line_two_desc;
    private String _im_of_rec_city_nm;
    private String _im_of_rec_st_prov_cd;
    private String _im_of_rec_pstl_cd;
    private String _im_of_rec_cont_nm;
    private String _im_of_rec_ph_nbr;
    private String _im_of_rec_fax_nbr;
    private String _im_of_rec_email_desc;
    private String _orig_acct_exec_nm;
    private String _orig_acct_exec_ph_nbr;
    private String _orig_acct_exec_fax_nbr;
    private String _orig_acct_exec_email_desc;
    private String _dest_acct_exec_nm;
    private String _dest_acct_exec_ph_nbr;
    private String _dest_acct_exec_fax_nbr;
    private String _dest_acct_exec_email_desc;
    private String _brkr_nm;
    private String _brkr_ph_nbr;
    private String _brkr_fax_nbr;
    private String _prim_engnr_nm;
    private String _prim_engnr_ph_nbr;
    private String _prim_engnr_fax_nbr;
    private String _prim_engnr_email_desc;
    private String _scndy_engnr_nm;
    private String _scndy_engnr_ph_nbr;
    private String _scndy_engnr_fax_nbr;
    private String _scndy_engnr_email_desc;
    
    public AccountLaneVO() {
        
    }
    
    public AccountLaneVO(int _group_nbr, String _acct_nbr, int _lane_nbr) {
        super();
        this._group_nbr = _group_nbr;
        this._acct_nbr = _acct_nbr;
        this._lane_nbr = _lane_nbr;
    }
    
    /**
     * @return the _acct_nbr
     */
    public String get_acct_nbr() {
        return _acct_nbr;
    }
    /**
     * @param _acct_nbr the _acct_nbr to set
     */
    public void set_acct_nbr(String _acct_nbr) {
        this._acct_nbr = _acct_nbr;
    }
    /**
     * @return the _brkr_fax_nbr
     */
    public String get_brkr_fax_nbr() {
        return _brkr_fax_nbr;
    }
    /**
     * @param _brkr_fax_nbr the _brkr_fax_nbr to set
     */
    public void set_brkr_fax_nbr(String _brkr_fax_nbr) {
        this._brkr_fax_nbr = _brkr_fax_nbr;
    }
    /**
     * @return the _brkr_nm
     */
    public String get_brkr_nm() {
        return _brkr_nm;
    }
    /**
     * @param _brkr_nm the _brkr_nm to set
     */
    public void set_brkr_nm(String _brkr_nm) {
        this._brkr_nm = _brkr_nm;
    }
    /**
     * @return the _brkr_ph_nbr
     */
    public String get_brkr_ph_nbr() {
        return _brkr_ph_nbr;
    }
    /**
     * @param _brkr_ph_nbr the _brkr_ph_nbr to set
     */
    public void set_brkr_ph_nbr(String _brkr_ph_nbr) {
        this._brkr_ph_nbr = _brkr_ph_nbr;
    }
    /**
     * @return the _dest_acct_exec_email_desc
     */
    public String get_dest_acct_exec_email_desc() {
        return _dest_acct_exec_email_desc;
    }
    /**
     * @param _dest_acct_exec_email_desc the _dest_acct_exec_email_desc to set
     */
    public void set_dest_acct_exec_email_desc(String _dest_acct_exec_email_desc) {
        this._dest_acct_exec_email_desc = _dest_acct_exec_email_desc;
    }
    /**
     * @return the _dest_acct_exec_fax_nbr
     */
    public String get_dest_acct_exec_fax_nbr() {
        return _dest_acct_exec_fax_nbr;
    }
    /**
     * @param _dest_acct_exec_fax_nbr the _dest_acct_exec_fax_nbr to set
     */
    public void set_dest_acct_exec_fax_nbr(String _dest_acct_exec_fax_nbr) {
        this._dest_acct_exec_fax_nbr = _dest_acct_exec_fax_nbr;
    }
    /**
     * @return the _dest_acct_exec_nm
     */
    public String get_dest_acct_exec_nm() {
        return _dest_acct_exec_nm;
    }
    /**
     * @param _dest_acct_exec_nm the _dest_acct_exec_nm to set
     */
    public void set_dest_acct_exec_nm(String _dest_acct_exec_nm) {
        this._dest_acct_exec_nm = _dest_acct_exec_nm;
    }
    /**
     * @return the _dest_acct_exec_ph_nbr
     */
    public String get_dest_acct_exec_ph_nbr() {
        return _dest_acct_exec_ph_nbr;
    }
    /**
     * @param _dest_acct_exec_ph_nbr the _dest_acct_exec_ph_nbr to set
     */
    public void set_dest_acct_exec_ph_nbr(String _dest_acct_exec_ph_nbr) {
        this._dest_acct_exec_ph_nbr = _dest_acct_exec_ph_nbr;
    }
    /**
     * @return the _group_nbr
     */
    public int get_group_nbr() {
        return _group_nbr;
    }

    /**
     * @param _group_nbr the _group_nbr to set
     */
    public void set_group_nbr(int _group_nbr) {
        this._group_nbr = _group_nbr;
    }

    /**
     * @return the _im_of_rec_addr_line_one_desc
     */
    public String get_im_of_rec_addr_line_one_desc() {
        return _im_of_rec_addr_line_one_desc;
    }
    /**
     * @param _im_of_rec_addr_line_one_desc the _im_of_rec_addr_line_one_desc to set
     */
    public void set_im_of_rec_addr_line_one_desc(
            String _im_of_rec_addr_line_one_desc) {
        this._im_of_rec_addr_line_one_desc = _im_of_rec_addr_line_one_desc;
    }
    /**
     * @return the _im_of_rec_addr_line_two_desc
     */
    public String get_im_of_rec_addr_line_two_desc() {
        return _im_of_rec_addr_line_two_desc;
    }
    /**
     * @param _im_of_rec_addr_line_two_desc the _im_of_rec_addr_line_two_desc to set
     */
    public void set_im_of_rec_addr_line_two_desc(
            String _im_of_rec_addr_line_two_desc) {
        this._im_of_rec_addr_line_two_desc = _im_of_rec_addr_line_two_desc;
    }
    /**
     * @return the _im_of_rec_city_nm
     */
    public String get_im_of_rec_city_nm() {
        return _im_of_rec_city_nm;
    }
    /**
     * @param _im_of_rec_city_nm the _im_of_rec_city_nm to set
     */
    public void set_im_of_rec_city_nm(String _im_of_rec_city_nm) {
        this._im_of_rec_city_nm = _im_of_rec_city_nm;
    }
    /**
     * @return the _im_of_rec_cont_nm
     */
    public String get_im_of_rec_cont_nm() {
        return _im_of_rec_cont_nm;
    }
    /**
     * @param _im_of_rec_cont_nm the _im_of_rec_cont_nm to set
     */
    public void set_im_of_rec_cont_nm(String _im_of_rec_cont_nm) {
        this._im_of_rec_cont_nm = _im_of_rec_cont_nm;
    }
    /**
     * @return the _im_of_rec_email_desc
     */
    public String get_im_of_rec_email_desc() {
        return _im_of_rec_email_desc;
    }
    /**
     * @param _im_of_rec_email_desc the _im_of_rec_email_desc to set
     */
    public void set_im_of_rec_email_desc(String _im_of_rec_email_desc) {
        this._im_of_rec_email_desc = _im_of_rec_email_desc;
    }
    /**
     * @return the _im_of_rec_fax_nbr
     */
    public String get_im_of_rec_fax_nbr() {
        return _im_of_rec_fax_nbr;
    }
    /**
     * @param _im_of_rec_fax_nbr the _im_of_rec_fax_nbr to set
     */
    public void set_im_of_rec_fax_nbr(String _im_of_rec_fax_nbr) {
        this._im_of_rec_fax_nbr = _im_of_rec_fax_nbr;
    }
    /**
     * @return the _im_of_rec_nm
     */
    public String get_im_of_rec_nm() {
        return _im_of_rec_nm;
    }
    /**
     * @param _im_of_rec_nm the _im_of_rec_nm to set
     */
    public void set_im_of_rec_nm(String _im_of_rec_nm) {
        this._im_of_rec_nm = _im_of_rec_nm;
    }
    /**
     * @return the _im_of_rec_ph_nbr
     */
    public String get_im_of_rec_ph_nbr() {
        return _im_of_rec_ph_nbr;
    }
    /**
     * @param _im_of_rec_ph_nbr the _im_of_rec_ph_nbr to set
     */
    public void set_im_of_rec_ph_nbr(String _im_of_rec_ph_nbr) {
        this._im_of_rec_ph_nbr = _im_of_rec_ph_nbr;
    }
    /**
     * @return the _im_of_rec_pstl_cd
     */
    public String get_im_of_rec_pstl_cd() {
        return _im_of_rec_pstl_cd;
    }
    /**
     * @param _im_of_rec_pstl_cd the _im_of_rec_pstl_cd to set
     */
    public void set_im_of_rec_pstl_cd(String _im_of_rec_pstl_cd) {
        this._im_of_rec_pstl_cd = _im_of_rec_pstl_cd;
    }
    /**
     * @return the _im_of_rec_st_prov_cd
     */
    public String get_im_of_rec_st_prov_cd() {
        return _im_of_rec_st_prov_cd;
    }
    /**
     * @param _im_of_rec_st_prov_cd the _im_of_rec_st_prov_cd to set
     */
    public void set_im_of_rec_st_prov_cd(String _im_of_rec_st_prov_cd) {
        this._im_of_rec_st_prov_cd = _im_of_rec_st_prov_cd;
    }
    /**
     * @return the _lane_nbr
     */
    public int get_lane_nbr() {
        return _lane_nbr;
    }
    /**
     * @param _lane_nbr the _lane_nbr to set
     */
    public void set_lane_nbr(int _lane_nbr) {
        this._lane_nbr = _lane_nbr;
    }
    /**
     * @return the _orig_acct_exec_email_desc
     */
    public String get_orig_acct_exec_email_desc() {
        return _orig_acct_exec_email_desc;
    }
    /**
     * @param _orig_acct_exec_email_desc the _orig_acct_exec_email_desc to set
     */
    public void set_orig_acct_exec_email_desc(String _orig_acct_exec_email_desc) {
        this._orig_acct_exec_email_desc = _orig_acct_exec_email_desc;
    }
    /**
     * @return the _orig_acct_exec_fax_nbr
     */
    public String get_orig_acct_exec_fax_nbr() {
        return _orig_acct_exec_fax_nbr;
    }
    /**
     * @param _orig_acct_exec_fax_nbr the _orig_acct_exec_fax_nbr to set
     */
    public void set_orig_acct_exec_fax_nbr(String _orig_acct_exec_fax_nbr) {
        this._orig_acct_exec_fax_nbr = _orig_acct_exec_fax_nbr;
    }
    /**
     * @return the _orig_acct_exec_nm
     */
    public String get_orig_acct_exec_nm() {
        return _orig_acct_exec_nm;
    }
    /**
     * @param _orig_acct_exec_nm the _orig_acct_exec_nm to set
     */
    public void set_orig_acct_exec_nm(String _orig_acct_exec_nm) {
        this._orig_acct_exec_nm = _orig_acct_exec_nm;
    }
    /**
     * @return the _orig_acct_exec_ph_nbr
     */
    public String get_orig_acct_exec_ph_nbr() {
        return _orig_acct_exec_ph_nbr;
    }
    /**
     * @param _orig_acct_exec_ph_nbr the _orig_acct_exec_ph_nbr to set
     */
    public void set_orig_acct_exec_ph_nbr(String _orig_acct_exec_ph_nbr) {
        this._orig_acct_exec_ph_nbr = _orig_acct_exec_ph_nbr;
    }
    /**
     * @return the _prim_engnr_email_desc
     */
    public String get_prim_engnr_email_desc() {
        return _prim_engnr_email_desc;
    }
    /**
     * @param _prim_engnr_email_desc the _prim_engnr_email_desc to set
     */
    public void set_prim_engnr_email_desc(String _prim_engnr_email_desc) {
        this._prim_engnr_email_desc = _prim_engnr_email_desc;
    }
    /**
     * @return the _prim_engnr_fax_nbr
     */
    public String get_prim_engnr_fax_nbr() {
        return _prim_engnr_fax_nbr;
    }
    /**
     * @param _prim_engnr_fax_nbr the _prim_engnr_fax_nbr to set
     */
    public void set_prim_engnr_fax_nbr(String _prim_engnr_fax_nbr) {
        this._prim_engnr_fax_nbr = _prim_engnr_fax_nbr;
    }
    /**
     * @return the _prim_engnr_nm
     */
    public String get_prim_engnr_nm() {
        return _prim_engnr_nm;
    }
    /**
     * @param _prim_engnr_nm the _prim_engnr_nm to set
     */
    public void set_prim_engnr_nm(String _prim_engnr_nm) {
        this._prim_engnr_nm = _prim_engnr_nm;
    }
    /**
     * @return the _prim_engnr_ph_nbr
     */
    public String get_prim_engnr_ph_nbr() {
        return _prim_engnr_ph_nbr;
    }
    /**
     * @param _prim_engnr_ph_nbr the _prim_engnr_ph_nbr to set
     */
    public void set_prim_engnr_ph_nbr(String _prim_engnr_ph_nbr) {
        this._prim_engnr_ph_nbr = _prim_engnr_ph_nbr;
    }
    /**
     * @return the _rtrn_acct_nbr
     */
    public String get_rtrn_acct_nbr() {
        return _rtrn_acct_nbr;
    }
    /**
     * @param _rtrn_acct_nbr the _rtrn_acct_nbr to set
     */
    public void set_rtrn_acct_nbr(String _rtrn_acct_nbr) {
        this._rtrn_acct_nbr = _rtrn_acct_nbr;
    }
    /**
     * @return the _rtrn_addr_line_one_desc
     */
    public String get_rtrn_addr_line_one_desc() {
        return _rtrn_addr_line_one_desc;
    }
    /**
     * @param _rtrn_addr_line_one_desc the _rtrn_addr_line_one_desc to set
     */
    public void set_rtrn_addr_line_one_desc(String _rtrn_addr_line_one_desc) {
        this._rtrn_addr_line_one_desc = _rtrn_addr_line_one_desc;
    }
    /**
     * @return the _rtrn_addr_line_three_desc
     */
    public String get_rtrn_addr_line_three_desc() {
        return _rtrn_addr_line_three_desc;
    }
    /**
     * @param _rtrn_addr_line_three_desc the _rtrn_addr_line_three_desc to set
     */
    public void set_rtrn_addr_line_three_desc(String _rtrn_addr_line_three_desc) {
        this._rtrn_addr_line_three_desc = _rtrn_addr_line_three_desc;
    }
    /**
     * @return the _rtrn_addr_line_two_desc
     */
    public String get_rtrn_addr_line_two_desc() {
        return _rtrn_addr_line_two_desc;
    }
    /**
     * @param _rtrn_addr_line_two_desc the _rtrn_addr_line_two_desc to set
     */
    public void set_rtrn_addr_line_two_desc(String _rtrn_addr_line_two_desc) {
        this._rtrn_addr_line_two_desc = _rtrn_addr_line_two_desc;
    }
    /**
     * @return the _rtrn_city_nm
     */
    public String get_rtrn_city_nm() {
        return _rtrn_city_nm;
    }
    /**
     * @param _rtrn_city_nm the _rtrn_city_nm to set
     */
    public void set_rtrn_city_nm(String _rtrn_city_nm) {
        this._rtrn_city_nm = _rtrn_city_nm;
    }
    /**
     * @return the _rtrn_cont_nm
     */
    public String get_rtrn_cont_nm() {
        return _rtrn_cont_nm;
    }
    /**
     * @param _rtrn_cont_nm the _rtrn_cont_nm to set
     */
    public void set_rtrn_cont_nm(String _rtrn_cont_nm) {
        this._rtrn_cont_nm = _rtrn_cont_nm;
    }
    /**
     * @return the _rtrn_cont_ph_nbr
     */
    public String get_rtrn_cont_ph_nbr() {
        return _rtrn_cont_ph_nbr;
    }
    /**
     * @param _rtrn_cont_ph_nbr the _rtrn_cont_ph_nbr to set
     */
    public void set_rtrn_cont_ph_nbr(String _rtrn_cont_ph_nbr) {
        this._rtrn_cont_ph_nbr = _rtrn_cont_ph_nbr;
    }
    /**
     * @return the _rtrn_st_prov_cd
     */
    public String get_rtrn_st_prov_cd() {
        return _rtrn_st_prov_cd;
    }
    /**
     * @param _rtrn_st_prov_cd the _rtrn_st_prov_cd to set
     */
    public void set_rtrn_st_prov_cd(String _rtrn_st_prov_cd) {
        this._rtrn_st_prov_cd = _rtrn_st_prov_cd;
    }
    /**
     * @return the _scndy_engnr_email_desc
     */
    public String get_scndy_engnr_email_desc() {
        return _scndy_engnr_email_desc;
    }
    /**
     * @param _scndy_engnr_email_desc the _scndy_engnr_email_desc to set
     */
    public void set_scndy_engnr_email_desc(String _scndy_engnr_email_desc) {
        this._scndy_engnr_email_desc = _scndy_engnr_email_desc;
    }
    /**
     * @return the _scndy_engnr_fax_nbr
     */
    public String get_scndy_engnr_fax_nbr() {
        return _scndy_engnr_fax_nbr;
    }
    /**
     * @param _scndy_engnr_fax_nbr the _scndy_engnr_fax_nbr to set
     */
    public void set_scndy_engnr_fax_nbr(String _scndy_engnr_fax_nbr) {
        this._scndy_engnr_fax_nbr = _scndy_engnr_fax_nbr;
    }
    /**
     * @return the _scndy_engnr_nm
     */
    public String get_scndy_engnr_nm() {
        return _scndy_engnr_nm;
    }
    /**
     * @param _scndy_engnr_nm the _scndy_engnr_nm to set
     */
    public void set_scndy_engnr_nm(String _scndy_engnr_nm) {
        this._scndy_engnr_nm = _scndy_engnr_nm;
    }
    /**
     * @return the _scndy_engnr_ph_nbr
     */
    public String get_scndy_engnr_ph_nbr() {
        return _scndy_engnr_ph_nbr;
    }
    /**
     * @param _scndy_engnr_ph_nbr the _scndy_engnr_ph_nbr to set
     */
    public void set_scndy_engnr_ph_nbr(String _scndy_engnr_ph_nbr) {
        this._scndy_engnr_ph_nbr = _scndy_engnr_ph_nbr;
    }


}
