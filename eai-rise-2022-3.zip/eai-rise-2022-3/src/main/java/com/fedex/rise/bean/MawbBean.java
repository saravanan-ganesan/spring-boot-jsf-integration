package com.fedex.rise.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.annotation.JsfController;
import com.fedex.rise.bo.ShipmentDelegate;
import com.fedex.rise.bo.issue.RiseIssues;
import com.fedex.rise.bo.status.StatusCalculator;
import com.fedex.rise.util.SpecialHandlingXlator;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentCommentVO;
import com.fedex.rise.vo.ShipmentVO;

/**
 * MAWB bean, aggrigates all the MAWB data (shipmentVO, events, issues, reference notes, etc.
 * CRNs are NOT encapsulated here. They are loosly coupled and available via the CrnListBean.
 */
@JsfController(path = "/mawb", page = "/pages/jsp/mawbList.jsp", value = "mawb")
public class MawbBean implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    /** logger */
    private static final Log log = LogFactory.getLog(MawbBean.class);
    
    private static long MILLI_SECS_IN_A_DAY = 24 * 60 * 60 * 1000L;

    /** encapsulated shipment data */
    private ShipmentVO shipment;
    
    private List shipmentReferences = new ArrayList();
    private List comments = new ArrayList();
    private List events = new ArrayList();
    private List issues = new ArrayList();
   
    /** list of AssociatedShipmentVO, for paperwork and return airbills */
    private List associatedShipments = new ArrayList();
   
    /** new comment to add */
    private String comment;
    /** is the Commit Data editable, not after POD/performance calculated */
    private boolean isAdjCommitDateChangeable = true;
    /** has the Commit Data changed */
    private boolean hasAdjCommitDateChanged = false;
    /** Dim Wgt units of messure, defaults to Kgs, but on entry of Dim Wgt can be Lbs */
    private String dimWgtUnits = "Kg";
   
    /** selected CRN */
    private CrnBean selectedCrnBean =  null;

    /** Count of Crns (Cancelled, DACR, Return */
    private int crnCancelCount = 0;
    private int crnDACRCount = 0;
    private int crnReturnCount = 0;
    private int crnTotalCount = 0;
    private int crnDeliveredCount = 0;
    private int crnPodCount = 0;
    private int crnDDexCount = 0;
    private int crnTotalDelivered = 0;
    private int crnTotalPod = 0;
    private int crnTotalDDex = 0;
   
    private transient ShipmentDelegate shipmentDelegate = new ShipmentDelegate();

    public MawbBean() {}
    /**
     * Construct new MAWB.
     * 
     * @param shipment
     * @param shipmentReferences
     * @param associatedShipments
     * @param comments
     * @param events
     * @param issues
     */
    //WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
    public MawbBean(CrnBean selectedCrnBean)
    {
    	super();
    	this.selectedCrnBean = selectedCrnBean;
    }
    
    public MawbBean(ShipmentVO shipment, List shipmentReferences, List associatedShipments, 
           List comments, List events, List issues) {
        super();
        this.shipment = shipment;
        this.shipmentReferences = shipmentReferences;
        this.associatedShipments = associatedShipments;
        this.comments = comments;
        this.events = events;
        this.issues = issues;
    }
    
    public String getSpecialHandlingCdTranslation() {
        return SpecialHandlingXlator.getSpecialHandlingCdTranlation(shipment.get_spcl_hndlg_grp());
    }

    /**
     * @return the adjCommitDate
     */
    public Date getAdjCommitDate() {
        Calendar cal = shipment.get_adj_commit_dt();
        if (cal != null) {
            Calendar c = (Calendar)cal.clone();
            // add any user entered adjustment already applied to this shipment 
            c.add(Calendar.DATE, shipment.get_adj_commit_dt_offst_nbr());
            return c.getTime();
        }

        return null;
    }

    /**
     * @param adjCommitDate the adjCommitDate to set
     */
    public void setAdjCommitDate(Date adjCommitDate) {
        // Calculate the difference between the commit date and the
        // adjusted commit date.  To do accurate math we strip off
        // the milliseconds back to midnight.  Thats what the
        // long -(long % MILLI_SECS_IN_A_DAY) is all about
        Calendar commitCal = shipment.get_adj_commit_dt();
        if (commitCal != null) {
           long midnightCommitDt = commitCal.getTime().getTime();
           midnightCommitDt = midnightCommitDt - (midnightCommitDt % MILLI_SECS_IN_A_DAY);
           long midnightAdjCommitDt = adjCommitDate.getTime() - 
               (adjCommitDate.getTime() % MILLI_SECS_IN_A_DAY);
           long diff = midnightAdjCommitDt - midnightCommitDt;
           int daysdiff = (int)(diff / MILLI_SECS_IN_A_DAY);
           setHasAdjCommitDateChanged(daysdiff);
           shipment.set_adj_commit_dt_offst_nbr(daysdiff);
        }
    }

    /**
     * @return the comments
     */
    public List getComments() {
        return comments;
    }

    /**
     * @return the events
     */
    public List getEvents() {
        if (events == null) {
//           events = shipmentDelegate.getEvents(this.shipment.get_trkng_item_nbr(), 
//                   this.shipment.get_trkng_item_uniq_nbr());
        }
        return events;
    }

    /**
     * @return the issues
     */
    public List getIssues() {
        return issues;
    }

    /**
     * @param issues the issues to set
     */
    public void setIssues(List issues) {
        this.issues = issues;
    }

    /**
     * @return the shipment
     */
    public ShipmentVO getShipment() {
        return shipment;
    }


    /**
     * @param shipment the shipment to set
     */
    public void setShipment(ShipmentVO shipment) {
        this.shipment = shipment;
    }

    /**
     * @return the shipmentReferences
     */
    public List getShipmentReferences() {
        return shipmentReferences;
    }

    /**
     * @param shipmentReferences the shipmentReferences to set
     */
    public void setShipmentReferences(List shipmentReferences) {
        this.shipmentReferences = shipmentReferences;
    }

    /**
     * @return the associatedShipments
     */
    public List getAssociatedShipments() {
        return associatedShipments;
    }

    /**
     * @param associatedShipments the associatedShipments to set
     */
    public void setAssociatedShipments(List associatedShipments) {
        this.associatedShipments = associatedShipments;
    }
    
    /**
     * Return the most recent scan event (track type).
     * @return the status
     */
    public String getStatus() {
        StringBuffer status = new StringBuffer();
        if (shipment.get_last_stat_desc() != null) {
            status.append(StatusCalculator.getStatusDesc(shipment.get_last_stat_desc()));
        }
        if (shipment.get_last_event_track_loc_cd() != null) {
            status.append(" @ ");
            // append last status location, since this field is new, if it is null, use old last event location 
            if (shipment.get_last_stat_track_loc_cd() == null) 
               status.append(shipment.get_last_event_track_loc_cd());
            else
               status.append(shipment.get_last_stat_track_loc_cd());
        }
        
        return status.toString();
    }

    /**
     * @return the crnCnt
     */
    public String getCrnCountStr() {
       StringBuffer crnCount = new StringBuffer();
       crnCount.append(String.valueOf(crnTotalCount)); 
       return crnCount.toString();
    }
   
    /**
     * Get IssuesStr
     * @return Issues, concat all issues comma delimited
     */
    public String getIssuesStr() {
       if (issues.size()>0) {
           // Issues, show all OPEN issues, not closed ones
           StringBuffer issueStr = new StringBuffer();
           for (Iterator itr=issues.iterator(); itr.hasNext(); ) {
               IssueBean issue = (IssueBean)itr.next();
               if (issue.getIssue().getRes_dt() == null) {
                   if (issueStr.length()>0)
                       issueStr.append(", ");
                   issueStr.append(issue.getDesc());
               }
           }
           return issueStr.toString();
       } else {
           // NO Issues
           return "";                 
       }
    }
    
    /**
     * @return the isClearedCustomsIssue, true if we have a cleared customs issue
     */
    public boolean isClearedCustomsIssue() {
        boolean isClearedCustomsIssue = false;
        for (Iterator itr=issues.iterator(); itr.hasNext(); ) {
            IssueBean issue = (IssueBean)itr.next();
            // If we have an open cleared customs issue then set flag on MAWB so we can show it
            // on UI with some special indicator
            if (RiseIssues.NOT_CLRD_CSTMS_DESC.getShortTextDesc().equals(issue.getDesc())) {
                if (issue.getIssue().getRes_dt() == null) // not resolved
                    isClearedCustomsIssue = true;
            }
        }
        return isClearedCustomsIssue;
    }

    /**
     * Get the CRN that is selected in the list
     * @return
     */
    public CrnBean getSelectedCRN() {
        return selectedCrnBean;
    }
    
    /**
     * Set the CRN that is selected in the list
     * @return
     */
    public void setSelectedCRN(CrnBean selectedCrnBean) {
        this.selectedCrnBean = selectedCrnBean;
    }
    
    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the dimWgtUnits
     */
    public String getDimWgtUnits() {
        return dimWgtUnits;
    }

    /**
     * @param dimWgtUnits the dimWgtUnits to set
     */
    public void setDimWgtUnits(String dimWgtUnits) {
        this.dimWgtUnits = dimWgtUnits;
    }

    /**
     * @return the isAdjCommitDateChangeable
     */
    public boolean isAdjCommitDateChangeable() {
        // Also, set adj changable to false after POD/DDEX and performance has been calculated,
        // because adjusting the commit date will have no affect.
        if (shipment.get_perf_rsult_cd() != null) {
            isAdjCommitDateChangeable = false;
        } else {
            isAdjCommitDateChangeable = true;
        }
        return isAdjCommitDateChangeable;
    }

    /**
     * @return the crnCancelCount
     */
    public int getCrnCancelCount() {
        return crnCancelCount;
    }

    /**
     * @return the crnDACRCount, destroyed
     */
    public int getCrnDACRCount() {
        return crnDACRCount;
    }

    /**
     * @return the crnReturnCount
     */
    public int getCrnReturnCount() {
        return crnReturnCount;
    }

    /**
     * @return the crnDelieveredCount
     */
    public int getCrnDeliveredCount() {
        return crnDeliveredCount;
    }
    
    /**
     * Depending on if we are viewing Issues Only or All, the count will be either all 
     * CRNs for this MAWB or just the ones with issues.  
     * @return the crnTotalCount
     */
    public int getCrnTotalCount() {
        return crnTotalCount;
    }

    /**
     * @return the crnTotalCount
     */
    public void setCrnTotalCount(int count) {
        crnTotalCount = count;
    }
    
    public String _workedStatusCd = null;
    
    /**
     * @return 
     * @return the worked status Cd
     */
    public String getWorkedStatusCd() {
        // the database stores a 1 character work status code that we are translating into either
        // c - Closed, v - Viewed, p - Pending, or " " for not worked or default.
        if ((shipment.get_wrk_stat_cd() != null) && shipment.get_wrk_stat_cd().equals("c")) {
            _workedStatusCd = "c";
        }else if ((shipment.get_wrk_stat_cd() != null) && shipment.get_wrk_stat_cd().equals("v")) {
        	_workedStatusCd = "v";       
        }else if ((shipment.get_wrk_stat_cd() != null) && shipment.get_wrk_stat_cd().equals("p")) {
        	_workedStatusCd = "p";  
        }else if ((shipment.get_wrk_stat_cd() != null) && shipment.get_wrk_stat_cd().equals("")) {
        	_workedStatusCd = "";
       // }else if ((shipment.get_wrk_stat_cd() != null) && shipment.get_wrk_stat_cd().equals("1")) {
         //	_workedStatusCd = "c";
        }else if ((shipment.get_wrk_stat_cd() != null) && shipment.get_wrk_stat_cd().equals("*")) {
        	_workedStatusCd = "*";
        }else {
        	_workedStatusCd = "";
        }
        return _workedStatusCd;        
    }
    
    /**
     * @return the worked status Cd
     */
    public void setWorkedStatusCd(String workedStatusCd) {
        // the database stores a 1 character work status code that we are translating into either
        // c - Closed, v - Viewed, p - Pending, or " " for not worked or default.     

    	_workedStatusCd = workedStatusCd;    	    	

    	if (_workedStatusCd.equals("c")) {
            shipment.set_wrk_stat_cd("c");
        }else if (_workedStatusCd.equals("v")) {
            shipment.set_wrk_stat_cd("v");
        }else if (_workedStatusCd.equals("p")) {
            shipment.set_wrk_stat_cd("p");            
        }else if (_workedStatusCd.equals("")){
        	shipment.set_wrk_stat_cd("");
        }else if (_workedStatusCd.equals("*")){
        	shipment.set_wrk_stat_cd("*");
        }else{	
            shipment.set_wrk_stat_cd(""); // reset to not worked
        }
    }    
    
    /*-----------------------------------------------------------------------
     * Action methods 
     *-----------------------------------------------------------------------
     */
   
    /**
     * Add a comment
     * @param comment a comment to add, can have formating (CR/LF, tabs, etc.)
     */
    public String addCommentAction() {
        if (comment != null && comment.length() > 0) {
            ShipmentCommentVO commentVO = new ShipmentCommentVO();
            commentVO.set_trkng_item_nbr(shipment.get_trkng_item_nbr());
            commentVO.set_trkng_item_uniq_nbr(shipment.get_trkng_item_uniq_nbr());
            commentVO.set_com_tmstp(new Date());
            commentVO.set_emp_nbr(UserBean.getLoggedInUser().getUserId());
            commentVO.set_com_desc(comment);
            //shipmentDelegate.saveComment(commentVO);
        
            // update UI, so we don't have to go back to DB
            this.comments.add(commentVO);
        
            comment = null;
        }
        
        // TODO: handle errors
        
        return null; // use null to redisplay same page
    }

    
    
    
    /**
     * Mark MAWB as work all complete
     */
    public void workedAction(ActionEvent event) throws AbortProcessingException {
//        shipmentDelegate.saveWorkedStatus(shipment.get_wrk_stat_cd(), 
//                shipment.get_trkng_item_nbr(), shipment.get_trkng_item_uniq_nbr());
        
        // TODO: handle errors
    }
    
    
    
    

    /** 
     * Save the Dim Wgt, Invoice Amount, and the new Commit Date
     */
    public String saveMawbAttributesAction() {
       
        boolean success = saveDimnlWgtAndInvAmt();
        
        if (hasAdjCommitDateChanged){
//        	success = shipmentDelegate.adjustCRNCommitDates(shipment.get_adj_commit_dt_offst_nbr(),
//                shipment.get_trkng_item_nbr(), shipment.get_trkng_item_uniq_nbr());
        }
       
        FacesMessage facesMessage;
        if (success) 
            facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO,  "Successfully saved", null); 
        else 
            facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR,  "Error saving", null); 
        
        FacesContext facesContext = FacesContext.getCurrentInstance(); 
        facesContext.addMessage(null, facesMessage);
        
        return null; // use null to redisplay same page
    }

    /**
     * Resolve the selected Issues Action
     */
    public String markIssuesResolvedAction() {
        // iterate through all issues
        for (Iterator itr=issues.iterator(); itr.hasNext(); ) {
            IssueBean issue = (IssueBean)itr.next();
            // if issue is set to be resolved and hasn't already been resolved then mark it resolved
            if (issue.isResolved() && issue.getIssue().getRes_dt() == null) {
                issue.markIssueResolvedAction();
            }
        }
        
        // TODO: handle errors
   
        return null; 
    }
    /**
     * Is the monitor allowed to edit.
     * Set boolean to indicate whether the request came from performance or not.
     * @return if came from performance, the flag is false, otherwise true.
     */
    public boolean isEditable(){
        return true;
    }
    
    /** 
     * Save the Dim Wgt and the Invoice Amount
     * @return true for success
     */
    public boolean saveDimnlWgtAndInvAmt() {
//        MAWBAttributesVO aVO = new MAWBAttributesVO();
//        
//        if (!dimWgtUnits.equals("Kg")) {
//            // must convert Lbs to Kg, round up to 1 decimal, store back in shipment 
//            BigDecimal bd = new BigDecimal(shipment.get_dimnl_wgt()/2.2);
//            bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
//            shipment.set_dimnl_wgt((int)bd.doubleValue());
//            dimWgtUnits = "Kg"; // reset to Kg
//        }
//        
//        aVO.set_trkng_item_nbr(shipment.get_trkng_item_nbr());
//        aVO.set_trkng_item_uniq_nbr(shipment.get_trkng_item_uniq_nbr());
//
//        aVO.set_dimnlWgt(shipment.get_dimnl_wgt());
//        aVO.set_inv_amt(shipment.get_inv_amt());
//        
//        return shipmentDelegate.saveMawbAttributes(aVO);
    	return false;
    }

    /** 
     * Initialize the CRN State Counts (Canceled, DACR, Return)
     * Only, necessary when showing MAWB details
     */
    public void setCRNStateCounts(List counts) {
        crnCancelCount = CrnCountHelper.getCanceledCount(counts);
        crnDACRCount = CrnCountHelper.getDACRCount(counts);
        crnReturnCount = CrnCountHelper.getReturnCount(counts);
        crnTotalCount = CrnCountHelper.getTotalCount(counts);
        crnDeliveredCount = CrnCountHelper.getDeliveredCount(counts);
        crnPodCount = CrnCountHelper.getPodCount(counts);
        crnDDexCount = CrnCountHelper.getDDexCount(counts);
    }
    
    public String createMonitorIssue() {
        log.info("Creating Monitor Issue");
        IssueVO newIssue = new IssueVO();
        newIssue.setTrkng_item_nbr(shipment.get_trkng_item_nbr());
        newIssue.setTrkng_item_uniq_nbr(shipment.get_trkng_item_uniq_nbr());
        newIssue.setIssue_type_cd(RiseIssues.MONITOR_ISSUE);
        newIssue.setIssue_loc_cd("    ");
        newIssue.setEvent_crtn_tmstp(new Date());
        newIssue.setIssue_tmstp(new Date());
        newIssue.setGrp_nbr(shipment.get_grp_nbr());
        newIssue.setAcct_nbr(shipment.get_acct_nbr());
        newIssue.setLane_nbr(shipment.get_lane_nbr());
        newIssue.setSvc_type_cd(shipment.get_svc_type_cd());
        newIssue.set_res_desc(null);
        newIssue.setRes_dt(null);
        newIssue.set_trackTypeCd(null);
//        shipmentDelegate.createMonitorIssue(newIssue);
        IssueBean issueBean = new IssueBean(newIssue);
        // See if there is already a monitor issue, if so remove
        // and add a new one to the begining of the list
        IssueBean removeIssue = null;
        Iterator iter = issues.listIterator();
        while (iter.hasNext()) {
            IssueBean issue = (IssueBean)iter.next();
            if (issue.getIssue().equals(newIssue)) {
                removeIssue = issue;
            }
        }
        if (removeIssue != null) {
            issues.remove(removeIssue);
        }
        issues.add(0, issueBean);
        return null;
    }

    /*-----------------------------------------------------------------------
     * Utility methods
     *-----------------------------------------------------------------------
     */
   
    /**
     *  Override deserialization to handle the re-creation of our transient data
     */
    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      shipmentDelegate = new ShipmentDelegate();
    }
    /**
     * Set the hasAdjCommitDateChanged 
     * @param adj_commit_dt_offst_nbr
     */
    private void setHasAdjCommitDateChanged(int adj_commit_dt_offst_nbr){
    	hasAdjCommitDateChanged = false;
    	if (shipment.get_adj_commit_dt_offst_nbr() != adj_commit_dt_offst_nbr){
    		hasAdjCommitDateChanged = true;
    	}
    }

}
    