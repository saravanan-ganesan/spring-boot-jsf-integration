package com.fedex.rise.webejb;

/**
 * 
 * @ejb:bean name="ShipperBean" display-name="ShipperEJB" jndi-name="ShipperEJB"
 *           local-jndi-name="LocalShipperEJB" type="Stateless"
 *           view-type="both"
 * 
 * @ejb:home extends="javax.ejb.EJBHome"
 *           local-extends="javax.ejb.EJBLocalHome"
 * 
 * @ejb:interface extends="javax.ejb.EJBObject"
 *                local-extends="javax.ejb.EJBLocalObject"
 * 
 * @weblogic.enable-call-by-reference True
 * 
 * @weblogic.pool max-beans-in-free-pool="10" 
 * initial-beans-in-free-pool="3"
 * 
 * @ejb.transaction type="Supports"
 */
/**
* ShipperEJB
* This class implements the EJB which is accessible via the JSPs. It is a
* stateless SessionBean. This class implements the facade for the Business
* Objects and or Data Access Objects. All EJB/J2EE related things should be
* implemented here leaving the BO's with no knowledge of the EJB/J2EE
* environment.
*/
//@JndiName(remote="webejb/ShipperEJBRemote")
//@Session(ejbName = "ShipperEJB",
//        maxBeansInFreePool="3",
//        initialBeansInFreePool="1",
//        type = Session.SessionType.STATELESS,
//        defaultTransaction=Constants.TransactionAttribute.SUPPORTS,
//        transactionType=Session.SessionTransactionType.BEAN,
//        enableCallByReference=Constants.Bool.TRUE)
public class ShipperEJB { //implements SessionBean {
//
//    private static final long serialVersionUID = 1L;
//
//    /** Logger */
//    private static Logger logger = LogManager.getLogger(ShipperEJB.class);
//    
//    private SessionContext mySessionContext = null;
//
//    public SessionContext getSessionContext() {
//        return mySessionContext;
//    }
//
//    public void setSessionContext(SessionContext aSessionContext)
//            throws RemoteException {
//        mySessionContext = aSessionContext;
//    }
//
//    public void ejbActivate() {
//        System.out.println("Activate ShipperEJB");
//    }
//
//    public void ejbPassivate() {
//        System.out.println("Passivate ShipperEJB");
//    }
//
//    /**
//     * @ejb:create-method
//     */
//    public void ejbCreate() {
//        System.out.println("EJB Create ShipperEJB");
//    }
//
//    /**
//     * @ejb:remove-method
//     */
//    public void ejbRemove() { 
//        System.out.println("EJB Remove ShipperEJB");
//    }
//
//    /**
//     * Get shippers, accounts, lane, services 
//     * @ejb:interface-method view-type="remote"
//     * @return List of Shippers, accounts, lanes, services
//     */
//    @RemoteMethod()
//    public List getAllShippers() throws SQLException {
//       
//        AdminDAO adminDAO = new AdminDAO();
//        List shippers= adminDAO.getAllShippers();
//        return shippers;
//    }
//    
//    /**
//     * Get monitor report 
//     * @ejb:interface-method view-type="remote"
//     * @return List of MonitorReportVO
//     */
//    @RemoteMethod()
//    public List getMonitorReportList(Date fromDate, Date toDate) throws SQLException, ServiceLocatorException {     
//    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
//        List monitorReports= monitorReportDAO.getMonitorReportList(fromDate, toDate);
//        return monitorReports;
//    }
//    
//    /**
//     * Get monitor report 
//     * @ejb:interface-method view-type="remote"
//     * @return List of MonitorReportVO
//     */
//    @RemoteMethod()
//    public List getMonitorReportDetailList(String monitorName, String monitorType, Date fromDate, Date toDate,
//    		int startIndex, int endIndex, String sortColumn, 
//    		boolean isSortAscending) throws SQLException, ServiceLocatorException {     
//    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
//        List monitorReports= monitorReportDAO.getMonitorReportList(monitorName, monitorType, fromDate, toDate,
//        		startIndex, endIndex, sortColumn, isSortAscending);
//        return monitorReports;
//    }
//    
//    /**
//     * Get monitor report 
//     * @ejb:interface-method view-type="remote"
//     * @return List of MonitorReportVO
//     */
//    @RemoteMethod()
//    public List getMonitorReportList(String monitorName, String monitorType, Date fromDate, Date toDate) throws SQLException, ServiceLocatorException {     
//    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
//        List monitorReports= monitorReportDAO.getMonitorReportList(monitorName, monitorType, fromDate, toDate);
//        return monitorReports;
//    }
//    
//    /**
//     * Get monitor report count
//     * @ejb:interface-method view-type="remote"
//     * @return List of MonitorReportVO
//     */
//    @RemoteMethod()
//    public int getMonitorReportCount(String monitorName, String monitorType, Date fromDate, Date toDate) throws SQLException, ServiceLocatorException {     
//    	MonitorReportDAO monitorReportDAO = new MonitorReportDAO();
//    	int size = 0;
//        size = monitorReportDAO.getMonitorReportCount(monitorName, monitorType, fromDate, toDate);
//        return size;
//    }
//   
//    /**
//     * Get a shipper
//     * @ejb:interface-method view-type="remote"
//     * @param groupName of the shipper
//     * @return AccountGroupVO 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public AccountGroupVO getShipper(String groupName) throws SQLException, ServiceLocatorException {
//       
//        AccountGroupDAO accountGroupDAO = new AccountGroupDAO();
//        AccountGroupVO accountGroupVO = accountGroupDAO.getAccountGroup(groupName);
//        return accountGroupVO;
//    }
//    
//    /**
//     * Get a shipper
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @return AccountGroupVO 
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public AccountGroupVO getShipper(int groupNbr) throws SQLException, ServiceLocatorException {
//       
//        AccountGroupDAO accountGroupDAO = new AccountGroupDAO();
//        AccountGroupVO accountGroupVO = accountGroupDAO.getAccountGroup(groupNbr);
//        return accountGroupVO;
//    }
//    
//    /**
//     * Get all AccountGroup table 
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @return List of AccountGroupVOs
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getAccountGroupTable() throws SQLException, ServiceLocatorException { 
//        AccountGroupDAO accountGroupDAO = new AccountGroupDAO();
//        return accountGroupDAO.getAccountGroupTable();
//    }
//    
//    /**
//     * Get a list of performance results. 
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @param fromDate start date of performance query
//     * @param toDate end date of performance query
//     * @param laneNbrStr lane number string
//     * @return List of PerformanceVOs
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getPerformanceList(String GroupNbr, Date fromDate, Date toDate,
//    		String laneNbrStr)throws SQLException, 
//    		ServiceLocatorException { 
//    	PerformanceDAO performanceDAO = new PerformanceDAO();
//        return performanceDAO.getPerformanceList(GroupNbr, fromDate, toDate, 
//        		laneNbrStr);
//    }
//    
//   //WR#:179441 Changes
//    /**
//     * Get a list of the sum of performance results. 
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @param fromDate start date of performance query
//     * @param toDate end date of performance query
//     * @param laneNbrStr lane number String
//     * @param monthNbr the month number (0-11)
//	 * @param empNbr
//     * @return List of PerformanceVOs
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getPerformanceSumList(String GroupNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, String empNbr)throws SQLException, 
//    		ServiceLocatorException { 
//    	PerformanceDAO performanceDAO = new PerformanceDAO();
//        return performanceDAO.getPerformanceSumList(GroupNbr, fromDate, toDate, 
//        		laneNbrStr, empNbr);
//    }
//    
//    //WR#:179441 Changes
//    /**
//     * Get a list of the sum performance results by account number. 
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @param fromDate start date of performance query
//     * @param toDate end date of performance query
//     * @param laneNbrStr lane number String
//     * @return List of PerformanceVOs
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getPerformanceAcctSumList(String GroupNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, int monthNbr, int monthSelectedNumber, String empNbr)throws SQLException, 
//    		ServiceLocatorException { 
//    	PerformanceDAO performanceDAO = new PerformanceDAO();
//        return performanceDAO.getPerformanceAcctSumList(GroupNbr, fromDate, toDate, 
//        		laneNbrStr, monthNbr, monthSelectedNumber, empNbr);
//    }
//    
//    /**
//     * Get a list of the sum performance results by group number. 
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @param fromDate start date of performance query
//     * @param toDate end date of performance query
//     * @param laneNbrStr lane number String
//     * @return List of PerformanceVOs
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getPerformanceGroupSumList(Date fromDate, Date toDate,
//    		int monthNbr, int monthSelectedNumber)throws SQLException, 
//    		ServiceLocatorException { 
//    	PerformanceDAO performanceDAO = new PerformanceDAO();
//        return performanceDAO.getPerformanceGroupSumList(fromDate, toDate, 
//        		monthNbr, monthSelectedNumber);
//    }
//    
//    /**
//     * Get all the LaneVOs for a specific group number.
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr
//     * @return
//     * @throws SQLException
//     * @throws ServiceLocatorException
//     */
//    @RemoteMethod()
//    public List getAllLanes(int groupNbr) throws SQLException, ServiceLocatorException {
//        AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
//        return accountLaneDAO.getAllLanes(groupNbr);
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     * @return List of LaneVOs
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public List getLanes() throws SQLException, ServiceLocatorException {
//        
//        LaneDAO laneDAO = new LaneDAO();
//        return laneDAO.getLaneTable();    
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     * @return laneVO LaneVO
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     */
//    @RemoteMethod()
//    public LaneVO getLane(String laneNbr) throws SQLException, NumberFormatException, ServiceLocatorException {
//        LaneDAO laneDAO = new LaneDAO();
//        return laneDAO.getLane(Integer.parseInt(laneNbr));    
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void deleteLane(String laneNbr) throws SQLException, NumberFormatException, ServiceLocatorException {
//        
//        LaneDAO laneDAO = new LaneDAO();
//        laneDAO.deleteLane(Integer.parseInt(laneNbr));
//    }
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void addLane(String originCountryCd, String destCountryCd) throws SQLException, ServiceLocatorException {
//        
//        LaneDAO laneDAO = new LaneDAO();
//        // laneNbr will be calculated on DB side
//        LaneVO laneVO = new LaneVO(0, originCountryCd, destCountryCd);
//        laneDAO.addLane(laneVO);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void addShipper(String shipperName) throws SQLException, ServiceLocatorException {
//        
//        AccountGroupDAO shipperDAO = new AccountGroupDAO();
//        // groupNbr will be calculated on DB side
//        AccountGroupVO shipperVO = new AccountGroupVO(0, shipperName, "");
//        shipperDAO.addAccountGroup(shipperVO);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void updateShipper(AccountGroupVO shipper) throws SQLException, ServiceLocatorException {
//        
//        AccountGroupDAO shipperDAO = new AccountGroupDAO();
//        shipperDAO.updateAccountGroup(shipper);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void deleteShipper(String shipperNbr) throws SQLException, NumberFormatException, ServiceLocatorException {
//        AccountGroupDAO shipperDAO = new AccountGroupDAO();
//        shipperDAO.deleteAccountGroup(Integer.parseInt(shipperNbr));
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void addAccount(AccountVO accountVO) throws SQLException, ServiceLocatorException {
//        
//        AccountDAO accountDAO = new AccountDAO();
//        accountDAO.addAccount(accountVO);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void updateAccount(AccountVO accountVO) throws SQLException, ServiceLocatorException {
//        
//        AccountDAO accountDAO = new AccountDAO();
//        accountDAO.updateAccount(accountVO);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void deleteAccount(String shipperNbr, String accountNbr) throws SQLException, NumberFormatException, ServiceLocatorException {
//        
//        // we need to cascade deletes...
//        
//        // so, delete all monitors at service level for this shipperNbr and accountNbr
//        AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//        acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(Integer.parseInt(shipperNbr), accountNbr);
//     
//        // and, delete all services associated with this shipperNbr and accountNbr
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        laneServiceDAO.deleteLaneServices(Integer.parseInt(shipperNbr), accountNbr);
//        
//        // and, delete all lanes associated with this shipperNbr and accountNbr
//        AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
//        accountLaneDAO.deleteAccountLanes(Integer.parseInt(shipperNbr), accountNbr);
//        
//        // finally, delete the account for this shipperNbr 
//        AccountDAO accountDAO = new AccountDAO();
//        accountDAO.deleteAccount(Integer.parseInt(shipperNbr), accountNbr);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public AccountVO getAccount(String shipperNbr, String accountNbr) 
//       throws SQLException, NumberFormatException, ServiceLocatorException {
//        AccountDAO accountDAO = new AccountDAO();
//        AccountVO accountVO = accountDAO.getAccount(Integer.parseInt(shipperNbr), accountNbr);
//        return accountVO;
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getAccountLanes(String shipperNbr, String accountNbr) 
//       throws SQLException, NumberFormatException, ServiceLocatorException {
//        AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
//        List lanes = accountLaneDAO.getAccountLane(Integer.parseInt(shipperNbr), accountNbr);
//        return lanes;
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public AccountLaneVO getAccountLane(String shipperNbr, String accountNbr, String laneNbr) 
//       throws SQLException, NumberFormatException, ServiceLocatorException {
//        AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
//        AccountLaneVO lane = accountLaneDAO.getAccountLane(Integer.parseInt(shipperNbr), accountNbr, 
//                Integer.parseInt(laneNbr));
//        return lane;
//    }
//    
//    /**
//     * This is the list of Lanes to now add to the Shipper.  Some Lanes may be new, while
//     * others could have been removed, so later we will determine which were removed so we can
//     * delete them and also cascade the delete to the monitor table.
//     * 
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void addLanesToShipper(String shipperNbr, String accountNbr, String[] laneNbrs) 
//       throws SQLException, ServiceLocatorException {
//        AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
//        List accountLaneVOs = null;
//        
//        if (laneNbrs == null || laneNbrs.length == 0) {
//            // delete any lanes on this account, pass in dummy lane of 0, so keys available 
//            accountLaneVOs = new ArrayList(1);
//            accountLaneVOs.add(new AccountLaneVO(Integer.parseInt(shipperNbr), accountNbr, 0));
//        } else {
//            accountLaneVOs = new ArrayList(laneNbrs.length);
//            for (int i=0; i<laneNbrs.length; i++) {
//                accountLaneVOs.add(new AccountLaneVO(Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbrs[i])));
//            }
//        }
//        
//        accountLaneDAO.addAccountLanes(accountLaneVOs);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void deleteLane(String shipperNbr, String accountNbr, String laneNbr) throws SQLException, NumberFormatException, ServiceLocatorException {
//        
//        // we need to cascade delete...
//        
//        // so, delete any monitor at service level for this shipperNbr and accountNbr
//        AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//        acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(Integer.parseInt(shipperNbr),
//               accountNbr, Integer.parseInt(laneNbr));
//      
//        // and, delete all services associated with this shipperNbr, accountNbr, laneNbr
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        laneServiceDAO.deleteLaneServices(Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr));
//        
//        // delete the lane for this shipperNbr and accountNbr
//        AccountLaneDAO accountLaneDAO = new AccountLaneDAO();
//        AccountLaneVO accountLaneVO = new AccountLaneVO(Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr));
//        accountLaneDAO.deleteAccountLane(accountLaneVO);
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getLaneServices(String shipperNbr, String accountNbr, String laneNbr) 
//       throws SQLException {
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        List services = laneServiceDAO.getLaneServices(Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr));
//        return services;
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public LaneServiceVO getLaneService(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd) 
//       throws SQLException {
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        LaneServiceVO service = laneServiceDAO.getLaneService(Integer.parseInt(shipperNbr), 
//                accountNbr, Integer.parseInt(laneNbr), serviceTypeCd);
//        return service;
//    }
//    
//    /**
//     * This is the list of Services to now add to the Shipper.  Some Services may be new, while
//     * others could have been removed, so later we will determine which were removed so we can
//     * delete them and also cascade the deletes to the monitor table.
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void addServicesToShipper(String shipperNbr, String accountNbr, String laneNbr, String[] serviceTypeCds) 
//       throws SQLException, ServiceLocatorException {
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        List laneServicesVO = null;
//        
//        if (serviceTypeCds == null || serviceTypeCds.length == 0) {
//            // delete any services on this account, pass in dummy service of null, so keys available 
//            laneServicesVO = new ArrayList(1);
//            laneServicesVO.add(new LaneServiceVO(null,
//                    Integer.parseInt(laneNbr), Integer.parseInt(shipperNbr), accountNbr));
//        } else {
//            laneServicesVO = new ArrayList(serviceTypeCds.length);
//            for (int i=0; i<serviceTypeCds.length; i++) {
//                laneServicesVO.add(new LaneServiceVO(serviceTypeCds[i], 
//                    Integer.parseInt(laneNbr), Integer.parseInt(shipperNbr), accountNbr));
//            }
//        }
//        
//        laneServiceDAO.addLaneServices(laneServicesVO);
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void updateLaneService(LaneServiceVO laneServiceVO) throws SQLException {
//        
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        laneServiceDAO.updateLaneService(laneServiceVO);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void deleteService(String shipperNbr, String accountNbr, String laneNbr, String serviceTypeCd) 
//    throws SQLException, NumberFormatException, ServiceLocatorException {
//        
//        // we need to cascade delete to the monitor tables, so, delete any monitor 
//        // at service level for this shipperNbr and accountNbr
//        AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//        acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(Integer.parseInt(shipperNbr),
//               accountNbr, Integer.parseInt(laneNbr), serviceTypeCd);
//
//        // delete the service for this shipperNbr, accountNbr, laneNbr
//        LaneServiceDAO laneServiceDAO = new LaneServiceDAO();
//        LaneServiceVO laneServiceVO = new LaneServiceVO(serviceTypeCd, 
//            Integer.parseInt(laneNbr), Integer.parseInt(shipperNbr), accountNbr);
//        laneServiceDAO.deleteLaneService(laneServiceVO);
//    }
//
//    /**
//     * Get monitors for an account
//    private List getMonitors(int shipperNbr, String accountNbr) 
//    throws SQLException {
//       
//        List monitors = new ArrayList();
//        // get monitors at account level
//        AccountMonitoringDAO accountMonitoringDAO = new AccountMonitoringDAO();
//        List accountMonitors = accountMonitoringDAO.getMonitors(shipperNbr, accountNbr);
//        for (Iterator itr=accountMonitors.iterator(); itr.hasNext(); ) {
//            monitors.add(((AccountMonitoringVO)itr.next()).get_emp_nbr());
//        }
//        
//        return monitors;
//    }
//     */
//
//    /**
//     * Get monitors for an account, lane
//    private List getMonitors(int shipperNbr, String accountNbr, int laneNbr) 
//    throws SQLException {
//       
//        List monitors = new ArrayList();
//        // get monitors at lane level
//        AccountLaneMonitoringDAO accountLaneMonitoringDAO = new AccountLaneMonitoringDAO();
//        List laneMonitors = accountLaneMonitoringDAO.getMonitors(shipperNbr, 
//            accountNbr, laneNbr);
//        for (Iterator itr=laneMonitors.iterator(); itr.hasNext(); ) {
//            monitors.add(((AccountLaneMonitoringVO)itr.next()).get_emp_nbr());
//        }
//       
//        // if no monitor at lane level, show monitor at account level if any
//        if (monitors.size() == 0) {
//            // get monitors at account level
//            monitors = getMonitors(shipperNbr, accountNbr);
//        }
//      
//        return monitors;
//    }
//     */
//    
//    /**
//     * Get monitors for an account, lane, or service
//     * @throws ServiceLocatorException 
//     */
//    private List getMonitors(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd) 
//    throws SQLException, ServiceLocatorException {
//       
//        List monitors = new ArrayList();
//        // get monitors at service level
//        AcctLaneServiceMonitoringDAO accountLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//        List serviceMonitors = accountLaneServiceMonitoringDAO.getMonitors(shipperNbr, 
//                accountNbr, laneNbr, serviceTypeCd);
//        
//        //Commented for while
//        /*for (Iterator itr=serviceMonitors.iterator(); itr.hasNext(); ) {
//            monitors.add(((AcctLaneServiceMonitoringVO)itr.next()).get_emp_nbr());
//        }*/
// /*       
//        // if no monitor at service level, show monitor at lane level if any
//        if (monitors.size() == 0) {
//            // get monitors at lane level
//            monitors = getMonitors(shipperNbr, accountNbr, laneNbr);
//        }
//       
//        // if no monitor at lane level, show monitor at account level if any
//        if (monitors.size() == 0) {
//            // get monitors at account level
//            monitors = getMonitors(shipperNbr, accountNbr);
//        }
//*/        
//        
//        return serviceMonitors;// monitors;
//    }
//    
//    /**
//     * Get monitors for an account, lane, or service
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getMonitors(String shipperNbr, String accountNbr, String laneNbr, String serviceTypeCd) 
//    throws SQLException, NumberFormatException, ServiceLocatorException {
//       
//        List monitors = new ArrayList();
//        // get monitors at service level
//        monitors = getMonitors(Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr),
//                    serviceTypeCd);
//        return monitors;
//    }
//    /**
//     * Add many monitors to a service
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"
//     */
//    
//       @RemoteMethod()
//    public void addAcctLaneServiceManyMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd, String[] emplyNbr) 
//    throws SQLException, NumberFormatException, ServiceLocatorException {
//    	
//    	AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//    	List acctLaneServiceMonitoringVO = null;     
//        
//        if(emplyNbr == null || emplyNbr.length == 0)
//        {
//        	// delete any monitors on this account, pass in dummy monitor of 0, so keys available
//        	acctLaneServiceMonitoringVO = new ArrayList(2);
//        	acctLaneServiceMonitoringVO.add(new AcctLaneServiceMonitoringVO("0", 
// 	               									Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr), serviceTypeCd));
//        }
//        else
//        {
//        	acctLaneServiceMonitoringVO = new ArrayList(emplyNbr.length);
//        	for (int i=0; i<emplyNbr.length; i++)
//        	{
//        		acctLaneServiceMonitoringVO.add(new AcctLaneServiceMonitoringVO(emplyNbr[i], 
//     	               							Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr), serviceTypeCd));
//        	}
//        }
//        
//        acctLaneServiceMonitoringDAO.addAccountLaneServiceMonitorings(acctLaneServiceMonitoringVO);
//    	
//       
//       }
//   
//    /**
//     * Add monitors to a service
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"n      
//     */
//    @RemoteMethod()
//    public void addAcctLaneServiceMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd, String emplyNbr) 
//    throws SQLException, NumberFormatException, ServiceLocatorException {
//       // TODO: put in DB Transaction
//        
//       // we will implicitly delete previously assigned monitors
//       // so, delete any monitor at service level for this shipperNbr and accountNbr
//       AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//       acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(Integer.parseInt(shipperNbr),
//               accountNbr, Integer.parseInt(laneNbr), serviceTypeCd);
//        
//       if (emplyNbr != null) {
//           AcctLaneServiceMonitoringVO acctLaneServiceMonitoringVO = new AcctLaneServiceMonitoringVO(emplyNbr, 
//               Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr), serviceTypeCd);
//           acctLaneServiceMonitoringDAO.addAccountLaneServiceMonitoring(acctLaneServiceMonitoringVO);
//       }
//    }
//    
//    /**
//     * Add monitor to a service
//     * @throws ServiceLocatorException 
//     * @throws NumberFormatException 
//     * @ejb:interface-method view-type="remote"n      
//     */
//    @RemoteMethod()
//    public void updateSelectedAcctLaneServiceMonitor(String shipperNbr, String accountNbr, 
//            String laneNbr, String serviceTypeCd, String emplyNbr, String oldEmpNbr) 
//    throws SQLException, NumberFormatException, ServiceLocatorException {
//    	
//    	AcctLaneServiceMonitoringDAO acctLaneServiceMonitoringDAO = new AcctLaneServiceMonitoringDAO();
//    	
//    	if (oldEmpNbr != null && oldEmpNbr.length() > 0)
//    	{
//    	    	
//    	//First delete the selected row monitor only on that service
//    	AcctLaneServiceMonitoringVO delAcctLaneServiceMonitoringVO = new AcctLaneServiceMonitoringVO(oldEmpNbr, 
//                Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr), serviceTypeCd);
//    	acctLaneServiceMonitoringDAO.deleteAccountLaneServiceMonitoring(delAcctLaneServiceMonitoringVO);
//    	}
//    	//Add the newly assigned monitor on that service
//    	
//    	
//    	if (emplyNbr != null) {
//	    	 AcctLaneServiceMonitoringVO addAcctLaneServiceMonitoringVO = new AcctLaneServiceMonitoringVO(emplyNbr, 
//	                 Integer.parseInt(shipperNbr), accountNbr, Integer.parseInt(laneNbr), serviceTypeCd);
//	         acctLaneServiceMonitoringDAO.addAccountLaneServiceMonitoring(addAcctLaneServiceMonitoringVO);
//    	}
//    	    	
//    }
//    
//    /**
//     * Update the GROUP_NBR in the SHIPMENT table of past shipments, if needed.
//     * @ejb:interface-method view-type="remote"
//     * @param groupNbr number of the shipper
//     * @param accountNbr number of the shipper
//     * @throws ServiceLocatorException 
//     */
//    @RemoteMethod()
//    public void updateGroupNbrPastShipments(String groupNbr, String accountNbr, String laneNbr, String svcTypeCd) 
//    	throws SQLException, ServiceLocatorException {
//       
//    	int groupNbrInt = Integer.parseInt(groupNbr);
//    	int laneNbrInt = Integer.parseInt(laneNbr);
//    	ShipmentDAO shipmentDAO = new ShipmentDAO();
//    	shipmentDAO.updateGroupNbrPastShipments(groupNbrInt, accountNbr, 
//    			laneNbrInt, svcTypeCd);
//    }
}
