package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.ServiceLocatorException;
import com.fedex.rise.vo.PerformanceVO;

public class ConfigurationDAO extends DatabaseDAO{
	/** Logger */
    private static Logger logger = LogManager.getLogger(ConfigurationDAO.class);
    
    /**
     * Persist the name and value to the Configuration table.
     * @param confgValueNm Name of configuration.
     * @param confgValueDesc Value of configuration.
     */
    public void doPersist(String  confgValueNm, String confgValueDesc) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection(); 
            ConfigurationPersister persister = 
            	new ConfigurationPersister(connection);
            persister.doPersist(confgValueNm, confgValueDesc);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Update the name and value to the Configuration table.
     * @param confgValueNm Name of configuration.
     * @param confgValueDesc Value of configuration.
     */
    public void updateConfiguration(String  confgValueNm, String confgValueDesc) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection();
            ConfigurationUpdater updater = new ConfigurationUpdater(connection);
            updater.updateConfiguration(confgValueNm, confgValueDesc);
        } finally {
            closeConnection(connection);
        }
    }
    
    /**
     * Persist or update the name and value to the Configuration table.
     * @param confgValueNm Name of configuration.
     * @param confgValueDesc Value of configuration.
     */
    public void doPersistOrUpdate(String  confgValueNm, String confgValueDesc) 
    	throws SQLException, ServiceLocatorException {
    	
        Connection connection = null;
        try {
            connection = initializeConnection();
            ConfigurationAccessor accessor = 
            	new ConfigurationAccessor(connection);
            if (accessor.getValue(confgValueNm)!= null){
            	// Update.
            	ConfigurationUpdater updater = 
            		new ConfigurationUpdater(connection);
            	updater.updateConfiguration(confgValueNm, confgValueDesc);
            	
            }else{
            	// Insert.
            	ConfigurationPersister persister = 
            		new ConfigurationPersister(connection);
            	persister.doPersist(confgValueNm, confgValueDesc);
            }
        } finally {
            closeConnection(connection);
        }
    }
}
