package com.fedex.rise.vo;

import java.io.Serializable;

public class AssociatedShipmentVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _trkng_item_nbr;              // VARCHAR2(12);
    private String _trkng_item_uniq_nbr;         // VARCHAR2(10);
    private String _assoc_trkng_item_nbr;        // VARCHAR2(12);
    private String _assoc_trkng_item_uniq_nbr;   // VARCHAR2(10);
    private char   _assoc_track_type_cd;         // 
        
    public AssociatedShipmentVO() {
        
    }
    
    public AssociatedShipmentVO(String _trkng_item_nbr, String _trkng_item_uniq_nbr,
                                String _assoc_trkng_item_nbr, String _assoc_trkng_item_uniq_nbr,
                                char _assoc_track_type_cd) {
        super();
        this._trkng_item_nbr = _trkng_item_nbr;
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
        this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
        this._assoc_trkng_item_uniq_nbr = _assoc_trkng_item_uniq_nbr;
        this._assoc_track_type_cd = _assoc_track_type_cd;
    }

    /**
     * @return the _assoc_trkng_item_nbr
     */
    public String get_assoc_trkng_item_nbr() {
        return _assoc_trkng_item_nbr;
    }
    
    /**
     * @param _assoc_trkng_item_nbr the _assoc_trkng_item_nbr to set
     */
    public void set_assoc_trkng_item_nbr(String _assoc_trkng_item_nbr) {
        this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
    }
    
    /**
     * @return the _assoc_trkng_item_uniq_nbr
     */
    public String get_assoc_trkng_item_uniq_nbr() {
        return _assoc_trkng_item_uniq_nbr;
    }
    
    /**
     * @param _assoc_trkng_item_uniq_nbr the _assoc_trkng_item_uniq_nbr to set
     */
    public void set_assoc_trkng_item_uniq_nbr(String _assoc_trkng_item_uniq_nbr) {
        this._assoc_trkng_item_uniq_nbr = _assoc_trkng_item_uniq_nbr;
    }
    
    /**
     * @return the _trkng_item_nbr
     */
    public String get_trkng_item_nbr() {
        return _trkng_item_nbr;
    }
    
    /**
     * @param _trkng_item_nbr the _trkng_item_nbr to set
     */
    public void set_trkng_item_nbr(String _trkng_item_nbr) {
        this._trkng_item_nbr = _trkng_item_nbr;
    }
    
    /**
     * @return the _trkng_item_uniq_nbr
     */
    public String get_trkng_item_uniq_nbr() {
        return _trkng_item_uniq_nbr;
    }
    
    /**
     * @param _trkng_item_uniq_nbr the _trkng_item_uniq_nbr to set
     */
    public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
        this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
    }
    
    /**
     * @return the _assoc_track_type_cd
     */
    public char get_assoc_track_type_cd() {
        return _assoc_track_type_cd;
    }

    /**
     * @param _assoc_track_type_cd the _assoc_track_type_cd to set
     */
    public void set_assoc_track_type_cd(char _assoc_track_type_cd) {
        this._assoc_track_type_cd = _assoc_track_type_cd;
    }
    
    public boolean hasAssocShipment() {
        if (_assoc_trkng_item_nbr != null) {
            return true;
        } else {
            return false;
        }
    }
    
    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + _assoc_track_type_cd;
        result = PRIME * result + ((_assoc_trkng_item_nbr == null) ? 0 : _assoc_trkng_item_nbr.hashCode());
        result = PRIME * result + ((_trkng_item_nbr == null) ? 0 : _trkng_item_nbr.hashCode());
        result = PRIME * result + ((_trkng_item_uniq_nbr == null) ? 0 : _trkng_item_uniq_nbr.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * This excludes the assoc trkng uniq nbr on purpose.  Association data can be found in both
     * the ML and SP.  For "Parent" associations in particular it seems the SP, will have the
     * unique id, but the ML will not.  To avoid extracting the data from both the ML and SP
     * because they don't have the exact same data, I have excluded the uniq number from the
     * association.  So when the contains method is used on the array list, they appear to
     * be the same because I am excluding the unique id
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final AssociatedShipmentVO other = (AssociatedShipmentVO) obj;
        if (_assoc_track_type_cd != other._assoc_track_type_cd)
            return false;
        if (_assoc_trkng_item_nbr == null) {
            if (other._assoc_trkng_item_nbr != null)
                return false;
        } else if (!_assoc_trkng_item_nbr.equals(other._assoc_trkng_item_nbr))
            return false;
        if (_trkng_item_nbr == null) {
            if (other._trkng_item_nbr != null)
                return false;
        } else if (!_trkng_item_nbr.equals(other._trkng_item_nbr))
            return false;
        if (_trkng_item_uniq_nbr == null) {
            if (other._trkng_item_uniq_nbr != null)
                return false;
        } else if (!_trkng_item_uniq_nbr.equals(other._trkng_item_uniq_nbr))
            return false;
        return true;
    }

    public String toString() {
         StringBuffer sb = new StringBuffer();
         sb.append(_assoc_track_type_cd);
         sb.append(":");
         sb.append(_trkng_item_nbr);
         sb.append(":");
         sb.append(_trkng_item_uniq_nbr);
         sb.append(":");
         sb.append(_assoc_trkng_item_nbr);
         sb.append(":");
         sb.append(_assoc_trkng_item_uniq_nbr);
         return sb.toString();
    }

}
