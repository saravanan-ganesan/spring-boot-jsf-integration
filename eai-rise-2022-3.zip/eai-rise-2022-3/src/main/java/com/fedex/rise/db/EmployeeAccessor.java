package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.EmployeeVO;

public class EmployeeAccessor extends OracleBase {
    private static Logger logger = LogManager.getLogger(EmployeeAccessor.class);
    
    public EmployeeAccessor(Connection con) {
        super(con);
    }
            
    private static final String selectAllEmployeesSQL =
        "select EMP_NBR, EMP_FIRST_NM, EMP_LAST_NM, EMP_ROLE_CD "
        + "from EMPLOYEE "
        + "order by EMP_LAST_NM";
    
    private static final String selectAllMonitorEmployeesSQL =
        "select EMP_NBR, EMP_FIRST_NM, EMP_LAST_NM, EMP_ROLE_CD "
        + "from EMPLOYEE "
        + "where EMP_ROLE_CD = 'M' "
        + "order by EMP_LAST_NM";
    
    private static final String selectEmployeeSQL = 
        "select " + "EMP_NBR, EMP_FIRST_NM, EMP_LAST_NM, EMP_ROLE_CD " 
        + "from Employee where EMP_NBR = ?"; 
    
    private static final String selectEmployeeNameSQL = 
        "select " + "EMP_NBR, EMP_FIRST_NM, EMP_LAST_NM, EMP_ROLE_CD " 
        + "from Employee where EMP_FIRST_NM = ? and EMP_LAST_NM = ? "; 
   
    /**
     * Get the list of employees
     * @return List of EmployeeVOs
     * @throws SQLException
     */
    public List getEmployees() throws SQLException {
        ArrayList employees = new ArrayList();
        
        try {
            setSqlSignature( selectAllEmployeesSQL, false, logger.isDebugEnabled() );

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
          
            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    // rows found
                    EmployeeVO employeeVO = new EmployeeVO();
                    employeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
                    employeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
                    employeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
                    employeeVO.set_emp_role_cd(rs.getString("EMP_ROLE_CD"));
                    
                    employees.add(employeeVO);
                }
            } else {
                return null;
            }            

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return employees;
    } 
   
    /**
     * Get the list of monitor employees
     * @return List of EmployeeVOs
     * @throws SQLException
     */
    public List getAllMonitorEmployees() throws SQLException {
        ArrayList employees = new ArrayList();
        
        try {
            setSqlSignature( selectAllMonitorEmployeesSQL, false, logger.isDebugEnabled() );

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
          
            execute();
            
            if ( hasResults ) {
                
                while(rs.next()) {
                    // rows found
                    EmployeeVO employeeVO = new EmployeeVO();
                    employeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
                    employeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
                    employeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
                    employeeVO.set_emp_role_cd(rs.getString("EMP_ROLE_CD"));
                    
                    employees.add(employeeVO);
                }
            } else {
                return null;
            }            

        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }
        return employees;
    }
    
    /**
     * Get the employee
     * @param emplyNbr
     * @return EmployeeVO
     * @throws SQLException 
     */
    public EmployeeVO getEmployee(String emplyNbr) throws SQLException {
        EmployeeVO employeeVO = null;
                
        try {
            setSqlSignature( selectEmployeeSQL, false, logger.isDebugEnabled() );
            
            pstmt.setString( 1, emplyNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    employeeVO = new EmployeeVO();
                        
                    employeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
                    employeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
                    employeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
                    employeeVO.set_emp_role_cd(rs.getString("EMP_ROLE_CD"));
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return employeeVO;
    }  
    
    /**
     * Get the employee
     * @param emplyNbr
     * @return EmployeeVO
     * @throws SQLException 
     */
    public EmployeeVO getEmployee(String firstName, String lastName) throws SQLException {
        EmployeeVO employeeVO = null;
                
        try {
            setSqlSignature( selectEmployeeNameSQL, false, logger.isDebugEnabled() );
            
            pstmt.setString( 1, firstName);
            pstmt.setString( 2, lastName);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
                
            execute();

            if ( hasResults ) {
                       
                while(rs.next()) {
                    employeeVO = new EmployeeVO();
                        
                    employeeVO.set_emp_nbr(rs.getString("EMP_NBR"));
                    employeeVO.set_emp_first_nm(rs.getString("EMP_FIRST_NM"));
                    employeeVO.set_emp_last_nm(rs.getString("EMP_LAST_NM"));
                    employeeVO.set_emp_role_cd(rs.getString("EMP_ROLE_CD"));
                }
            } else {
                return null;
            }
        } catch (SQLException sqle) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                logger.warn(sqle2.getMessage(), sqle2);
            }
        }
        return employeeVO;
    }
}
