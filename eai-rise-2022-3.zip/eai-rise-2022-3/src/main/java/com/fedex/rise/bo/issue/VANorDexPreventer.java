package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class VANorDexPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(VANorDexPreventer.class);
    private static ArrayList _preventingScans = new ArrayList();
    private static VANorDexPreventer _instance = new VANorDexPreventer();

    static {
        // The previous scans below will prevent a new issue being created.
       	_preventingScans.add(RiseConstants.VAN);
       	_preventingScans.add(RiseConstants.DEX);
    }
  
    private VANorDexPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	// If it has been delivered, do not create any new events.
        if (DeliveryPreventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (_preventingScans.contains(anPastEventVO.get_track_type_cd())) {
            logger.debug("Issue prevented by VAN or DEX Scans Preventer.");
            return true;
        }
             
        return false;
    }

    public static VANorDexPreventer getInstance() {
        return _instance;
    }
}
