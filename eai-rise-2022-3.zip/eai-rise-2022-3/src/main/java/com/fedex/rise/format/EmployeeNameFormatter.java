package com.fedex.rise.format;

/**
 * Format the Employee Name
 */
public class EmployeeNameFormatter {
  
    /**
     * Format like "firstname lastname (empNbr)"
     * 
     * @param firstName
     * @param lastName
     * @param emplyNbr
     * @return formatted employee name
     */
    public static String format(String firstName, String lastName,
            String emplyNbr) {
   
        StringBuffer sb = new StringBuffer();
        if (firstName != null && firstName.length()>0) {
           sb.append(firstName).append(' ');
        } 
        if (lastName != null && lastName.length()>0) {
           sb.append(lastName).append(' ');
        }
        if (emplyNbr != null && emplyNbr.length()>0) {
           sb.append('(').append(emplyNbr).append(')'); 
        }
        return sb.toString();
    }
}
