package com.fedex.rise.bean;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fedex.rise.bo.ShipperDelegate;
import com.fedex.rise.format.LaneFormatter;
import com.fedex.rise.vo.AccountLaneVO;
import com.fedex.rise.vo.LaneServiceVO;
import com.fedex.rise.vo.LaneVO;

/**
 * Backer bean for AccountLane, lanes associated with an account
 * 
 */
public class AccountLaneBean implements Serializable {
    /** serial id for serialisation versioning */
    private static final long serialVersionUID = 1L;
    
    private static final Log log = LogFactory.getLog(AccountLaneBean.class);

    /** delegate to get shipper data */
    private ShipperDelegate shipperDelegate = new ShipperDelegate();
    
    /** Shipper Tree */
    private ShipperTreeBean _shipperTreeBean = null;
   
    /** other key values, to identify an AccountLane */
    private String _shipperNbr = null;
    private String _accountNbr =  null;
    
    /** editable attributes */
    private String _laneNbr =  null;
    private String _laneName;
    private String[] _selectedServiceTypeCds = null;
   
    
    /** 
     * Default Constructor
     */
    public AccountLaneBean() {
        shipperDelegate = new ShipperDelegate();
        
        // get the ShipperTreeBean from the session, so we can get access to 
        // (1) the selected shipper node (we'll need the shipperNbr) or 
        // (2) the selected account node (we'll need the shipperNbr & accountNbr)
        Map params = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        _shipperTreeBean = (ShipperTreeBean)params.get("shipperTreeBean");
        init();
    }
    
    private void init() {
        // Get the selected node key values (shipperNbr, accountNbr)
        String[] keys = _shipperTreeBean.getSelectedKeys();
        _shipperNbr = keys[0];
        _accountNbr = keys[1];
 
        // determine if we are adding a new lane from the account (2 nodes, shipper, account)
        // or if we are showing the lane info (should be 3 nodes, shipper, account, lane);
        if (keys.length > 2) {
            _laneNbr = keys[2];
      
            // Get the selected lane info
            AccountLaneVO accountLaneVO = shipperDelegate.getAccountLane(_shipperNbr,
                   _accountNbr, _laneNbr);
            // TODO: use accountLaneVO info someday
            
            LaneVO laneVO = shipperDelegate.getLane(_laneNbr);
            _laneName = LaneFormatter.format(laneVO.get_orig_cntry_cd(), laneVO.get_dest_cntry_cd());
         
        }
    }
    
    
    /*---------------------------------------------------------------------
     * Getter/Setter methods
     *--------------------------------------------------------------------- 
     */
   
    /**
     * Set the lane name
     * @param laneName name of lane
     */
    public void setLaneName(String laneName) {
        _laneName = laneName;
    }

    /**
     * Get the lane name
     * @return laneName
     */
    public String getLaneName() {
        return _laneName;
    }
   
    /**
     * set selected Services (Add Services to a Lane)
     * @param services array of service type codes
     */
    public void setSelectedServices(String[] services) {
        log.debug("Entering setSelectedServices()");
        
        _selectedServiceTypeCds = services;
    }
    
    /**
     * get selected Services (Services on a Lane)
     * @return services array of service type codes
     */
    public String[] getSelectedServices() {
        log.debug("Entering getSelectedServices()");

        // get services for this shipper, account, lane
        List selectedServiceVOs = shipperDelegate.getLaneServices(_shipperNbr,
                _accountNbr, _laneNbr);
        
        if (selectedServiceVOs == null) {
           _selectedServiceTypeCds = null;
           return new String[0]; // no services yet, so default to none
        } else {
           //return services;
           _selectedServiceTypeCds = new String[selectedServiceVOs.size()];
           int i=0;
           for (Iterator itr=selectedServiceVOs.iterator(); itr.hasNext(); i++) {
               _selectedServiceTypeCds[i] = ((LaneServiceVO)itr.next()).get_svc_type_cd();
           }
           return _selectedServiceTypeCds;
        }
    }
    
    
    /*---------------------------------------------------------------------
     * Actions
     *--------------------------------------------------------------------- 
     */
    
    /**
     * Save Lane, add lanes or remove lanes from an Account
     */
    public String saveAccountLaneAction() {
        log.debug("Entering saveAccountLaneAction()");
        
        // add these lanes to the shippers account (causes adds, deletes, updates)
        shipperDelegate.addServiceToShipper(_shipperNbr, _accountNbr, _laneNbr, 
                _selectedServiceTypeCds);
        
        // TODO: handle errors
        return "success";
    }
   
    /**
     * Delete a Lane from an account
     */
    public String deleteAccountLaneAction() {
        log.debug("Entering deleteAccountLaneAction()");
 
        shipperDelegate.deleteLaneFromShipper(_shipperNbr, _accountNbr, _laneNbr);
        
        // tell shipper so this new node will not be selected 
        _shipperTreeBean.notifyDelete();
       
        // TODO: handle errors
        return "success";
    }
    
}
