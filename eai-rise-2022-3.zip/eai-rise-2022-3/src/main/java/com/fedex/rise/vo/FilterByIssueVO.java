package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class FilterByIssueVO implements Serializable {

	/** serializing version */
	private static final long serialVersionUID = 1L;

	private String _assoc_trkng_item_nbr;
	private String _trkng_item_nbr; // VARCHAR2(12);
	private String _trkng_item_uniq_nbr;

	private String _group_nm;
	private String _acct_nm;
	private String _shpr_cntry_cd;
	

	private String _recp_cntry_cd;
	private String _SVC_TYPE_CD;
	private String _acct_nbr; // VARCHAR2(9);
	private String _shpmt_type_cd; // VARCHAR2(3);
	private String _orig_loc_cd; // VARCHAR2(5);
	private String _dest_loc_cd; // VARCHAR2(5);
	private Date _ship_dt; // DATE;
	private Calendar _commit_dt; // DATE(7);
	private int _adj_commit_dt_offst_nbr;
	private String _last_event_track_loc_cd;// NUMBER(6);
	private String _last_stat_track_loc_cd;

	private String _last_stat_desc;
	private Date _last_stat_tmstp;
	private String _emp_first_nm;
	private String _emp_last_nm;
	private String _emp_nbr;

	/**
	 * Default Constructor
	 */
	public FilterByIssueVO() {
	}

	/**
	 * Think of this as a deep copy constructor
	 * 
	 * @param aShipmentVO
	 */
	public FilterByIssueVO(FilterByIssueVO aFilterByIssueVo) {
		super();
		this._assoc_trkng_item_nbr = aFilterByIssueVo._assoc_trkng_item_nbr;
		this._trkng_item_nbr = aFilterByIssueVo._trkng_item_nbr;
		this._trkng_item_uniq_nbr = aFilterByIssueVo._trkng_item_uniq_nbr;
		this._group_nm = aFilterByIssueVo._group_nm;
		this._acct_nm = aFilterByIssueVo._acct_nm;
		this._shpr_cntry_cd = aFilterByIssueVo._shpr_cntry_cd;
		this._recp_cntry_cd = aFilterByIssueVo._recp_cntry_cd;		
		this._SVC_TYPE_CD = aFilterByIssueVo._SVC_TYPE_CD;		
		this._acct_nbr = aFilterByIssueVo._acct_nbr;
		this._shpmt_type_cd = aFilterByIssueVo._shpmt_type_cd;
		this._orig_loc_cd = aFilterByIssueVo._orig_loc_cd;
		this._dest_loc_cd = aFilterByIssueVo._dest_loc_cd;
		if (aFilterByIssueVo._ship_dt != null) {
			this._ship_dt = (Date) aFilterByIssueVo._ship_dt.clone();
		} else {
			this._ship_dt = null;
		}
		if (aFilterByIssueVo._commit_dt != null) {
			this._commit_dt = (Calendar) aFilterByIssueVo._commit_dt.clone();
		} else {
			this._commit_dt = null;
		}

		this._adj_commit_dt_offst_nbr = aFilterByIssueVo._adj_commit_dt_offst_nbr;
		this._last_event_track_loc_cd = aFilterByIssueVo._last_event_track_loc_cd;
		this._last_stat_track_loc_cd = aFilterByIssueVo._last_stat_track_loc_cd;

		this._last_stat_desc = aFilterByIssueVo.get_last_stat_desc();

		if (aFilterByIssueVo._last_stat_tmstp != null) {
			this._last_stat_tmstp = (Date) aFilterByIssueVo.get_last_stat_tmstp().clone();
		} else {
			this._last_stat_tmstp = null;
		}

		this._emp_first_nm = aFilterByIssueVo._emp_first_nm;
		this._emp_last_nm = aFilterByIssueVo._emp_last_nm;
		this._emp_nbr = aFilterByIssueVo._emp_nbr;
	}

	public String get_group_nm() {
		return _group_nm;
	}

	public void set_group_nm(String _group_nm) {
		this._group_nm = _group_nm;
	}

	public String get_acct_nm() {
		return _acct_nm;
	}

	public void set_acct_nm(String _acct_nm) {
		this._acct_nm = _acct_nm;
	}

	
	public String get_shpr_cntry_cd() {
		return _shpr_cntry_cd;
	}

	public void set_shpr_cntry_cd(String _shpr_cntry_cd) {
		this._shpr_cntry_cd = _shpr_cntry_cd;
	}

	public String get_recp_cntry_cd() {
		return _recp_cntry_cd;
	}

	public void set_recp_cntry_cd(String _recp_cntry_cd) {
		this._recp_cntry_cd = _recp_cntry_cd;
	}
	
	
	

	public String get_SVC_TYPE_CD() {
		return _SVC_TYPE_CD;
	}

	public void set_SVC_TYPE_CD(String _SVC_TYPE_CD) {
		this._SVC_TYPE_CD = _SVC_TYPE_CD;
	}

	/**
	 * /**
	 * 
	 * @return the _last_stat_desc
	 */

	public String get_last_stat_desc() {
		return _last_stat_desc;
	}

	/**
	 * @param _last_stat_desc
	 *            the _last_stat_desc to set
	 */
	public void set_last_stat_desc(String _last_stat_desc) {
		this._last_stat_desc = _last_stat_desc;
	}

	public String get_trkng_item_uniq_nbr() {
		return _trkng_item_uniq_nbr;
	}

	public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
		this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
	}

	/**
	 * @return the _commit_dt
	 */
	public Calendar get_commit_dt() {
		return _commit_dt;
	}

	/**
	 * @param _commit_dt
	 *            the _commit_dt to set
	 */
	public void set_commit_dt(Calendar _commit_dt) {
		this._commit_dt = _commit_dt;
	}

	public String get_last_stat_track_loc_cd() {
		return _last_stat_track_loc_cd;
	}

	public void set_last_stat_track_loc_cd(String _last_stat_track_loc_cd) {
		this._last_stat_track_loc_cd = _last_stat_track_loc_cd;
	}

	/**
	 * @return the _adj_commit_dt_offst_nbr
	 */
	public int get_adj_commit_dt_offst_nbr() {
		return _adj_commit_dt_offst_nbr;
	}

	/**
	 * @param _adj_commit_dt_offst_nbr
	 *            the _adj_commit_dt_offst_nbr to set
	 */
	public void set_adj_commit_dt_offst_nbr(int _adj_commit_dt_offst_nbr) {
		this._adj_commit_dt_offst_nbr = _adj_commit_dt_offst_nbr;
	}

	public String get_last_event_track_loc_cd() {
		return _last_event_track_loc_cd;
	}

	public void set_last_event_track_loc_cd(String _last_event_track_loc_cd) {
		this._last_event_track_loc_cd = _last_event_track_loc_cd;
	}

	/**
	 * @return the _ship_dt
	 */
	public Date get_ship_dt() {
		return _ship_dt;
	}

	/**
	 * @param _ship_dt
	 *            the _ship_dt to set
	 */
	public void set_ship_dt(Date _ship_dt) {
		this._ship_dt = _ship_dt;
	}

	/**
	 * @return the _acct_nbr
	 */
	public String get_acct_nbr() {
		return _acct_nbr;
	}

	/**
	 * @param _acct_nbr
	 *            the _acct_nbr to set
	 */
	public void set_acct_nbr(String _acct_nbr) {
		this._acct_nbr = _acct_nbr;
	}

	/**
	 * @return the _dest_loc_cd
	 */
	public String get_dest_loc_cd() {
		return _dest_loc_cd;
	}

	/**
	 * @param _dest_loc_cd
	 *            the _dest_loc_cd to set
	 */
	public void set_dest_loc_cd(String _dest_loc_cd) {
		this._dest_loc_cd = _dest_loc_cd;
	}

	/**
	 * @return the _orig_loc_cd
	 */
	public String get_orig_loc_cd() {
		return _orig_loc_cd;
	}

	/**
	 * @param _orig_loc_cd
	 *            the _orig_loc_cd to set
	 */
	public void set_orig_loc_cd(String _orig_loc_cd) {
		this._orig_loc_cd = _orig_loc_cd;
	}

	/**
	 * @return the _shpmt_type_cd
	 */
	public String get_shpmt_type_cd() {
		return _shpmt_type_cd;
	}

	/**
	 * @param _shpmt_type_cd
	 *            the _shpmt_type_cd to set
	 */
	public void set_shpmt_type_cd(String _shpmt_type_cd) {
		this._shpmt_type_cd = _shpmt_type_cd;
	}

	public String get_assoc_trkng_item_nbr() {
		return _assoc_trkng_item_nbr;
	}

	public void set_assoc_trkng_item_nbr(String _assoc_trkng_item_nbr) {
		this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
	}

	public String get_emp_first_nm() {
		return _emp_first_nm;
	}

	public void set_emp_first_nm(String _emp_first_nm) {
		this._emp_first_nm = _emp_first_nm;
	}

	public String get_emp_last_nm() {
		return _emp_last_nm;
	}

	public void set_emp_last_nm(String _emp_last_nm) {
		this._emp_last_nm = _emp_last_nm;
	}

	public String get_emp_nbr() {
		return _emp_nbr;
	}

	public void set_emp_nbr(String _emp_nbr) {
		this._emp_nbr = _emp_nbr;
	}

	/**
	 * @return the _trkng_item_nbr
	 */
	public String get_trkng_item_nbr() {
		return _trkng_item_nbr;
	}

	/**
	 * @param _trkng_item_nbr
	 *            the _trkng_item_nbr to set
	 */
	public void set_trkng_item_nbr(String _trkng_item_nbr) {
		this._trkng_item_nbr = _trkng_item_nbr;
	}

	/**
	 * @return the _last_stat_tmstp
	 */
	public Date get_last_stat_tmstp() {
		return _last_stat_tmstp;
	}

	/**
	 * @param _last_stat_tmstp
	 *            the _last_stat_tmstp to set
	 */
	public void set_last_stat_tmstp(Date _last_stat_tmstp) {
		this._last_stat_tmstp = _last_stat_tmstp;
	}

	/**
	 * Truncate the String to the given length with no warnings or error raised
	 * if it is bigger.
	 *
	 * @param value
	 *            String to be truncated
	 * @param length
	 *            Maximum length of string
	 *
	 * @return Returns value if value is null or value.length() is less or equal
	 *         to than length, otherwise a String representing value truncated
	 *         to length.
	 */
	private String truncate(String value, int length) {
		if (value != null && value.length() > length)
			value = value.substring(0, length);
		return value;
	}

}
