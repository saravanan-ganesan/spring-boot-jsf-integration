package com.fedex.rise.constant;

public interface QueryConstant {

	String GET_FILTER_BY_ISSUES = "SELECT DISTINCT issue.issueTypeCd "
									+ "FROM IssueEntity issue "
									+ "WHERE issue.issueTypeCd is null "
									+ "AND  issue.issueTmstp <= CURRENT_TIMESTAMP";
}
