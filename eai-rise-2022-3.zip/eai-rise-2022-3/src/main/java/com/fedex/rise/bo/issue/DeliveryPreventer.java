package com.fedex.rise.bo.issue;

import java.util.ArrayList;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.bo.issue.STAT31Preventer;
import com.fedex.rise.bo.issue.STAT41Preventer;
import com.fedex.rise.bo.issue.STAT84Preventer;
import com.fedex.rise.util.RiseConstants;
import com.fedex.rise.vo.EventVO;
import com.fedex.rise.vo.IssueVO;
import com.fedex.rise.vo.ShipmentVO;

public class DeliveryPreventer extends Preventer {
	private static Logger logger = LogManager.getLogger(DeliveryPreventer.class);
    private static ArrayList _deliveryScans = new ArrayList();
    private static DeliveryPreventer _instance = new DeliveryPreventer();
    
    static {
        // These scans are determined by me to mean a delivery has occurred
        _deliveryScans.add(RiseConstants.POD);
        _deliveryScans.add(RiseConstants.DDEX);   
    };
    
    private DeliveryPreventer() {}
    
    public boolean isPrevented(EventVO anEventVO, EventVO anPastEventVO, 
    		IssueVO anIssueVO, ShipmentVO anShipmentVO) {
    	
        if (_deliveryScans.contains(anPastEventVO.get_track_type_cd())) {
        	logger.debug("Issue prevented by Delivery Scan:" + anPastEventVO.get_track_type_cd());
            return true;
        }
        
        // Check if a STAT31, STAT41, or STAT84 will prevent an issue.
        if (STAT31Preventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (STAT41Preventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        if (STAT84Preventer.getInstance().isPrevented(anEventVO, anPastEventVO, 
        		anIssueVO, anShipmentVO)) {
            return true;
        }
        
        return false;
    }
    
    
    
    public static DeliveryPreventer getInstance() {
        return _instance;
    }

}
