package com.fedex.rise.webejb;

/**
 * 
 * @ejb:bean name="ShipmentBean" display-name="ShipmentEJB" jndi-name="ShipmentEJB"
 *           local-jndi-name="LocalShipmentEJB" type="Stateless"
 *           view-type="both"
 * 
 * @ejb:home extends="javax.ejb.EJBHome"
 *           local-extends="javax.ejb.EJBLocalHome"
 * 
 * @ejb:interface extends="javax.ejb.EJBObject"
 *                local-extends="javax.ejb.EJBLocalObject"
 * 
 * @weblogic.enable-call-by-reference True
 
 * @weblogic.pool max-beans-in-free-pool="40" 
 * initial-beans-in-free-pool="10"
 * 
 * @ejb.transaction type="Supports"
 */
/**
* ShipmentEJB
* This class implements the EJB which is accessible via the JSPs. It is a
* stateless SessionBean. This class implements the facade for the Business
* Objects and or Data Access Objects. All EJB/J2EE related things should be
* implemented here leaving the BO's with no knowledge of the EJB/J2EE
* environment.
*/
//@JndiName(remote="webejb/ShipmentEJBRemote")
//@Session(ejbName = "ShipmentEJB",
//        maxBeansInFreePool="3",
//        initialBeansInFreePool="1",
//        type = Session.SessionType.STATELESS,
//        defaultTransaction=Constants.TransactionAttribute.SUPPORTS,
//        transactionType=Session.SessionTransactionType.BEAN,
//        enableCallByReference=Constants.Bool.TRUE)
public class ShipmentEJB { //implements SessionBean {
//
//    private static final long serialVersionUID = 1L;
//
//    /** Logger */
//    private static Logger logger = LogManager.getLogger(ShipmentEJB.class);
//    
//    private SessionContext mySessionContext = null;
//
//    public SessionContext getSessionContext() {
//        return mySessionContext;
//    }
//
//    public void setSessionContext(SessionContext aSessionContext)
//            throws RemoteException {
//        mySessionContext = aSessionContext;
//    }
//
//    public void ejbActivate() {
//        System.out.println("Activate ShipmentEJB");
//    }
//
//    public void ejbPassivate() {
//        System.out.println("Passivate ShipmentEJB");
//    }
//
//    /**
//     * @ejb:create-method
//     */
//    public void ejbCreate() {
//        System.out.println("EJB Create ShipmentEJB");
//    }
//
//    /**
//     * @ejb:remove-method
//     */
//    public void ejbRemove() { 
//        System.out.println("EJB Remove ShipmentEJB");
//    }
//    
//    
//    /**
//	 * @ejb:interface-method view-type="remote"
//	 */
//	@RemoteMethod()
//	public List getFilterByIssues() throws SQLException {
//
//		MonitorDAO monitorDAO = new MonitorDAO();
//		return monitorDAO.getFilterByIssues();
//	}
//	
//	/**
//	 * @ejb:interface-method view-type="remote"
//	 */
//	@RemoteMethod()
//	public List getfilterByIssueDetails(String[] filterByIssues, int getfilterByIssueDetails) throws SQLException {
//		MonitorDAO monitorDAO = new MonitorDAO();
//		return monitorDAO.getfilterByIssueDetails(filterByIssues, getfilterByIssueDetails);
//	}
//	
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getMAWBShipments(int aGroupNbr, String anAcctNbr, int aLaneNbr, 
//            String aServiceType, boolean issuesOnly, int aStartIndex, 
//            int anEndIndex, String sortColumn, boolean isSortAscending, 
//            int shipDateOffsetInt)
//            throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getMAWBShipments(aGroupNbr, anAcctNbr, aLaneNbr, 
//        		aServiceType, issuesOnly, aStartIndex, anEndIndex, sortColumn, 
//        		isSortAscending, shipDateOffsetInt);
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public int getMAWBShipmentsCount(int aGroupNbr, String anAcctNbr, 
//    		int aLaneNbr, String aServiceType, boolean issuesOnly, 
//    		int shipDateOffsetInt) throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getMAWBShipmentsCount(aGroupNbr, anAcctNbr, aLaneNbr, 
//        		aServiceType, issuesOnly, shipDateOffsetInt);
//             
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public int getCRNShipmentsCount(String acctNbr, 
//    		Date fromDate, Date toDate, String laneNbrStr, int monthNbr, 
//    		String performanceType) throws SQLException {
//        
//        PerformanceDAO performanceDAO = new PerformanceDAO();
//        return performanceDAO.getShipmentsCount(acctNbr, fromDate, toDate, 
//        		laneNbrStr, monthNbr, performanceType);
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public ShipmentVO getShipment(String aTrkngItemNbr, String aTrkngUniqItemNbr)
//            throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getShipment(aTrkngItemNbr, aTrkngUniqItemNbr);
//    }
//    
//    /**
//     * Get the list of CRNs for a MAWB 
//     * Allows "paging" the results by selecting the first and last index to retrieve.
//     * 
//     * @param aParntTrkngItemNbr MAWB tracking number
//     * @param aParntTrkngUniqItemNbr MAWB tracking unique number
//     * @param issuesOnly true to get only CRNs with issue
//     * @param aStartIndex start rownum, for paging results
//     * @param anEndIndex end rownum, for paging results
//     * @param sortColumn column to sort on
//     * @param isSortAscending true to filter by Ascending, false for descending
//     * @param filterByIssues the Issue Type Cd(s) to filter on 
//     * @param shipDt of the MAWB 
//     * @return List of ShipmentVOs
//     * @throws SQLException
//     * 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getCRNShipments(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr, boolean issuesOnly,
//            int startIndex, int endIndex, String sortColumn, boolean isSortAscending, String[] filterByIssues,
//            Date shipDt) 
//            throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getCRNShipments(aParntTrkngItemNbr, aParntTrkngUniqItemNbr, 
//        		issuesOnly, startIndex, endIndex, sortColumn, isSortAscending, 
//        		filterByIssues, shipDt);
//    }
//    
//    /**
//     * Get the list of CRN Issues for a MAWB 
//     * 
//     * @param aParntTrkngItemNbr MAWB tracking number
//     * @param aParntTrkngUniqItemNbr MAWB tracking unique number
//     * @return List of Issue Type Cds
//     * @throws SQLException
//     * 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getCRNIssues(String aParntTrkngItemNbr, String aParntTrkngUniqItemNbr) throws SQLException {    
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getCRNIssues(aParntTrkngItemNbr, aParntTrkngUniqItemNbr);
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getCRNShipments(String acctNbr, Date fromDate, Date toDate,
//    		String laneNbrStr, int monthNbr, String performanceType, 
//    		int startIndex, int endIndex, String sortColumn, 
//    		boolean isSortAscending) throws SQLException {
//        
//        PerformanceDAO performanceDAO = new PerformanceDAO();
//        return performanceDAO.getCRNShipments(acctNbr, fromDate, toDate, 
//        		laneNbrStr, monthNbr, performanceType, startIndex, endIndex, 
//        		sortColumn, isSortAscending);
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getShipmentViaRtrnTrkngNbr(String aRtrnTrkngItemNbr, String aRtrnTrkngUniqItemNbr)
//                                           throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getShipmentViaRtrnTrkngNbr(aRtrnTrkngItemNbr, aRtrnTrkngUniqItemNbr);    
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getEvents(String aTrkngItemNbr, String aTrkngUniqItemNbr)
//                          throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO(); 
//        return monitorDAO.getEvents(aTrkngItemNbr, aTrkngUniqItemNbr);
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getIssues(String aTrkngItemNbr, String aTrkngUniqItemNbr)
//                          throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getIssues(aTrkngItemNbr, aTrkngUniqItemNbr);   
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getComments(String aTrkngItemNbr, String aTrkngUniqItemNbr)
//                            throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getComments(aTrkngItemNbr, aTrkngUniqItemNbr);
//    }
//    
//    /**
//     * @throws SQLException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void saveComment(ShipmentCommentVO aShipmentCommentVO) throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        monitorDAO.saveComment(aShipmentCommentVO);
//    }
//
//    /**
//     * @throws SQLException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void saveMawbAttributes(MAWBAttributesVO aVO) throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        monitorDAO.saveMAWBAttributes(aVO);
//    }
//    
//    /**
//     * @throws SQLException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getCrnStateCounts(String aTrkngItemNbr, String aTrkngItemUniqNbr) throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getCrnStateCounts(aTrkngItemNbr, aTrkngItemUniqNbr);
//    }    
//
//    /**
//     * Get the CRN count for the specified MAWB Tracking Nbr
//     * 
//     * @param aTrkngItemNbr MAWB tracking number
//     * @param aTrkngUniqItemNbr MAWB tracking unique number
//     * @param issuesOnly true to get only CRNs with issue
//     * @param filterByIssues the Issue Type Cd(s) to filter on 
//     * @throws SQLException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public int getCrnCount(String aTrkngItemNbr, String aTrkngItemUniqNbr, boolean issuesOnly,
//            String[] filterByIssues) throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getCrnCount(aTrkngItemNbr, aTrkngItemUniqNbr, issuesOnly, filterByIssues);
//    }    
//    //start WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
//    @RemoteMethod()
//    public int getAllCrnsCount(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd, int shipDateOffsetInt) throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getAllCrnsCount(shipperNbr, accountNbr, laneNbr, serviceTypeCd,shipDateOffsetInt);
//    } 
//   
//    
//    @RemoteMethod()
//    public List getAllCrns(int shipperNbr, String accountNbr, int laneNbr, String serviceTypeCd,
//            int startIndex, int endIndex, String sortColumn, boolean isSortAscending, int shipDateOffsetInt,
//            String[] filterByIssues) throws SQLException {
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getAllCrns(shipperNbr, accountNbr, laneNbr, serviceTypeCd,startIndex,endIndex,sortColumn,isSortAscending,shipDateOffsetInt,filterByIssues);
//    } 
//    //end WR #:CRN all for OC, JDK maintenance and weblgoic startup changes
//    /**
//     * @throws SQLException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void adjustCRNCommitDates(int aCRNDeliveryDtAdjustment, String aTrkngItemNbr,
//            String aTrkngItemUniqNbr) throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        monitorDAO.adjustCRNCommitDates(aCRNDeliveryDtAdjustment, aTrkngItemNbr, aTrkngItemUniqNbr);
//    }
//    
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getReferenceNotes(String aTrkngItemNbr, String aTrkngUniqItemNbr)
//                                  throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getReferenceNotes(aTrkngItemNbr, aTrkngUniqItemNbr);    
//    }
//
//    /**
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public List getRelatedAirbills(String aTrkngItemNbr, String aTrkngUniqItemNbr)
//                                   throws SQLException {
//        
//        MonitorDAO monitorDAO = new MonitorDAO();
//        return monitorDAO.getRelatedAirbills(aTrkngItemNbr, aTrkngUniqItemNbr);     
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */
//    @RemoteMethod()
//    public void updateIssue(IssueVO issue) throws SQLException, ServiceLocatorException {
//       
//        IssueDAO issueDAO = new IssueDAO();
//        issueDAO.updateIssue(issue);
//    }
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */  
//    @RemoteMethod()
//    public void createMonitorIssue(IssueVO anIssue) throws SQLException, ServiceLocatorException {   
//        IssueDAO issueDAO = new IssueDAO();
//        boolean result = issueDAO.persistIssue(anIssue);
//        if (!result) {
//            issueDAO.updateIssue(anIssue);
//        }
//    }    
//    
//    /**
//     * @throws ServiceLocatorException 
//     * @ejb:interface-method view-type="remote"
//     */    
//    @RemoteMethod()
//    public void saveWorkedStatus(String statusCd, String aTrkngItemNbr, String aTrkngItemUniqNbr) 
//           throws SQLException, ServiceLocatorException {   
//        MonitorDAO monitorDAO = new MonitorDAO();
//        monitorDAO.saveWorkedStatus(statusCd, aTrkngItemNbr, aTrkngItemUniqNbr);     
//    }
}
