package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

public class AccountGroupDeleter extends OracleBase {

    private static Logger logger = LogManager.getLogger(AccountGroupDeleter.class);

    public AccountGroupDeleter(Connection con) {
        super(con);
    }

    private static final String deleteAccountSQL = "Delete from Account_Group where " +
                "GROUP_NBR = ?";

    public void deleteAccountGroup(int aGroupNbr) throws SQLException {

        try {
            setSqlSignature(deleteAccountSQL, false, logger.isDebugEnabled());

            pstmt.setInt(1, aGroupNbr);

            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }

            execute();

       } catch (SQLException sqle) {
           logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                   + ": ErrorCode: " + sqle.getErrorCode()); 
           throw sqle;
       } finally {
           try {
               cleanResultSet();
           } catch (SQLException sqle2) {
               sqle2.printStackTrace();
               throw sqle2;
           }
       }
    }
}
