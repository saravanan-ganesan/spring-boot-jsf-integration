package com.fedex.rise.util;

import java.io.Serializable;
import java.util.AbstractList;
import java.util.List;

/** 
 * This is a list that can page forward and backwards, so only one page (X rows) of data is
 * loaded/fetched at a time.
 */
public class PagedList extends AbstractList implements Serializable {
    /** serial id for serialization versioning */
    private static final long serialVersionUID = 1L;
    
    /** backing model for the list */    
    private Pageable model;        

    /** cached page of loaded items */    
    private List loaded;

    /** number of results to fetch, each time */    
    private int pageSize;    

    /** current page we have loaded */ 
    private int currentPage = 0;

    /** size of items (all pages) */ 
    private int size = -1;
    
    /**     
     * Create a PagedList backed by the given query, using pageSize results     
     * per page, and expecting numResults from the query.     
     */    
    public PagedList(Pageable model, int pageSize) {       
        this.model = model;        
        this.pageSize = pageSize;        
    }        
    
    /**
     * Fetch an item from the list or loading the new page containing it if it isn't in the cache.
     */     
    public Object get(int item) {         
        // determine the page this index(i) is on
        int page = item > 0 ? ((item / pageSize) + 1) : 1;
        
        // if page isn't in cache, load the page that has this item
        if (page != currentPage) {
            loaded = model.getPage(page, pageSize);
            // cache size, recalc after each new page
            size = model.getSize();
            currentPage = page;
        } 
      
        // return the correct item in the cached page
        int index = item % pageSize;
        
        if (loaded.size() == 0) {
            return null;
        } else {
            return loaded.get(index);
        }
    }     
    
    /**      
     * Return the total number of items in the list. 
     */     
    public int size() {         
        // cache the size
        if (size == -1)
            size = model.getSize();
        
        return size;
    }

    /**
     * @param pageSize the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }          

}