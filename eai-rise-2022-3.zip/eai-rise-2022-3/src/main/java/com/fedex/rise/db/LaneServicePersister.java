package com.fedex.rise.db;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.Logger;import org.apache.logging.log4j.LogManager;

import com.fedex.rise.vo.LaneServiceVO;

public class LaneServicePersister extends OracleBase {
   private static Logger logger = LogManager.getLogger(LaneServicePersister.class);
    
    public LaneServicePersister(Connection con) {
        super(con);
    }
           
    private static final String addLaneServiceSQL =
        "Insert into Lane_Service(" +
            "SVC_TYPE_CD, " +
            "LANE_NBR, " +
            "GROUP_NBR, " +
            "ACCT_NBR, " +
            "COMMIT_DAYS_QTY, " +
            "PRIM_CONT_NM, " +
            "PRIM_CONT_PH_NBR, " +
            "PRIM_CONT_FAX_NBR, " +
            "PRIM_CONT_EMAIL_DESC, " +
            "SCNDY_CONT_NM, " +
            "SCNDY_CONT_PH_NBR, " +
            "SCNDY_CONT_FAX_NBR, " +
            "SCNDY_CONT_EMAIL_DESC, " +
            "PICKUP_DAY_GRP, " +
            "LIFT_DAY_GRP, " +
            "INPUT_TMSTP, " +
            "LAST_UPDT_TMSTP)" +
             "values(?,?,?,?,?,?,?,?," +
                    "?,?,?,?,?,?,?," +
                    "SYSDATE, SYSDATE)";        
    
    public void addLaneService(LaneServiceVO anLaneServiceVO) throws SQLException {
        
        try {
            setSqlSignature( addLaneServiceSQL, false, logger.isDebugEnabled() );

            pstmt.setString( 1, anLaneServiceVO.get_svc_type_cd());
            pstmt.setInt(    2, anLaneServiceVO.get_lane_nbr());
            pstmt.setInt( 3, anLaneServiceVO.get_group_nbr());
            pstmt.setString( 4, anLaneServiceVO.get_acct_nbr());
            pstmt.setString( 5, anLaneServiceVO.get_commit_days_qty());
            pstmt.setString( 6, anLaneServiceVO.get_prim_cont_nm());
            pstmt.setString( 7, anLaneServiceVO.get_prim_cont_ph_nbr());
            pstmt.setString( 8, anLaneServiceVO.get_prim_cont_fax_nbr());
            pstmt.setString( 9, anLaneServiceVO.get_prim_cont_email_desc());
            pstmt.setString(10, anLaneServiceVO.get_scndy_cont_nm());
            pstmt.setString(11, anLaneServiceVO.get_scndy_cont_ph_nbr());
            pstmt.setString(12, anLaneServiceVO.get_scndy_cont_fax_nbr());
            pstmt.setString(13, anLaneServiceVO.get_scndy_cont_email_desc());
            pstmt.setString(14, String.valueOf(anLaneServiceVO.get_pickup_day_grp()));
            pstmt.setString(15, String.valueOf(anLaneServiceVO.get_lift_day_grp()));
           
           
            if (logger.isDebugEnabled()) {
                logger.debug(pstmt.toString());
            }
            
            execute();

        } catch ( SQLException sqle ) {
            logger.error("DB_SQL_ERROR: " + sqle.getMessage() + ": SQLState: " + sqle.getSQLState()
                    + ": ErrorCode: " + sqle.getErrorCode()); 
            throw sqle;
        } finally {
            try {
                cleanResultSet();
            } catch (SQLException sqle2) {
                sqle2.printStackTrace();
                throw sqle2;
            }
        }    
    }       
}
