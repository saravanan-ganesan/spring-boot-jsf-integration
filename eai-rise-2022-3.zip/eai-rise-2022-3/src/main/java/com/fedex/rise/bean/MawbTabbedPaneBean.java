package com.fedex.rise.bean;

import java.io.Serializable;

import javax.faces.event.AbortProcessingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.custom.tabbedpane.TabChangeEvent;
import org.apache.myfaces.custom.tabbedpane.TabChangeListener;

/**
 * Tabbed Pane Bean to maintain tab state for the MAWB Details dialog.
 * Tab: Details, Events, CRNs
 * 
 * TODO: rename tab1 to details, etc.
 */
public class MawbTabbedPaneBean implements Serializable, TabChangeListener  {
    private static final Log log = LogFactory.getLog(MawbTabbedPaneBean.class);

    /** serialize id */
    private static final long serialVersionUID = 1L;

    private boolean _tab1Visible = true;
    private boolean _tab2Visible = true;
    private boolean _tab3Visible = true;
    private boolean _tab4Visible = true;
    
    /** currently selected tab index */
    private int _selectedIndex = 0;

    public MawbTabbedPaneBean() {
    }
    
    public boolean isTab1Visible() {
        return _tab1Visible;
    }

    public void setTab1Visible(boolean tab1Visible) {
        _tab1Visible = tab1Visible;
    }

    public boolean isTab2Visible() {
        return _tab2Visible;
    }

    public void setTab2Visible(boolean tab2Visible) {
        _tab2Visible = tab2Visible;
    }

    public boolean isTab3Visible() {
        return _tab3Visible;
    }

    public void setTab3Visible(boolean tab3Visible) {
        _tab3Visible = tab3Visible;
    }
    
    public boolean isTab4Visible() {
        return _tab4Visible;
    }

    public void setTab4Visible(boolean tab4Visible) {
        _tab4Visible = tab4Visible;
    }
    
    public Integer getSelectedIndex() {
        return new Integer(_selectedIndex);
    }
    
    public void setSelectedIndex(int selectedIndex) {
        _selectedIndex = selectedIndex;
    }
    
    /* (non-Javadoc)
     * @see org.apache.myfaces.custom.tabbedpane.TabChangeListener#processTabChange(org.apache.myfaces.custom.tabbedpane.TabChangeEvent)
     */
    public void processTabChange(TabChangeEvent event) throws AbortProcessingException {
        if (log.isDebugEnabled())
            log.debug("processTabChange(): " + event.getNewTabIndex() + " " + event.getPhaseId());
        _selectedIndex = event.getNewTabIndex();
    }
    
}
