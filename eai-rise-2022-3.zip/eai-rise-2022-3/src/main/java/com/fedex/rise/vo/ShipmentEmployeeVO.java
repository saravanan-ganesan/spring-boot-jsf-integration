package com.fedex.rise.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * Shipment Value Object (or Transfer Object) used to encapsulate the shipment
 * data for transport.
 */
public class ShipmentEmployeeVO implements Serializable {
    /** serializing version */
    private static final long serialVersionUID = 1L;
    
    private String _group_nm;
    private String _track_type_cd;
    private String _orig_cntry_cd;
    private String _dest_cntry_cd;    
    private String _acct_nm;            		
    private String _assoc_trkng_item_nbr;
    private String _trkng_item_nbr;              // VARCHAR2(12);
    private String _trkng_item_uniq_nbr;         // VARCHAR2(10);
    private int    _grp_nbr;                     // NUMBER(6);
    private String _grp_nm;                      // VARCHAR2(30);
    private String _acct_nbr;                    // VARCHAR2(9);
    private int    _lane_nbr;                    // NUMBER(6);
    private String _lane_string;                    // NUMBER(6);
    private String _svc_type_cd;                 // VARCHAR2(10);
    private String _shpmt_type_cd;               // VARCHAR2(3);
    private int    _trkng_item_form_cd;          // NUMBER(4);
    private int    _pack_type_cd;                // NUMBER(2);
    private String _orig_loc_cd;                 // VARCHAR2(5);
    private String _dest_loc_cd;                 // VARCHAR2(5);
    private int    _shpmt_wgt;                   // NUMBER(10,6);
    private double _shpmt_wgt_double;                  
    private char   _shpmt_uom_cd = ' ';          // CHAR(1);
    private Date   _ship_dt;                     // DATE;
    private String _shpr_co_nm;                  // VARCHAR2(35);
    private String _shpr_ph_nbr;                 // VARCHAR2(15);
    private String _shpr_addr_line_one_desc;     // VARCHAR2(35);
    private String _shpr_addr_line_two_desc;     // VARCHAR2(35);
    private String _shpr_addr_line_three_desc;   // VARCHAR2(35);
    private String _shpr_city_nm;                // VARCHAR2(30);
    private String _shpr_pstl_cd;                // VARCHAR2(9);
    private String _shpr_cntry_cd;               // VARCHAR2(2);
    private String _shpr_st_prov_cd;             // VARCHAR2(2);
    private String _recp_co_nm;                  // VARCHAR2(35);
    private String _recp_ph_nbr;                 // VARCHAR2(15);
    private String _recp_addr_line_one_desc;     // VARCHAR2(35);
    private String _recp_addr_line_two_desc;     // VARCHAR2(35);
    private String _recp_addr_line_three_desc;   // VARCHAR2(35);
    private String _recp_city_nm;                // VARCHAR2(30);
    private String _recp_st_prov_cd;             // VARCHAR2(2);
    private String _recp_cntry_cd;               // VARCHAR2(2);
    private String _recp_pstl_cd;                // VARCHAR2(9);
    private String _actl_del_nm;                 // VARCHAR2(35);
    private String _actl_addr_line_one_desc;     // VARCHAR2(35);
    private Calendar   _del_dt;                  // DATE;
    private String _spcl_hndlg_grp;              // VARCHAR2(8);
    private String _crtg_agent_co_nm;            // VARCHAR2(35);
    private String _cstms_curr_cd;               // VARCHAR2(3);
    private int    _cstms_value_amt;             // NUMBER(10,2);
    private int    _dimnl_wgt;                   // NUMBER(10,6);
    private int    _inv_amt;                     // NUMBER(10,2);
    private int    _shpmt_pkg_qt;                // NUMBER(4);
    private Calendar _last_event_tmstp;          // TIMESTAMP(6);
    private String _last_event_track_type_cd;    // VARCHAR2(2);
    private String _last_event_track_loc_cd;
    private Calendar _commit_dt;                 // DATE(7);
    private Calendar _adj_commit_dt;             // DATE(7);
    private int    _adj_commit_dt_offst_nbr;     // NUMBER(6);
    private Date   _commit_date;             // DATE(7);
    private String _perf_rsult_cd;               // VARCHAR2(11);
    private int   _package_piece_qty;            // NUMBER(4);
    private int   _delivery_qty;                 // NUMBER(6);
    private char _skid_intact_flag = ' ';        // CHAR(1);
    private char _quantity_observed_flag = ' ';  // CHAR(1);
    private Calendar _est_avail_for_delv_dt;
    private String _last_stat_desc;
    private Calendar _cleared_cstms_tmstp;
    
    private String _emp_nbr;
    private String _emp_first_nm;
    private String _emp_last_nm;
    private String _emp_role_cd;
    
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

    /**
     * @return the _dest_cntry_cd
     */
    public String get_dest_cntry_cd() {
        return _dest_cntry_cd;
    }
    /**
     * @param _dest_cntry_cd the _dest_cntry_cd to set
     */
    public void set_dest_cntry_cd(String _dest_cntry_cd) {
        this._dest_cntry_cd = _dest_cntry_cd;
    }
    
    /**
     * @return the _orig_cntry_cd
     */
    public String get_orig_cntry_cd() {
        return _orig_cntry_cd;
    }
    /**
     * @param _orig_cntry_cd the _orig_cntry_cd to set
     */
    public void set_orig_cntry_cd(String _orig_cntry_cd) {
        this._orig_cntry_cd = _orig_cntry_cd;
    }    
	
	public String get_acct_nm() {
		return _acct_nm;
	}
	public void set_acct_nm(String _acct_nm) {
		this._acct_nm = _acct_nm;
	}	
	public String get_acct_nbr() {
		return _acct_nbr;
	}
	public void set_acct_nbr(String _acct_nbr) {
		this._acct_nbr = _acct_nbr;
	}
	public void set_lane_string(String _lane_string) {
		this._lane_string = _lane_string;
	}
	public String get_lane_string() {
		return _lane_string;
	}
	public String get_actl_addr_line_one_desc() {
		return _actl_addr_line_one_desc;
	}
	public void set_actl_addr_line_one_desc(String _actl_addr_line_one_desc) {
		this._actl_addr_line_one_desc = _actl_addr_line_one_desc;
	}
	public String get_actl_del_nm() {
		return _actl_del_nm;
	}
	public void set_actl_del_nm(String _actl_del_nm) {
		this._actl_del_nm = _actl_del_nm;
	}
	public Calendar get_adj_commit_dt() {
		return _adj_commit_dt;
	}
	public void set_adj_commit_dt(Calendar _adj_commit_dt) {
		this._adj_commit_dt = _adj_commit_dt;
	}
	public Date get_commit_date() {
		return _commit_date;
	}
	public void set_commit_date(Date _commit_date) {
		this._commit_date = _commit_date;
	}
	public int get_adj_commit_dt_offst_nbr() {
		return _adj_commit_dt_offst_nbr;
	}
	public void set_adj_commit_dt_offst_nbr(int _adj_commit_dt_offst_nbr) {
		this._adj_commit_dt_offst_nbr = _adj_commit_dt_offst_nbr;
	}
	public Calendar get_commit_dt() {
		return _commit_dt;
	}
	public void set_commit_dt(Calendar _commit_dt) {
		this._commit_dt = _commit_dt;
	}
	public String get_crtg_agent_co_nm() {
		return _crtg_agent_co_nm;
	}
	public void set_crtg_agent_co_nm(String _crtg_agent_co_nm) {
		this._crtg_agent_co_nm = _crtg_agent_co_nm;
	}
	public String get_cstms_curr_cd() {
		return _cstms_curr_cd;
	}
	public void set_cstms_curr_cd(String _cstms_curr_cd) {
		this._cstms_curr_cd = _cstms_curr_cd;
	}
	public int get_cstms_value_amt() {
		return _cstms_value_amt;
	}
	public void set_cstms_value_amt(int _cstms_value_amt) {
		this._cstms_value_amt = _cstms_value_amt;
	}
	public Calendar get_del_dt() {
		return _del_dt;
	}
	public void set_del_dt(Calendar _del_dt) {
		this._del_dt = _del_dt;
	}
	public int get_delivery_qty() {
		return _delivery_qty;
	}
	public void set_delivery_qty(int _delivery_qty) {
		this._delivery_qty = _delivery_qty;
	}
	public String get_dest_loc_cd() {
		return _dest_loc_cd;
	}
	public void set_dest_loc_cd(String _dest_loc_cd) {
		this._dest_loc_cd = _dest_loc_cd;
	}
	public int get_dimnl_wgt() {
		return _dimnl_wgt;
	}
	public void set_dimnl_wgt(int _dimnl_wgt) {
		this._dimnl_wgt = _dimnl_wgt;
	}
	public String get_emp_first_nm() {
		return _emp_first_nm;
	}
	public void set_emp_first_nm(String _emp_first_nm) {
		this._emp_first_nm = _emp_first_nm;
	}
	public String get_emp_last_nm() {
		return _emp_last_nm;
	}
	public void set_emp_last_nm(String _emp_last_nm) {
		this._emp_last_nm = _emp_last_nm;
	}
	public String get_emp_nbr() {
		return _emp_nbr;
	}
	public void set_emp_nbr(String _emp_nbr) {
		this._emp_nbr = _emp_nbr;
	}
	public String get_emp_role_cd() {
		return _emp_role_cd;
	}
	public void set_emp_role_cd(String _emp_role_cd) {
		this._emp_role_cd = _emp_role_cd;
	}
	public Calendar get_est_avail_for_delv_dt() {
		return _est_avail_for_delv_dt;
	}
	public void set_est_avail_for_delv_dt(Calendar _est_avail_for_delv_dt) {
		this._est_avail_for_delv_dt = _est_avail_for_delv_dt;
	}
	public int get_grp_nbr() {
		return _grp_nbr;
	}
	public void set_grp_nbr(int _grp_nbr) {
		this._grp_nbr = _grp_nbr;
	}
	public String get_grp_nm() {
		return _grp_nm;
	}
	public void set_grp_nm(String _grp_nm) {
		this._grp_nm = _grp_nm;
	}
	public int get_inv_amt() {
		return _inv_amt;
	}
	public void set_inv_amt(int _inv_amt) {
		this._inv_amt = _inv_amt;
	}
	public int get_lane_nbr() {
		return _lane_nbr;
	}
	public void set_lane_nbr(int _lane_nbr) {
		this._lane_nbr = _lane_nbr;
	}
	public Calendar get_last_event_tmstp() {
		return _last_event_tmstp;
	}
	public void set_last_event_tmstp(Calendar _last_event_tmstp) {
		this._last_event_tmstp = _last_event_tmstp;
	}
	public String get_last_event_track_loc_cd() {
		return _last_event_track_loc_cd;
	}
	public void set_last_event_track_loc_cd(String _last_event_track_loc_cd) {
		this._last_event_track_loc_cd = _last_event_track_loc_cd;
	}
	public String get_last_event_track_type_cd() {
		return _last_event_track_type_cd;
	}
	public void set_last_event_track_type_cd(String _last_event_track_type_cd) {
		this._last_event_track_type_cd = _last_event_track_type_cd;
	}
	public String get_last_stat_desc() {
		return _last_stat_desc;
	}
	public void set_last_stat_desc(String _last_stat_desc) {
		this._last_stat_desc = _last_stat_desc;
	}
	public String get_orig_loc_cd() {
		return _orig_loc_cd;
	}
	public void set_orig_loc_cd(String _orig_loc_cd) {
		this._orig_loc_cd = _orig_loc_cd;
	}
	public int get_pack_type_cd() {
		return _pack_type_cd;
	}
	public void set_pack_type_cd(int _pack_type_cd) {
		this._pack_type_cd = _pack_type_cd;
	}
	public int get_package_piece_qty() {
		return _package_piece_qty;
	}
	public void set_package_piece_qty(int _package_piece_qty) {
		this._package_piece_qty = _package_piece_qty;
	}
	public String get_perf_rsult_cd() {
		return _perf_rsult_cd;
	}
	public void set_perf_rsult_cd(String _perf_rsult_cd) {
		this._perf_rsult_cd = _perf_rsult_cd;
	}
	public char get_quantity_observed_flag() {
		return _quantity_observed_flag;
	}
	public void set_quantity_observed_flag(char _quantity_observed_flag) {
		this._quantity_observed_flag = _quantity_observed_flag;
	}
	public String get_recp_addr_line_one_desc() {
		return _recp_addr_line_one_desc;
	}
	public void set_recp_addr_line_one_desc(String _recp_addr_line_one_desc) {
		this._recp_addr_line_one_desc = _recp_addr_line_one_desc;
	}
	public String get_recp_addr_line_three_desc() {
		return _recp_addr_line_three_desc;
	}
	public void set_recp_addr_line_three_desc(String _recp_addr_line_three_desc) {
		this._recp_addr_line_three_desc = _recp_addr_line_three_desc;
	}
	public String get_recp_addr_line_two_desc() {
		return _recp_addr_line_two_desc;
	}
	public void set_recp_addr_line_two_desc(String _recp_addr_line_two_desc) {
		this._recp_addr_line_two_desc = _recp_addr_line_two_desc;
	}
	public String get_recp_city_nm() {
		return _recp_city_nm;
	}
	public void set_recp_city_nm(String _recp_city_nm) {
		this._recp_city_nm = _recp_city_nm;
	}
	public String get_recp_cntry_cd() {
		return _recp_cntry_cd;
	}
	public void set_recp_cntry_cd(String _recp_cntry_cd) {
		this._recp_cntry_cd = _recp_cntry_cd;
	}
	public String get_recp_co_nm() {
		return _recp_co_nm;
	}
	public void set_recp_co_nm(String _recp_co_nm) {
		this._recp_co_nm = _recp_co_nm;
	}
	public String get_recp_ph_nbr() {
		return _recp_ph_nbr;
	}
	public void set_recp_ph_nbr(String _recp_ph_nbr) {
		this._recp_ph_nbr = _recp_ph_nbr;
	}
	public String get_recp_pstl_cd() {
		return _recp_pstl_cd;
	}
	public void set_recp_pstl_cd(String _recp_pstl_cd) {
		this._recp_pstl_cd = _recp_pstl_cd;
	}
	public String get_recp_st_prov_cd() {
		return _recp_st_prov_cd;
	}
	public void set_recp_st_prov_cd(String _recp_st_prov_cd) {
		this._recp_st_prov_cd = _recp_st_prov_cd;
	}
	public Date get_ship_dt() {
		return _ship_dt;
	}
	public void set_ship_dt(Date _ship_dt) {
		this._ship_dt = _ship_dt;
	}
	public int get_shpmt_pkg_qt() {
		return _shpmt_pkg_qt;
	}
	public void set_shpmt_pkg_qt(int _shpmt_pkg_qt) {
		this._shpmt_pkg_qt = _shpmt_pkg_qt;
	}
	public String get_shpmt_type_cd() {
		return _shpmt_type_cd;
	}
	public void set_shpmt_type_cd(String _shpmt_type_cd) {
		this._shpmt_type_cd = _shpmt_type_cd;
	}
	public char get_shpmt_uom_cd() {
		return _shpmt_uom_cd;
	}
	public void set_shpmt_uom_cd(char _shpmt_uom_cd) {
		this._shpmt_uom_cd = _shpmt_uom_cd;
	}
	public int get_shpmt_wgt() {
		return _shpmt_wgt;
	}
	public void set_shpmt_wgt(int _shpmt_wgt) {
		this._shpmt_wgt = _shpmt_wgt;
	}
	public double get_shpmt_wgt_double() {
		return _shpmt_wgt_double;
	}
	public void set_shpmt_wgt_double(double _shpmt_wgt_double) {
		this._shpmt_wgt_double = _shpmt_wgt_double;
	}
	public String get_shpr_addr_line_one_desc() {
		return _shpr_addr_line_one_desc;
	}
	public void set_shpr_addr_line_one_desc(String _shpr_addr_line_one_desc) {
		this._shpr_addr_line_one_desc = _shpr_addr_line_one_desc;
	}
	public String get_shpr_addr_line_three_desc() {
		return _shpr_addr_line_three_desc;
	}
	public void set_shpr_addr_line_three_desc(String _shpr_addr_line_three_desc) {
		this._shpr_addr_line_three_desc = _shpr_addr_line_three_desc;
	}
	public String get_shpr_addr_line_two_desc() {
		return _shpr_addr_line_two_desc;
	}
	public void set_shpr_addr_line_two_desc(String _shpr_addr_line_two_desc) {
		this._shpr_addr_line_two_desc = _shpr_addr_line_two_desc;
	}
	public String get_shpr_city_nm() {
		return _shpr_city_nm;
	}
	public void set_shpr_city_nm(String _shpr_city_nm) {
		this._shpr_city_nm = _shpr_city_nm;
	}
	public String get_shpr_cntry_cd() {
		return _shpr_cntry_cd;
	}
	public void set_shpr_cntry_cd(String _shpr_cntry_cd) {
		this._shpr_cntry_cd = _shpr_cntry_cd;
	}
	public String get_shpr_co_nm() {
		return _shpr_co_nm;
	}
	public void set_shpr_co_nm(String _shpr_co_nm) {
		this._shpr_co_nm = _shpr_co_nm;
	}
	public String get_shpr_ph_nbr() {
		return _shpr_ph_nbr;
	}
	public void set_shpr_ph_nbr(String _shpr_ph_nbr) {
		this._shpr_ph_nbr = _shpr_ph_nbr;
	}
	public String get_shpr_pstl_cd() {
		return _shpr_pstl_cd;
	}
	public void set_shpr_pstl_cd(String _shpr_pstl_cd) {
		this._shpr_pstl_cd = _shpr_pstl_cd;
	}
	public String get_shpr_st_prov_cd() {
		return _shpr_st_prov_cd;
	}
	public void set_shpr_st_prov_cd(String _shpr_st_prov_cd) {
		this._shpr_st_prov_cd = _shpr_st_prov_cd;
	}
	public char get_skid_intact_flag() {
		return _skid_intact_flag;
	}
	public void set_skid_intact_flag(char _skid_intact_flag) {
		this._skid_intact_flag = _skid_intact_flag;
	}
	public String get_spcl_hndlg_grp() {
		return _spcl_hndlg_grp;
	}
	public void set_spcl_hndlg_grp(String _spcl_hndlg_grp) {
		this._spcl_hndlg_grp = _spcl_hndlg_grp;
	}
	public String get_svc_type_cd() {
		return _svc_type_cd;
	}
	public void set_svc_type_cd(String _svc_type_cd) {
		this._svc_type_cd = _svc_type_cd;
	}
	public int get_trkng_item_form_cd() {
		return _trkng_item_form_cd;
	}
	public void set_trkng_item_form_cd(int _trkng_item_form_cd) {
		this._trkng_item_form_cd = _trkng_item_form_cd;
	}
	public String get_trkng_item_nbr() {
		return _trkng_item_nbr;
	}
	public void set_trkng_item_nbr(String _trkng_item_nbr) {
		this._trkng_item_nbr = _trkng_item_nbr;
	}
	public String get_trkng_item_uniq_nbr() {
		return _trkng_item_uniq_nbr;
	}
	public void set_trkng_item_uniq_nbr(String _trkng_item_uniq_nbr) {
		this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
	}
	public String get_group_nm() {
		return _group_nm;
	}
	public void set_group_nm(String _group_nm) {
		this._group_nm = _group_nm;
	}
	public String get_track_type_cd() {
		return _track_type_cd;
	}
	public void set_track_type_cd(String _track_type_cd) {
		this._track_type_cd = _track_type_cd;
	} 	
	
	public String get_assoc_trkng_item_nbr() {
		return _assoc_trkng_item_nbr;
	}

	public void set_assoc_trkng_item_nbr(String _assoc_trkng_item_nbr) {
		this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
	}	
	
    /**
     * @return the _cleared_cstms_tmstp
     */
    public Calendar get_cleared_cstms_tmstp() {
        return _cleared_cstms_tmstp;
    }

    /**
     * @param _cleared_cstms_tmstp the _cleared_cstms_tmstp to set
     */
    public void set_cleared_cstms_tmstp(Calendar _cleared_cstms_tmstp) {
        this._cleared_cstms_tmstp = _cleared_cstms_tmstp;
    }
	
	public ShipmentEmployeeVO(String _orig_cntry_cd, String _dest_cntry_cd, String _acct_nm, String _assoc_trkng_item_nbr, String _trkng_item_nbr, String _trkng_item_uniq_nbr, int _grp_nbr, String _acct_nbr, int _lane_nbr, String _svc_type_cd, String _shpmt_type_cd, int _trkng_item_form_cd, int _pack_type_cd, String _orig_loc_cd, String _dest_loc_cd, int _shpmt_wgt, char _shpmt_uom_cd, Date _ship_dt, String _shpr_co_nm, String _shpr_ph_nbr, String _shpr_addr_line_one_desc, String _shpr_addr_line_two_desc, String _shpr_addr_line_three_desc, String _shpr_city_nm, String _shpr_pstl_cd, String _shpr_cntry_cd, String _shpr_st_prov_cd, String _recp_co_nm, String _recp_ph_nbr, String _recp_addr_line_one_desc, String _recp_addr_line_two_desc, String _recp_addr_line_three_desc, String _recp_city_nm, String _recp_st_prov_cd, String _recp_cntry_cd, String _recp_pstl_cd, String _actl_del_nm, String _actl_addr_line_one_desc, Calendar _del_dt, String _spcl_hndlg_grp, String _crtg_agent_co_nm, String _cstms_curr_cd, int _cstms_value_amt, int _dimnl_wgt, int _inv_amt, int _shpmt_pkg_qt, Calendar _last_event_tmstp, String _last_event_track_type_cd, String _last_event_track_loc_cd, Calendar _commit_dt, Calendar _adj_commit_dt, int _adj_commit_dt_offst_nbr, String _perf_rsult_cd, int _package_piece_qty, int _delivery_qty, char _skid_intact_flag, char _quantity_observed_flag, Calendar _est_avail_for_delv_dt, String _last_stat_desc, String _emp_nbr, String _emp_first_nm, String _emp_last_nm, String _emp_role_cd) {
		super();
        this._orig_cntry_cd = _orig_cntry_cd;
        this._dest_cntry_cd = _dest_cntry_cd;		
		this._acct_nm = _acct_nm;		
		this._assoc_trkng_item_nbr = _assoc_trkng_item_nbr;
		this._trkng_item_nbr = _trkng_item_nbr;
		this._trkng_item_uniq_nbr = _trkng_item_uniq_nbr;
		this._grp_nbr = _grp_nbr;
		this._acct_nbr = _acct_nbr;
		this._lane_nbr = _lane_nbr;
		this._svc_type_cd = _svc_type_cd;
		this._shpmt_type_cd = _shpmt_type_cd;
		this._trkng_item_form_cd = _trkng_item_form_cd;
		this._pack_type_cd = _pack_type_cd;
		this._orig_loc_cd = _orig_loc_cd;
		this._dest_loc_cd = _dest_loc_cd;
		this._shpmt_wgt = _shpmt_wgt;
		this._shpmt_uom_cd = _shpmt_uom_cd;
		this._ship_dt = _ship_dt;
		this._shpr_co_nm = _shpr_co_nm;
		this._shpr_ph_nbr = _shpr_ph_nbr;
		this._shpr_addr_line_one_desc = _shpr_addr_line_one_desc;
		this._shpr_addr_line_two_desc = _shpr_addr_line_two_desc;
		this._shpr_addr_line_three_desc = _shpr_addr_line_three_desc;
		this._shpr_city_nm = _shpr_city_nm;
		this._shpr_pstl_cd = _shpr_pstl_cd;
		this._shpr_cntry_cd = _shpr_cntry_cd;
		this._shpr_st_prov_cd = _shpr_st_prov_cd;
		this._recp_co_nm = _recp_co_nm;
		this._recp_ph_nbr = _recp_ph_nbr;
		this._recp_addr_line_one_desc = _recp_addr_line_one_desc;
		this._recp_addr_line_two_desc = _recp_addr_line_two_desc;
		this._recp_addr_line_three_desc = _recp_addr_line_three_desc;
		this._recp_city_nm = _recp_city_nm;
		this._recp_st_prov_cd = _recp_st_prov_cd;
		this._recp_cntry_cd = _recp_cntry_cd;
		this._recp_pstl_cd = _recp_pstl_cd;
		this._actl_del_nm = _actl_del_nm;
		this._actl_addr_line_one_desc = _actl_addr_line_one_desc;
		this._del_dt = _del_dt;
		this._spcl_hndlg_grp = _spcl_hndlg_grp;
		this._crtg_agent_co_nm = _crtg_agent_co_nm;
		this._cstms_curr_cd = _cstms_curr_cd;
		this._cstms_value_amt = _cstms_value_amt;
		this._dimnl_wgt = _dimnl_wgt;
		this._inv_amt = _inv_amt;
		this._shpmt_pkg_qt = _shpmt_pkg_qt;
		this._last_event_tmstp = _last_event_tmstp;
		this._last_event_track_type_cd = _last_event_track_type_cd;
		this._last_event_track_loc_cd = _last_event_track_loc_cd;
		this._commit_dt = _commit_dt;
		this._adj_commit_dt = _adj_commit_dt;
		this._adj_commit_dt_offst_nbr = _adj_commit_dt_offst_nbr;
		this._perf_rsult_cd = _perf_rsult_cd;
		this._package_piece_qty = _package_piece_qty;
		this._delivery_qty = _delivery_qty;
		this._skid_intact_flag = _skid_intact_flag;
		this._quantity_observed_flag = _quantity_observed_flag;
		this._est_avail_for_delv_dt = _est_avail_for_delv_dt;
		this._last_stat_desc = _last_stat_desc;
		this._emp_nbr = _emp_nbr;
		this._emp_first_nm = _emp_first_nm;
		this._emp_last_nm = _emp_last_nm;
		this._emp_role_cd = _emp_role_cd;
	}
	public ShipmentEmployeeVO() {
		// TODO Auto-generated constructor stub
	}



   
    
}
