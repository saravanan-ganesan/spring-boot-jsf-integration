package com.jsf.samples.bootfaces.controller;

import java.time.ZonedDateTime;
import java.util.Calendar;

import com.jsf.samples.bootfaces.annotation.JsfController;
import com.jsf.samples.bootfaces.dto.TimeZone;

@JsfController(path = "/timezone", page = "/pages/jsp/timezone.jsp", value = "timezoneController")
public class TimeZoneController extends BaseController {

	private TimeZone timezone;
	
	public TimeZone getTimezone() {
		
		timezone = new TimeZone();
		
		Calendar now = Calendar.getInstance();
		java.util.TimeZone systemTimeZone = now.getTimeZone();
		
		timezone.setCurrentTimeZone(systemTimeZone.getDisplayName());
		ZonedDateTime zoneNow = ZonedDateTime.now(java.util.TimeZone.getTimeZone(systemTimeZone.getDisplayName()).toZoneId());
		timezone.setCurrentTime(zoneNow.toString());
		
		return timezone;
	}

}
