package com.jsf.samples.bootfaces.controller;

import com.jsf.samples.bootfaces.annotation.JsfController;

@JsfController(path = "/home", page = "/pages/jsp/home.jsp", value = "homeController")
public class HomeController {

}
