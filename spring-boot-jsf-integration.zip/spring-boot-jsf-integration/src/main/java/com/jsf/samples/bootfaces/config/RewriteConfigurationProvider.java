//package com.jsf.samples.bootfaces.config;
//
//import java.io.IOException;
//import java.lang.annotation.Annotation;
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.LinkedList;
//import java.util.List;
//
//import javax.servlet.ServletContext;
//
//import org.ocpsoft.rewrite.annotation.RewriteConfiguration;
//import org.ocpsoft.rewrite.config.Configuration;
//import org.ocpsoft.rewrite.config.ConfigurationBuilder;
//import org.ocpsoft.rewrite.servlet.config.HttpConfigurationProvider;
//import org.ocpsoft.rewrite.servlet.config.rule.Join;
//import org.springframework.beans.factory.config.BeanDefinition;
//import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
//import org.springframework.web.context.support.StandardServletEnvironment;
//
//import com.google.common.reflect.ClassPath;
//
//@RewriteConfiguration
//public class RewriteConfigurationProvider extends HttpConfigurationProvider {
//
//	@Override
//	public Configuration getConfiguration(ServletContext context) {
//
//		final List<Class<?>> result = new LinkedList<Class<?>>();
//		final ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(
//				true, new StandardServletEnvironment());
//
//		for (BeanDefinition beanDefinition : provider.findCandidateComponents("com.jsf.samples.bootfaces.controller")) {
//			try {
//				result.add(Class.forName(beanDefinition.getBeanClassName()));
//			} catch (ClassNotFoundException e) {
//
//			}
//		}
//
//		final ClassLoader loader = Thread.currentThread().getContextClassLoader();
//
//		try {
//			for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {
//				if (info.getName().startsWith("com.jsf.samples.bootfaces.controller.")) {
//
//					final Class<?> clazz = info.load();
//
//					getAnnotationValue(clazz);
//				}
//			}
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}
//
//		return ConfigurationBuilder.begin()
//
//				.addRule(Join.path("/product/{id}/edit").to("/faces/view/editProduct.xhtml"))
//				.addRule(Join.path("/product/{id}/details").to("/faces/view/productDetails.xhtml"))
//				.addRule(Join.path("/products").to("/faces/view/productList.xhtml"));
//	}
//
//	@Override
//	public int priority() {
//		return 10;
//	}
//
//	private String getAnnotationValue(Class<?> clazz) {
//
//		String annotationValue = "";
//
//		if (clazz != null) {
//
//			Annotation[] arr = clazz.getAnnotations();
//			
//			if (arr != null) {
//				
//				for (Annotation a : arr) {
//
//					
//					Class<? extends Annotation> type = a.annotationType();
//
//					if(null != type) {
//						
//						if("org.springframework.stereotype.Component".equals(type.getName())) {
//							
//							for (Method method : type.getDeclaredMethods()) {
//								try {
//									Object value = method.invoke(a, (Object[]) null);
//									System.out.println(" " + method.getName() + ": " + value);
//								} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
//									e.printStackTrace();
//								}
//							}
//						}
//					}
//					
//				}
//			}
//		}
//		
//		return annotationValue;
//	}
//
//}