package com.jsf.samples.bootfaces.config;

import java.util.Arrays;
import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

@Aspect
@Component
@EnableAspectJAutoProxy
public class LoggerAspect {

	@Autowired
	private Environment environment;
	
	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	private final String PACKAGE_PATH = "execution(* com.jsf.samples.bootfaces..*.*(..)))";
	
	@Pointcut(PACKAGE_PATH)
	public void appPointcut() {
		// Method is empty as this is just a point-cut, the implementations are in the advice.
	}

	@AfterThrowing(pointcut = "appPointcut()", throwing = "e")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {
		
		LOGGER.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), e.getCause() != null ? e.getCause() : "NULL");
		e.printStackTrace();
	}

	@Around("appPointcut()")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {

		List<String> profileList = null;
		String[] profileArr = this.environment.getActiveProfiles();
		
		Object result;

		if(null != profileArr) {
			profileList = Arrays.asList(profileArr);
		}
		
		if(!ObjectUtils.isEmpty(profileList) && profileList.contains("prod")) {
			LOGGER.debug("Enter: {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
		} else {
			LOGGER.info("Enter: {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
		}
		

		try {
			result = joinPoint.proceed();

		} finally {
			
			if(!ObjectUtils.isEmpty(profileList) && profileList.contains("prod")) {
				LOGGER.debug("Exit: {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
			} else {
				LOGGER.info("Exit: {}.{}()", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
			}
			
		}
		
		return result;
	}
}
