package com.jsf.samples.bootfaces.config;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.ocpsoft.rewrite.annotation.RewriteConfiguration;
import org.ocpsoft.rewrite.config.Configuration;
import org.ocpsoft.rewrite.config.ConfigurationBuilder;
import org.ocpsoft.rewrite.config.ConfigurationRuleBuilder;
import org.ocpsoft.rewrite.servlet.config.HttpConfigurationProvider;
import org.ocpsoft.rewrite.servlet.config.rule.Join;
import org.springframework.util.ObjectUtils;

import com.google.common.reflect.ClassPath;

@RewriteConfiguration
public class ControllerMappingConfig extends HttpConfigurationProvider {

	final static String CONTROLLER_PACKAGE = "com.jsf.samples.bootfaces.controller.";
	@Override
	public Configuration getConfiguration(ServletContext context) {
		
		List<Join> joinList = new ArrayList<>();
		
		try {
			
			final ClassLoader loader = Thread.currentThread().getContextClassLoader();
			
			if(null != loader) {
				
				for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {
					
					 if (info.getName().startsWith(CONTROLLER_PACKAGE)) {
						 
						 final Class<?> clazz = info.load();
						 
						 if(null != clazz) {
							 
							 Map<String, String> annotationValueMap = getAnnotationValue(clazz);
							 
							 if(!ObjectUtils.isEmpty(annotationValueMap)) {
								 
								 for (Map.Entry<String, String> entry : annotationValueMap.entrySet()) {
									 joinList.add(Join.path(entry.getKey()).to(entry.getValue()));
								 }
								 
							 }
						 }
					 }
				}
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		ConfigurationBuilder builder = ConfigurationRuleBuilder.begin();
		for(Join join : joinList) {
			System.out.println(join);
			builder.addRule(join);
		}
		
		return builder;
		
	}

	@Override
	public int priority() {
		return 10;
	}
	
	private Map<String, String> getAnnotationValue(Class<?> clazz) {

		Map<String, String> annotationMap = new HashMap<>();

		if (clazz != null) {

			Annotation[] arr = clazz.getAnnotations();
			
			if (arr != null) {
				
				for (Annotation a : arr) {

					
					Class<? extends Annotation> type = a.annotationType();

					if(null != type) {
						
						if("com.jsf.samples.bootfaces.annotation.JsfController".equals(type.getName())) {
							
							List<String> valueList = new ArrayList<>();
							
							for (Method method : type.getDeclaredMethods()) {
								try {
									Object value = method.invoke(a, (Object[]) null);
									System.out.println(" " + method.getName() + ": " + value);
									
									String path = "";
									String page = "";
									
									if("path".equals(method.getName())) {
										path = value.toString();
									} else if("page".equals(method.getName())) {
										page = value.toString();
									}
									
									if(!ObjectUtils.isEmpty(path)) {
										
										if(!path.startsWith("/")) {
											path = "/" + path;
										}
										valueList.add(path);
									}
									
									if(!ObjectUtils.isEmpty(page)) {
										
										if(page.endsWith(".jsp")) {
											page = page.replace(".jsp", ".jsf");

										} else if(page.endsWith(".xhtml")) {
											page = page.replace(".jsp", ".jsf");

										}
										
										if(!page.startsWith("/")) {
											page = "/WEB-INF/" + page;
										} else {
											page = "/WEB-INF" + page;
										}
										valueList.add(page);
										
									}
									
								} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
									e.printStackTrace();
								}
							}
							
							if(!ObjectUtils.isEmpty(valueList) && valueList.size() == 2) {
								
								annotationMap.put(valueList.get(0), valueList.get(1));
							}

						}
					}
					
				}
			}
		}
		
		return annotationMap;
	}

}
