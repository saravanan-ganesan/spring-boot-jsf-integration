package com.example.demo.listener;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.activemq.command.ActiveMQObjectMessage;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.example.demo.dto.Product;

@Component
public class Receiver {

	private static final String PRODUCT_QUEUE = "product_queue";
	private static final String PRODUCT_TOPIC = "product_topic";

	@JmsListener(destination = PRODUCT_QUEUE, containerFactory = "myFactory")
	public Product receiveMessage(Message message) throws JMSException {
		
		System.out.println("Successfully queue message received ");
		
		if(message instanceof ActiveMQObjectMessage) {
			
			ActiveMQObjectMessage activeMQObjectMessage = (ActiveMQObjectMessage) message;
			
			Product product = (Product)  activeMQObjectMessage.getObject();
			System.out.println(product);
		}
        
		return null;
		
	}
	
	@JmsListener(destination = PRODUCT_TOPIC, containerFactory = "myFactory")
	public Product receiveTopicMessage(Message message) throws JMSException {
		
		System.out.println("Successfully topic message received ");
		
		if(message instanceof ActiveMQObjectMessage) {
			
			ActiveMQObjectMessage activeMQObjectMessage = (ActiveMQObjectMessage) message;
			
			Product product = (Product)  activeMQObjectMessage.getObject();
			System.out.println(product);
		}
        
		return null;
		
	}

}