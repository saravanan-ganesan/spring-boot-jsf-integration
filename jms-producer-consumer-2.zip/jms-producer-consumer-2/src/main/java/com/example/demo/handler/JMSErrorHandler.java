package com.example.demo.handler;

import org.springframework.stereotype.Component;
import org.springframework.util.ErrorHandler;

@Component
public class JMSErrorHandler implements ErrorHandler {

    @Override
    public void handleError(Throwable t) {
        System.out.println("Error in listener=" + t);
    }
}