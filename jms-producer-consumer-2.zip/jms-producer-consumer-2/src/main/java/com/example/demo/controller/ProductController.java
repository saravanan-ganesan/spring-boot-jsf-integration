package com.example.demo.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Product;

@RestController
public class ProductController {

	@Autowired
	JmsTemplate jmsTemplate;
	
	private static final String PRODUCT_QUEUE = "product_queue";
	private static final String PRODUCT_TOPIC = "product_topic";
	
	@PostMapping("/publish")
	public ResponseEntity<String> publishEvent(@RequestBody Product prodcut) {
		
		jmsTemplate.convertAndSend(PRODUCT_QUEUE, prodcut, m -> {
			
			m.setJMSCorrelationID(UUID.randomUUID().toString());
			m.setJMSExpiration(1000); //after this time elapse, consumer cannot consume the message
			m.setJMSMessageID("product_queue");
			
			return m;
		});
		return ResponseEntity.ok("Succesfully send events to the queue name: "+ PRODUCT_QUEUE);
	}
	
	@PostMapping("/publish-topic")
	public ResponseEntity<String> publishTopicEvent(@RequestBody Product prodcut) {
		
		jmsTemplate.convertAndSend(PRODUCT_TOPIC, prodcut);
		return ResponseEntity.ok("Succesfully send events to the topic name: "+ PRODUCT_TOPIC);
	}
}
