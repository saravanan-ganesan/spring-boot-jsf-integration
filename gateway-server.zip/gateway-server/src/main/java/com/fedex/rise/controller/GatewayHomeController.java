package com.fedex.rise.controller;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GatewayHomeController {

	@GetMapping("/")
	public String greeting(@AuthenticationPrincipal OidcUser oidcUser, Model model, 
			@RegisteredOAuth2AuthorizedClient("okta") OAuth2AuthorizedClient client) {
		
		Map<String, Object> attribtesMap = new HashMap<>();
		
		attribtesMap.put("givenName", oidcUser.getGivenName());
		
		ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(oidcUser.getAuthenticatedAt(), ZoneId.systemDefault());
		attribtesMap.put("authenticatedTime", zonedDateTime);
		
		attribtesMap.put("principalName", client.getPrincipalName());
		
		attribtesMap.put("accessToken", client.getAccessToken().getTokenValue());
		
		attribtesMap.put("logoutUrl", "http://localhost:8080/login?logout=true");
		
		model.addAllAttributes(attribtesMap);
		
		return "home";
	}
}
