package com.fedex.rise.filter;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.GatewayFilterFactory;
import org.springframework.context.annotation.Configuration;

//@Configuration
public class MyTokenRelayGatewayFilterFactory implements GatewayFilterFactory<MyTokenRelayGatewayFilterFactory.Config> {

    
	@Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            System.out.println("gateway filter name "+config.getName());
            return chain.filter(exchange);
        };
    }
    
    @Override
    public Config newConfig() {
        return new Config("MyTokenRelayGatewayFilterFactory");
    }

    public static class Config {

        public Config(String name){
            this.name = name;
        }
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

}