package com.fedex.rise.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.security.reactive.EndpointRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

/**
 * 
 * This configuration class is used Configures our application with Spring Security 
 * to restrict access to our API end points.
 *
 */
@EnableWebFluxSecurity
public class SecurityConfig {

    @Value("${okta.oauth2.issuer}")
    private String issuerUrl;
    
    @Bean
    public SecurityWebFilterChain configure(ServerHttpSecurity http) throws Exception {
    	
    	http.csrf(csrf -> csrf.disable());
    	
    	return http
		        .authorizeExchange(exchange -> exchange.matchers(EndpointRequest.toAnyEndpoint()).permitAll()
		                .anyExchange().authenticated())
				        .oauth2Login(Customizer.withDefaults())
				        .build();
    	
//    	http.authorizeExchange()
//        .anyExchange().authenticated()
//        .and().oauth2Login()
//        .and().logout().logoutSuccessHandler(logoutSuccessHandler())
//        .and()
//        .oauth2ResourceServer()
//        .jwt().jwtDecoder(jwtDecoder());
    	
    	
    	//return http.build();
    	
    }
    
//    @Bean
//    public ReactiveJwtDecoder jwtDecoder() {
//    	//return NimbusReactiveJwtDecoder.withJwkSetUri(issuerUrl + "/v1/keys").jwsAlgorithm(SignatureAlgorithm.RS256).build();
//        return ReactiveJwtDecoders.fromOidcIssuerLocation(issuerUrl);
//    }
//    
//    @Bean
//    public ServerLogoutSuccessHandler logoutSuccessHandler() {
//            
//    	RedirectServerLogoutSuccessHandler handler = new RedirectServerLogoutSuccessHandler();
//        handler.setLogoutSuccessUrl(URI.create("/logout"));
//        return handler;
//    }

}