package com.fedex.rise.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtIssuerValidator;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.BaseSubscriber;
import reactor.core.publisher.Mono;

//@Component
public class LoggingGlobalPreFilter implements GlobalFilter {

	final Logger logger = LoggerFactory.getLogger(LoggingGlobalPreFilter.class);

	@Autowired
	ReactiveJwtDecoder decoder;

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

		logger.info("Global Pre Filter executed");
		HttpHeaders headers = exchange.getRequest().getHeaders();

		List<String> authHeaders = headers.get(HttpHeaders.AUTHORIZATION);

		if (authHeaders != null) {

			String token = authHeaders.get(0).split(" ")[1];
			Mono<Jwt> monoJwt = decoder.decode(token);
			
			
			monoJwt.subscribe(
					  value -> {
						  if(value != null && value.getIssuer() != null) {
							  System.out.println("inside");
							  JwtIssuerValidator validator = new JwtIssuerValidator(value.getIssuer().toString());
							  OAuth2TokenValidatorResult oauth2TokenValidatorResult = validator.validate(value);
							  System.out.println("isError="+oauth2TokenValidatorResult.hasErrors());
							  
						  }
					  }, 
					  error -> error.printStackTrace(), 
					  () -> System.out.println("completed without a value")
			);
			
			
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return chain.filter(exchange);
	}
	
	public Jwt getJwt(Mono<Jwt> monoJwt) {
		
		AtomicReference<String> ref = new AtomicReference<>();
		AtomicReference<Jwt> jwtref = new AtomicReference<>();
		
//		monoJwt.subscribe(x -> {
//			String issuer = x.getIssuer().toString();
//			System.out.println("inside issuer="+issuer);
//			ref.set(issuer);
//			jwtref.set(x);
//			
//		});
		monoJwt.mapNotNull(x -> {
			if(x != null) {
				ref.set(x.getIssuer().toString());
				System.out.println("x="+x);
				System.out.println("ref.get="+ref.get());
				return x;
			} else {
				return null;
			}
		});
		
//		System.out.println("outside issuer="+ref.get());
//		System.out.println("outside jwt="+jwtref.get());
		return null;
	}
}