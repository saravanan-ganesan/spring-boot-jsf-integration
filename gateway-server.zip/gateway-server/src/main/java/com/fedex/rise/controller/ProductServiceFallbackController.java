package com.fedex.rise.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import reactor.core.publisher.Mono;

@RestController
public class ProductServiceFallbackController {

	@GetMapping("/product-service-fallback")
	@CrossOrigin
	public Mono<ResponseEntity<?>> getProductServiceFallback(HttpClientErrorException e) {
		
		String msg = "There is an exception with status " + e.getStatusCode();
		return Mono.just(ResponseEntity.ok().body(msg));
	}
}
