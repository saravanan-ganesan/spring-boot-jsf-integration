package com.okta.examples.oauth2.pkcealways.config;

import static org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter.DEFAULT_AUTHORIZATION_REQUEST_BASE_URI;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.web.SecurityFilterChain;

import com.okta.examples.oauth2.pkcealways.custom.CustomAuthorizationRequestResolver;

@EnableWebSecurity
public class SecurityConfig { //extends WebSecurityConfigurerAdapter {

	private ClientRegistrationRepository clientRegistrationRepository;
	String[] pathMatcher = new String[] {"/", "/img/**"};
   

    public SecurityConfig(ClientRegistrationRepository clientRegistrationRepository) {
        this.clientRegistrationRepository = clientRegistrationRepository;
    }

    @Bean
    protected SecurityFilterChain configure(HttpSecurity http) throws Exception {
        
		http
		.csrf().disable().cors().and()
		.authorizeRequests()
		.antMatchers(pathMatcher).permitAll()
		.anyRequest().authenticated();

		http
		.oauth2Login()
        //.clientRegistrationRepository(clientRegistrationRepository)
        .authorizationEndpoint()
        .authorizationRequestResolver(new CustomAuthorizationRequestResolver(
            clientRegistrationRepository, DEFAULT_AUTHORIZATION_REQUEST_BASE_URI
        ));

      return http.build();      
    }
}
