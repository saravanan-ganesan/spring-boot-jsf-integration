package com.okta.examples.oauth2.pkcealways.contoller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {

    @GetMapping("/")
    public void home(HttpServletResponse response) throws IOException {
        //return "home";
    	response.sendRedirect("/home");
    	
    }

    @GetMapping("/home")
    public void profile(@AuthenticationPrincipal OidcUser user, HttpServletResponse response) throws IOException {
    	
    	System.out.println("user="+user);
    	
        ModelAndView mav = new ModelAndView();
        mav.addObject("user", user);
        mav.setViewName("home");
        System.out.println("Family Name = "+user.getUserInfo().getFamilyName());
        //return mav;
        response.sendRedirect("/user");
    }
    
    
    @GetMapping("/user")
    public ModelAndView user(@AuthenticationPrincipal OidcUser user, HttpServletResponse response) throws IOException {
    	
    	System.out.println("user from user controller method="+user);
    	
    	ModelAndView mav = new ModelAndView();
        mav.addObject("user", user);
        mav.setViewName("user");
        System.out.println("Family Name = "+user.getUserInfo().getFamilyName());
        
        user.getAuthorities().forEach(x -> {
        	System.out.println(x.getAuthority());
        });
        return mav;
    }
}
