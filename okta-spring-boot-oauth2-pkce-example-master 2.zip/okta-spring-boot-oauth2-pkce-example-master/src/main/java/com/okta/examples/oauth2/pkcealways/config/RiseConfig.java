//package com.okta.examples.oauth2.pkcealways.config;
//
//import static org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter.DEFAULT_AUTHORIZATION_REQUEST_BASE_URI;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.oauth2.client.registration.ClientRegistration;
//import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
//import org.springframework.security.web.SecurityFilterChain;
//
//import com.okta.examples.oauth2.pkcealways.custom.CustomAuthorizationRequestResolver;
//import com.okta.spring.boot.oauth.Okta;
//
////@EnableWebSecurity
//@Configuration
//public class RiseConfig {
//
//	@Autowired
//	ClientRegistrationRepository clientRegistrationRepository;
//
//	@Bean
//	protected SecurityFilterChain configure(HttpSecurity http) throws Exception {
//
//		ClientRegistration cr = clientRegistrationRepository.findByRegistrationId("okta");
//		System.out.println(cr.getClientId());
//		System.out.println(cr.getClientSecret());
//		System.out.println(cr.getRedirectUri());
//		System.out.println(cr.getRegistrationId());
//		System.out.println(cr.getAuthorizationGrantType());
//		System.out.println(cr.getClientAuthenticationMethod());
//		System.out.println(cr.getProviderDetails());
//		System.out.println(cr.getScopes());
//		
//		
//		// @formatter:off
//		http
//			.csrf().disable().cors().and()
//			.authorizeRequests()
//			.antMatchers("/", "/img/**").permitAll()
//			.anyRequest().authenticated()
//			.and()
//			.oauth2ResourceServer().jwt();
//		
//		http.cors();
//		//Okta.configureResourceServer401ResponseBody(http);
//		
////		http
////			.oauth2Login()
////			.authorizationEndpoint()
////			.authorizationRequestResolver(new CustomAuthorizationRequestResolver(
////					clientRegistrationRepository,
////					DEFAULT_AUTHORIZATION_REQUEST_BASE_URI));
//		// @formatter:on
//
//		return http.build();
//	}
//	
//	
//}
