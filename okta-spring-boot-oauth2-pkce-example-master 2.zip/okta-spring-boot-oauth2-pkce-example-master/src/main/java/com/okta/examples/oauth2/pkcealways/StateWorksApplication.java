package com.okta.examples.oauth2.pkcealways;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StateWorksApplication {

	public static void main(String[] args) {
		SpringApplication.run(StateWorksApplication.class, args);
	}
}
