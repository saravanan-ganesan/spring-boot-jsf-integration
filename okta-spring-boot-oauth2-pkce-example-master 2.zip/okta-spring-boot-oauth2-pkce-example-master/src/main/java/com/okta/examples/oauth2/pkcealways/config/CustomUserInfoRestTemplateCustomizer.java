//package com.okta.examples.oauth2.pkcealways.config;
//
//import java.io.IOException;
//import java.net.InetSocketAddress;
//import java.net.Proxy;
//import java.net.Proxy.Type;
//import java.net.URI;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.autoconfigure.security.oauth2.resource.UserInfoRestTemplateCustomizer;
//import org.springframework.context.annotation.Bean;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.client.ClientHttpRequest;
//import org.springframework.http.client.ClientHttpRequestFactory;
//import org.springframework.http.client.SimpleClientHttpRequestFactory;
//import org.springframework.security.oauth2.client.OAuth2RestTemplate;
//
//public class CustomUserInfoRestTemplateCustomizer implements UserInfoRestTemplateCustomizer {
//    @Value("${http.custom.connect-timeout:500}")
//    private int connectTimeout;
//
//    @Value("${http.custom.read-timeout:30000}")
//    private int readTimeout;
//
//    @Value("${http.custom.proxy-host:}")
//    private String proxyHost;
//
//    @Value("${http.custom.proxy-port:-1}")
//    private int proxyPort;
//    
//    @Bean
//    public CustomUserInfoRestTemplateCustomizer customUserInfoRestTemplateCustomizer() {
//        return new CustomUserInfoRestTemplateCustomizer();
//    }
//
//    @Override
//    public void customize(OAuth2RestTemplate template) {
//        template.setRequestFactory(new ClientHttpRequestFactory() {
//            @Override
//            public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
//                SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
//                clientHttpRequestFactory.setConnectTimeout(connectTimeout);
//                clientHttpRequestFactory.setReadTimeout(readTimeout);
//                
//                if (proxyHost != null) {
//                    Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
//                    clientHttpRequestFactory.setProxy(proxy);
//                }
//                return clientHttpRequestFactory.createRequest(uri, httpMethod);
//            }
//        });
//    }
//}