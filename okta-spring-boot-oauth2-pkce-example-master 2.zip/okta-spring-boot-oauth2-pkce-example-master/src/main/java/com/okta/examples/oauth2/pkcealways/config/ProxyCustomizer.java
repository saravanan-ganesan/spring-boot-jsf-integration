package com.okta.examples.oauth2.pkcealways.config;


import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.protocol.HttpContext;
import org.springframework.boot.web.client.RestTemplateCustomizer;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class ProxyCustomizer implements RestTemplateCustomizer {

	@Override
	public void customize(RestTemplate restTemplate) {
		
		final String proxyUrl = "proxy.example.com";
		final int port = 3128;

		HttpHost proxy = new HttpHost(proxyUrl, port);
		HttpClient httpClient = HttpClientBuilder.create().setRoutePlanner(new DefaultProxyRoutePlanner(proxy) {
			
			@Override
			protected HttpHost determineProxy(HttpHost target, HttpRequest request, HttpContext context)
					throws HttpException {
				
				System.out.println("****************************************************");
				System.out.println(target.getHostName());
				System.out.println("****************************************************");
//				if (target.getHostName().equals("https://dev-38289286.okta.com/oauth2/default/v1/token")) {
//					return super.determineProxy(target, request, context);
//				}
//				return null;
				return super.determineProxy(target, request, context);
			}
		}).build();
		
		//httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory(httpClient));
		
		
	}

}