package com.okta.examples.oauth2.pkcealways.logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * 
 * This class is used to add log message on each and every method entry/exit
 */
@Aspect
@Component
@EnableAspectJAutoProxy
public class LoggerAspect {

	@Autowired
	private Environment environment;
	
	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	private final String PACKAGE_PATH = "execution(* com.fedex.rise..*.*(..)))";
	
	/*****************************************************************************
	 * This method is used to create point-cut for specific package
	 * 
	 * @return void
	 * ---------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ---------------------------------------------------------------------------
	 * 1.0		12/05/2022	5412859		Initial code
	 *****************************************************************************/
	@Pointcut(PACKAGE_PATH)
	public void appPointcut() {
		// Method is empty as this is just a point-cut, the implementations are in the advice.
	}
	
	
	/*****************************************************************************
	 * This method is used to add log message if any error occurs
	 * 
	 * @param joinPoint JointPoint object
	 * @param throwable object
	 * @return void
	 * ---------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ---------------------------------------------------------------------------
	 * 1.0		12/05/2022	5412859		Initial code
	 *****************************************************************************/
	@AfterThrowing(pointcut = "appPointcut()", throwing = "e")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {
		
		LOGGER.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), e.getCause() != null ? e.getCause() : "NULL");
		e.printStackTrace();
	}

	
	/*****************************************************************************
	 * This method is used to add log message for each method entry/exit
	 * 
	 * @param joinPoint JointPoint object
	 * @return Object
	 * ---------------------------------------------------------------------------
	 * Version	Date		Developer	Comments
	 * ---------------------------------------------------------------------------
	 * 1.0		12/05/2022	5412859		Initial code
	 *****************************************************************************/
	@Around("appPointcut()")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {

		
		Object result;
		
		System.out.println("Enter: " + joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName());

		try {
			result = joinPoint.proceed();

		} finally {
			
			System.out.println("Exit: " + joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName());
		}
		
		return result;
	}
	
	
}
