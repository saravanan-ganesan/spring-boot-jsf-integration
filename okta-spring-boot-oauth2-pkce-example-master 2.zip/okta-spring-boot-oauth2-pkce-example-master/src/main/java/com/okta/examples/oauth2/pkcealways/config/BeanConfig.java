//package com.okta.examples.oauth2.pkcealways.config;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import javax.annotation.PostConstruct;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
//import org.springframework.security.oauth2.client.registration.ClientRegistration;
//import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
//import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
//import org.springframework.security.oauth2.core.AuthorizationGrantType;
//import org.springframework.security.web.SecurityFilterChain;
//
//import com.okta.spring.boot.oauth.Okta;
//
//@Configuration
////@Order(Ordered.LOWEST_PRECEDENCE) 
//public class BeanConfig {
//
//	
//	@Autowired
//	ClientRegistrationRepository clientRegistrationRepository;
//
//	@Bean
//	protected SecurityFilterChain configure(HttpSecurity http) throws Exception {
//
//		ClientRegistration cr = clientRegistrationRepository.findByRegistrationId("okta");
//		System.out.println(cr.getClientId());
//		System.out.println(cr.getClientSecret());
//		System.out.println(cr.getRedirectUri());
//		System.out.println(cr.getRegistrationId());
//		System.out.println(cr.getAuthorizationGrantType());
//		System.out.println(cr.getClientAuthenticationMethod());
//		System.out.println(cr.getProviderDetails());
//		System.out.println(cr.getScopes());
//		
//		
//		// @formatter:off
//		http
//			.csrf().disable().cors().and()
//			.authorizeRequests()
//			.antMatchers("/", "/img/**").permitAll()
//			.anyRequest().authenticated()
//			.and()
//			.oauth2ResourceServer().jwt();
//		
//		http.cors();
//		Okta.configureResourceServer401ResponseBody(http);
//
//		return http.build();
//	}
//	
//	@PostConstruct
//	public void init() {
//		ClientRegistration cr = clientRegistrationRepository.findByRegistrationId("okta");
//		System.out.println(cr.getClientId());
//		System.out.println(cr.getClientSecret());
//		System.out.println(cr.getRedirectUri());
//		System.out.println(cr.getRegistrationId());
//		System.out.println(cr.getAuthorizationGrantType());
//		System.out.println(cr.getClientAuthenticationMethod());
//		System.out.println(cr.getProviderDetails().getAuthorizationUri());
//		System.out.println(cr.getProviderDetails().getIssuerUri());
//		System.out.println(cr.getProviderDetails().getJwkSetUri());
//		System.out.println(cr.getProviderDetails().getTokenUri());
//		System.out.println(cr.getProviderDetails().getUserInfoEndpoint());
//		System.out.println(cr.getScopes());
//	}
//	
//	//@Bean
//	//@Primary
//	public static ClientRegistrationRepository clientRepository() {
//
//		Map<String, Object> metadata = new HashMap<>();
//		
//		ClientRegistration oktaRegistration = CommonOAuth2Provider.OKTA.getBuilder("okta")
//				.clientId("0oa7n3tkp4Tk8sdhT5d7")
//				.clientSecret("S4p89zNgbcSEyt_kdvcPcf0QsFD3FX1d-jASEwrv")
//				.authorizationUri("https://dev-38289286.okta.com/oauth2/default/v1/authorize")
//				.authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
//				.issuerUri("https://dev-38289286.okta.com/oauth2/default")
//				.redirectUri("{baseUrl}/login/oauth2/code/okta")
//				.userInfoUri("https://dev-38289286.okta.com/oauth2/default/v1/userinfo")
//				.registrationId("okta")
//				.tokenUri("https://dev-38289286.okta.com/oauth2/default/v1/token")
//				.jwkSetUri("https://dev-38289286.okta.com/oauth2/default/v1/keys")
//				.providerConfigurationMetadata(metadata)
//				.build();
//
//
//		return new InMemoryClientRegistrationRepository(oktaRegistration);
//	}
//	
//}
